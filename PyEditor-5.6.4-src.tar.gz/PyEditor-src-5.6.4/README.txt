YHHYPy 5.6.4 源码备份（versionCode 87）

original/ 原始 Java + native + res + manifest + build.sh + tools + test + 文档
minified/ Java 压缩版（删注释/缩进/空行，单行），已 javac 验证；native 原样
不含 assets/libs/lib/build/dist/keystore。

相对 5.6.3/86 的变化（只改 Java 层，C++ 内核没动）：
- 分区记忆落盘：Prefs.setZoneState 改 commit()（同步）；每次保存先用
  App.writeRaw 写 files/zone-state.txt（不写时间戳、flush + FileDescriptor.sync）；
  恢复时优先读该文件，其次 SharedPreferences。
- 恢复容错：记录数 >6 只取前 6 条；形状坏退回网格但保留区数/类型/文件/光标；
  恢复成功后立刻回写当前真实界面。
- 一变就存：结构变化立刻存；焦点切换 / 区里换文件走 400ms 防抖 saveZoneStateSoon()。
- 单测不变：PaneTilingTest 27；native 90 + 91。

versionCode 87 可覆盖 5.6.3（86）。

重建：./build.sh；路径带中文，javac 前 export LC_ALL=C.UTF-8（build.sh 已内置）。
