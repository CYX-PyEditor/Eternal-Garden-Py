#include <cstdio>
#include <cstring>
#include "../native/engine.h"
using namespace pe;

static int pass = 0, fail = 0;

static U16 U(const char* s) {
    U16 u;
    for (; *s; s++) u += (char16_t)(unsigned char)*s;
    return u;
}

static bool has(const U16& src, int16_t id, int wantLine) {
    Doc d;
    d.setText(src);
    Prob* p = nullptr;
    int n = d.problems(true, p);
    for (int i = 0; i < n; i++) {
        if (p[i].id == id && (wantLine < 0 || (int)p[i].line == wantLine)) return true;
    }
    return false;
}

static void wantInvalid(const char* title, const char* src, int line = 0) {
    if (has(U(src), M_INVALID_TARGET, line)) {
        pass++;
        printf("OK   invalid  %s\n", title);
    } else {
        fail++;
        printf("FAIL invalid  %s\n", title);
    }
}

static void wantMissingRhs(const char* title, const char* src, int line = 0) {
    if (has(U(src), M_MISSING_RHS, line)) {
        pass++;
        printf("OK   no-rhs   %s\n", title);
    } else {
        fail++;
        printf("FAIL no-rhs   %s\n", title);
    }
}

static void wantClean(const char* title, const char* src) {
    bool a = has(U(src), M_INVALID_TARGET, -1);
    bool b = has(U(src), M_MISSING_RHS, -1);
    if (!a && !b) {
        pass++;
        printf("OK   clean    %s\n", title);
    } else {
        fail++;
        printf("FAIL clean    %s (%s%s)\n", title, a ? "invalid-target " : "", b ? "missing-rhs" : "");
    }
}

static bool hasIndentProblem(const U16& src) {
    Doc d;
    d.setText(src);
    Prob* p = nullptr;
    int n = d.problems(true, p);
    for (int i = 0; i < n; i++) {
        if (p[i].id == M_TAB_INDENT || p[i].id == M_INDENT_STEP) return true;
    }
    return false;
}

static void wantIndentClean(const char* title, const char* src) {
    if (!hasIndentProblem(U(src))) {
        pass++;
        printf("OK   indent-  %s\n", title);
    } else {
        fail++;
        printf("FAIL indent-  %s\n", title);
    }
}

static void wantIndentBad(const char* title, const char* src) {
    if (hasIndentProblem(U(src))) {
        pass++;
        printf("OK   indent+  %s\n", title);
    } else {
        fail++;
        printf("FAIL indent+  %s\n", title);
    }
}

int main() {
    // ---- 必须报错
    wantInvalid("字面量赋值 4=1", "4=1");
    wantInvalid("表达式赋值 x + 1 = 2", "x + 1 = 2");
    wantInvalid("函数调用赋值 f() = 1", "f() = 1");
    wantInvalid("if 里写了 =", "if x = 1:\n    pass\n");
    wantInvalid("while 里写了 =", "while x = 1:\n    pass\n");
    wantInvalid("None = 1", "None = 1");
    wantInvalid("True = 1", "True = 1");
    wantInvalid("列表字面量 [1] = [1]", "[1] = [1]");
    wantInvalid("元组 (1) = 1", "(1) = 1");
    wantInvalid("a, [1] = ...", "a, [1] = 1, 2");
    wantInvalid("[a, 1] = ...", "[a, 1] = 1, 2");
    wantInvalid("条件表达式赋值", "a if b else c = 1");
    wantInvalid("增强赋值 4 += 1", "4 += 1");
    wantInvalid("中间空元素 a,,b", "a,,b = 1, 2");
    wantInvalid("前导空元素 [,a]", "[,a] = 1");
    wantInvalid("空目标 = 1", "= 1");
    wantInvalid("集合字面量 {a} = 1", "{a} = 1");
    wantInvalid("调用后再调用 a[0]()", "a[0]() = 1");
    wantInvalid("type (X) = int", "type (X) = int");
    wantInvalid("第二行报错", "a = 1\n4 = 2\n", 1);

    // ---- 合法：不能误报
    wantClean("比较 4 == 1", "4 == 1");
    wantClean("普通赋值", "x = 1");
    wantClean("链式赋值", "x = y = 1");
    wantClean("元组解包", "a, b = 1, 2");
    wantClean("星号解包", "a, *b = 1, 2");
    wantClean("括号目标", "(a, b) = 1, 2");
    wantClean("方括号目标", "[a, b] = [1, 2]");
    wantClean("下标", "a[0] = 1");
    wantClean("切片", "a[1:2] = [3]");
    wantClean("self 属性", "self.x = 1");
    wantClean("属性+下标", "a.b[0] = 1");
    wantClean("调用后属性", "a().b = 1");
    wantClean("字符串下标", "\"abc\"[0] = \"x\"");
    wantClean("数字属性 1 .real", "1 .real = 5");
    wantClean("None.x", "None.x = 1");
    wantClean("True[0]", "True[0] = 1");
    wantClean("列表显示下标", "[a][0] = 1");
    wantClean("括号后属性", "(a).b = 1");
    wantClean("类型注解", "a: int = 1");
    wantClean("复杂注解", "d: dict[str, int] = {}");
    wantClean("3.12 类型别名", "type X = int");
    wantClean("变量名叫 type", "type = 1");
    wantClean("软关键字 match", "match = 1");
    wantClean("软关键字 case", "case = 2");
    wantClean("关键字参数 f(a=1)", "f(a=1)");
    wantClean("def 默认参数", "def f(x=1):\n    pass\n");
    wantClean("async def 默认参数", "async def f(a=1):\n    pass\n");
    wantClean("装饰器参数", "@deco(x=1)\ndef f():\n    pass\n");
    wantClean("lambda 默认参数", "x = lambda a=1: a");
    wantClean("lambda 无参", "x = lambda: 1");
    wantClean("三元表达式", "x = 1 if a == b else 2");
    wantClean("分号两条语句", "x = 1; y = 2");
    wantClean("反斜杠续行", "x = \\\n1");
    wantClean("多目标", "x[0], y = 1, 2");
    wantClean("尾随逗号", "a, = [1]");
    wantClean("多尾随逗号", "a, b, = 1, 2,");
    wantClean("星号目标", "*a, b = 1, 2");
    wantClean("括号尾随逗号", "(a,) = (1,)");
    wantClean("print = 1", "print = 1");
    wantClean("增强赋值", "x += 1");
    wantClean("下标增强赋值", "x[0] += 1");
    wantClean("字典合并赋值", "d |= {}");
    wantClean("海象运算符", "if (n := 1):\n    pass\n");
    wantClean("f-string 里的等号", "print(f\"{x=}\")");

    // ---- 合法：空目标 / 类型别名 / lambda 多个默认值 / 单行复合语句
    wantClean("空列表目标 [] = x", "[] = gen_b");
    wantClean("空元组目标 () = x", "() = gen_b");
    wantClean("类型别名带类型参数", "type TA1[B] = dict[A, B]");
    wantClean("类型别名带约束", "type Alias[T: int] = list[T]");
    wantClean("lambda 多个默认值", "g = lambda v=a, x=b, *, y=c, z=d: None");
    wantClean("属性 + lambda 默认值", "first.find_spec = lambda self, path=None: None");
    wantClean("单行 if 复合语句", "if o == '-e': func = encode");
    wantClean("单行 for 复合语句", "for i in range(3): x[i] = i");
    wantClean("单行 while 复合语句", "while True: x = 1");
    wantClean("单行 finally 复合语句", "finally: x = 1");
    wantClean("单行 with 复合语句", "with open('a') as f: s = f.read()");
    wantClean("反斜杠续行的链式赋值", "a0 = a1 = \\\n    None");
    wantClean("反斜杠续行的目标列表", "(name, version) \\\n    = platform.f()");
    wantInvalid("单行复合语句里的坏目标", "if x: 4 = 1");
    wantInvalid("空目标里的逗号 (,) = x", "(,) = x");

    // ---- 多行注释 / docstring 内的缩进不检查
    wantIndentClean("docstring 内奇数缩进",
                    "def f():\n    \"\"\"doc\n  two\n     three\n    \"\"\"\n    return 1\n");
    wantIndentClean("docstring 内 Tab 缩进",
                    "x = 1\n    '''\n\tbad tab\n  odd\n'''\ny = 2\n");
    wantIndentClean("docstring 内伪代码",
                    "x = 1\n\"\"\"\nif y\n    z\n\"\"\"\n");
    wantIndentBad("普通代码 2 空格缩进", "x = 1\n  y = 2\n");
    wantIndentBad("普通代码 Tab 缩进", "x = 1\n\ty = 2\n");

    // ---- 缺少右值
    wantMissingRhs("x = 结尾", "x =");
    wantMissingRhs("x = 后面只有注释", "x =  # todo");
    wantMissingRhs("链式最后缺右值", "a = b =");
    wantMissingRhs("缺右值在第二行", "y = 1\nx =\n", 1);
    wantClean("右侧是括号开的行", "x = (");
    wantClean("右侧是反斜杠续行", "x = \\");

    printf("\nCheckTest: pass=%d fail=%d\n", pass, fail);
    return fail > 0 ? 1 : 0;
}
