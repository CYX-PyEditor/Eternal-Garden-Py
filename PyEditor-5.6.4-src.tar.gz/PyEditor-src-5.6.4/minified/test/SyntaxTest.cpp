#include <cstdio>
#include <string>
#include "../native/engine.h"
using namespace pe;

static int pass = 0, fail = 0;

static U16 U(const std::string& s) {
    U16 u;
    for (unsigned char c : s) u += (char16_t)c;
    return u;
}

static bool has(const std::string& src, int16_t id) {
    Doc d;
    d.setText(U(src));
    Prob* p = nullptr;
    int n = d.problems(true, p);
    for (int i = 0; i < n; i++) if (p[i].id == id) return true;
    return false;
}

static void want(const char* title, const std::string& src, int16_t id) {
    if (has(src, id)) { pass++; printf("OK   %s\n", title); }
    else { fail++; printf("FAIL %s (want id %d)\n", title, id); }
}

static void clean(const char* title, const std::string& src) {
    static const int16_t bad[] = {12,13,14,15,16,17,18,19,20,21,22,23,24};
    for (int16_t id : bad) {
        if (has(src, id)) { fail++; printf("FAIL %s (unexpected id %d)\n", title, id); return; }
    }
    pass++; printf("OK   %s\n", title);
}

int main() {
    // 关键字 / 名字
    want("def 关键字名", "def return(): pass\n", M_BAD_DEF_NAME);
    want("class 关键字名", "class while: pass\n", M_BAD_DEF_NAME);
    clean("def match（软关键字）", "def match(): pass\n");
    clean("def print（内建名）", "def print(): pass\n");

    // 意外缩进
    want("顶格后意外缩进", "x = 1\n    y = 2\n", M_UNEXPECTED_INDENT);
    clean("正常块缩进", "if x:\n    y = 2\n");
    clean("正常 class/def", "class C:\n    def f(self):\n        return 1\n");
    clean("括号跨行的续行", "x = (1 +\n     2)\n");

    // 函数参数
    want("默认值在前", "def f(a=1, b): pass\n", M_BAD_PARAMS);
    want("参数重名", "def f(a, a): pass\n", M_BAD_PARAMS);
    clean("默认值在后", "def f(a, b=1): pass\n");
    clean("keyword-only 无默认", "def f(a=1, *, b): pass\n");
    clean("*args/**kw", "def f(a=1, *args, b, **kw): pass\n");
    clean("位置-only", "def f(a, /, b, *, c=1): pass\n");
    clean("参数名 match", "def f(match, case=None): pass\n");
    clean("lambda 参数名", "def f(x=lambda a, b=1: a): pass\n");

    // 调用参数
    want("关键字后位置参数", "f(a=1, 2)\n", M_BAD_CALL_ARGS);
    want("** 后位置参数", "f(**d, 1)\n", M_BAD_CALL_ARGS);
    clean("位置参数在前", "f(1, a=2)\n");
    clean("关键字后 *a", "f(a=1, *b)\n");
    clean("** 后关键字", "f(**d, a=1)\n");
    clean("lambda 参数逗号", "f(key=lambda x, y: x)\n");
    clean("嵌套调用", "f(g(a=1), 2)\n");

    // import
    want("import 里混 from", "import os from sys\n", M_BAD_IMPORT);
    want("from import", "from import x\n", M_BAD_IMPORT);
    want("import 没名字", "import\n", M_BAD_IMPORT);
    clean("正常 import", "import os, sys\n");
    clean("正常 from", "from os import path\n");
    clean("分号两条", "import os; from sys import path\n");

    // 数字
    want("前导零", "x = 012\n", M_BAD_NUMBER);
    want("两个点", "x = 1.2.3\n", M_BAD_NUMBER);
    want("空 hex", "x = 0x\n", M_BAD_NUMBER);
    want("非法二进制", "x = 0b102\n", M_BAD_NUMBER);
    want("非法八进制", "x = 0o8\n", M_BAD_NUMBER);
    want("下划线结尾", "x = 1_\n", M_BAD_NUMBER);
    want("指数没数字", "x = 1e\n", M_BAD_NUMBER);
    clean("零", "x = 0\n");
    clean("多个零", "x = 000\n");
    clean("浮点", "x = 0.5\n");
    clean("hex 下划线", "x = 0x_FF\n");
    clean("二进制", "x = 0b_10\n");
    clean("八进制", "x = 0o_7\n");
    clean("千位下划线", "x = 1_000\n");
    clean("1.", "x = 1.\n");
    clean("1.e5", "x = 1.e5\n");
    clean("虚数", "x = 10j\n");
    clean("数字属性", "x = 1.2.real\n");

    // 模块级 await / yield
    want("模块 await", "await f()\n", M_SCOPE);
    want("模块 yield", "yield 1\n", M_SCOPE);
    clean("async def await", "async def f():\n    await g()\n");
    clean("def yield", "def f():\n    yield 1\n");
    clean("单行 async def", "async def f(): yield\n");

    // 星号
    want("星号列表右值", "x = *[1, 2]\n", M_BAD_STAR);
    want("双星右值", "y = **{'a': 1}\n", M_BAD_STAR);
    clean("星号元组", "x = *a,\n");
    clean("列表内星号", "x = [*a]\n");
    clean("调用双星", "f(**d)\n");

    // 子句宿主
    want("孤立 else", "else: pass\n", M_ORPHAN_CLAUSE);
    want("孤立 elif", "elif x: pass\n", M_ORPHAN_CLAUSE);
    want("孤立 except", "except E: pass\n", M_ORPHAN_CLAUSE);
    want("孤立 finally", "finally: pass\n", M_ORPHAN_CLAUSE);
    want("孤立 case", "case 1: pass\n", M_ORPHAN_CLAUSE);
    clean("if/elif/else", "if a:\n    pass\nelif b:\n    pass\nelse:\n    pass\n");
    clean("try 全部", "try:\n    pass\nexcept E:\n    pass\nelse:\n    pass\nfinally:\n    pass\n");
    clean("for else", "for x in y:\n    pass\nelse:\n    pass\n");
    clean("while else", "while x:\n    pass\nelse:\n    pass\n");
    clean("match/case", "match x:\n    case 1:\n        pass\n    case _:\n        pass\n");
    clean("try/finally", "try:\n    pass\nfinally:\n    pass\n");
    clean("多行 if + else", "if (a and\n        b):\n    pass\nelse:\n    pass\n");

    // type 语句
    want("type 缺等号", "type Alias\n", M_TYPE_STMT);
    want("type 泛型缺等号", "type Alias[T]\n", M_TYPE_STMT);
    clean("type 别名", "type Alias = int\n");
    clean("type 变量", "type = 1\n");

    // f-string
    want("f 空表达式", "x = f\"{}\"\n", M_BAD_FSTRING);
    want("f 没闭合花括号", "x = f\"{y\"\n", M_BAD_FSTRING);
    want("f 非法转换", "x = f\"{y!z}\"\n", M_BAD_FSTRING);
    clean("f 正常", "x = f\"{y}\"\n");
    clean("f 转换", "x = f\"{y!r}\"\n");
    clean("f 格式说明", "x = f\"{y:>10}\"\n");
    clean("f 格式说明感叹号", "x = f\"{3.14:!<10.10}\"\n");
    clean("f 转义花括号", "x = f\"{{}}\"\n");
    clean("f 调试等号", "x = f\"{y=}\"\n");
    clean("f 嵌套格式", "x = f\"{y:{w}}\"\n");
    clean("普通字符串花括号", "x = \"{y}\"\n");

    // except*
    want("except* 缺类型", "try: pass\nexcept* : pass\n", M_EXCEPT_STAR);
    clean("except* 正常", "try: pass\nexcept* ValueError: pass\n");
    clean("裸 except", "try: pass\nexcept: pass\n");

    // 未闭合字符串
    want("双引号未闭合", "x = \"hello\n", M_UNTERM_STRING_ONE);
    want("单引号未闭合", "x = 'hello\n", M_UNTERM_STRING_ONE);
    clean("正常字符串", "x = \"hello\"\n");
    clean("docstring", "def f():\n    \"\"\"doc\n  odd\n\ttab\n    \"\"\"\n");

    printf("\nSyntaxTest: pass=%d fail=%d\n", pass, fail);
    return fail ? 1 : 0;
}
