package com.yhhy.pyeditor;

import java.util.ArrayList;

/** SnippetTemplate / AssignScan 的 JVM 单测（不进 APK）。 */
public class SnippetAssignTest {
    static int pass = 0, fail = 0;

    static void check(String title, boolean ok, String detail) {
        if (ok) {
            pass++;
            System.out.println("OK   " + title);
        } else {
            fail++;
            System.out.println("FAIL " + title + "  " + detail);
        }
    }

    static String offs(int[] a) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < a.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(a[i]);
        }
        return sb.append(']').toString();
    }

    static void pv(String title, String raw, String expect) {
        String got = SnippetTemplate.preview(raw);
        check(title, got.equals(expect), "got=" + got.replace("\n", "\\n"));
    }

    static void tpl(String title, String raw, String text, int[] offs) {
        SnippetTemplate t = SnippetTemplate.parse(raw);
        check(title, t.text.equals(text) && java.util.Arrays.equals(t.offsets, offs),
                "text=" + t.text.replace("\n", "\\n") + " offs=" + offs(t.offsets));
    }

    static void calls(String title, String[] src, String expect) {
        ArrayList<CallScan.Block> got = CallScan.scan(src);
        StringBuilder sb = new StringBuilder();
        for (CallScan.Block b : got) {
            if (sb.length() > 0) sb.append(';');
            sb.append(b.start).append('-').append(b.end).append(':').append(b.summary);
        }
        check(title, sb.toString().equals(expect), "got=" + sb);
    }

    static void assign(String title, String[] src, String expect) {
        ArrayList<AssignScan.Block> got = AssignScan.scan(src);
        StringBuilder sb = new StringBuilder();
        for (AssignScan.Block b : got) {
            if (sb.length() > 0) sb.append(';');
            sb.append(b.start).append('-').append(b.end).append(':').append(b.summary);
        }
        check(title, sb.toString().equals(expect), "got=" + sb);
    }

    public static void main(String[] a) {
        tpl("单个 ${cursor}", "while True:\n    ${cursor}\n", "while True:\n    \n", new int[]{16});
        tpl("多个编号 + 尾部默认", "def ${cursor1}(${cursor2}):\n    ${cursor}",
                "def ():\n    ", new int[]{12, 4, 5});
        tpl("默认位置先跳", "${cursor}x${cursor1}y${cursor2}z", "xyz", new int[]{0, 1, 2});
        tpl("编号顺序（不按出现顺序）", "${cursor2}x${cursor1}y", "xy", new int[]{1, 0});
        tpl("旧版 \\u0001", "\u0001a\u0001", "a", new int[]{0, 1});
        tpl("无占位符", "print(1)", "print(1)", new int[]{});
        tpl("非法占位符当普通文本", "${cursorX}", "${cursorX}", new int[]{});
        pv("预览：单个", "while True:\n    ${cursor}\n", "while True:\n    |\n");
        pv("预览：两个", "${cursor2}x${cursor1}", "|x|");
        pv("预览：旧标记", "\u0001a\u0001", "|a|");
        pv("预览：非法占位符保留", "a ${cursorX} b", "a ${cursorX} b");

        assign("示例 5 个值", new String[]{"a=b=c=0", "d=0", "e=0"}, "0-2:5 Value = int");
        assign("空行/注释不阻挡", new String[]{"x = 1", "# c", "", "y = 2"}, "0-3:2 Value = int");
        assign("两种类型", new String[]{"a=1", "b='s'"}, "0-1:2 Value = int|str");
        assign("类型标注", new String[]{"x: int = 0", "y: int = 1"}, "0-1:2 Value = int");
        assign("行尾注释", new String[]{"a = 1  # c", "b = 2"}, "0-1:2 Value = int");
        assign("RHS 是调用", new String[]{"a = foo()", "b = bar()"}, "0-1:2 Value = Any");
        assign("单行链式不折", new String[]{"a=b=0"}, "");
        assign("if 语句不参与", new String[]{"if x == 0:", "    y = 1"}, "");
        assign("复合赋值不参与", new String[]{"a += 1", "b = 2"}, "");
        assign("集合 RHS 交给集合折叠", new String[]{"a = [1,2]", "b = 3"}, "");
        assign("字典 RHS 交给集合折叠", new String[]{"a = {'k': 1}", "b = 3"}, "");
        assign("三元组解包", new String[]{"a, b = 1, 2", "c, d = 3, 4"}, "0-1:4 Value = Any");

        calls("示例 print 三次", new String[]{"print(a,b,c)", "print(\"gbjj\")", "print(bool)"},
                "0-2:print() * 3");
        calls("空行/注释间隔", new String[]{"print(1)", "# c", "", "print(2)"}, "0-3:print() * 2");
        calls("不同函数断开", new String[]{"print(1)", "log(2)", "print(3)"}, "");
        calls("赋值不算调用", new String[]{"x = f()", "y = f()"}, "");
        calls("def 行不算", new String[]{"def f():", "    pass"}, "");
        calls("行尾还有语句不算", new String[]{"print(1); print(2)", "print(3)"}, "");
        calls("括号/字符串嵌套", new String[]{"print(\")\")", "print(a(b))"}, "0-1:print() * 2");
        calls("带点的方法名", new String[]{"log.info(1)", "log.info(2)"}, "0-1:log.info() * 2");

        System.out.println("\npass=" + pass + " fail=" + fail);
        if (fail > 0) System.exit(1);
    }
}
