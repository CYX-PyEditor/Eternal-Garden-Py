package com.yhhy.pyeditor;

import java.util.ArrayList;

/** DocOutline（MiniMap 大纲扫描）的 JVM 单测（不进 APK）。 */
public class MiniMapTest {
    static int pass = 0, fail = 0;

    static String[] L(String... l) {
        return l;
    }

    static void outline(String title, String[] src, String expect) {
        ArrayList<DocOutline.Item> got = DocOutline.scan(src);
        StringBuilder sb = new StringBuilder();
        for (DocOutline.Item it : got) {
            if (sb.length() > 0) sb.append(';');
            sb.append(it.kind).append(':').append(it.name)
                    .append('@').append(it.line).append('-').append(it.endLine);
        }
        if (sb.toString().equals(expect)) {
            pass++;
            System.out.println("OK   " + title);
        } else {
            fail++;
            System.out.println("FAIL " + title + "\n  got  " + sb + "\n  want " + expect);
        }
    }

    static void size(String title, String[] src, int want) {
        int got = DocOutline.scan(src).size();
        if (got == want) {
            pass++;
            System.out.println("OK   " + title);
        } else {
            fail++;
            System.out.println("FAIL " + title + " got=" + got + " want=" + want);
        }
    }

    public static void main(String[] a) {
        outline("顶层函数 + 类 + 方法",
                L("def a():", "    x = 1", "", "# c",
                        "class B:", "    def m1(self):", "        pass", "",
                        "    def m2(self):", "        pass",
                        "def c():", "    return 1"),
                "1:a@0-1;0:B@4-9;2:m1@5-6;2:m2@8-9;1:c@10-11");

        outline("async def + 装饰器 + 多行签名",
                L("@deco", "async def fetch(", "        url,", "        timeout=1):",
                        "    return url", "", "@deco", "class C:"),
                "1:fetch@1-4;0:C@7-7");

        outline("三引号里的 def 不算",
                L("def real():", "    s = '''", "def fake():", "    pass",
                        "'''", "    return s"),
                "1:real@0-5");

        outline("注释里的定义不算",
                L("# def fake():", "   # class Ghost:", "class Real:", "    pass"),
                "0:Real@2-3");

        outline("不是定义行",
                L("classify = 1", "default = 2", "def", "class", "x.def = 3"),
                "");

        outline("函数里的嵌套函数算方法",
                L("class C:", "    def m(self):", "        def inner():",
                        "            pass", "        return inner"),
                "0:C@0-4;2:m@1-4;2:inner@2-3");

        outline("模块级 if 里的 def 不进大纲",
                L("if __name__ == '__main__':", "    def helper():", "        pass"),
                "");

        outline("块内空行 / 顶层注释不断块",
                L("class C:", "    x = 1", "# note", "", "    def m(self):",
                        "        pass"),
                "0:C@0-5;2:m@4-5");

        outline("单行 def",
                L("def f(): pass", "def g(): pass"),
                "1:f@0-0;1:g@1-1");

        outline("制表符缩进",
                L("class T:", "\tdef m(self):", "\t\tpass", "def after():",
                        "    pass"),
                "0:T@0-2;2:m@1-2;1:after@3-4");

        outline("空文件", L(""), "");
        size("空数组", new String[0], 0);

        String[] many = new String[DocOutline.MAX_ITEMS + 60];
        for (int i = 0; i < many.length; i++) many[i] = "def f" + i + "():";
        size("超大文件截断到 MAX_ITEMS", many, DocOutline.MAX_ITEMS);

        System.out.println("\nDocOutline: pass=" + pass + " fail=" + fail);
        if (fail > 0) System.exit(1);
    }
}
