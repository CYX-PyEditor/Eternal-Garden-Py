// Python tokenizer + symbol extraction (pure C++, no Android deps).
#include "engine.h"

#include <cstring>
#include <string>

namespace pe {

// ---------------------------------------------------------------- char utils
static inline bool isSpace16(char16_t c) {
    return c == u' ' || c == u'\t' || c == u'\r' || c == u'\f' || c == u'\v';
}
static inline bool isDigit16(char16_t c) { return c >= u'0' && c <= u'9'; }
static inline bool isHex16(char16_t c) {
    return isDigit16(c) || (c >= u'a' && c <= u'f') || (c >= u'A' && c <= u'F');
}
static inline bool isAlpha16(char16_t c) {
    return (c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z') || c == u'_';
}
static inline bool isIdentStart(char16_t c) { return isAlpha16(c) || c >= 0x80; }
static inline bool isIdentCont(char16_t c) { return isAlpha16(c) || isDigit16(c) || c >= 0x80; }
static inline char16_t lower16(char16_t c) {
    return (c >= u'A' && c <= u'Z') ? (char16_t)(c - u'A' + u'a') : c;
}

static U16 asciiU16(const char* a) {
    U16 t;
    for (; *a; a++) t += (char16_t)*a;
    return t;
}

// ---------------------------------------------------------------- word lists
static const char* kKeywords[] = {
    "and", "as", "assert", "async", "await", "break", "class", "continue",
    "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
    "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass",
    "raise", "return", "try", "while", "with", "yield", "match", "case",
    nullptr};

static const char* kConstNames[] = {"False", "None", "True", nullptr};

static const char* kBuiltins[] = {
    "abs", "aiter", "all", "anext", "any", "ascii", "bin", "bool", "breakpoint",
    "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex",
    "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter",
    "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash",
    "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter",
    "len", "list", "locals", "map", "max", "memoryview", "min", "next",
    "object", "oct", "open", "ord", "pow", "print", "property", "range",
    "repr", "reversed", "round", "set", "setattr", "slice", "sorted",
    "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip",
    "__import__", "Exception", "BaseException", "ValueError", "TypeError",
    "KeyError", "IndexError", "AttributeError", "RuntimeError", "ImportError",
    "OSError", "IOError", "FileNotFoundError", "ZeroDivisionError",
    "StopIteration", "SystemExit", "NotImplementedError", "AssertionError",
    "NameError", "UnboundLocalError", "OverflowError", "PermissionError",
    "TimeoutError", "UnicodeDecodeError", "UnicodeEncodeError",
    "RecursionError", "GeneratorExit", "KeyboardInterrupt", "Warning",
    "DeprecationWarning", nullptr};

static const std::unordered_set<U16>& kwSet() {
    static const std::unordered_set<U16>* s = [] {
        auto* p = new std::unordered_set<U16>();
        for (int i = 0; kKeywords[i]; i++) p->insert(asciiU16(kKeywords[i]));
        return p;
    }();
    return *s;
}
static const std::unordered_set<U16>& constSet() {
    static const std::unordered_set<U16>* s = [] {
        auto* p = new std::unordered_set<U16>();
        for (int i = 0; kConstNames[i]; i++) p->insert(asciiU16(kConstNames[i]));
        return p;
    }();
    return *s;
}
static const std::unordered_set<U16>& builtinSet() {
    static const std::unordered_set<U16>* s = [] {
        auto* p = new std::unordered_set<U16>();
        for (int i = 0; kBuiltins[i]; i++) p->insert(asciiU16(kBuiltins[i]));
        return p;
    }();
    return *s;
}

static std::vector<U16> toVec(const char* const* arr) {
    std::vector<U16> v;
    for (int i = 0; arr[i]; i++) v.push_back(asciiU16(arr[i]));
    return v;
}
const std::vector<U16>& allKeywords() { static std::vector<U16> v = toVec(kKeywords); return v; }
const std::vector<U16>& allConsts() { static std::vector<U16> v = toVec(kConstNames); return v; }
const std::vector<U16>& allBuiltins() { static std::vector<U16> v = toVec(kBuiltins); return v; }

const std::vector<U16>& allSnippets() {
    static std::vector<U16> v = [] {
        const char* names[] = {"while", "try", "for", "def", "class", "if", "main",
                               "elif", "else", "tryf", "trye", "with", "match",
                               "async", "lambda", "comp", "dcomp", "decor", "prop",
                               "init", "fori", nullptr};
        std::vector<U16> out;
        for (int i = 0; names[i]; i++) out.push_back(asciiU16(names[i]));
        return out;
    }();
    return v;
}

bool isKeyword(const U16& s) { return kwSet().count(s) > 0; }
bool isBuiltin(const U16& s) { return builtinSet().count(s) > 0; }
bool isConstName(const U16& s) { return constSet().count(s) > 0; }

// ---------------------------------------------------------------- helpers
static U16 tokText(const U16& s, const Tok& t) { return s.substr(t.start, t.end - t.start); }

static bool isStrPrefix(const U16& w) {
    static const char* kP[] = {"r", "b", "u", "f", "rb", "br", "fr", "rf", "ur", "ru", nullptr};
    for (int i = 0; kP[i]; i++) {
        size_t n = strlen(kP[i]);
        if (w.size() != n) continue;
        bool ok = true;
        for (size_t j = 0; j < n; j++) if (lower16(w[j]) != (char16_t)kP[i][j]) { ok = false; break; }
        if (ok) return true;
    }
    return false;
}

// scan one string literal starting at quoteIdx; returns end index, sets closed
static size_t scanString(const U16& s, size_t quoteIdx, char16_t q, bool triple, bool& closed) {
    const size_t n = s.size();
    size_t j = quoteIdx + (triple ? 3 : 1);
    closed = false;
    while (j < n) {
        if (s[j] == u'\\') { j += 2; continue; }
        if (triple) {
            if (j + 2 < n && s[j] == q && s[j + 1] == q && s[j + 2] == q) {
                closed = true;
                return j + 3;
            }
            j++;
        } else {
            if (s[j] == q) { closed = true; return j + 1; }
            j++;
        }
    }
    return n > quoteIdx ? n : quoteIdx;
}

static void addSym(std::vector<Sym>& syms, const U16& name, uint8_t kind, int32_t line) {
    if (name.empty()) return;
    syms.push_back(Sym{name, kind, (u32)line});
}

// second pass: pull assignment / import / loop target names out of the token list
static void postScanSymbols(const U16& s, const std::vector<Tok>& toks,
                            std::vector<Sym>& syms, int32_t lineNo) {
    const int n = (int)toks.size();
    if (n == 0) return;

    // attributes: IDENT "." IDENT
    for (int i = 1; i < n; i++) {
        if (toks[i].type != T_TEXT) continue;
        if (toks[i - 1].type != T_OPERATOR) continue;
        if (tokText(s, toks[i - 1]) != u".") continue;
        addSym(syms, tokText(s, toks[i]), SK_ATTR, lineNo);
    }

    for (int i = 0; i < n; i++) {
        if (toks[i].type != T_KEYWORD) continue;
        U16 kw = tokText(s, toks[i]);
        if (kw == u"import" || kw == u"from") {
            for (int j = i + 1; j < n; j++) {
                if (toks[j].type == T_KEYWORD && tokText(s, toks[j]) == u"as") {
                    if (j + 1 < n && toks[j + 1].type == T_TEXT) addSym(syms, tokText(s, toks[j + 1]), SK_VAR, lineNo);
                    j++;
                    continue;
                }
                if (toks[j].type == T_TEXT) {
                    // skip dotted path inner parts: only record the head
                    if (j + 1 < n && toks[j + 1].type == T_OPERATOR && tokText(s, toks[j + 1]) == u".") {
                        addSym(syms, tokText(s, toks[j]), SK_MODULE, lineNo);
                        j++;
                        while (j + 1 < n && toks[j + 1].type == T_OPERATOR && tokText(s, toks[j + 1]) == u".") {
                            j += 2;
                        }
                        continue;
                    }
                    addSym(syms, tokText(s, toks[j]), SK_MODULE, lineNo);
                }
            }
        } else if (kw == u"for") {
            for (int j = i + 1; j < n; j++) {
                if (toks[j].type == T_KEYWORD) break;
                if (toks[j].type == T_TEXT) addSym(syms, tokText(s, toks[j]), SK_VAR, lineNo);
            }
        } else if (kw == u"as") {
            if (i + 1 < n && toks[i + 1].type == T_TEXT) addSym(syms, tokText(s, toks[i + 1]), SK_VAR, lineNo);
        } else if (kw == u"global" || kw == u"nonlocal") {
            for (int j = i + 1; j < n; j++) {
                if (toks[j].type == T_TEXT) addSym(syms, tokText(s, toks[j]), SK_VAR, lineNo);
            }
        }
    }

    // assignment LHS at bracket depth 0
    int depth = 0;
    int assignIdx = -1;
    for (int i = 0; i < n && assignIdx < 0; i++) {
        const Tok& t = toks[i];
        if (t.type != T_OPERATOR) continue;
        U16 op = tokText(s, t);
        if (op.size() == 1 && (op[0] == u'(' || op[0] == u'[' || op[0] == u'{')) { depth++; continue; }
        if (op.size() == 1 && (op[0] == u')' || op[0] == u']' || op[0] == u'}')) { depth--; continue; }
        if (depth != 0) continue;
        if (op == u"=" || op == u"+=" || op == u"-=" || op == u"*=" || op == u"/=" ||
            op == u"//=" || op == u"%=" || op == u"**=" || op == u"&=" || op == u"|=" ||
            op == u"^=" || op == u">>=" || op == u"<<=") {
            assignIdx = i;
        }
    }
    if (assignIdx > 0) {
        for (int t = 0; t < assignIdx; t++) {
            if (toks[t].type == T_KEYWORD) break;
            if (toks[t].type == T_TEXT) addSym(syms, tokText(s, toks[t]), SK_VAR, lineNo);
            else if (toks[t].type == T_OPERATOR) {
                U16 op = tokText(s, toks[t]);
                if (op == u",") continue;
                if (op == u"[" || op == u"]" || op == u"(" || op == u")") continue;
                break;
            }
        }
    }
}

// ---------------------------------------------------------------- tokenizer
static const char16_t* kOps[] = {
    u"**=", u"//=", u">>=", u"<<=", u"...", u"->", u":=", u"**", u"//", u"==",
    u"!=", u"<=", u">=", u"+=", u"-=", u"*=", u"/=", u"%=", u"&=", u"|=", u"^=",
    u"<<", u">>", u"@=", nullptr};

void tokenizeLine(const U16& s, uint8_t& strState, int32_t& depth,
                  std::vector<Tok>& toks, std::vector<Sym>& syms, int32_t lineNo) {
    const size_t n = s.size();
    size_t i = 0;
    int expectName = 0;          // 1 = after def, 2 = after class
    bool pendingDefSig = false;  // saw def, waiting for '('
    bool inParams = false;
    int32_t paramDepth = 0;
    bool firstTok = true;

    while (i < n) {
        if (strState != 0) {
            char16_t q = (strState == 1) ? u'"' : u'\'';
            size_t j = i;
            bool closed = false;
            size_t end = n;
            while (j + 2 < n) {
                if (s[j] == u'\\') { j += 2; continue; }   // 三引号内的 \" / \' 不算闭合
                if (s[j] == q && s[j + 1] == q && s[j + 2] == q) { end = j + 3; closed = true; break; }
                j++;
            }
            toks.push_back(Tok{(u32)i, (u32)end, T_STRING});
            i = end;
            if (closed) strState = 0;
            continue;
        }

        char16_t c = s[i];
        if (isSpace16(c)) { i++; continue; }
        if (c == u'#') {
            toks.push_back(Tok{(u32)i, (u32)n, T_COMMENT});
            i = n;
            break;
        }
        if (c == u'"' || c == u'\'') {
            bool triple = (i + 2 < n && s[i + 1] == c && s[i + 2] == c);
            bool closed = false;
            size_t end = scanString(s, i, c, triple, closed);
            if (!closed && triple) strState = (c == u'"') ? 1 : 2;
            toks.push_back(Tok{(u32)i, (u32)end, T_STRING});
            i = end;
            firstTok = false;
            continue;
        }

        if (isIdentStart(c)) {
            size_t j = i;
            while (j < n && isIdentCont(s[j])) j++;
            U16 word = s.substr(i, j - i);

            // string prefix: rb"..." / f'...'
            if (j < n && (s[j] == u'"' || s[j] == u'\'') && isStrPrefix(word)) {
                char16_t q = s[j];
                bool triple = (j + 2 < n && s[j + 1] == q && s[j + 2] == q);
                bool closed = false;
                size_t end = scanString(s, j, q, triple, closed);
                if (!closed && triple) strState = (q == u'"') ? 1 : 2;
                toks.push_back(Tok{(u32)i, (u32)end, T_STRING});
                i = end;
                firstTok = false;
                continue;
            }

            uint8_t type = T_TEXT;
            if (expectName == 1) {
                type = T_DEF;
                addSym(syms, word, SK_FUNC, lineNo);
                expectName = 0;
            } else if (expectName == 2) {
                type = T_CLASS;
                addSym(syms, word, SK_CLASS, lineNo);
                expectName = 0;
            } else if (isConstName(word)) {
                type = T_CONST;
            } else if (isKeyword(word)) {
                type = T_KEYWORD;
                if (word == u"def") { expectName = 1; pendingDefSig = true; }
                else if (word == u"class") { expectName = 2; }
            } else if (word == u"self" || word == u"cls") {
                type = T_SELF;
            } else if (isBuiltin(word)) {
                type = T_BUILTIN;
            } else if (inParams && depth == paramDepth) {
                type = T_PARAM;
                addSym(syms, word, SK_PARAM, lineNo);
            }
            toks.push_back(Tok{(u32)i, (u32)j, type});
            i = j;
            firstTok = false;
            continue;
        }

        if (isDigit16(c) || (c == u'.' && i + 1 < n && isDigit16(s[i + 1]))) {
            size_t j = i;
            if (c == u'0' && i + 1 < n && (s[i + 1] == u'x' || s[i + 1] == u'X')) {
                j = i + 2;
                while (j < n && (isHex16(s[j]) || s[j] == u'_')) j++;
            } else if (c == u'0' && i + 1 < n && (s[i + 1] == u'b' || s[i + 1] == u'B')) {
                j = i + 2;
                while (j < n && (s[j] == u'0' || s[j] == u'1' || s[j] == u'_')) j++;
            } else if (c == u'0' && i + 1 < n && (s[i + 1] == u'o' || s[i + 1] == u'O')) {
                j = i + 2;
                while (j < n && ((s[j] >= u'0' && s[j] <= u'7') || s[j] == u'_')) j++;
            } else {
                while (j < n && (isDigit16(s[j]) || s[j] == u'_')) j++;
                if (j < n && s[j] == u'.') { j++; while (j < n && (isDigit16(s[j]) || s[j] == u'_')) j++; }
                if (j < n && (s[j] == u'e' || s[j] == u'E')) {
                    j++;
                    if (j < n && (s[j] == u'+' || s[j] == u'-')) j++;
                    while (j < n && isDigit16(s[j])) j++;
                }
            }
            if (j < n && (s[j] == u'j' || s[j] == u'J')) j++;
            toks.push_back(Tok{(u32)i, (u32)j, T_NUMBER});
            i = j;
            firstTok = false;
            continue;
        }

        if (c == u'@' && firstTok) {
            size_t j = i + 1;
            size_t end = j;
            while (j < n && (isIdentCont(s[j]) || s[j] == u'.')) { j++; end = j; }
            toks.push_back(Tok{(u32)i, (u32)(end > i + 1 ? end : i + 1), T_DECORATOR});
            i = end > i + 1 ? end : i + 1;
            firstTok = false;
            continue;
        }

        if (c == u'(' || c == u'[' || c == u'{') {
            depth++;
            if (c == u'(' && pendingDefSig) {
                inParams = true;
                paramDepth = depth;
                pendingDefSig = false;
            }
            toks.push_back(Tok{(u32)i, (u32)(i + 1), T_OPERATOR});
            i++;
            firstTok = false;
            continue;
        }
        if (c == u')' || c == u']' || c == u'}') {
            depth--;
            if (inParams && depth < paramDepth) inParams = false;
            toks.push_back(Tok{(u32)i, (u32)(i + 1), T_OPERATOR});
            i++;
            firstTok = false;
            continue;
        }

        bool matched = false;
        for (int k = 0; kOps[k]; k++) {
            size_t L = std::char_traits<char16_t>::length(kOps[k]);
            if (i + L > n) continue;
            bool ok = true;
            for (size_t t = 0; t < L; t++) {
                if (s[i + t] != kOps[k][t]) { ok = false; break; }
            }
            if (!ok) continue;
            toks.push_back(Tok{(u32)i, (u32)(i + L), T_OPERATOR});
            i += L;
            matched = true;
            break;
        }
        if (matched) { firstTok = false; continue; }

        toks.push_back(Tok{(u32)i, (u32)(i + 1), T_OPERATOR});
        i++;
        firstTok = false;
    }

    postScanSymbols(s, toks, syms, lineNo);
}

}  // namespace pe
