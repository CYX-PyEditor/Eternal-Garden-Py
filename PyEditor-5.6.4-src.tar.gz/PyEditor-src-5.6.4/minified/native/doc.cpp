// Document model: buffer, editing ops, undo, syntax check, completion, runs.
#include "engine.h"
#include <chrono>
#include <algorithm>

#include <algorithm>
#include <cstring>

namespace pe {

static inline bool isDigit16(char16_t c) { return c >= u'0' && c <= u'9'; }
static inline bool isAlpha16(char16_t c) {
    return (c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z') || c == u'_';
}
static inline bool isIdentCont(char16_t c) { return isAlpha16(c) || isDigit16(c) || c >= 0x80; }
static inline bool surIsHigh(char16_t c) { return c >= 0xD800 && c <= 0xDBFF; }
static inline bool surIsLow(char16_t c) { return c >= 0xDC00 && c <= 0xDFFF; }

static U16 tokTextOf(const U16& s, const Tok& t) { return s.substr(t.start, t.end - t.start); }

static bool endsWithBackslash(const U16& L) {
    int k = (int)L.size() - 1;
    while (k >= 0 && (L[k] == u' ' || L[k] == u'\t')) k--;
    return k >= 0 && L[k] == u'\\';
}

static bool isBlockHeaderKw(const U16& w) {
    return w == u"def" || w == u"class" || w == u"if" || w == u"elif" || w == u"else" ||
           w == u"for" || w == u"while" || w == u"try" || w == u"except" ||
           w == u"finally" || w == u"with" || w == u"match" || w == u"case";
}

Doc::Doc() {
    lines_.emplace_back();
    meta_.emplace_back();
    maxLen_ = 0;
}

// ------------------------------------------------------------------ document
void Doc::setText(const U16& text) {
    lines_.clear();
    meta_.clear();
    U16 cur;
    cur.reserve(128);
    for (char16_t c : text) {
        if (c == u'\r') continue;
        if (c == u'\n') {
            lines_.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    lines_.push_back(cur);
    meta_.resize(lines_.size());
    revision_++;
    foldsDirty_ = true;
    dirty_ = false;
    cl_ = cc_ = al_ = ac_ = 0;
    hasSel_ = false;
    vMode_ = false;
    desiredCol_ = 0;
    undo_.clear();
    redo_.clear();
    undoTotal_ = 0;
    typingBurst_ = false;
    symDirty_ = true;
    probsDirty_ = true;
    maxLen_ = 0;
    for (auto& l : lines_) {
        if ((int)l.size() > maxLen_) maxLen_ = (int)l.size();
    }
    retokenize(0);
    probsDirty_ = true;
}

U16 Doc::getText() const {
    U16 out;
    for (size_t i = 0; i < lines_.size(); i++) {
        if (i) out += u'\n';
        out += lines_[i];
    }
    return out;
}

void Doc::retokenize(int fromLine) {
    const int n = (int)lines_.size();
    if (n <= 0) return;
    if (fromLine < 0) fromLine = 0;
    if (fromLine >= n) return;
    uint8_t st = (fromLine == 0) ? 0 : meta_[fromLine - 1].strEnd;
    int32_t dp = (fromLine == 0) ? 0 : meta_[fromLine - 1].depthEnd;

    for (int i = fromLine; i < n; i++) {
        LineData& m = meta_[i];
        bool had = m.rev != 0;
        uint8_t oldEnd = m.strEnd;
        int32_t oldDepth = m.depthEnd;
        m.toks.clear();
        m.syms.clear();
        uint8_t nst = st;
        int32_t ndp = dp;
        tokenizeLine(lines_[i], nst, ndp, m.toks, m.syms, i);
        m.strStart = st;
        m.strEnd = nst;
        m.depthStart = dp;
        m.depthEnd = ndp;
        m.rev = revision_;
        m.blank = m.toks.empty();
        int32_t ind = 0;
        const U16& L = lines_[i];
        for (size_t k = 0; k < L.size(); k++) {
            char16_t c = L[k];
            if (c == u' ') ind++;
            else if (c == u'\t') ind += tabSize_ - (ind % tabSize_);
            else break;
        }
        m.indent = ind;
        st = nst;
        dp = ndp;
        if (had && i > fromLine && oldEnd == nst && oldDepth == ndp) break;
    }
    symDirty_ = true;
    probsDirty_ = true;
}

void Doc::clampCursor() {
    if (cl_ < 0) cl_ = 0;
    if (cl_ >= (int)lines_.size()) cl_ = (int)lines_.size() - 1;
    if (cc_ < 0) cc_ = 0;
    if (cc_ > (int)lines_[cl_].size()) cc_ = (int)lines_[cl_].size();
    if (al_ < 0) al_ = 0;
    if (al_ >= (int)lines_.size()) al_ = (int)lines_.size() - 1;
    if (ac_ < 0) ac_ = 0;
    if (ac_ > (int)lines_[al_].size()) ac_ = (int)lines_[al_].size();
}

void Doc::touchMaxLen(int line) {
    if (lines_.size() <= 3000) {
        maxLen_ = 0;
        for (auto& l : lines_) {
            if ((int)l.size() > maxLen_) maxLen_ = (int)l.size();
        }
        return;
    }
    if (line >= 0 && line < (int)lines_.size() && (int)lines_[line].size() > maxLen_) {
        maxLen_ = (int)lines_[line].size();
    }
}

void Doc::afterEdit(int firstLine) {
    if (meta_.size() != lines_.size()) meta_.resize(lines_.size());
    revision_++;
    foldsDirty_ = true;
    dirty_ = true;
    clampCursor();
    if (firstLine >= 0) retokenize(firstLine);
    touchMaxLen(firstLine);
}

// ------------------------------------------------------------------ undo
void Doc::trimUndo() {
    while (undo_.size() > 120U) {
        undoTotal_ -= undo_.front().bytes;
        undo_.erase(undo_.begin());
    }
    while (undoTotal_ > (size_t)24 * 1024 * 1024 && undo_.size() > 1) {
        undoTotal_ -= undo_.front().bytes;
        undo_.erase(undo_.begin());
    }
}

void Doc::snap(bool typing) {
    long long now = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    // 连续输入/删除：同一段操作只落一个快照；停顿超过 100ms 才另起一段
    bool sameBurst = typing && typingBurst_ && !undo_.empty();
    if (sameBurst && now - lastEditMs_ < 100) {
        lastEditMs_ = now;
        return;
    }
    lastEditMs_ = now;
    lastSnapMs_ = now;
    typingBurst_ = typing;
    Snap s;
    s.text = getText();
    s.cl = cl_;
    s.cc = cc_;
    s.al = al_;
    s.ac = ac_;
    s.sel = hasSel_;
    s.bytes = s.text.size() * 2 + 64;
    undoTotal_ += s.bytes;
    undo_.push_back(std::move(s));
    redo_.clear();
    trimUndo();
}

void Doc::loadJoined(const U16& text) {
    lines_.clear();
    meta_.clear();
    U16 cur;
    cur.reserve(128);
    for (char16_t c : text) {
        if (c == u'\r') continue;
        if (c == u'\n') {
            lines_.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    lines_.push_back(cur);
    meta_.resize(lines_.size());
    maxLen_ = 0;
    for (auto& l : lines_) {
        if ((int)l.size() > maxLen_) maxLen_ = (int)l.size();
    }
    revision_++;
    foldsDirty_ = true;
    dirty_ = true;
    clampCursor();
    retokenize(0);
}

bool Doc::undo() {
    if (undo_.empty()) return false;
    Snap cur;
    cur.text = getText();
    cur.cl = cl_;
    cur.cc = cc_;
    cur.al = al_;
    cur.ac = ac_;
    cur.sel = hasSel_;
    cur.bytes = cur.text.size() * 2 + 64;
    redo_.push_back(std::move(cur));

    Snap s = std::move(undo_.back());
    undo_.pop_back();
    undoTotal_ -= s.bytes;
    typingBurst_ = false;
    vMode_ = false;
    loadJoined(s.text);
    cl_ = s.cl;
    cc_ = s.cc;
    al_ = s.al;
    ac_ = s.ac;
    hasSel_ = s.sel;
    clampCursor();
    probsDirty_ = true;
    return true;
}

bool Doc::redo() {
    if (redo_.empty()) return false;
    Snap cur;
    cur.text = getText();
    cur.cl = cl_;
    cur.cc = cc_;
    cur.al = al_;
    cur.ac = ac_;
    cur.sel = hasSel_;
    cur.bytes = cur.text.size() * 2 + 64;
    undoTotal_ += cur.bytes;
    undo_.push_back(std::move(cur));

    Snap s = std::move(redo_.back());
    redo_.pop_back();
    typingBurst_ = false;
    vMode_ = false;
    loadJoined(s.text);
    cl_ = s.cl;
    cc_ = s.cc;
    al_ = s.al;
    ac_ = s.ac;
    hasSel_ = s.sel;
    clampCursor();
    probsDirty_ = true;
    trimUndo();
    return true;
}

// ------------------------------------------------------------------ cursor
void Doc::setCursor(int line, int col) {
    hasSel_ = false;
    cl_ = line;
    cc_ = col;
    al_ = line;
    ac_ = col;
    vMode_ = false;
    clampCursor();
    desiredCol_ = cc_;
}

void Doc::setSelection(int l1, int c1, int l2, int c2) {
    al_ = l1;
    ac_ = c1;
    cl_ = l2;
    cc_ = c2;
    hasSel_ = !(l1 == l2 && c1 == c2);
    vMode_ = false;
    clampCursor();
    desiredCol_ = cc_;
}

void Doc::normalizeSel(int& l1, int& c1, int& l2, int& c2) const {
    if (al_ < cl_ || (al_ == cl_ && ac_ <= cc_)) {
        l1 = al_; c1 = ac_; l2 = cl_; c2 = cc_;
    } else {
        l1 = cl_; c1 = cc_; l2 = al_; c2 = ac_;
    }
    if (l1 > l2 || (l1 == l2 && c1 > c2)) {
        std::swap(l1, l2);
        std::swap(c1, c2);
    }
    if (l1 < 0) l1 = 0;
    if (l1 >= (int)lines_.size()) l1 = (int)lines_.size() - 1;
    if (l2 >= (int)lines_.size()) l2 = (int)lines_.size() - 1;
    if (c1 < 0) c1 = 0;
    if (c1 > (int)lines_[l1].size()) c1 = (int)lines_[l1].size();
    if (c2 < 0) c2 = 0;
    if (c2 > (int)lines_[l2].size()) c2 = (int)lines_[l2].size();
}

void Doc::selectAll() {
    al_ = 0;
    ac_ = 0;
    cl_ = (int)lines_.size() - 1;
    cc_ = (int)lines_.back().size();
    hasSel_ = true;
}

void Doc::selectLine(int line) {
    if (line < 0 || line >= (int)lines_.size()) return;
    al_ = line;
    ac_ = 0;
    cl_ = line;
    cc_ = (int)lines_[line].size();
    hasSel_ = true;
}

void Doc::selectWord(int line, int col) {
    if (line < 0 || line >= (int)lines_.size()) return;
    const U16& L = lines_[line];
    if (col > (int)L.size()) col = (int)L.size();
    int a = col, b = col;
    while (a > 0 && isIdentCont(L[a - 1])) a--;
    while (b < (int)L.size() && isIdentCont(L[b])) b++;
    if (a == b) {
        // no word: select nothing
        setCursor(line, col);
        return;
    }
    al_ = line;
    ac_ = a;
    cl_ = line;
    cc_ = b;
    hasSel_ = true;
}

void Doc::moveHorizontal(int dir, bool extend) {
    vMode_ = false;
    if (!extend && hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        if (dir < 0) { cl_ = l1; cc_ = c1; } else { cl_ = l2; cc_ = c2; }
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
        desiredCol_ = cc_;
        return;
    }
    if (dir < 0) {
        if (cc_ > 0) {
            const U16& L = lines_[cl_];
            cc_ -= (cc_ >= 2 && surIsLow(L[cc_ - 1]) && surIsHigh(L[cc_ - 2])) ? 2 : 1;
        } else if (cl_ > 0) {
            cl_--;
            cc_ = (int)lines_[cl_].size();
        }
    } else {
        if (cc_ < (int)lines_[cl_].size()) {
            const U16& L = lines_[cl_];
            cc_ += (surIsHigh(L[cc_]) && cc_ + 1 < (int)L.size() && surIsLow(L[cc_ + 1])) ? 2 : 1;
        } else if (cl_ + 1 < (int)lines_.size()) {
            cl_++;
            cc_ = 0;
        }
    }
    if (extend) {
        hasSel_ = true;
    } else {
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
    }
    desiredCol_ = cc_;
}

void Doc::moveVertical(int dir, bool extend) {
    if (!vMode_) {
        desiredCol_ = cc_;
        vMode_ = true;
    }
    int nl = cl_ + dir;
    if (nl < 0 || nl >= (int)lines_.size()) return;
    cl_ = nl;
    int want = desiredCol_;
    int len = (int)lines_[cl_].size();
    if (want > len) want = len;
    if (want > 0 && want < len && surIsLow(lines_[cl_][want]) && surIsHigh(lines_[cl_][want - 1])) want--;
    cc_ = want;
    if (extend) {
        hasSel_ = true;
    } else {
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
    }
}

void Doc::moveLineEdge(bool toEnd, bool extend) {
    const U16& L = lines_[cl_];
    if (toEnd) {
        cc_ = (int)L.size();
    } else {
        int first = 0;
        while (first < (int)L.size() && (L[first] == u' ' || L[first] == u'\t')) first++;
        cc_ = (cc_ == first) ? 0 : first;
    }
    vMode_ = false;
    desiredCol_ = cc_;
    if (extend) hasSel_ = true;
    else {
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
    }
}

U16 Doc::selectedText() const {
    if (!hasSel_) return U16();
    int l1, c1, l2, c2;
    normalizeSel(l1, c1, l2, c2);
    if (l1 == l2) return lines_[l1].substr(c1, c2 - c1);
    U16 out = lines_[l1].substr(c1);
    for (int i = l1 + 1; i < l2; i++) {
        out += u'\n';
        out += lines_[i];
    }
    out += u'\n';
    out += lines_[l2].substr(0, c2);
    return out;
}

// ------------------------------------------------------------------ editing
void Doc::put(const U16& text) {
    if (text.empty()) return;
    std::vector<U16> parts;
    size_t start = 0;
    for (size_t i = 0; i < text.size(); i++) {
        if (text[i] == u'\n') {
            parts.push_back(text.substr(start, i - start));
            start = i + 1;
        }
    }
    parts.push_back(text.substr(start));

    int startLine = cl_;
    if (parts.size() == 1) {
        lines_[cl_].insert(cc_, parts[0]);
        cc_ += (int)parts[0].size();
    } else {
        U16 head = lines_[cl_].substr(0, cc_);
        U16 tail = lines_[cl_].substr(cc_);
        lines_[cl_] = head + parts[0];
        U16 last = parts.back() + tail;
        std::vector<U16> mids;
        for (size_t i = 1; i + 1 < parts.size(); i++) mids.push_back(parts[i]);
        int insertAt = cl_ + 1;
        lines_.insert(lines_.begin() + insertAt, last);
        meta_.insert(meta_.begin() + insertAt, LineData());
        if (!mids.empty()) {
            lines_.insert(lines_.begin() + insertAt, mids.begin(), mids.end());
            meta_.insert(meta_.begin() + insertAt, mids.size(), LineData());
        }
        cl_ = startLine + (int)parts.size() - 1;
        cc_ = (int)parts.back().size();
    }
    afterEdit(startLine);
}

void Doc::eraseRange(int l1, int c1, int l2, int c2) {
    if (l1 == l2) {
        if (c2 > c1) lines_[l1].erase(c1, c2 - c1);
        cl_ = l1;
        cc_ = c1;
        afterEdit(l1);
        return;
    }
    U16 joined = lines_[l1].substr(0, c1) + lines_[l2].substr(c2);
    lines_[l1] = joined;
    lines_.erase(lines_.begin() + l1 + 1, lines_.begin() + l2 + 1);
    meta_.erase(meta_.begin() + l1 + 1, meta_.begin() + l2 + 1);
    cl_ = l1;
    cc_ = c1;
    afterEdit(l1);
}

bool Doc::insertText(const U16& s) {
    if (s.empty()) return false;
    snap(false);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    put(s);
    return true;
}

bool Doc::insertTyped(char16_t c) {
    snap(true);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    const U16& L = lines_[cl_];
    bool atEnd = (cc_ >= (int)L.size());

    if (autoPair_) {
        if (c == u')' || c == u']' || c == u'}') {
            if (!atEnd && L[cc_] == c) {
                cc_++;
                desiredCol_ = cc_;
                return true;
            }
        }
        if (c == u'(' || c == u'[' || c == u'{') {
            U16 pair;
            pair += c;
            pair += (c == u'(') ? u')' : (c == u'[') ? u']' : u'}';
            put(pair);
            cc_--;
            desiredCol_ = cc_;
            return true;
        }
        if (c == u'"' || c == u'\'') {
            char16_t prev = (cc_ > 0) ? L[cc_ - 1] : 0;
            char16_t next = atEnd ? 0 : L[cc_];
            bool prevOk = !(isIdentCont(prev) || prev == u'"' || prev == u'\'');
            bool nextOk = (atEnd || next == u' ' || next == u')' || next == u']' ||
                           next == u'}' || next == u',' || next == u':' || next == u'\t');
            if (prevOk && nextOk) {
                U16 pair;
                pair += c;
                pair += c;
                put(pair);
                cc_--;
                desiredCol_ = cc_;
                return true;
            }
        }
    }
    U16 s(1, c);
    put(s);
    desiredCol_ = cc_;
    return true;
}

bool Doc::backspace() {
    snap(true);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
        return true;
    }
    if (cc_ > 0) {
        U16& L = lines_[cl_];
        if (cc_ < (int)L.size()) {
            char16_t prev = L[cc_ - 1], next = L[cc_];
            if ((prev == u'(' && next == u')') || (prev == u'[' && next == u']') ||
                (prev == u'{' && next == u'}') || (prev == u'"' && next == u'"') ||
                (prev == u'\'' && next == u'\'')) {
                eraseRange(cl_, cc_ - 1, cl_, cc_ + 1);
                return true;
            }
        }
        int n = (cc_ >= 2 && surIsHigh(L[cc_ - 2]) && surIsLow(L[cc_ - 1])) ? 2 : 1;
        eraseRange(cl_, cc_ - n, cl_, cc_);
        return true;
    }
    if (cl_ > 0) {
        int prevLen = (int)lines_[cl_ - 1].size();
        eraseRange(cl_ - 1, prevLen, cl_, 0);
        return true;
    }
    return false;
}

bool Doc::deleteForward() {
    snap(true);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
        return true;
    }
    if (cc_ < (int)lines_[cl_].size()) {
        U16& L = lines_[cl_];
        int n = (cc_ + 1 < (int)L.size() && surIsHigh(L[cc_]) && surIsLow(L[cc_ + 1])) ? 2 : 1;
        eraseRange(cl_, cc_, cl_, cc_ + n);
        return true;
    }
    if (cl_ + 1 < (int)lines_.size()) {
        eraseRange(cl_, cc_, cl_ + 1, 0);
        return true;
    }
    return false;
}

bool Doc::newline() {
    snap(true);   // 回车也算连续输入的一批：避免每次回车整篇快照，撤销仍按输入批次合并
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    const U16& L = lines_[cl_];
    size_t k = 0;
    while (k < L.size() && (L[k] == u' ' || L[k] == u'\t')) k++;
    if (k > (size_t)cc_) k = (size_t)cc_;
    U16 ind = L.substr(0, k);
    size_t e = (size_t)cc_;
    while (e > 0 && (L[e - 1] == u' ' || L[e - 1] == u'\t')) e--;
    bool extra = autoIndent_ && e > 0 && L[e - 1] == u':';
    U16 ins = u"\n";
    ins += ind;
    if (extra) ins += U16((size_t)tabSize_, u' ');
    put(ins);
    desiredCol_ = cc_;
    return true;
}

bool Doc::indentBlock(bool outdent) {
    if (!hasSel_) {
        if (!outdent) {
            return insertText(U16((size_t)tabSize_, u' '));
        }
        const U16& L = lines_[cl_];
        int k = 0;
        while (k < tabSize_ && k < cc_ && L[cc_ - 1 - k] == u' ') k++;
        if (k == 0) return false;
        snap(false);
        eraseRange(cl_, cc_ - k, cl_, cc_);
        return true;
    }
    int l1, c1, l2, c2;
    normalizeSel(l1, c1, l2, c2);
    if (c2 == 0 && l2 > l1) l2--;
    snap(false);
    for (int i = l1; i <= l2; i++) {
        if (!outdent) {
            lines_[i].insert((size_t)0, U16((size_t)tabSize_, u' '));
        } else {
            int k = 0;
            const U16& L = lines_[i];
            while (k < tabSize_ && k < (int)L.size()) {
                if (L[k] == u' ') k++;
                else if (L[k] == u'\t') { k++; break; }
                else break;
            }
            if (k > 0) lines_[i].erase(0, k);
        }
    }
    cc_ = std::min(cc_, (int)lines_[cl_].size());
    ac_ = std::min(ac_, (int)lines_[al_].size());
    afterEdit(l1);
    return true;
}

void Doc::setOptions(int tabSize, bool autoIndent, bool autoPair) {
    if (tabSize < 1) tabSize = 1;
    if (tabSize > 16) tabSize = 16;
    tabSize_ = tabSize;
    autoIndent_ = autoIndent;
    autoPair_ = autoPair;
    meta_.assign(lines_.size(), LineData());
    retokenize(0);
}

// ------------------------------------------------------------------ symbols
void Doc::rebuildSymbols() {
    symList_.clear();
    symKind_.clear();
    attrs_.clear();
    auto prio = [](uint8_t k) -> int {
        switch (k) {
            case SK_CLASS: return 5;
            case SK_FUNC: return 4;
            case SK_MODULE: return 3;
            case SK_PARAM: return 2;
            case SK_VAR: return 1;
            default: return 0;
        }
    };
    for (int i = 0; i < (int)meta_.size(); i++) {
        for (const Sym& s : meta_[i].syms) {
            if (s.name.size() < 1) continue;
            if (s.kind == SK_ATTR) {
                attrs_.insert(s.name);
                continue;
            }
            auto it = symKind_.find(s.name);
            if (it == symKind_.end()) {
                symKind_.emplace(s.name, s.kind);
                symList_.push_back(Sym{s.name, s.kind, s.line});
            } else if (prio(s.kind) > prio(it->second)) {
                it->second = s.kind;
            }
        }
    }
    symDirty_ = false;
}

int Doc::fillRuns(int fromLine, int toLine, int32_t* out, int maxRecords) {
    if (symDirty_) rebuildSymbols();
    int cnt = 0;
    if (fromLine < 0) fromLine = 0;
    if (toLine >= (int)lines_.size()) toLine = (int)lines_.size() - 1;
    for (int i = fromLine; i <= toLine; i++) {
        const U16& L = lines_[i];
        for (const Tok& t : meta_[i].toks) {
            if (cnt + 4 > maxRecords) return cnt;
            uint8_t type = t.type;
            if (type == T_TEXT) {
                scratch_.assign(L, t.start, t.end - t.start);
                auto it = symKind_.find(scratch_);
                if (it != symKind_.end()) {
                    if (it->second == SK_FUNC) type = T_USERFUNC;
                    else if (it->second == SK_CLASS) type = T_USERCLASS;
                }
            }
            out[cnt++] = i;
            out[cnt++] = (int32_t)t.start;
            out[cnt++] = (int32_t)t.end;
            out[cnt++] = (int32_t)type;
        }
    }
    return cnt;
}

// ---------------------------------------------------------------- 赋值目标检查（5.5.1）
// 只做「一眼能看出错」的轻量检查，不解析完整表达式：
//   4 = 1 / x + 1 = 2 / f() = 1 / if x = 1: / None = 1 / [1] = [1] / x =
// 规则对齐 CPython 的 assignment target：字面量本身不能当目标，但
// `"abc"[0] = ...`、`1 .real = ...`、`(a).b = ...` 是合法语法，不能误报。
namespace {

bool tokIsText(const U16& L, const Tok& t, const char16_t* lit) {
    return t.type == T_OPERATOR && tokTextOf(L, t) == lit;
}

// 可作变量名的记号（match / case 是软关键字，允许当变量名）
bool identTok(const U16& L, const Tok& t) {
    if (t.type == T_TEXT || t.type == T_SELF || t.type == T_BUILTIN || t.type == T_PARAM)
        return true;
    if (t.type == T_KEYWORD) {
        U16 w = tokTextOf(L, t);
        return w == u"match" || w == u"case";
    }
    return false;
}

// 字面量 / ... 可以作 primary，但不能单独当赋值目标
bool literalTok(const U16& L, const Tok& t) {
    if (t.type == T_NUMBER || t.type == T_STRING || t.type == T_CONST) return true;
    return tokIsText(L, t, u"...");
}

// i 指向 ( [ {，返回匹配的右括号之后的下标；失败 -1
int matchGroup(const U16& L, const std::vector<Tok>& toks, int i, int end) {
    int depth = 0;
    for (int k = i; k < end; k++) {
        const Tok& t = toks[k];
        if (t.type != T_OPERATOR) continue;
        U16 op = tokTextOf(L, t);
        if (op.size() != 1) continue;
        char16_t c = op[0];
        if (c == u'(' || c == u'[' || c == u'{') {
            depth++;
        } else if (c == u')' || c == u']' || c == u'}') {
            depth--;
            if (depth == 0) return k + 1;
            if (depth < 0) return -1;
        }
    }
    return -1;
}

// 解析 primary 之后的 .name / [..] / (..) 链。
// 调用结尾不能赋值（f() = 1）；attr / 下标结尾可以（f().x = 1）。
int invalidTrailers(const U16& L, const std::vector<Tok>& toks, int k, int to) {
    bool lastIsCall = false;
    while (k < to) {
        const Tok& t = toks[k];
        if (t.type != T_OPERATOR) return k;
        U16 op = tokTextOf(L, t);
        if (op == u".") {
            if (k + 1 >= to || !identTok(L, toks[k + 1])) return k;
            k += 2;
            lastIsCall = false;
        } else if (op == u"[") {
            int close = matchGroup(L, toks, k, to);
            if (close < 0) return k;
            k = close;
            lastIsCall = false;
        } else if (op == u"(") {
            int close = matchGroup(L, toks, k, to);
            if (close < 0) return k;
            k = close;
            lastIsCall = true;
        } else {
            return k;
        }
    }
    return lastIsCall ? to - 1 : -1;
}

int invalidTargetListAt(const U16& L, const std::vector<Tok>& toks, int from, int to);

// 单个目标：*a / (a, b) / [a, b] / a.b[0] / "s"[0] / ...
int invalidElementAt(const U16& L, const std::vector<Tok>& toks, int from, int to) {
    while (from < to && toks[from].type == T_COMMENT) from++;
    while (to > from && toks[to - 1].type == T_COMMENT) to--;
    if (from >= to) return from;

    // 类型注解：a: int = 1 —— 只校验冒号前的目标
    {
        int depth = 0;
        for (int k = from; k < to; k++) {
            const Tok& t = toks[k];
            if (t.type != T_OPERATOR) continue;
            U16 op = tokTextOf(L, t);
            if (op.size() != 1) continue;
            char16_t c = op[0];
            if (c == u'(' || c == u'[' || c == u'{') depth++;
            else if (c == u')' || c == u']' || c == u'}') depth--;
            else if (c == u':' && depth == 0) { to = k; break; }
        }
    }
    if (from >= to) return from;

    // *target
    if (tokIsText(L, toks[from], u"*")) {
        if (from + 1 >= to) return from;
        return invalidElementAt(L, toks, from + 1, to);
    }

    // 括号 / 方括号 / 花括号开头
    if (toks[from].type == T_OPERATOR) {
        U16 op = tokTextOf(L, toks[from]);
        if (op == u"(" || op == u"[" || op == u"{") {
            int close = matchGroup(L, toks, from, to);
            if (close < 0) return from;
            if (close == to) {
                if (op == u"{") return from;              // set / dict 显示不能当目标
                // 空目标 () / [] 是合法的（用来耗尽迭代器），(,) / [,] 不是
                if (from + 1 == to - 1) return -1;
                return invalidTargetListAt(L, toks, from + 1, to - 1);
            }
            // 整个括号组作为 primary，再接 trailer：(a).b / [a][0] / {1}[0]
            return invalidTrailers(L, toks, close, to);
        }
    }

    bool ident = identTok(L, toks[from]);
    if (!ident && !literalTok(L, toks[from])) return from;
    // Python 3.12 类型别名：type X[...] = ...（type 是内建名，X 是别名）
    int k = from + 1;
    if (toks[from].type == T_BUILTIN && tokTextOf(L, toks[from]) == u"type" &&
        k < to && identTok(L, toks[k])) {
        k++;
    }
    int bad = invalidTrailers(L, toks, k, to);
    if (bad >= 0) return bad;
    // 纯字面量（4 = 1 / None = 1）不能赋值；带 trailer 的（4 .real、None.x）可以
    if (!ident && from + 1 >= to) return from;
    return -1;
}

// 逗号分隔的目标列表（语句 LHS 或 () / [] 内层）
int invalidTargetListAt(const U16& L, const std::vector<Tok>& toks, int from, int to) {
    while (from < to && toks[from].type == T_COMMENT) from++;
    while (to > from && toks[to - 1].type == T_COMMENT) to--;
    if (from >= to) return from;
    int depth = 0;
    int start = from;
    int nonEmpty = 0;
    int firstBad = -1;
    for (int k = from; k <= to; k++) {
        bool atEnd = (k == to);
        bool comma = false;
        if (!atEnd) {
            const Tok& t = toks[k];
            if (t.type == T_OPERATOR) {
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') depth++;
                    else if (c == u')' || c == u']' || c == u'}') depth--;
                    else if (c == u',' && depth == 0) comma = true;
                }
            }
        }
        if (!comma && !atEnd) continue;
        int a = start;
        while (a < k && toks[a].type == T_COMMENT) a++;
        int b = k;
        while (b > a && toks[b - 1].type == T_COMMENT) b--;
        if (a >= b) {
            // 只有末尾的逗号（a, / (a,)）是合法的
            if (!atEnd && firstBad < 0) firstBad = k;
        } else {
            nonEmpty++;
            if (firstBad < 0) {
                int bad = invalidElementAt(L, toks, a, b);
                if (bad >= 0) firstBad = bad;
            }
        }
        start = k + 1;
    }
    return nonEmpty == 0 ? from : firstBad;
}

bool isAssignOpText(const U16& op) {
    if (op == u"=") return true;
    if (op.size() < 2) return false;
    if (op == u"==" || op == u"!=" || op == u"<=" || op == u">=" || op == u":=") return false;
    return op[op.size() - 1] == u'=';
}

}  // namespace

// ---------------------------------------------------------------- 5.5.4 扩展语法检查
namespace {

bool isHexChar(char16_t c) {
    return (c >= u'0' && c <= u'9') || (c >= u'a' && c <= u'f') || (c >= u'A' && c <= u'F');
}

bool isSpaceChar(char16_t c) {
    return c == u' ' || c == u'\t' || c == u'\r' || c == u'\f' || c == u'\v';
}

bool nameToken(const U16& L, const Tok& t) {
    if (t.type == T_TEXT || t.type == T_PARAM || t.type == T_SELF ||
        t.type == T_BUILTIN || t.type == T_DEF || t.type == T_CLASS)
        return true;
    if (t.type == T_KEYWORD) {
        U16 w = tokTextOf(L, t);
        return w == u"match" || w == u"case";   // 软关键字可以当变量/参数名
    }
    return false;
}

int firstCode(const std::vector<Tok>& toks) {
    int i = 0;
    while (i < (int)toks.size() && toks[i].type == T_COMMENT) i++;
    return i;
}

int lastCode(const std::vector<Tok>& toks) {
    int i = (int)toks.size() - 1;
    while (i >= 0 && toks[i].type == T_COMMENT) i--;
    return i;
}


/* 跳过 async，取真正的块关键字：async def / async for / async with */
U16 lineOwnerKw(const U16& L, const LineData& m) {
    int i = firstCode(m.toks);
    if (i >= (int)m.toks.size() || m.toks[i].type != T_KEYWORD) return U16();
    U16 w = tokTextOf(L, m.toks[i]);
    if (w == u"async" && i + 1 < (int)m.toks.size() && m.toks[i + 1].type == T_KEYWORD)
        return tokTextOf(L, m.toks[i + 1]);
    return w;
}

bool lineHasTopColon(const U16& L, const LineData& m) {
    int depth = 0;
    for (const Tok& t : m.toks) {
        if (t.type != T_OPERATOR) continue;
        U16 op = tokTextOf(L, t);
        if (op.size() != 1) continue;
        char16_t c = op[0];
        if (c == u'(' || c == u'[' || c == u'{') depth++;
        else if (c == u')' || c == u']' || c == u'}') depth--;
        else if (depth == 0 && c == u':') return true;
    }
    return false;
}

bool endsWithColonTok(const U16& L, const LineData& m) {
    int i = lastCode(m.toks);
    return i >= 0 && m.toks[i].type == T_OPERATOR && tokTextOf(L, m.toks[i]) == u":";
}

int prevCodeLine(const std::vector<U16>& lines, const std::vector<LineData>& meta, int i) {
    for (int j = i - 1; j >= 0; j--) {
        const LineData& m = meta[j];
        if (m.blank || m.strStart != 0 || m.depthStart > 0) continue;
        if (j > 0 && endsWithBackslash(lines[j - 1])) continue;   // 反斜杠续行
        int f = firstCode(m.toks);
        if (f >= (int)m.toks.size()) continue;
        return j;
    }
    return -1;
}

/* 8/16 进制前缀、前导零、下划线、指数、1.2.3 这类数字字面量错误 */
bool badNumberTok(const U16& L, const Tok& t, const U16& raw) {
    U16 x = raw;
    if (!x.empty() && (x.back() == u'j' || x.back() == u'J')) x.pop_back();
    if (x.empty()) return true;

    // 1.2.3 / 1..2：数字后面紧跟着「点 + 数字」
    if (t.end < L.size() && L[t.end] == u'.' && t.end + 1 < L.size() && isDigit16(L[t.end + 1]))
        return true;

    bool hex = false, bin = false, oct = false;
    size_t p = 0;
    if (x.size() >= 2 && x[0] == u'0' && (x[1] == u'x' || x[1] == u'X')) { hex = true; p = 2; }
    else if (x.size() >= 2 && x[0] == u'0' && (x[1] == u'b' || x[1] == u'B')) { bin = true; p = 2; }
    else if (x.size() >= 2 && x[0] == u'0' && (x[1] == u'o' || x[1] == u'O')) { oct = true; p = 2; }

    if (hex || bin || oct) {
        int digits = 0;
        bool prevUnderscore = false;
        for (size_t k = p; k < x.size(); k++) {
            char16_t c = x[k];
            if (c == u'_') {
                if (prevUnderscore) return true;
                prevUnderscore = true;
                continue;
            }
            bool ok = hex ? isHexChar(c)
                          : (bin ? (c == u'0' || c == u'1') : (c >= u'0' && c <= u'7'));
            if (!ok) return true;
            digits++;
            prevUnderscore = false;
        }
        if (digits == 0 || prevUnderscore) return true;
        // 0b102 / 0x1g：进制字面量后面直接跟标识符字符
        if (t.end < L.size() && isIdentCont(L[t.end])) return true;
        return false;
    }

    if (x.back() == u'_') return true;
    for (size_t k = 0; k + 1 < x.size(); k++)
        if (x[k] == u'_' && x[k + 1] == u'_') return true;

    bool hasDot = false, hasExp = false;
    for (size_t k = 0; k < x.size(); k++) {
        char16_t c = x[k];
        if (c == u'.') hasDot = true;
        if (c == u'e' || c == u'E') {
            hasExp = true;
            size_t q = k + 1;
            if (q < x.size() && (x[q] == u'+' || x[q] == u'-')) q++;
            int d = 0;
            while (q < x.size() && isDigit16(x[q])) { q++; d++; }
            if (d == 0 || q != x.size()) return true;
            break;
        }
    }
    if (!hasDot && !hasExp) {
        U16 d;
        for (char16_t c : x) if (c != u'_') d += c;
        if (d.size() > 1 && d[0] == u'0') {
            bool nz = false;
            for (size_t k = 1; k < d.size(); k++) if (d[k] != u'0') nz = true;
            if (nz) return true;   // 012 / 0_1（00 合法）
        }
    }
    return false;
}

/* 解析字符串 token 的前缀 / 引号位置；不是字符串返回 false */
bool stringHead(const U16& text, int& quotePos, U16& prefix, bool& triple) {
    int q = -1;
    for (int k = 0; k < (int)text.size(); k++) {
        char16_t c = text[k];
        if (c == u'\'' || c == u'"') { q = k; break; }
        if (!((c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z'))) return false;
    }
    if (q < 0) return false;
    quotePos = q;
    prefix = text.substr(0, q);
    char16_t quote = text[q];
    triple = q + 2 < (int)text.size() && text[q + 1] == quote && text[q + 2] == quote;
    return true;
}

/* 单行字符串是否在行内闭合（跳过转义） */
bool stringClosed(const U16& text, int q) {
    char16_t quote = text[q];
    int i = q + 1;
    while (i < (int)text.size()) {
        if (text[i] == u'\\') { i += 2; continue; }
        if (text[i] == quote) return true;
        i++;
    }
    return false;
}

/* f-string：空的 {}、没闭合的 {、非法 !x 转换 */
int skipQuotedRaw(const U16& L, int i, int end) {
    char16_t q = L[i];
    bool triple = i + 2 < end && L[i + 1] == q && L[i + 2] == q;
    int k = i + (triple ? 3 : 1);
    while (k < end) {
        if (L[k] == u'\\') { k += 2; continue; }
        if (triple) {
            if (L[k] == q && k + 2 < end && L[k + 1] == q && L[k + 2] == q) return k + 3;
            k++;
        } else {
            if (L[k] == q) return k + 1;
            k++;
        }
    }
    return end;
}

/* f-string：空的 {}、没闭合的 {、非法 !x 转换。直接扫原始行，兼容 PEP 701 嵌套引号 */
bool badFStringTok(const U16& L, const Tok& t) {
    U16 text = tokTextOf(L, t);
    int qRel = 0; U16 prefix; bool triple = false;
    if (!stringHead(text, qRel, prefix, triple)) return false;
    bool isF = false;
    for (char16_t c : prefix) if (c == u'f' || c == u'F') isF = true;
    if (!isF || triple) return false;
    int q = (int)t.start + qRel;
    char16_t quote = L[q];
    int i = q + 1, n = (int)L.size();
    while (i < n) {
        char16_t c = L[i];
        if (c == u'\\') {
            // 反斜杠只在转义引号时跳过；\{ 仍按花括号规则处理
            if (i + 1 < n && L[i + 1] == quote) { i += 2; continue; }
            i++;
            continue;
        }
        if (c == quote) return false;                 // 正常闭合
        if (c != u'{') { i++; continue; }
        if (i + 1 < n && L[i + 1] == u'{') { i += 2; continue; }   // {{
        int j = i + 1, d = 1;
        bool closed = false, outerEnded = false;
        while (j < n) {
            char16_t ch = L[j];
            if (ch == quote) {
                // 表达式里的同一个引号：如果后面只剩空白/注释，说明这是 f-string 的收尾引号，
                // 而 { 还没闭合 → 真错误（不是 PEP 701 的嵌套引号）
                int nx = j + 1;
                while (nx < n && isSpaceChar(L[nx])) nx++;
                if (nx >= n || L[nx] == u'#') { outerEnded = true; break; }
                j = skipQuotedRaw(L, j, n);
                continue;
            }
            if (ch == u'\'' || ch == u'"') { j = skipQuotedRaw(L, j, n); continue; }
            if (ch == u'{') d++;
            else if (ch == u'}') {
                d--;
                if (d == 0) { closed = true; break; }
            }
            j++;
        }
        // 未闭合的 {：可能是 PEP 701 的跨行 f-string（表达式里有未闭合括号 / 注释）
        if (!closed) {
            if (outerEnded) return true;   // 外层引号已经收尾，仍缺 } → 真错误
            bool multiline = false;
            int od = 0;
            for (int m = i + 1; m < n; m++) {
                char16_t ch = L[m];
                if (ch == u'#') multiline = true;
                if (ch == u'(' || ch == u'[' || ch == u'{') od++;
                else if (ch == u')' || ch == u']' || ch == u'}') od--;
            }
            if (multiline || od > 0) return false;
            return true;
        }
        int a = i + 1, b = j;
        while (a < b && isSpaceChar(L[a])) a++;
        while (b > a && isSpaceChar(L[b - 1])) b--;
        if (a >= b) return true;                      // f"{}"
        int dd = 0;
        bool spec = false;
        for (int m = a; m < b; m++) {
            char16_t ch = L[m];
            if (ch == u'\'' || ch == u'"') { m = skipQuotedRaw(L, m, b) - 1; continue; }
            if (ch == u'(' || ch == u'[' || ch == u'{') dd++;
            else if (ch == u')' || ch == u']' || ch == u'}') dd--;
            else if (dd == 0 && ch == u':') spec = true;   // 后面是格式说明
            else if (dd == 0 && ch == u'!' && !spec) {
                char16_t nx = (m + 1 < b) ? L[m + 1] : 0;
                if (nx == u'=') continue;             // !=
                if (!(nx == u's' || nx == u'r' || nx == u'a')) return true;
                m++;
            }
        }
        i = j + 1;
    }
    return false;
}

/* def 参数：默认值顺序 + 重名。返回第一个出错 token 下标，-1 正常 */
int badParamsAt(const U16& L, const std::vector<Tok>& toks, int from, int to) {
    int depth = 0, start = from, firstBad = -1;
    bool seenDefault = false, keywordOnly = false, inLambda = false;
    std::unordered_set<U16> names;
    for (int k = from; k <= to; k++) {
        bool atEnd = (k == to);
        bool comma = false;
        if (!atEnd) {
            const Tok& t = toks[k];
            if (t.type == T_KEYWORD && tokTextOf(L, t) == u"lambda" && depth == 0) inLambda = true;
            if (t.type == T_OPERATOR) {
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') depth++;
                    else if (c == u')' || c == u']' || c == u'}') depth--;
                    else if (c == u':' && inLambda && depth == 0) inLambda = false;
                    else if (c == u',' && depth == 0 && !inLambda) comma = true;
                }
            }
        }
        if (!comma && !atEnd) continue;
        int a = start, b = k;
        while (a < b && toks[a].type == T_COMMENT) a++;
        while (b > a && toks[b - 1].type == T_COMMENT) b--;
        start = k + 1;
        if (a >= b) continue;

        int p = a;
        bool star = false, dstar = false;
        if (tokIsText(L, toks[p], u"**")) {
            dstar = true;
            p++;
        } else if (tokIsText(L, toks[p], u"*")) {
            if (p + 1 >= b) { keywordOnly = true; continue; }        // 裸 *
            star = true;
            p++;
        } else if (tokIsText(L, toks[p], u"/") && p + 1 == b) {
            continue;                                                 // /
        }

        int np = -1;
        for (int q = p; q < b; q++) {
            if (nameToken(L, toks[q])) { np = q; break; }
            if (tokIsText(L, toks[q], u"=") || tokIsText(L, toks[q], u":")) break;
            break;
        }
        U16 name;
        if (np < 0) {
            if (firstBad < 0) firstBad = a;
        } else {
            name = tokTextOf(L, toks[np]);
            if (!names.insert(name).second && firstBad < 0) firstBad = np;
        }

        int d = 0;
        bool hasDefault = false;
        for (int q = p; q < b; q++) {
            const Tok& t = toks[q];
            if (t.type != T_OPERATOR) continue;
            U16 op = tokTextOf(L, t);
            if (op.size() == 1) {
                char16_t c = op[0];
                if (c == u'(' || c == u'[' || c == u'{') d++;
                else if (c == u')' || c == u']' || c == u'}') d--;
            }
            if (d == 0 && op == u"=") hasDefault = true;
        }
        if (!keywordOnly && !star && !dstar) {
            if (seenDefault && !hasDefault && firstBad < 0) firstBad = (np >= 0 ? np : a);
            if (hasDefault) seenDefault = true;
        }
        if (star || dstar) keywordOnly = true;
    }
    return firstBad;
}

/* 调用参数：关键字参数后面不能再有普通位置参数（* 解包允许，** 之后 * 也不允许） */
int badCallArgsAt(const U16& L, const std::vector<Tok>& toks, int from, int to) {
    int depth = 0, start = from;
    bool seenKeyword = false, seenDoubleStar = false, inLambda = false;
    for (int k = from; k <= to; k++) {
        bool atEnd = (k == to);
        bool comma = false;
        if (!atEnd) {
            const Tok& t = toks[k];
            if (t.type == T_KEYWORD && tokTextOf(L, t) == u"lambda" && depth == 0) inLambda = true;
            if (t.type == T_OPERATOR) {
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') depth++;
                    else if (c == u')' || c == u']' || c == u'}') depth--;
                    else if (c == u':' && inLambda && depth == 0) inLambda = false;
                    else if (c == u',' && depth == 0 && !inLambda) comma = true;
                }
            }
        }
        if (!comma && !atEnd) continue;
        int a = start, b = k;
        while (a < b && toks[a].type == T_COMMENT) a++;
        while (b > a && toks[b - 1].type == T_COMMENT) b--;
        start = k + 1;
        if (a >= b) continue;

        if (tokIsText(L, toks[a], u"**")) {
            seenDoubleStar = true;
            continue;
        }
        if (tokIsText(L, toks[a], u"*")) {
            if (seenDoubleStar) return a;              // f(**d, *a)
            continue;                                  // f(a=1, *b) 合法
        }

        int d = 0;
        int firstEq = -1, firstLambda = -1;
        for (int q = a; q < b; q++) {
            const Tok& t = toks[q];
            if (t.type == T_KEYWORD && tokTextOf(L, t) == u"lambda" && d == 0 && firstLambda < 0)
                firstLambda = q;
            if (t.type != T_OPERATOR) continue;
            U16 op = tokTextOf(L, t);
            if (op.size() == 1) {
                char16_t c = op[0];
                if (c == u'(' || c == u'[' || c == u'{') d++;
                else if (c == u')' || c == u']' || c == u'}') d--;
            }
            if (d == 0 && op == u"=" && firstEq < 0) firstEq = q;
        }
        // command=lambda x=1: ...：等号在 lambda 前面，是关键字参数；
        // lambda x=1: x 里等号在 lambda 后面，是默认值，不能当关键字参数
        bool keyword = firstEq >= 0 && (firstLambda < 0 || firstEq < firstLambda);
        if (keyword) { seenKeyword = true; continue; }
        if (seenKeyword || seenDoubleStar) return a;   // 位置参数跟在关键字 / ** 后面
    }
    return -1;
}

/* 子句是否有合法的 if / try / for / while / match 宿主 */
}  // namespace

bool Doc::clauseHasOwner(int i, const U16& kw) const {
    const int ind = meta_[i].indent;
    if (kw == u"case") {
        for (int j = i - 1; j >= 0; j--) {
            const LineData& m = meta_[j];
            if (m.blank || m.strStart != 0 || m.depthStart > 0) continue;
            int f = firstCode(m.toks);
            if (f >= (int)m.toks.size()) continue;
            if (m.indent < ind) return lineOwnerKw(lines_[j], m) == u"match";
            // 同缩进的 case / case 体都跳过
        }
        return false;
    }
    bool sawExcept = false;
    for (int j = i - 1; j >= 0; j--) {
        const LineData& m = meta_[j];
        if (m.blank || m.strStart != 0 || m.depthStart > 0) continue;
        int f = firstCode(m.toks);
        if (f >= (int)m.toks.size()) continue;
        if (m.indent > ind) continue;
        if (m.indent < ind) return false;
        U16 w = lineOwnerKw(lines_[j], m);
        if (w.empty()) return false;
        if (w == u"elif") {
            if (kw == u"else" || kw == u"elif") continue;
            return false;
        }
        if (w == u"else") {
            if (kw == u"finally") continue;            // try/except/else/finally
            return false;
        }
        if (w == u"except") {
            sawExcept = true;
            if (kw == u"except" || kw == u"else" || kw == u"finally") continue;
            return false;
        }
        if (w == u"finally") return false;
        if (w == u"if") return kw == u"else" || kw == u"elif";
        if (w == u"for" || w == u"while") return kw == u"else";
        if (w == u"try") {
            if (kw == u"except" || kw == u"finally") return true;
            if (kw == u"else") return sawExcept;
            return false;
        }
        return false;
    }
    return false;
}

void Doc::checkLineExtras(int i) {
    const U16& L = lines_[i];
    const LineData& m = meta_[i];
    if (m.blank || m.strStart != 0) return;
    const std::vector<Tok>& toks = m.toks;
    const int tn = (int)toks.size();
    const int first = firstCode(toks);
    if (first >= tn) return;
    const bool continued = i > 0 && endsWithBackslash(lines_[i - 1]);
    const U16 w0 = lineOwnerKw(L, m);

    // ---- 意外缩进：上一行是顶格普通语句（不以 : 结尾）却缩进
    if (!continued && m.depthStart == 0 && m.indent > 0 && (m.indent % tabSize_ == 0)) {
        int p = prevCodeLine(lines_, meta_, i);
        bool ok = false;
        if (p >= 0) {
            if (meta_[p].indent > 0) ok = true;
            else if (endsWithColonTok(lines_[p], meta_[p])) ok = true;
            else {
                // 上一行是缺冒号的块头：让 M_COLON 报，不重复报「意外缩进」
                U16 pw = lineOwnerKw(lines_[p], meta_[p]);
                ok = pw == u"if" || pw == u"elif" || pw == u"else" || pw == u"for" ||
                     pw == u"while" || pw == u"try" || pw == u"except" || pw == u"finally" ||
                     pw == u"with" || pw == u"def" || pw == u"class" || pw == u"match" ||
                     pw == u"case";
            }
        }
        if (!ok) probs_.push_back(Prob{(u32)i, 0, (u32)m.indent, 0, M_UNEXPECTED_INDENT});
    }

    // ---- import / from
    {
        int depth = 0, stmtEnd = tn;
        for (int k = first; k < tn; k++) {
            const Tok& t = toks[k];
            if (t.type == T_OPERATOR) {
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') depth++;
                    else if (c == u')' || c == u']' || c == u'}') depth--;
                    else if (c == u';' && depth == 0) { stmtEnd = k; break; }
                }
            }
        }
        U16 w = (toks[first].type == T_KEYWORD) ? tokTextOf(L, toks[first]) : U16();
        if (w == u"import") {
            bool hasName = false, hasFrom = false;
            int badFrom = -1;
            for (int k = first + 1; k < stmtEnd; k++) {
                const Tok& t = toks[k];
                if (t.type == T_COMMENT) break;
                hasName = true;
                if (t.type == T_KEYWORD && tokTextOf(L, t) == u"from" && badFrom < 0) {
                    hasFrom = true;
                    badFrom = k;
                }
            }
            if (!hasName) probs_.push_back(Prob{(u32)i, toks[first].start, toks[first].end, 0, M_BAD_IMPORT});
            if (hasFrom) probs_.push_back(Prob{(u32)i, toks[badFrom].start, toks[badFrom].end, 0, M_BAD_IMPORT});
        } else if (w == u"from") {
            int imp = -1;
            for (int k = first + 1; k < stmtEnd; k++) {
                const Tok& t = toks[k];
                if (t.type == T_COMMENT) break;
                if (t.type == T_KEYWORD && tokTextOf(L, t) == u"import") { imp = k; break; }
            }
            if (imp < 0 || imp == first + 1) {
                probs_.push_back(Prob{(u32)i, toks[first].start, toks[first].end, 0, M_BAD_IMPORT});
            } else {
                bool hasName = false;
                for (int k = imp + 1; k < stmtEnd; k++) {
                    if (toks[k].type == T_COMMENT) break;
                    hasName = true;
                    break;
                }
                if (!hasName)
                    probs_.push_back(Prob{(u32)i, toks[imp].start, toks[imp].end, 0, M_BAD_IMPORT});
            }
        }
    }

    // ---- def / class 名字 & 函数参数
    int defIdx = -1, clsIdx = -1;
    if (toks[first].type == T_KEYWORD) {
        U16 w = tokTextOf(L, toks[first]);
        if (w == u"def") defIdx = first;
        else if (w == u"class") clsIdx = first;
        else if (w == u"async" && first + 1 < tn && toks[first + 1].type == T_KEYWORD &&
                 tokTextOf(L, toks[first + 1]) == u"def") defIdx = first + 1;
    }
    if (defIdx >= 0 || clsIdx >= 0) {
        int hi = (defIdx >= 0) ? defIdx : clsIdx;
        int ni = hi + 1;
        if (ni < tn && toks[ni].type != T_COMMENT) {
            uint8_t want = (defIdx >= 0) ? T_DEF : T_CLASS;
            bool badName = false;
            if (toks[ni].type == T_STRING) {
                badName = false;   // `def"..."` 这种是字符串测试数据，别误报
            } else if (toks[ni].type == want) {
                // lexer 会把 def 后面的任何词都标成 T_DEF（包括关键字），这里再按文本判一次
                U16 nm = tokTextOf(L, toks[ni]);
                bool soft = (nm == u"match" || nm == u"case");
                badName = !soft && (isKeyword(nm) || isConstName(nm));
            } else {
                badName = !tokIsText(L, toks[ni], u"=");   // `class = 10` 交给赋值检查
            }
            if (badName)
                probs_.push_back(Prob{(u32)i, toks[ni].start, toks[ni].end, 0, M_BAD_DEF_NAME});
        }
        if (defIdx >= 0 && ni < tn && toks[ni].type == T_DEF) {
            int p = ni + 1;
            if (p < tn && tokIsText(L, toks[p], u"[")) {
                int c = matchGroup(L, toks, p, tn);
                p = (c < 0) ? -1 : c;
            }
            if (p >= 0 && p < tn && tokIsText(L, toks[p], u"(")) {
                int close = matchGroup(L, toks, p, tn);
                if (close > 0) {
                    int bad = badParamsAt(L, toks, p + 1, close - 1);
                    if (bad >= 0)
                        probs_.push_back(Prob{(u32)i, toks[bad].start, toks[bad].end, 0, M_BAD_PARAMS});
                }
            }
        }
    }

    // ---- 裸调用：关键字参数后又有位置参数
    {
        uint8_t ft = toks[first].type;
        if (ft == T_TEXT || ft == T_BUILTIN || ft == T_SELF) {
            int p = first + 1;
            while (p + 1 < tn && tokIsText(L, toks[p], u".") && toks[p + 1].type == T_TEXT) p += 2;
            if (p < tn && tokIsText(L, toks[p], u"(")) {
                int close = matchGroup(L, toks, p, tn);
                int last = lastCode(toks);
                if (close > 0 && close - 1 == last) {
                    int bad = badCallArgsAt(L, toks, p + 1, close - 1);
                    if (bad >= 0)
                        probs_.push_back(Prob{(u32)i, toks[bad].start, toks[bad].end, 0, M_BAD_CALL_ARGS});
                }
            }
        }
    }

    // ---- 数字 / 字符串 / f-string
    for (const Tok& t : toks) {
        if (t.type == T_NUMBER) {
            if (badNumberTok(L, t, tokTextOf(L, t)))
                probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_BAD_NUMBER});
        } else if (t.type == T_STRING && !continued) {
            U16 text = tokTextOf(L, t);
            int q = 0;
            U16 prefix;
            bool triple = false;
            if (!stringHead(text, q, prefix, triple)) continue;
            if (triple) continue;
            bool isF = false;
            for (char16_t c : prefix) if (c == u'f' || c == u'F') isF = true;
            if (!stringClosed(text, q)) {
                // 行尾反斜杠续行（"abc\ 换行 def"）、f-string（有自己的检查）、
                // 单独一个引号（跨行 f-string 的收尾片段）先放过
                if (!isF && text.size() > 1 && text.back() != u'\\')
                    probs_.push_back(Prob{(u32)i, (u32)(t.start + q), (u32)t.end, 0, M_UNTERM_STRING_ONE});
                continue;
            }
            if (badFStringTok(L, t))
                probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_BAD_FSTRING});
        }
    }

    // ---- 模块级 await / yield（def / async def 的单行体除外）
    U16 firstKw = (toks[first].type == T_KEYWORD) ? tokTextOf(L, toks[first]) : U16();
    bool inlineDef = firstKw == u"def" ||
                     (firstKw == u"async" && first + 1 < tn &&
                      toks[first + 1].type == T_KEYWORD &&
                      tokTextOf(L, toks[first + 1]) == u"def");
    if (m.indent == 0 && m.depthStart == 0 && !inlineDef) {
        int depth = 0;
        for (const Tok& t : toks) {
            if (t.type == T_OPERATOR) {
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') depth++;
                    else if (c == u')' || c == u']' || c == u'}') depth--;
                }
            }
            if (depth == 0 && t.type == T_KEYWORD) {
                U16 kw = tokTextOf(L, t);
                if (kw == u"await" || kw == u"yield")
                    probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_SCOPE});
            }
        }
    }

    // ---- 海象 / except* / 星号右值 / type 语句 / 子句
    {
        int depth = 0;
        for (int k = 0; k < tn; k++) {
            const Tok& t = toks[k];
            if (t.type == T_OPERATOR) {
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') { depth++; continue; }
                    if (c == u')' || c == u']' || c == u'}') { depth--; continue; }
                }
                if (op == u":=") {
                    int j = k + 1;
                    while (j < tn && toks[j].type == T_COMMENT) j++;
                    bool missing = (j >= tn);
                    if (!missing && toks[j].type == T_OPERATOR) {
                        U16 nx = tokTextOf(L, toks[j]);
                        if (nx == u")" || nx == u"]" || nx == u"}" || nx == u"," ||
                            nx == u":" || nx == u";")
                            missing = true;
                    }
                    if (missing)
                        probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_MISSING_RHS});
                }
                if (op == u"=" && depth == 0) {
                    int j = k + 1;
                    while (j < tn && toks[j].type == T_COMMENT) j++;
                    if (j < tn && tokIsText(L, toks[j], u"**")) {
                        probs_.push_back(Prob{(u32)i, toks[j].start, toks[j].end, 0, M_BAD_STAR});
                    } else if (j < tn && tokIsText(L, toks[j], u"*")) {
                        int d = 0;
                        bool comma = false;
                        for (int q = j + 1; q < tn; q++) {
                            const Tok& u = toks[q];
                            if (u.type != T_OPERATOR) continue;
                            U16 o = tokTextOf(L, u);
                            if (o.size() != 1) continue;
                            char16_t c = o[0];
                            if (c == u'(' || c == u'[' || c == u'{') d++;
                            else if (c == u')' || c == u']' || c == u'}') d--;
                            else if (d == 0 && c == u',') comma = true;
                        }
                        if (!comma)
                            probs_.push_back(Prob{(u32)i, toks[j].start, toks[j].end, 0, M_BAD_STAR});
                    }
                }
            }
            if (t.type == T_KEYWORD && tokTextOf(L, t) == u"except" &&
                k + 1 < tn && tokIsText(L, toks[k + 1], u"*")) {
                int j = k + 2;
                while (j < tn && toks[j].type == T_COMMENT) j++;
                if (j >= tn || tokIsText(L, toks[j], u":") || tokIsText(L, toks[j], u";"))
                    probs_.push_back(Prob{(u32)i, toks[k].start, toks[k].end, 0, M_EXCEPT_STAR});
            }
        }
    }

    // ---- type 别名语句：type Alias / type Alias[T] 后面没有 =
    if (toks[first].type == T_BUILTIN && tokTextOf(L, toks[first]) == u"type" &&
        first + 1 < tn && toks[first + 1].type == T_TEXT) {
        bool hasAssign = false;
        int depth = 0;
        for (int k = first + 1; k < tn; k++) {
            const Tok& t = toks[k];
            if (t.type != T_OPERATOR) continue;
            U16 op = tokTextOf(L, t);
            if (op.size() == 1) {
                char16_t c = op[0];
                if (c == u'(' || c == u'[' || c == u'{') depth++;
                else if (c == u')' || c == u']' || c == u'}') depth--;
            }
            if (depth == 0 && op == u"=") hasAssign = true;
        }
        if (!hasAssign)
            probs_.push_back(Prob{(u32)i, toks[first].start, toks[first].end, 0, M_TYPE_STMT});
    }

    // ---- 子句缺少宿主
    if (!w0.empty() && (w0 == u"else" || w0 == u"elif" || w0 == u"except" ||
                        w0 == u"finally" || w0 == u"case") &&
        m.depthStart == 0 && lineHasTopColon(L, m) && !clauseHasOwner(i, w0)) {
        probs_.push_back(Prob{(u32)i, toks[first].start, toks[first].end, 0, M_ORPHAN_CLAUSE});
    }
}

// ------------------------------------------------------------------ check
void Doc::runCheck() {
    probs_.clear();
    struct Open {
        u32 line;
        u32 col;
        char16_t ch;
    };
    std::vector<Open> stack;
    const int n = (int)lines_.size();

    for (int i = 0; i < n; i++) {
        const U16& L = lines_[i];
        LineData& m = meta_[i];
        if (m.blank) continue;

        // indentation: inside an unclosed ( [ { Python lets you align freely,
        // so only judge lines that start at bracket depth 0.
        // 5.5.2: 三引号（多行注释 / docstring）内部的行也不算代码缩进。
        if (m.depthStart == 0 && m.strStart == 0) {
            size_t k = 0;
            bool tabIndent = false;
            for (; k < L.size() && (L[k] == u' ' || L[k] == u'\t'); k++) {
                if (L[k] == u'\t') tabIndent = true;
            }
            if (tabIndent) {
                probs_.push_back(Prob{(u32)i, 0, (u32)k, 1, M_TAB_INDENT});
            } else if (k > 0 && (int)k % tabSize_ != 0) {
                probs_.push_back(Prob{(u32)i, 0, (u32)k, 1, M_INDENT_STEP});
            }
        }

        // brackets
        for (const Tok& t : m.toks) {
            if (t.type != T_OPERATOR || t.end - t.start != 1) continue;
            char16_t c = L[t.start];
            if (c == u'(' || c == u'[' || c == u'{') {
                stack.push_back(Open{(u32)i, t.start, c});
            } else if (c == u')' || c == u']' || c == u'}') {
                if (stack.empty()) {
                    probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_EXTRA_CLOSE});
                } else {
                    char16_t o = stack.back().ch;
                    bool ok = (o == u'(' && c == u')') || (o == u'[' && c == u']') ||
                              (o == u'{' && c == u'}');
                    if (!ok) probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_MISMATCH_BRACKET});
                    stack.pop_back();
                }
            }
        }

        // 赋值目标 / 缺少右值：只判断整行括号配平的普通语句，避免把
        // f(a=1) / def f(x=1) / 跨行签名 这些合法的 `=` 误报。
        bool continued = i > 0 && endsWithBackslash(lines_[i - 1]);
        if (m.depthStart == 0 && m.depthEnd == 0 && m.strStart == 0 && !continued) {
            int depth = 0;
            int stmtStart = 0;
            bool inLambdaParams = false;
            for (int k = 0; k < (int)m.toks.size(); k++) {
                const Tok& t = m.toks[k];
                if (t.type == T_KEYWORD && tokTextOf(L, t) == u"lambda" && depth == 0)
                    inLambdaParams = true;
                if (t.type != T_OPERATOR) continue;
                U16 op = tokTextOf(L, t);
                if (op.size() == 1) {
                    char16_t c = op[0];
                    if (c == u'(' || c == u'[' || c == u'{') { depth++; continue; }
                    if (c == u')' || c == u']' || c == u'}') { depth--; continue; }
                    if (c == u';' && depth == 0) { stmtStart = k + 1; inLambdaParams = false; continue; }
                    if (c == u':' && depth == 0) {
                        if (inLambdaParams) { inLambdaParams = false; continue; }
                        // 单行复合语句：if x: y = 1 / for ...: y = 1 / finally: y = 1
                        // 只在这一段确实以块头关键字开头时才把冒号当语句分隔符，
                        // 否则它是类型注解（x: int = 1）或 lambda 的冒号。
                        int fi = stmtStart;
                        while (fi < k && m.toks[fi].type == T_COMMENT) fi++;
                        bool header = false;
                        if (fi < k && m.toks[fi].type == T_KEYWORD) {
                            U16 w = tokTextOf(L, m.toks[fi]);
                            header = isBlockHeaderKw(w);
                            if (w == u"async" && fi + 1 < k &&
                                m.toks[fi + 1].type == T_KEYWORD) {
                                U16 w2 = tokTextOf(L, m.toks[fi + 1]);
                                header = (w2 == u"def" || w2 == u"for" || w2 == u"with");
                            }
                        }
                        if (header) { stmtStart = k + 1; inLambdaParams = false; }
                        continue;
                    }
                }
                if (depth != 0 || !isAssignOpText(op)) continue;

                if (!inLambdaParams) {
                    int bad = invalidTargetListAt(L, m.toks, stmtStart, k);
                    if (bad >= 0) {
                        if (bad < (int)m.toks.size()) {
                            probs_.push_back(Prob{(u32)i, m.toks[bad].start, m.toks[bad].end, 0, M_INVALID_TARGET});
                        } else {
                            probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_INVALID_TARGET});
                        }
                    }
                }
                if (op == u"=") {
                    bool hasRhs = false;
                    for (int j = k + 1; j < (int)m.toks.size(); j++) {
                        if (m.toks[j].type == T_COMMENT) break;
                        hasRhs = true;
                        break;
                    }
                    if (!hasRhs) {
                        probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_MISSING_RHS});
                    }
                }
                stmtStart = k + 1;
            }
        }

        checkLineExtras(i);

        // block header checks (only when the line is complete)
        if (m.depthEnd == 0 && m.depthStart == 0) {
            size_t ti = 0;
            while (ti < m.toks.size() && m.toks[ti].type == T_COMMENT) ti++;
            if (ti < m.toks.size()) {
                const Tok& first = m.toks[ti];
                bool header = false;
                if (first.type == T_KEYWORD) header = isBlockHeaderKw(tokTextOf(L, first));
                if (!header && first.type == T_KEYWORD && tokTextOf(L, first) == u"async" &&
                    ti + 1 < m.toks.size() && m.toks[ti + 1].type == T_KEYWORD) {
                    U16 w = tokTextOf(L, m.toks[ti + 1]);
                    header = (w == u"def" || w == u"for" || w == u"with");
                }
                if (header) {
                    bool defNoParen = false;
                    if (tokTextOf(L, first) == u"def") {
                        bool hasParen = false;
                        for (const Tok& t : m.toks) {
                            if (t.type == T_OPERATOR && L[t.start] == u'(') { hasParen = true; break; }
                        }
                        defNoParen = !hasParen;
                    }
                    if (defNoParen) {
                        probs_.push_back(Prob{(u32)i, first.start, first.end, 0, M_DEF_PARENS});
                    }
                    // find a ':' at depth 0
                    int d = 0;
                    bool hasColon = false;
                    u32 colonPos = (u32)L.size();
                    for (const Tok& t : m.toks) {
                        if (t.type != T_OPERATOR) continue;
                        char16_t c = L[t.start];
                        if (c == u'(' || c == u'[' || c == u'{') d++;
                        else if (c == u')' || c == u']' || c == u'}') d--;
                        else if (d == 0 && t.end - t.start == 1 && c == u':') {
                            hasColon = true;
                            colonPos = t.start;
                            break;
                        }
                    }
                    if (!hasColon) {
                        probs_.push_back(Prob{(u32)i, (u32)L.size(), (u32)L.size(), 0, M_COLON});
                    } else {
                        // does the last code token sit right at the colon?
                        int last = -1;
                        for (int t = (int)m.toks.size() - 1; t >= 0; t--) {
                            if (m.toks[t].type == T_COMMENT) continue;
                            last = t;
                            break;
                        }
                        bool endsColon = last >= 0 && m.toks[last].type == T_OPERATOR &&
                                         m.toks[last].start == colonPos;
                        if (endsColon) {
                            // expect an indented block on the following non blank line
                            int j = i + 1;
                            while (j < n && meta_[j].blank) j++;
                            if (j >= n || meta_[j].indent <= m.indent) {
                                probs_.push_back(Prob{(u32)i, colonPos, colonPos + 1, 0, M_EXPECT_BLOCK});
                            }
                        }
                    }
                }
            }
        }
    }

    // unmatched opens
    for (size_t i = 0; i < stack.size() && i < 8; i++) {
        probs_.push_back(Prob{stack[i].line, stack[i].col, stack[i].col + 1, 0, M_OPEN_BRACKET});
    }

    // unterminated triple quoted string
    if (n > 0 && meta_[n - 1].strEnd != 0) {
        int startLine = n - 1;
        while (startLine > 0 && meta_[startLine].strStart != 0) startLine--;
        probs_.push_back(Prob{(u32)startLine, 0, 0, 0, M_UNTERM_STRING});
    }

    if (probs_.size() > 400) probs_.resize(400);
    probsDirty_ = false;
}

int Doc::problems(bool recheck, Prob*& out) {
    if (recheck || probsDirty_) runCheck();
    out = probs_.empty() ? nullptr : &probs_[0];
    return (int)probs_.size();
}

// ------------------------------------------------------------------ complete
static int matchScore(const U16& name, const U16& prefix) {
    if (prefix.empty()) return 1;
    if (name.size() < prefix.size()) {
        // subsequence only
        size_t i = 0;
        for (size_t j = 0; j < name.size() && i < prefix.size(); j++) {
            if (name[j] == prefix[i]) i++;
        }
        return 0;
    }
    bool pre = true;
    for (size_t i = 0; i < prefix.size(); i++) {
        if (name[i] != prefix[i]) { pre = false; break; }
    }
    if (pre) return (name.size() == prefix.size()) ? 4 : 3;
    bool ci = true;
    for (size_t i = 0; i < prefix.size(); i++) {
        char16_t a = name[i], b = prefix[i];
        if (a >= u'A' && a <= u'Z') a = (char16_t)(a - u'A' + u'a');
        if (b >= u'A' && b <= u'Z') b = (char16_t)(b - u'A' + u'a');
        if (a != b) { ci = false; break; }
    }
    if (ci) return 2;
    for (size_t st = 0; st + prefix.size() <= name.size(); st++) {
        bool ok = true;
        for (size_t i = 0; i < prefix.size(); i++) {
            if (name[st + i] != prefix[i]) { ok = false; break; }
        }
        if (ok) return 1;
    }
    return 0;
}

static int kindRank(uint8_t k) {
    switch (k) {
        case SK_CLASS: return 60;
        case SK_FUNC: return 55;
        case SK_PARAM: return 50;
        case SK_VAR: return 45;
        case SK_MODULE: return 40;
        case SK_ATTR: return 35;
        case SK_SNIPPET: return 70;
        case SK_KW: return 30;
        case SK_BUILTIN: return 25;
        case SK_CONST: return 20;
        default: return 0;
    }
}

std::vector<Candidate> Doc::complete(int maxItems) {
    rebuildSymbols();
    const U16& L = lines_[cl_];
    int end = cc_;
    if (end > (int)L.size()) end = (int)L.size();
    int start = end;
    while (start > 0 && isIdentCont(L[start - 1])) start--;
    U16 prefix = L.substr(start, end - start);
    bool attrMode = (start > 0 && L[start - 1] == u'.');

    std::vector<Candidate> raw;
    if (attrMode) {
        for (const U16& a : attrs_) raw.push_back(Candidate{a, SK_ATTR});
        for (const Sym& s : symList_) {
            if (s.kind == SK_FUNC || s.kind == SK_CLASS) raw.push_back(Candidate{s.name, s.kind});
        }
    } else {
        for (const Sym& s : symList_) raw.push_back(Candidate{s.name, s.kind});
        for (const U16& w : allKeywords()) raw.push_back(Candidate{w, SK_KW});
        for (const U16& w : allSnippets()) raw.push_back(Candidate{w, SK_SNIPPET});
        for (const U16& w : allConsts()) raw.push_back(Candidate{w, SK_CONST});
        for (const U16& w : allBuiltins()) raw.push_back(Candidate{w, SK_BUILTIN});
    }

    struct Ranked {
        int score;
        int rank;
        int len;
        Candidate c;
    };
    std::vector<Ranked> ranked;
    ranked.reserve(raw.size());
    std::unordered_set<U16> seen;
    for (auto& c : raw) {
        if (c.kind != SK_SNIPPET && !seen.insert(c.name).second) continue;
        int sc = matchScore(c.name, prefix);
        if (sc <= 0 && !prefix.empty()) continue;
        ranked.push_back(Ranked{sc, kindRank(c.kind), (int)c.name.size(), c});
    }
    std::sort(ranked.begin(), ranked.end(), [](const Ranked& a, const Ranked& b) {
        if (a.score != b.score) return a.score > b.score;
        if (a.rank != b.rank) return a.rank > b.rank;
        if (a.len != b.len) return a.len < b.len;
        return a.c.name < b.c.name;
    });
    // 名额分配：先每类取一个，再按排序补齐（避免 5 个变量把函数挤掉）
    std::vector<Candidate> out;
    out.reserve((size_t)maxItems);
    std::vector<char> used(ranked.size(), 0);
    std::unordered_set<int> kindsDone;
    for (size_t i = 0; i < ranked.size() && (int)out.size() < maxItems; i++) {
        int k = (int)ranked[i].c.kind;
        if (kindsDone.count(k)) continue;
        kindsDone.insert(k);
        used[i] = 1;
        out.push_back(Candidate{ranked[i].c.name, ranked[i].c.kind});
    }
    for (size_t i = 0; i < ranked.size() && (int)out.size() < maxItems; i++) {
        if (used[i]) continue;
        out.push_back(Candidate{ranked[i].c.name, ranked[i].c.kind});
    }
    return out;
}


// ------------------------------------------------------------------ snippets
void Doc::snapNow() {
    snap(false);
}

bool Doc::insertSnippet(const U16& text, int caretOffset) {
    if (text.empty()) return false;
    snap(false);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    int startLine = cl_, startCol = cc_;
    put(text);
    int tl = startLine, tc = startCol;
    int limit = std::min<int>(caretOffset, (int)text.size());
    for (int i = 0; i < limit; i++) {
        if (text[i] == u'\n') { tl++; tc = 0; }
        else tc++;
    }
    if (tl < (int)lines_.size()) {
        cl_ = tl;
        cc_ = std::min(tc, (int)lines_[tl].size());
    }
    hasSel_ = false;
    al_ = cl_;
    ac_ = cc_;
    desiredCol_ = cc_;
    return true;
}

// ------------------------------------------------------------------ find
static U16 lowerU16(const U16& s) {
    U16 o = s;
    for (auto& c : o) {
        if (c >= u'A' && c <= u'Z') c = (char16_t)(c - u'A' + u'a');
    }
    return o;
}

static bool isWordChar(char16_t c) {
    return (c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z') ||
           (c >= u'0' && c <= u'9') || c == u'_' || c > 127;
}

bool Doc::find(const U16& needle, int fromLine, int fromCol, bool ignoreCase, bool wholeWord,
               int* out3) {
    if (needle.empty()) return false;
    U16 nd = ignoreCase ? lowerU16(needle) : needle;
    int n = (int)lines_.size();
    if (fromLine < 0) fromLine = 0;
    for (int i = fromLine; i < n; i++) {
        const U16& L = lines_[i];
        U16 hay = ignoreCase ? lowerU16(L) : L;
        size_t startPos = (i == fromLine && fromCol > 0) ? (size_t)fromCol : 0;
        if (startPos > hay.size()) startPos = hay.size();
        size_t p = hay.find(nd, startPos);
        while (p != U16::npos) {
            bool ok = true;
            if (wholeWord) {
                if (p > 0 && isWordChar(L[p - 1])) ok = false;
                if (p + nd.size() < L.size() && isWordChar(L[p + nd.size()])) ok = false;
            }
            if (ok) {
                out3[0] = i;
                out3[1] = (int)p;
                out3[2] = (int)(p + nd.size());
                return true;
            }
            p = hay.find(nd, p + 1);
        }
    }
    return false;
}

bool Doc::replaceRange(int l1, int c1, int l2, int c2, const U16& text) {
    if (l1 < 0 || l1 >= (int)lines_.size()) return false;
    if (l2 < 0 || l2 >= (int)lines_.size()) return false;
    setSelection(l1, c1, l2, c2);
    if (text.empty()) {
        if (!hasSel_) return false;
        return backspace();
    }
    return insertText(text);
}

bool Doc::replaceWholeText(const U16& text, int caretLine, int caretCol) {
    snap(false);              // 整篇替换算一步撤销，但不清空撤销栈
    hasSel_ = false;
    loadJoined(text);
    cl_ = caretLine;
    cc_ = caretCol;
    clampCursor();
    al_ = cl_;
    ac_ = cc_;
    desiredCol_ = cc_;
    vMode_ = false;
    hasSel_ = false;
    return true;
}

// ------------------------------------------------------------------ folds
static bool isClauseKw(const U16& w) {
    return w == u"else" || w == u"elif" || w == u"except" || w == u"finally" || w == u"case";
}

static bool isBlockKw(const U16& w) {
    return w == u"def" || w == u"class" || w == u"if" || w == u"elif" || w == u"else" ||
           w == u"for" || w == u"while" || w == u"try" || w == u"except" ||
           w == u"finally" || w == u"with" || w == u"match" || w == u"case" ||
           w == u"async";
}

// 行首关键字 + 行尾（深度 0）冒号
static bool lineHeaderKw(const U16& L, const LineData& m, U16& kw) {
    if (m.depthEnd != 0) return false;
    int t0 = 0;
    while (t0 < (int)m.toks.size() && m.toks[t0].type == T_COMMENT) t0++;
    if (t0 >= (int)m.toks.size()) return false;
    const Tok& first = m.toks[t0];
    if (first.type != T_KEYWORD) return false;
    kw = L.substr(first.start, first.end - first.start);
    if (!isBlockKw(kw)) return false;
    // 最后一个非注释 token 必须是 ':'
    int last = -1;
    for (int t = (int)m.toks.size() - 1; t >= 0; t--) {
        if (m.toks[t].type == T_COMMENT) continue;
        last = t;
        break;
    }
    if (last < 0) return false;
    const Tok& lt = m.toks[last];
    if (lt.type != T_OPERATOR || lt.end - lt.start != 1 || L[lt.start] != u':') return false;
    return true;
}

static bool lineIsImport(const U16& L, const LineData& m) {
    int t0 = 0;
    while (t0 < (int)m.toks.size() && m.toks[t0].type == T_COMMENT) t0++;
    if (t0 >= (int)m.toks.size()) return false;
    const Tok& t = m.toks[t0];
    if (t.type != T_KEYWORD) return false;
    U16 w = L.substr(t.start, t.end - t.start);
    return w == u"import" || w == u"from";
}

void Doc::computeFolds() {
    // 未 lex 的行 blank/indent 都是默认值，会把后续行整段吞进折叠区，先补齐
    for (size_t i = 0; i < meta_.size(); i++) {
        if (meta_[i].rev == 0) {
            retokenize(0);
            break;
        }
    }
    folds_.clear();
    const int n = (int)lines_.size();
    for (int i = 0; i < n; i++) {
        LineData& m = meta_[i];
        if (m.blank) continue;
        if (lineIsImport(lines_[i], m)) {
            int j = i;
            while (j + 1 < n && !meta_[j + 1].blank && lineIsImport(lines_[j + 1], meta_[j + 1])) j++;
            if (j > i) folds_.push_back(Fold{i, j, 1});
            i = j;
            continue;
        }
        U16 kw;
        if (!lineHeaderKw(lines_[i], m, kw)) continue;
        if (isClauseKw(kw)) continue;
        int indent = m.indent;
        int j = i + 1;
        while (j < n && (meta_[j].blank || meta_[j].indent > indent)) j++;
        int end = j - 1;
        // 依次吞掉 else / elif / except / finally / case 子句
        while (j < n && !meta_[j].blank && meta_[j].indent == indent) {
            U16 ckw;
            if (!lineHeaderKw(lines_[j], meta_[j], ckw) || !isClauseKw(ckw)) break;
            int k = j + 1;
            while (k < n && (meta_[k].blank || meta_[k].indent > indent)) k++;
            end = k - 1;
            j = k;
        }
        while (end > i && meta_[end].blank) end--;   // 别吞掉尾部空行
        if (end > i) folds_.push_back(Fold{i, end, 0});
    }
    foldsDirty_ = false;
}

const std::vector<Fold>& Doc::folds() {
    if (foldsDirty_) computeFolds();
    return folds_;
}

U16 Doc::foldHeaderText(int startLine) {
    if (foldsDirty_) computeFolds();
    for (const Fold& f : folds_) {
        if (f.start != startLine) continue;
        if (f.kind == 1) return U16(u"import ...");
        U16 out;
        const LineData& m = meta_[startLine];
        int t0 = 0;
        while (t0 < (int)m.toks.size() && m.toks[t0].type == T_COMMENT) t0++;
        if (t0 >= (int)m.toks.size()) return U16(u"...");
        const Tok& first = m.toks[t0];
        out = lines_[startLine].substr(first.start, first.end - first.start);
        if (out == u"def" || out == u"class") {
            if (t0 + 1 < (int)m.toks.size()) {
                const Tok& nt = m.toks[t0 + 1];
                out += u" ";
                out += lines_[startLine].substr(nt.start, nt.end - nt.start);
            }
        }
        int indent = m.indent;
        int j = f.start + 1;
        while (j <= f.end) {
            if (!meta_[j].blank && meta_[j].indent == indent) {
                U16 ckw;
                if (lineHeaderKw(lines_[j], meta_[j], ckw) && isClauseKw(ckw)) {
                    out += u" ... ";
                    out += ckw;
                }
            }
            j++;
        }
        out += u" ...";
        return out;
    }
    return U16(u"...");
}

}  // namespace pe
