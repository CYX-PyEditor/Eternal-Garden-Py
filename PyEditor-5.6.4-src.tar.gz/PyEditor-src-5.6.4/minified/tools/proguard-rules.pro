# PyEditor 混淆白名单（R8）
-dontwarn **

# 清单里写死的组件：类名必须保留，成员也保留（Android 反射创建）
-keep class com.yhhy.pyeditor.MainActivity { *; }
-keep class com.yhhy.pyeditor.SettingsActivity { *; }
-keep class com.yhhy.pyeditor.PipActivity { *; }
-keep class com.yhhy.pyeditor.App { *; }

# JNI：类名 + 所有 native 方法名不能变
-keep class com.yhhy.pyeditor.Native { *; }
# 多编辑区自定义容器：覆盖 dispatchDraw/onInterceptTouchEvent 等，不能被改名/裁剪
-keep class com.yhhy.pyeditor.PaneLayout { *; }
# 5.5.0：MiniMap 侧边栏 / 大纲扫描（被 View 体系与反射式构造间接使用，保险起见整类保留）
-keep class com.yhhy.pyeditor.PaneHost { *; }
-keep class com.yhhy.pyeditor.MiniMapView { *; }
-keep class com.yhhy.pyeditor.DocOutline { *; }
-keep class com.yhhy.pyeditor.DocOutline$* { *; }
-keepclasseswithmembernames class * { native <methods>; }

# 生命周期/回调：所有 on* 方法保留（onCreate/onDraw/onTouchEvent…）
-keepclassmembers class * { *** on*(...); }

# Shizuku / XZ 是外部库，保持原样，避免反射/AIDL 踩坑
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep class org.tukaani.xz.** { *; }

# Android 13+ 预测性返回：系统按接口回调，实现类和 onBackInvoked 不能改名/删掉
-keep class com.yhhy.pyeditor.BackCompat { *; }
-keep class com.yhhy.pyeditor.BackCompat$** { *; }
-keep class * implements android.window.OnBackInvokedCallback { *; }
-keepclassmembers class * implements android.window.OnBackInvokedCallback {
    public void onBackInvoked();
}
-keep class * implements android.window.OnBackAnimationCallback { *; }
-keepclassmembers class * implements android.window.OnBackAnimationCallback {
    public void onBackStarted(android.window.BackEvent);
    public void onBackProgressed(android.window.BackEvent);
    public void onBackCancelled();
    public void onBackInvoked();
}

-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
