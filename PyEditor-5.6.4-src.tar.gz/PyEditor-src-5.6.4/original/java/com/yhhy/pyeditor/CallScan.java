package com.yhhy.pyeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

/**
 * 连续同名函数调用折叠（5.4.4）。
 *
 * <pre>
 * print(a,b,c)
 * print("gbjj")
 * print(bool)
 * </pre>
 * 折叠为 {@code print() * 3}。允许空行 / 注释间隔；只认「整行就是一个调用」的语句。
 */
final class CallScan {

    static final class Block {
        final int start;
        final int end;
        final String summary;

        Block(int s, int e, String sum) {
            start = s;
            end = e;
            summary = sum;
        }
    }

    private static final HashSet<String> STOP = new HashSet<>(Arrays.asList(
            "if", "elif", "else", "for", "while", "def", "class", "return", "yield",
            "import", "from", "try", "except", "finally", "with", "assert", "del",
            "global", "nonlocal", "raise", "pass", "break", "continue", "lambda",
            "match", "case", "async", "await"));

    private CallScan() {
    }

    static ArrayList<Block> scan(String[] txt) {
        ArrayList<Block> out = new ArrayList<>();
        if (txt == null || txt.length == 0) return out;
        int n = txt.length;
        int i = 0;
        while (i < n) {
            String name = callName(txt[i]);
            if (name == null) {
                i++;
                continue;
            }
            int first = i, last = i, count = 1;
            int j = i + 1;
            while (j < n) {
                if (txt[j].trim().isEmpty() || isComment(txt[j])) {
                    j++;
                    continue;
                }
                String nm = callName(txt[j]);
                if (nm == null || !nm.equals(name)) break;
                last = j;
                count++;
                j++;
            }
            if (count >= 2) out.add(new Block(first, last, name + "() * " + count));
            i = count >= 2 ? last + 1 : i + 1;
        }
        return out;
    }

    /** 整行是一个函数调用时返回函数名（可带点），否则 null。 */
    static String callName(String raw) {
        String s = stripComment(raw).trim();
        if (s.isEmpty() || s.startsWith("@") || s.startsWith("#")) return null;
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '.') i++;
            else break;
        }
        if (i == 0 || i >= s.length() || s.charAt(i) != '(') return null;
        String name = s.substring(0, i);
        if (!isDottedName(name)) return null;
        String head = name;
        int dot = head.indexOf('.');
        if (dot >= 0) head = head.substring(0, dot);
        if (STOP.contains(head)) return null;
        int close = matchParen(s, i);
        if (close < 0) return null;
        String rest = s.substring(close + 1).trim();
        return rest.isEmpty() ? name : null;
    }

    private static int matchParen(String s, int open) {
        int depth = 0;
        char q = 0;
        boolean inStr = false;
        boolean inTriple = false;
        for (int i = open; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inTriple) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q && i + 2 < s.length() && s.charAt(i + 1) == q && s.charAt(i + 2) == q) {
                    i += 2;
                    inTriple = false;
                }
                continue;
            }
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                if (i + 2 < s.length() && s.charAt(i + 1) == c && s.charAt(i + 2) == c) {
                    inTriple = true;
                    i += 2;
                } else {
                    inStr = true;
                }
                q = c;
                continue;
            }
            if (c == '(') depth++;
            else if (c == ')') {
                depth--;
                if (depth == 0) return i;
            }
        }
        return -1;
    }

    private static boolean isDottedName(String s) {
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (!(Character.isLetter(c) || c == '_')) return false;
            i++;
            while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
            if (i == s.length()) return true;
            if (s.charAt(i) != '.') return false;
            i++;
            if (i == s.length()) return false;
        }
        return false;
    }

    private static boolean isComment(String s) {
        return s.trim().startsWith("#");
    }

    private static String stripComment(String s) {
        char q = 0;
        boolean inStr = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                inStr = true;
                q = c;
                continue;
            }
            if (c == '#') return s.substring(0, i);
        }
        return s;
    }
}
