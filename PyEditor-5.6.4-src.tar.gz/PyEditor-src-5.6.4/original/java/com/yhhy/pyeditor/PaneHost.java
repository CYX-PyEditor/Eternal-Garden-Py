package com.yhhy.pyeditor;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/**
 * 一个编辑区（5.5.0）：{@link EditorView} + 右侧的 {@link MiniMapView}。
 *
 * <p>MiniMap 打开时<b>挤压</b> EditorView 的宽度（桌面 IDE 右侧栏的做法），
 * 编辑区整体变窄，miniMap 不悬浮在正文上。每个 Pane 各有一个 PaneHost，
 * 多编辑区下各自独立；分割线挤掉 / 换位时整个 PaneHost 一起移动，miniMap 状态不丢。
 */
class PaneHost extends FrameLayout {

    interface Listener {
        /** MiniMap 正在打开：MainActivity 用它收起其它区的 miniMap。 */
        void onMinimapOpened(PaneHost host);
    }

    private final EditorView editor;
    private final MiniMapView minimap;
    private final int mapWidth;
    private boolean enabled = true;
    private float frac;
    private ValueAnimator anim;
    private Listener listener;

    PaneHost(Context ctx, EditorView ev) {
        super(ctx);
        editor = ev;
        minimap = new MiniMapView(ctx, ev);
        mapWidth = Math.round(56 * ctx.getResources().getDisplayMetrics().density);
        addView(ev, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(minimap, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        setClipChildren(true);
        ev.setMiniMap(minimap);
    }

    EditorView editor() {
        return editor;
    }

    MiniMapView minimap() {
        return minimap;
    }

    void setListener(Listener l) {
        listener = l;
    }

    void applyTheme(Theme t) {
        minimap.setTheme(t);
    }

    void setMinimapEnabled(boolean on) {
        enabled = on;
        if (!on) closeMinimap();
    }

    boolean isMinimapOpen() {
        return frac > 0.001f;
    }

    void openMinimap() {
        if (!enabled) return;
        if (listener != null) listener.onMinimapOpened(this);
        minimap.refreshNow();   // 打开时立刻按当前文本算一次大纲
        animateTo(1f);
    }

    void closeMinimap() {
        animateTo(0f);
    }

    void toggleMinimap() {
        if (isMinimapOpen()) closeMinimap();
        else openMinimap();
    }

    private void animateTo(float to) {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        if (Math.abs(frac - to) < 0.001f) {
            setFrac(to);
            return;
        }
        final ValueAnimator a = ValueAnimator.ofFloat(frac, to);
        a.setDuration(to > frac ? 150 : 120);
        a.setInterpolator(new DecelerateInterpolator(1.5f));
        a.addUpdateListener(an -> setFrac((Float) an.getAnimatedValue()));
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (anim == a) {
                    anim = null;
                    setFrac(to);
                }
            }
        });
        anim = a;
        a.start();
    }

    private void setFrac(float f) {
        f = Math.max(0f, Math.min(1f, f));
        if (f == frac) return;
        frac = f;
        editor.setMinimapOpen(f > 0.001f);
        requestLayout();
        minimap.invalidate();
    }

    private int mapWidthNow(int w) {
        int mw = Math.round(mapWidth * frac);
        if (mw > w / 2) mw = w / 2;
        return Math.max(0, Math.min(w, mw));
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int h = MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(w, h);
        int mw = mapWidthNow(w);
        editor.measure(MeasureSpec.makeMeasureSpec(Math.max(1, w - mw), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(Math.max(1, h), MeasureSpec.EXACTLY));
        minimap.measure(MeasureSpec.makeMeasureSpec(mw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(Math.max(1, h), MeasureSpec.EXACTLY));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l, h = b - t;
        int mw = mapWidthNow(w);
        editor.layout(0, 0, Math.max(1, w - mw), h);
        minimap.layout(w - mw, 0, w, h);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }
}
