package com.yhhy.pyeditor;

import android.app.Application;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Writes crash traces to the app's external files dir so they can be inspected. */
public class App extends Application {

    public static File dir;

    @Override
    public void onCreate() {
        super.onCreate();
        Lang.init(this);
        try {
            dir = getExternalFilesDir(null);
        } catch (Throwable ignored) {
        }
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                if (dir == null) dir = getExternalFilesDir(null);
                if (dir != null) {
                    File f = new File(dir, "crash.txt");
                    FileWriter w = new FileWriter(f, false);
                    w.write(stamp() + " thread=" + t.getName() + "\n");
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    w.write(sw.toString());
                    w.close();
                }
            } catch (Throwable ignored) {
            }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static String stamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }

    /** 追加写（带时间戳），用于排查「保存/恢复」这类需要历史的问题；超过 32KB 自动重来。 */
    static void noteAppend(String name, String text) {
        try {
            File d = dir;
            if (d == null) return;
            File f = new File(d, name);
            if (f.length() > 32 * 1024) f.delete();
            FileWriter w = new FileWriter(f, true);
            w.write(stamp() + " " + text + "\n");
            w.close();
        } catch (Throwable ignored) {
        }
    }

    /** 原样同步写（不写时间戳、flush + fsync），用于「关掉软件也要记住」的落盘。 */
    static boolean writeRaw(String name, String text) {
        try {
            File d = dir;
            if (d == null) return false;
            File f = new File(d, name);
            FileOutputStream out = new FileOutputStream(f);
            out.write(text.getBytes("UTF-8"));
            out.flush();
            try {
                out.getFD().sync();
            } catch (Throwable ignored) {
            }
            out.close();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static void note(String name, String text) {
        try {
            File d = dir != null ? dir : null;
            if (d == null) return;
            FileWriter w = new FileWriter(new File(d, name), false);
            w.write(stamp() + " " + text);
            w.close();
        } catch (Throwable ignored) {
        }
    }
}
