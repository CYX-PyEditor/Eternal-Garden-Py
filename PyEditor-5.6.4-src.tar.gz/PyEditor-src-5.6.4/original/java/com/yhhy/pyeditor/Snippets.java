package com.yhhy.pyeditor;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * 代码片段注册表：内置默认 + 用户自定义 / 覆盖 / 删除。
 *
 * <p>模板里的 {@code ${cursor}} 是「插入后最终光标位置」；用户编辑时用 {@link #CURSOR}
 * （{@code ${cursor}}）书写，保存时换成控制符，显示时再换回来。不写标记则光标停在末尾。
 * 存 SharedPreferences（与 {@link Prefs} 同一个文件，键前缀 snippet_）。
 */
public final class Snippets {

    /** 编辑框里代表最终光标位置的占位符。 */
    public static final String CURSOR = "${cursor}";
    static final char MARK = '\u0001';

    private static final String K_OVERRIDE = "snippet_overrides";
    private static final String K_DELETED = "snippet_deleted";
    private static final String K_CUSTOM = "snippet_custom";

    /** 内置片段（初始化时的默认模板，不会被就地修改）。 */
    private static final String[][] DEFAULT = {
            {"while", "while True:\n    ${cursor}\n"},
            {"try", "try:\n    ${cursor}\nexcept Exception as e:\n    pass\n"},
            {"for", "for i in range(${cursor}):\n    pass\n"},
            {"def", "def ${cursor}():\n    pass\n"},
            {"class", "class ${cursor}:\n    pass\n"},
            {"if", "if ${cursor}:\n    pass\n"},
            {"main", "if __name__ == \"__main__\":\n    ${cursor}\n"},
            {"elif", "elif ${cursor}:\n    pass\n"},
            {"else", "else:\n    ${cursor}\n"},
            {"tryf", "try:\n    ${cursor}\nexcept Exception as e:\n    pass\nfinally:\n    pass\n"},
            {"trye", "try:\n    ${cursor}\nexcept ValueError as e:\n    pass\nelse:\n    pass\n"},
            {"with", "with open(\"${cursor}\") as f:\n    pass\n"},
            {"match", "match ${cursor}:\n    case _:\n        pass\n"},
            {"async", "async def ${cursor}():\n    pass\n"},
            {"lambda", "lambda x: ${cursor}"},
            {"comp", "[${cursor} for x in items]"},
            {"dcomp", "{k: v for k, v in ${cursor}.items()}"},
            {"decor", "@${cursor}\ndef wrapper(fn):\n    pass\n"},
            {"prop", "@property\ndef ${cursor}(self):\n    return self._x\n"},
            {"init", "def __init__(self${cursor}):\n    pass\n"},
            {"fori", "for i, x in enumerate(${cursor}):\n    pass\n"},
    };

    /** 一个片段。builtin 表示来自内置表；edited 表示内置被用户改过。 */
    public static final class Item {
        public final String trigger;
        public final String body;
        public final boolean builtin;
        public final boolean edited;

        Item(String t, String b, boolean bi, boolean ed) {
            trigger = t;
            body = b;
            builtin = bi;
            edited = ed;
        }
    }

    private Snippets() {
    }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("pyedit", Context.MODE_PRIVATE);
    }

    // ---------------------------------------------------------------- 读
    private static JSONObject overrides(Context c) {
        try {
            return new JSONObject(p(c).getString(K_OVERRIDE, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static HashSet<String> deleted(Context c) {
        HashSet<String> set = new HashSet<>();
        try {
            JSONArray a = new JSONArray(p(c).getString(K_DELETED, "[]"));
            for (int i = 0; i < a.length(); i++) set.add(a.getString(i));
        } catch (Exception ignored) {
        }
        return set;
    }

    private static ArrayList<Item> customs(Context c) {
        ArrayList<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString(K_CUSTOM, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                String t = o.optString("t", "");
                String b = o.optString("b", "");
                if (t.isEmpty() || b.isEmpty()) continue;
                if (!isValidName(t)) continue;
                out.add(new Item(t, b, false, false));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static void writeCustoms(Context c, List<Item> list) {
        JSONArray a = new JSONArray();
        for (Item it : list) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", it.trigger);
                o.put("b", it.body);
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        p(c).edit().putString(K_CUSTOM, a.toString()).apply();
    }

    /** 全部内置（含被删的，编辑页要能恢复）。body 为覆盖后的模板。 */
    public static List<Item> allBuiltins(Context c) {
        JSONObject ov = overrides(c);
        ArrayList<Item> out = new ArrayList<>();
        for (String[] d : DEFAULT) {
            String body = ov.optString(d[0], null);
            String use = body == null || body.isEmpty() ? d[1] : body;
            out.add(new Item(d[0], use, true, body != null && !body.isEmpty()));
        }
        return out;
    }

    /** 内置片段里当前被用户删掉的。 */
    public static List<String> deletedBuiltins(Context c) {
        HashSet<String> del = deleted(c);
        ArrayList<String> out = new ArrayList<>();
        for (String[] d : DEFAULT) if (del.contains(d[0])) out.add(d[0]);
        return out;
    }

    public static List<Item> allCustoms(Context c) {
        return customs(c);
    }

    /** 补全候选里要用的片段：未删的内置（含覆盖）+ 自定义。 */
    public static List<Item> all(Context c) {
        ArrayList<Item> out = new ArrayList<>();
        HashSet<String> del = deleted(c);
        for (Item it : allBuiltins(c)) {
            if (!del.contains(it.trigger)) out.add(it);
        }
        out.addAll(customs(c));
        return out;
    }

    /** 名字 → 插入模板（带 ${cursor}）；不是片段返回 null。 */
    public static String template(Context c, String trigger) {
        if (trigger == null) return null;
        if (deleted(c).contains(trigger)) {
            for (Item it : customs(c)) if (it.trigger.equals(trigger)) return it.body;
            return null;
        }
        JSONObject ov = overrides(c);
        for (String[] d : DEFAULT) {
            if (!d[0].equals(trigger)) continue;
            String body = ov.optString(trigger, null);
            return body == null || body.isEmpty() ? d[1] : body;
        }
        for (Item it : customs(c)) if (it.trigger.equals(trigger)) return it.body;
        return null;
    }

    public static boolean isBuiltinName(String trigger) {
        for (String[] d : DEFAULT) if (d[0].equals(trigger)) return true;
        return false;
    }

    // ---------------------------------------------------------------- 写
    /**
     * 新增 / 修改一个片段。
     *
     * @param original 原来的名字（新增传 null）
     * @param builtin  改的是不是内置片段（内置不允许改名）
     * @return 错误信息；成功返回 null
     */
    public static String save(Context c, String original, boolean builtin,
                              String trigger, String body) {
        String t = trigger == null ? "" : trigger.trim();
        if (t.isEmpty()) return Lang.s("片段名不能为空");
        if (!isValidName(t)) return Lang.s("片段名只能用字母 / 数字 / 下划线，且不能以数字开头");
        if (builtin) t = original;   // 内置名固定
        String b = normalize(body);
        if (SnippetTemplate.plainText(b).trim().isEmpty()) return Lang.s("模板不能为空");
        if (b.length() > 4000) return Lang.s("模板太长了（上限 4000 字符）");

        if (!builtin) {
            if (isBuiltinName(t)) return Lang.s("片段名和内置片段冲突：") + t;
        }
        if (!t.equals(original) || !builtin) {
            for (Item it : all(c)) {
                if (it.trigger.equals(t) && !it.trigger.equals(original)) return Lang.s("片段名已存在：") + t;
            }
        }

        if (builtin) {
            if (b.equals(defaultBody(original))) {
                // 和默认一样就不留覆盖
                JSONObject ov = overrides(c);
                ov.remove(original);
                p(c).edit().putString(K_OVERRIDE, ov.toString()).apply();
            } else {
                JSONObject ov = overrides(c);
                try {
                    ov.put(original, b);
                } catch (Exception e) {
                    return Lang.s("保存失败");
                }
                p(c).edit().putString(K_OVERRIDE, ov.toString()).apply();
            }
            HashSet<String> del = deleted(c);
            if (del.remove(original)) {
                p(c).edit().putString(K_DELETED, toArray(del)).apply();
            }
            return null;
        }

        ArrayList<Item> cs = customs(c);
        int idx = -1;
        for (int i = 0; i < cs.size(); i++) {
            if (cs.get(i).trigger.equals(original)) {
                idx = i;
                break;
            }
        }
        Item ni = new Item(t, b, false, false);
        if (idx >= 0) {
            cs.set(idx, ni);
        } else {
            cs.add(ni);
        }
        writeCustoms(c, cs);
        return null;
    }

    /** 删除一个片段：内置记为“已删”，自定义直接移除。 */
    public static void remove(Context c, Item it) {
        if (it == null) return;
        if (it.builtin) {
            HashSet<String> del = deleted(c);
            del.add(it.trigger);
            JSONObject ov = overrides(c);
            ov.remove(it.trigger);
            p(c).edit().putString(K_DELETED, toArray(del))
                    .putString(K_OVERRIDE, ov.toString()).apply();
            return;
        }
        ArrayList<Item> cs = customs(c);
        for (int i = cs.size() - 1; i >= 0; i--) {
            if (cs.get(i).trigger.equals(it.trigger)) cs.remove(i);
        }
        writeCustoms(c, cs);
    }

    /** 内置恢复默认：去掉覆盖和删除标记。 */
    public static void resetBuiltin(Context c, String trigger) {
        JSONObject ov = overrides(c);
        ov.remove(trigger);
        HashSet<String> del = deleted(c);
        del.remove(trigger);
        p(c).edit().putString(K_OVERRIDE, ov.toString())
                .putString(K_DELETED, toArray(del)).apply();
    }

    /** 所有内置恢复默认（自定义片段保留）。 */
    public static void resetAllBuiltins(Context c) {
        p(c).edit().remove(K_OVERRIDE).remove(K_DELETED).apply();
    }

    // ---------------------------------------------------------------- 工具
    private static String defaultBody(String trigger) {
        for (String[] d : DEFAULT) if (d[0].equals(trigger)) return d[1];
        return "";
    }

    private static String toArray(HashSet<String> set) {
        JSONArray a = new JSONArray();
        for (String s : set) a.put(s);
        return a.toString();
    }

    /** 编辑框里的写法 → 存储用模板（${cursor} → ${cursor}）。 */
    public static String normalize(String text) {
        if (text == null) return "";
        // 统一存成 ${cursor} / ${cursorN} 文本；旧数据里的 \u0001 也转过来
        return text.replace(String.valueOf(MARK), CURSOR);
    }

    /** 存储用模板 → 编辑框里的写法（${cursor} → ${cursor}）。 */
    public static String display(String body) {
        if (body == null) return "";
        return body.replace(String.valueOf(MARK), CURSOR);
    }

    /** 列表里的一行预览：换行变成 ⏎，光标标记显示成 |。 */
    public static String preview(String body, int max) {
        if (body == null) return "";
        String s = SnippetTemplate.preview(body)
                .replace("\r", "")
                .replace("\n", " ⏎ ");
        if (s.length() > max) s = s.substring(0, Math.max(0, max - 1)) + "…";
        return s;
    }

    public static boolean isValidName(String t) {
        if (t == null || t.isEmpty()) return false;
        char c0 = t.charAt(0);
        if (!((c0 >= 'a' && c0 <= 'z') || (c0 >= 'A' && c0 <= 'Z') || c0 == '_')) return false;
        for (int i = 1; i < t.length(); i++) {
            char c = t.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9') || c == '_')) return false;
        }
        return true;
    }
}
