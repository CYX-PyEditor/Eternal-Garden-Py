package com.yhhy.pyeditor;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/**
 * 5.6.0 自定义主题仓库。
 *
 * <p>删掉 Monokai / Solarized 两个英文内置主题后，用户可以把当前整套配色存成
 * 一个自己命名的主题，保存在 App 里（SharedPreferences {@code pyedit_custom_themes}），
 * 下次启动还在，可以多个、可以删除。
 *
 * <p>存储格式：
 * <ul>
 *   <li>{@code names} —— 主题名，用 {@code \n} 连接，顺序就是设置页的显示顺序；</li>
 *   <li>{@code d_<名字>} —— {@link Theme#encode()} 出来的整篇配色。</li>
 * </ul>
 * 名字只去掉换行和控制字符，其余原样保留（中文、空格、emoji 都可以）。
 */
final class CustomThemes {

    private static final String PREF = "pyedit_custom_themes";
    private static final String KEY_NAMES = "names";

    private CustomThemes() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** 所有自定义主题名（保持保存顺序）。 */
    static List<String> names(Context c) {
        ArrayList<String> out = new ArrayList<>();
        String all = sp(c).getString(KEY_NAMES, "");
        if (all == null || all.isEmpty()) return out;
        for (String s : all.split("\n")) {
            String n = clean(s);
            if (!n.isEmpty() && !out.contains(n)) out.add(n);
        }
        return out;
    }

    private static String clean(String name) {
        if (name == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < name.length() && sb.length() < 24; i++) {
            char ch = name.charAt(i);
            if (ch == '\n' || ch == '\r' || ch == '\t') continue;
            sb.append(ch);
        }
        return sb.toString().trim();
    }

    /** 新增 / 覆盖同名主题，返回最终使用的名字（可能被裁剪过）。 */
    static String save(Context c, String name, Theme t) {
        String n = clean(name);
        if (n.isEmpty()) n = "自定义";
        Theme copy = new Theme();
        copy.copyFrom(t);
        copy.themeName = n;
        SharedPreferences.Editor e = sp(c).edit();
        e.putString("d_" + n, copy.encode());
        List<String> list = names(c);
        if (!list.contains(n)) list.add(n);
        e.putString(KEY_NAMES, join(list));
        e.apply();
        return n;
    }

    static Theme load(Context c, String name) {
        String n = clean(name);
        if (n.isEmpty()) return null;
        return Theme.decode(sp(c).getString("d_" + n, null), n);
    }

    static void delete(Context c, String name) {
        String n = clean(name);
        if (n.isEmpty()) return;
        SharedPreferences.Editor e = sp(c).edit();
        e.remove("d_" + n);
        List<String> list = names(c);
        list.remove(n);
        e.putString(KEY_NAMES, join(list));
        e.apply();
    }

    private static String join(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        return sb.toString();
    }
}
