package com.yhhy.pyeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity implements EditorView.Listener {

    private static final int REQ_OPEN = 1001;
    private static final int REQ_SAVE_AS = 1002;

    private EditorView editor;
    private PaneLayout paneLayout;
    private final java.util.ArrayList<Pane> panes = new java.util.ArrayList<>();
    private Pane focusedPane;
    private TextView plusBtn;
    private boolean panePick;
    private int pendingReplaceTab = -1;
    private android.widget.FrameLayout shell;
    private View drawerScrim;
    private LinearLayout drawer;
    private LinearLayout statusBar;
    /** 5.6.0：同一个状态栏也可以放到顶部（设置里按方向选）。 */
    private LinearLayout statusBarTop;
    private android.widget.FrameLayout.LayoutParams drawerLp;
    private int drawerBgUsed;
    private LinearLayout drawerFiles;
    private boolean drawerOpen;
    private int drawerWidth;
    private RunPanel runPanel;
    private FindBar findBar;
    private Object backToken;
    private TextView titleView;
    private TextView statusView;
    private TextView statusViewTop;
    /** 5.6.0：顶栏（常用栏）里的紧凑状态（行/列 + 问题数）。 */
    private TextView topStatus;
    private TextView undoBtn, redoBtn;
    private LinearLayout topBar;
    private Theme theme;

    // ---------------- 5.6.0 多区：一个区可以是编辑区 / 终端 / 解释器
    static final int KIND_EDITOR = 0, KIND_TERM = 1, KIND_INTERP = 2;

    /**
     * 一个「区」：编辑区（EditorView + MiniMap）或终端 / 解释器区。
     *
     * <p>终端和解释器没有文件，所以 {@code tabIdx} 只有编辑区用；换位时整个区（View 实例）
     * 一起换位置，终端 / 解释器不参与文件交换 —— 它们本来就没有文件。
     */
    private static class Pane {
        int kind = KIND_EDITOR;
        EditorView view;
        PaneHost host;
        TerminalPanel term;
        RunPanel repl;
        int tabIdx = -1;

        boolean isEditor() {
            return kind == KIND_EDITOR;
        }

        View root() {
            if (kind == KIND_TERM) return term;
            if (kind == KIND_INTERP) return repl;
            return host != null ? host : view;
        }
    }


    private static class Tab {
        String name;
        Uri uri;
        String text;
        int line, col;
        boolean dirty;
    }

    private final java.util.ArrayList<Tab> tabs = new java.util.ArrayList<>();
    private int curTab = -1;
    private Uri currentUri;
    private String currentName = Lang.s("未命名.py");
    private boolean loading;
    /** 正在恢复分区：期间不要落盘（否则会把恢复了一半的状态写进去）。 */
    private boolean restoringZones;
    /** 焦点 / 文件切换这类小变化用 400ms 防抖落盘（结构变化是立刻落盘）。 */
    private final android.os.Handler zoneHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable zoneSaveLater = () -> saveZoneState();

    /** 欢迎文档：语言设置改了以后要重新生成，所以不做 static final。 */
    private static String welcomeText() {
        return Lang.s("# 欢迎使用 YHHYPy\n")
                + Lang.s("# 支持语法高亮 / 智能补全 / 语法检查\n\n")
                + "def greet(name):\n"
                    + "    message = \"Hello, \" + name\n"
                    + "    print(message)\n"
                    + "    return message\n\n\n"
                    + "class Greeter:\n"
                    + "    def __init__(self, prefix):\n"
                    + "        self.prefix = prefix\n\n"
                    + "    def run(self, who):\n"
                    + "        return self.prefix + who\n\n\n"
                    + "if __name__ == \"__main__\":\n"
                    + "    greet(\"Python\")\n"
                    + "    Greeter(\"> \").run(\"world\")\n";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        theme = Theme.load(this);
        getWindow().setStatusBarColor(theme.statusBg);
        getWindow().setNavigationBarColor(theme.statusBg);
        buildUi();
        editor.setSyntaxCheckEnabled(Prefs.syntaxCheck(this));
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            backToken = BackCompat.registerAnimated(this, new BackCompat.Anim() {
                @Override
                public void onStart() {
                    predictiveStart();
                }

                @Override
                public void onProgress(float progress) {
                    predictiveProgress(progress);
                }

                @Override
                public void onCancel() {
                    predictiveCancel();
                }

                @Override
                public void onInvoke() {
                    predictiveInvoke();
                }
            });
        } else {
            backToken = BackCompat.register(this, this::handleBack);
        }
        App.note("start.txt", "ok lines=" + Native.nativeLineCount(editor.docHandle()));
        try {
            Shizuku.addRequestPermissionResultListener((code, res) -> updateTerminalZones());
            Shizuku.addBinderReceivedListener(MainActivity.this::updateTerminalZones);
        } catch (Throwable ignored) {
        }
        // 5.6.0：点进终端输入框 / 解释器输出时，把「焦点区」切过去
        try {
            getWindow().getDecorView().getViewTreeObserver()
                    .addOnGlobalFocusChangeListener((oldV, newV) -> {
                        if (newV == null) return;
                        Pane p = paneContaining(newV);
                        if (p != null) focusPane(p);
                    });
        } catch (Throwable ignored) {
        }
        // 5.6.1：关掉软件时的分区会记住，这里先恢复；恢复成功就不再走「打开上次的文件」
        boolean zones = restoreZones();
        if (zones) {
            Uri ext = intentUri();
            if (ext != null) openUriInto(ext, focusedPane);
        } else if (!restoreFromIntent()) {
            loadLastOrDefault();
        }
        Immersive.apply(this);
        Immersive.applyStatusBarIcons(this, theme.statusBg);
    }

    /** 所有终端区（Shizuku 授权变化后刷新身份显示）。 */
    private void updateTerminalZones() {
        for (Pane p : panes) if (p.term != null) p.term.updateMode();
    }

    /** 从某个获得焦点的子 View 往上找它属于哪个区。 */
    private Pane paneContaining(View v) {
        View cur = v;
        for (int depth = 0; cur != null && depth < 24; depth++) {
            for (Pane p : panes) {
                if (p.root() == cur) return p;
            }
            if (!(cur.getParent() instanceof View)) break;
            cur = (View) cur.getParent();
        }
        return null;
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        Immersive.apply(this);
        if (paneLayout != null) paneLayout.requestLayout();
        updateStatusBarVisibility();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        // 某些 ROM 在对话框 / 切后台后会把 immersive sticky 留在竖屏上，失焦恢复时再校正
        if (hasFocus) Immersive.apply(this);
    }

    private float d(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    // ---------------------------------------------------------------- 多区
    /** 排布偏好（1×2 / 1×3 / 2×2）；手机、平板都能改，区数不再受它限制。 */
    private int layoutMode() {
        return Prefs.zoneLayout(this);
    }

    /** 最多放几个区：和布局偏好无关，统一 {@link PaneLayout#MAX_ZONES}。 */
    private int maxZones() {
        return PaneLayout.MAX_ZONES;
    }

    private int editorCount() {
        int c = 0;
        for (Pane p : panes) if (p.isEditor()) c++;
        return c;
    }

    private Pane createEditorPane() {
        final Pane p = new Pane();
        p.kind = KIND_EDITOR;
        p.view = new EditorView(this);
        p.host = new PaneHost(this, p.view);
        p.view.setTheme(theme, true);
        p.host.applyTheme(theme);
        p.host.setMinimapEnabled(Prefs.miniMap(this));
        p.host.setListener(h -> closeMinimapsExcept(p));
        p.view.setSyntaxCheckEnabled(Prefs.syntaxCheck(this));
        p.view.setListener(new PaneListener(p));
        p.view.setEdgeSwipeListener(new EditorView.EdgeSwipeListener() {
            @Override
            public void onProgress(float progress) {
                edgeSwipeProgress(progress);
            }

            @Override
            public void onEnd(boolean open) {
                edgeSwipeEnd(open);
            }
        });
        p.view.setAnnotationListener(name -> {
            focusPane(p);
            if (findBar == null) return;
            findBar.setEditor(p.view);
            findBar.open(name);
        });
        // 右侧边缘向左滑 → 呼出本区的 MiniMap（每个区独立）
        p.view.setMapGestureListener(() -> {
            focusPane(p);
            openMinimap(p);
        });
        // 点正文（MiniMap 外部）→ 立刻收起
        p.view.setMapTapListener(() -> {
            if (p.host != null && p.host.isMinimapOpen()) p.host.closeMinimap();
        });
        p.view.setOnFocusChangeListener((vv, has) -> {
            if (has) focusPane(p);
        });
        // 点任何位置（含行号栏）都先把焦点切到这个区
        p.view.setOnTouchListener((vv, ev) -> {
            if (ev.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) {
                focusPane(p);
                closeMinimapsExcept(p);
            }
            return false;
        });
        panes.add(p);
        if (focusedPane == null) {
            focusedPane = p;
            editor = p.view;
        }
        updatePlusButton();
        updateStatusBarVisibility();
        return p;
    }

    /** 5.6.0：新建一个终端区（Shell）。 */
    private Pane createTermPane() {
        final Pane p = new Pane();
        p.kind = KIND_TERM;
        p.term = new TerminalPanel(this, theme, () -> removeZone(p), Prefs.termDir(this));
        p.term.setZoneMode(true);
        panes.add(p);
        p.term.open();
        updatePlusButton();
        updateStatusBarVisibility();
        return p;
    }

    /** 5.6.0：新建一个解释器区（CPython REPL）。 */
    private Pane createInterpPane() {
        final Pane p = new Pane();
        p.kind = KIND_INTERP;
        p.repl = new RunPanel(this, theme, () -> removeZone(p));
        p.repl.setZoneMode(true);
        panes.add(p);
        p.repl.setVisibility(View.VISIBLE);
        startReplIn(p);
        updatePlusButton();
        updateStatusBarVisibility();
        return p;
    }

    /** 点 + 时的菜单：编辑区 / 解释器 / 终端 × 右侧 / 下方（自由拆分）。 */
    private void showAddZoneMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        android.view.SubMenu e = pm.getMenu().addSubMenu(0, 10, 0, Lang.s("编辑区"));
        e.add(0, 11, 0, Lang.s("在右侧拆分"));
        e.add(0, 12, 1, Lang.s("在下方拆分"));
        android.view.SubMenu i = pm.getMenu().addSubMenu(0, 20, 1, Lang.s("解释器"));
        i.add(0, 21, 0, Lang.s("在右侧拆分"));
        i.add(0, 22, 1, Lang.s("在下方拆分"));
        android.view.SubMenu t = pm.getMenu().addSubMenu(0, 30, 2, Lang.s("终端"));
        t.add(0, 31, 0, Lang.s("在右侧拆分"));
        t.add(0, 32, 1, Lang.s("在下方拆分"));
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 11:
                    addZone(KIND_EDITOR, false);
                    return true;
                case 12:
                    addZone(KIND_EDITOR, true);
                    return true;
                case 21:
                    addZone(KIND_INTERP, false);
                    return true;
                case 22:
                    addZone(KIND_INTERP, true);
                    return true;
                case 31:
                    addZone(KIND_TERM, false);
                    return true;
                case 32:
                    addZone(KIND_TERM, true);
                    return true;
                default:
                    return false;
            }
        });
        pm.show();
    }

    /** 新建一个区，插到当前焦点区旁边（below=true 放下面，否则放右边）。 */
    private Pane addZone(int kind, boolean below) {
        if (panes.size() >= maxZones()) {
            toast(Lang.s("最多 ") + maxZones() + Lang.s(" 个区，再多手指就点不过来了；先挤掉一个再加吧"));
            return null;
        }
        if (runPanel != null && runPanel.isFull()) runPanel.collapseFull();
        if (paneLayout != null) paneLayout.setVisibility(View.VISIBLE);
        View anchor = null;
        if (focusedPane != null) anchor = focusedPane.root();
        else if (!panes.isEmpty()) anchor = panes.get(0).root();
        Pane p;
        if (kind == KIND_TERM) {
            p = createTermPane();
        } else if (kind == KIND_INTERP) {
            p = createInterpPane();
        } else {
            p = createEditorPane();
            syncTabFromEditor();
            Tab t = new Tab();
            t.name = Lang.s("未命名.py");
            t.text = "";
            tabs.add(t);
            bindTabToPane(p, tabs.size() - 1);
        }
        // 真正插进分割树：焦点区旁边
        if (p != null) paneLayout.addZone(p.root(), anchor, below);
        focusPane(p);
        if (p != null && p.isEditor()) {
            p.view.requestFocus();
            p.view.showIme();
        }
        updatePlusButton();
        updateStatusBarVisibility();
        refreshDrawerFiles();
        return p;
    }

    /** 同一类型的区已经存在就聚焦过去，否则新建一个。 */
    private void openZone(int kind) {
        for (Pane p : panes) {
            if (p.kind == kind) {
                focusPane(p);
                if (p.term != null) p.term.open();
                return;
            }
        }
        addZone(kind, false);
    }

    /** 销毁一个区（终端/解释器区的 × / 分割线挤掉；编辑区只销毁视图，文档留在打开的文件里）。 */
    private void removeZone(Pane p) {
        if (p == null) return;
        if (p.isEditor()) syncPane(p);
        if (p.term != null) p.term.dispose();
        if (p.repl != null) p.repl.dispose();
        panes.remove(p);
        paneLayout.removeZone(p.root());
        if (focusedPane == p) {
            focusedPane = null;
            Pane next = null;
            for (Pane q : panes) {
                if (q.isEditor()) {
                    next = q;
                    break;
                }
            }
            if (next == null && !panes.isEmpty()) next = panes.get(0);
            if (next != null) focusPane(next);
        }
        if (panes.isEmpty()) {
            // 至少留一个编辑区，否则设置 / 菜单 / 运行全都无处可去
            Pane np = createEditorPane();
            paneLayout.setPanes(paneViews());
            focusPane(np);
            if (!tabs.isEmpty()) bindTabToPane(np, Math.min(Math.max(curTab, 0), tabs.size() - 1));
        }
        updatePlusButton();
        updateStatusBarVisibility();
        refreshDrawerFiles();
    }

    private java.util.List<View> paneViews() {
        java.util.ArrayList<View> out = new java.util.ArrayList<>();
        for (Pane p : panes) out.add(p.root());
        return out;
    }

    private Pane paneOf(View v) {
        if (v == null) return null;
        for (Pane p : panes) {
            if (p.root() == v || p.view == v) return p;
        }
        for (Pane p : panes) {
            if (p.host != null && v.getParent() == p.host) return p;
        }
        return null;
    }

    /** 当前应该接受编辑操作的那个区（编辑区优先，终端/解释器不抢文件）。 */
    private Pane editTarget() {
        if (focusedPane != null && focusedPane.isEditor()) return focusedPane;
        Pane p = editorPane();
        if (p != null) return p;
        Pane np = createEditorPane();
        attachPane(np);
        if (!tabs.isEmpty()) bindTabToPane(np, Math.min(Math.max(curTab, 0), tabs.size() - 1));
        return np;
    }

    /** 把刚建好的区挂进分割树：树是空的就当第一个，否则拆在焦点区右边。 */
    private void attachPane(Pane p) {
        if (p == null) return;
        ArrayList<View> tree = new ArrayList<>(paneLayout.panes());
        if (tree.isEmpty()) {
            paneLayout.setPanes(paneViews());
            return;
        }
        View anchor = null;
        if (focusedPane != null && focusedPane != p) anchor = focusedPane.root();
        if (anchor == null || anchor == p.root()) anchor = tree.get(0);
        paneLayout.addZone(p.root(), anchor, false);
    }

    /** editor 字段所在的那个编辑区。 */
    private Pane editorPane() {
        if (editor == null) return null;
        for (Pane p : panes) if (p.isEditor() && p.view == editor) return p;
        return null;
    }

    // ---------------------------------------------------------------- MiniMap
    private void openMinimap(Pane p) {
        if (p == null || p.host == null) return;
        if (!Prefs.miniMap(this)) {
            toast(Lang.s("MiniMap 已关闭：可在 设置 → 编辑器 打开"));
            return;
        }
        closeMinimapsExcept(p);
        p.host.openMinimap();
    }

    private void closeMinimapsExcept(Pane keep) {
        for (Pane p : panes) {
            if (p != keep && p.host != null && p.host.isMinimapOpen()) p.host.closeMinimap();
        }
    }

    private void closeAllMinimaps() {
        closeMinimapsExcept(null);
    }

    private boolean anyMinimapOpen() {
        for (Pane p : panes) if (p.host != null && p.host.isMinimapOpen()) return true;
        return false;
    }

    private final class PaneListener implements EditorView.Listener {
        private final Pane pane;

        PaneListener(Pane p) {
            pane = p;
        }

        @Override
        public void onEditorStateChanged() {
            if (loading || pane != focusedPane) return;
            updateTitle();
            updateStatus();
        }

        @Override
        public void onEditorTextChanged() {
            if (loading || pane != focusedPane) return;
            updateTitle();
        }

        @Override
        public void onRequestSave() {
            save();
        }
    }

    /** 焦点换到一个区：先保存旧编辑区的快照，再切过去。终端/解释器不改当前文件。 */
    private void focusPane(Pane p) {
        if (p == null) return;
        if (focusedPane == p) {
            if (p.isEditor()) editor = p.view;
            return;
        }
        if (focusedPane != null && focusedPane.isEditor()) {
            syncPane(focusedPane);
            if (focusedPane.view != null) focusedPane.view.hideCompletion();
        }
        focusedPane = p;
        if (!p.isEditor()) {
            // 焦点在终端 / 解释器上：不动 editor / 当前文件名，只刷新标题与状态
            if (findBar != null && findBar.isOpen()) findBar.close();
            updateTitle();
            updateStatus();
            refreshDrawerFiles();
            if (paneLayout != null) paneLayout.invalidate();
            saveZoneStateSoon();
            return;
        }
        editor = p.view;
        if (p.tabIdx >= 0 && p.tabIdx < tabs.size()) {
            Tab t = tabs.get(p.tabIdx);
            curTab = p.tabIdx;
            currentName = t.name;
            currentUri = t.uri;
            editor.setPythonMode(isPythonName(t.name));
            if (!t.dirty) editor.markClean();
        }
        if (findBar != null) {
            if (findBar.isOpen()) findBar.close();
            findBar.setEditor(editor);
        }
        updateTitle();
        updateStatus();
        refreshDrawerFiles();
        if (paneLayout != null) paneLayout.invalidate();
        saveZoneStateSoon();
    }

    /** 把一个编辑区的正文/光标/脏标记写回它的 Tab 快照。 */
    private void syncPane(Pane p) {
        if (p == null || !p.isEditor() || p.view == null) return;
        if (p.tabIdx < 0 || p.tabIdx >= tabs.size()) return;
        Tab t = tabs.get(p.tabIdx);
        t.text = p.view.getText();
        t.line = Native.nativeCursorLine(p.view.docHandle());
        t.col = Native.nativeCursorCol(p.view.docHandle());
        t.dirty = p.view.isDirty();
        if (p == focusedPane) {
            t.name = currentName;
            t.uri = currentUri;
        }
    }

    /** 把第 idx 个 Tab 装进指定编辑区。 */
    private void bindTabToPane(Pane p, int idx) {
        if (p == null || !p.isEditor() || p.view == null) return;
        if (idx < 0 || idx >= tabs.size()) return;
        Tab t = tabs.get(idx);
        p.tabIdx = idx;
        boolean isFocused = p == focusedPane;
        loading = true;
        p.view.setDocumentText(t.text == null ? "" : t.text, true);
        loading = false;
        p.view.setPythonMode(isPythonName(t.name));
        if (!t.dirty) p.view.markClean();
        p.view.moveCursorTo(Math.max(0, t.line), Math.max(0, t.col));
        if (isFocused) {
            curTab = idx;
            currentName = t.name;
            currentUri = t.uri;
            updateTitle();
            updateStatus();
        }
        // 「哪个区开着哪个文件」也算分区状态：换文件就记住（防抖，大退也不丢）
        saveZoneStateSoon();
    }

    private void updatePlusButton() {
        if (plusBtn == null) return;
        plusBtn.setVisibility(panes.size() < maxZones() ? View.VISIBLE : View.GONE);
    }

    /**
     * 行/列状态栏（5.6.0）：横屏 / 竖屏各有「显示 / 不显示」+「顶部 / 底部」四个开关；
     * 另外「在常用栏中显示」控制顶栏里的紧凑状态。
     */
    private void updateStatusBarVisibility() {
        boolean landscape = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        boolean show = landscape ? Prefs.statusBarLandscape(this) : Prefs.statusBarPortrait(this);
        int pos = landscape ? Prefs.statusBarLandscapePos(this) : Prefs.statusBarPortraitPos(this);
        if (statusBar != null) {
            statusBar.setVisibility(show && pos == Prefs.BAR_BOTTOM ? View.VISIBLE : View.GONE);
        }
        if (statusBarTop != null) {
            statusBarTop.setVisibility(show && pos == Prefs.BAR_TOP ? View.VISIBLE : View.GONE);
        }
        if (topStatus != null) {
            topStatus.setVisibility(Prefs.statusBarInTopBar(this) ? View.VISIBLE : View.GONE);
        }
    }

    private void hideIme() {
        try {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            View f = getCurrentFocus();
            if (imm != null && f != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    /** 分割线把某个区挤没了：销毁该区（编辑区的 Tab 仍留在「打开的文件」里）。 */
    private void removePaneByView(View v) {
        Pane p = paneOf(v);
        if (p == null) return;
        removeZone(p);
    }

    /** 换位：PaneLayout 已经调换了显示顺序，这里同步数据顺序。 */
    private void swapPaneViews(View a, View b) {
        Pane pa = paneOf(a), pb = paneOf(b);
        if (pa == null || pb == null) return;
        int ia = panes.indexOf(pa), ib = panes.indexOf(pb);
        panes.set(ia, pb);
        panes.set(ib, pa);
        refreshDrawerFiles();
    }

    /** 抽屉点文件：只有一个编辑区就直接替换，多个编辑区进入「点哪个区替换哪个」状态。 */
    private void requestReplace(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        if (editorCount() <= 1) {
            if (idx == curTab) return;
            syncTabFromEditor();
            loadTab(idx);
            return;
        }
        pendingReplaceTab = idx;
        panePick = true;
        paneLayout.setPickMode(true);
        toast(Lang.s("点一个编辑区，把文件替换进去"));
    }

    private void onPanePicked(View v) {
        Pane target = paneOf(v);
        panePick = false;
        if (paneLayout != null) paneLayout.setPickMode(false);
        int idx = pendingReplaceTab;
        pendingReplaceTab = -1;
        if (target == null) return;
        if (!target.isEditor()) {
            toast(Lang.s("终端 / 解释器区不能放文件，请点一个编辑区"));
            return;
        }
        if (idx < 0 || idx >= tabs.size()) return;
        for (Pane other : panes) {
            if (other != target && other.tabIdx == idx) {
                focusPane(other);
                toast(Lang.s("该文件已在其它编辑区"));
                return;
            }
        }
        focusPane(target);
        bindTabToPane(target, idx);
        target.view.requestFocus();
        refreshDrawerFiles();
        toast(Lang.s("已替换到该编辑区"));
    }

    private boolean anyPaneDirty() {
        for (Pane p : panes) if (p.isEditor() && p.view != null && p.view.isDirty()) return true;
        return false;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(theme.bg);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(theme.statusBg);
        topBar.setPadding((int) d(4), 0, (int) d(4), 0);
        int barH = (int) d(46);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, barH));

        TextView menu = icon("☰", 20, 0xFFE0E0E0);
        menu.setOnClickListener(v -> openDrawer());
        topBar.addView(menu);

        titleView = new TextView(this);
        titleView.setTextColor(0xFFE0E0E0);
        titleView.setTextSize(13);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins((int) d(8), 0, (int) d(6), 0);
        titleView.setLayoutParams(tp);
        titleView.setOnLongClickListener(v -> {
            captureUi();
            return true;
        });
        topBar.addView(titleView);

        undoBtn = icon("↶", 20, 0xFFE0E0E0);
        undoBtn.setOnClickListener(v -> editor.undo());
        redoBtn = icon("↷", 20, 0xFFE0E0E0);
        redoBtn.setOnClickListener(v -> editor.redo());
        TextView runBtn = icon("▶", 18, 0xFF8BD17C);
        runBtn.setOnClickListener(v -> runCurrent());
        topBar.addView(runBtn);
        TextView comp = textBtn(Lang.s("补全"));
        comp.setOnClickListener(v -> {
            editor.requestFocus();
            editor.showCompletion(true);
            editor.showIme();
        });
        comp.setVisibility(View.GONE);
        TextView save = textBtn(Lang.s("保存"));
        save.setOnClickListener(v -> save());
        TextView common = textBtn(Lang.s("常用"));
        common.setOnClickListener(this::showCommonMenu);
        topBar.addView(common);
        // 5.6.0：顶栏（常用栏）里的紧凑状态；设置 → 编辑器 →「在常用栏中显示」
        topStatus = new TextView(this);
        topStatus.setTextSize(9.5f);
        topStatus.setTextColor(0xFF9DA5B4);
        topStatus.setSingleLine(true);
        topStatus.setPadding((int) d(3), 0, (int) d(3), 0);
        topStatus.setVisibility(View.GONE);
        topBar.addView(topStatus);
        topBar.addView(undoBtn);
        topBar.addView(redoBtn);
        TextView compBtn = textBtn(Lang.s("补全"));
        compBtn.setOnClickListener(v -> {
            if (editor == null) return;
            editor.requestFocus();
            editor.showCompletion(true);
            editor.showIme();
        });
        topBar.addView(compBtn);
        plusBtn = textBtn("+");
        plusBtn.setTextSize(18);
        plusBtn.setPadding((int) d(8), 0, (int) d(8), 0);
        // 5.6.0：点 + 选「编辑区 / 解释器 / 终端」
        plusBtn.setOnClickListener(this::showAddZoneMenu);
        plusBtn.setVisibility(View.GONE);
        topBar.addView(plusBtn);
        save.setVisibility(View.GONE);
        root.addView(topBar);

        paneLayout = new PaneLayout(this);
        paneLayout.setGridMode(layoutMode());
        paneLayout.setColors(theme.bg, theme.gutterText, theme.colors[Theme.TOK_KEYWORD], 0xFFFF6B6B);
        paneLayout.setCallback(new PaneLayout.Callback() {
            @Override
            public void onSqueeze(java.util.List<View> gone) {
                for (View v : gone) removePaneByView(v);
            }

            @Override
            public void onSwap(View a, View b) {
                swapPaneViews(a, b);
            }

            @Override
            public void onPick(View v) {
                onPanePicked(v);
            }

            @Override
            public void onSwapModeChanged(boolean on) {
                if (on) {
                    hideIme();
                    toast(Lang.s("已进入换位模式：点一个区，再点另一个交换"));
                }
            }

            @Override
            public void onLayoutChanged() {
                saveZoneState();
            }
        });
        root.addView(paneLayout, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        createEditorPane();
        paneLayout.setPanes(paneViews());

        // 5.6.0：状态栏也可以放在顶部（编辑区上方、顶栏下方）
        LinearLayout statusTop = new LinearLayout(this);
        statusBarTop = statusTop;
        statusTop.setOrientation(LinearLayout.HORIZONTAL);
        statusTop.setGravity(Gravity.CENTER_VERTICAL);
        statusTop.setBackgroundColor(theme.statusBg);
        statusTop.setPadding((int) d(10), 0, (int) d(10), 0);
        statusTop.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) d(24)));
        statusViewTop = new TextView(this);
        statusViewTop.setTextColor(theme.statusText);
        statusViewTop.setTextSize(10.5f);
        statusViewTop.setSingleLine(true);
        statusViewTop.setOnClickListener(v -> showProblems());
        statusTop.addView(statusViewTop);
        statusTop.setVisibility(View.GONE);
        // createEditorPane 已经 addView 过 paneLayout，这里把顶部状态栏插到它前面
        int pi = root.indexOfChild(paneLayout);
        root.addView(statusTop, pi >= 0 ? pi : root.getChildCount());

        // 5.6.0：终端 / 解释器不再是底部面板，而是「区」（见 + 菜单 / 抽屉 → 命令行）
        runPanel = new RunPanel(this, theme, () -> {
            if (runPanel != null) runPanel.close();
        });
        runPanel.setVisibility(View.GONE);
        root.addView(runPanel);
        runPanel.setFullListener(full -> onPanelFull(runPanel, full));

        findBar = new FindBar(this, editor);
        findBar.setVisibility(View.GONE);
        root.addView(findBar);
        // 点行尾「被使用 N 次」→ 打开查找栏并自动填好函数名
        editor.setAnnotationListener(name -> {
            if (findBar != null) findBar.open(name);
        });

        LinearLayout status = new LinearLayout(this);
        statusBar = status;
        status.setOrientation(LinearLayout.HORIZONTAL);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setBackgroundColor(theme.statusBg);
        status.setPadding((int) d(10), 0, (int) d(10), 0);
        status.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) d(24)));
        statusView = new TextView(this);
        statusView.setTextColor(theme.statusText);
        statusView.setTextSize(10.5f);
        statusView.setSingleLine(true);
        statusView.setOnClickListener(v -> showProblems());
        status.addView(statusView);
        root.addView(status);

        shell = new android.widget.FrameLayout(this);
        shell.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0x99000000);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        shell.addView(drawerScrim, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildDrawer();
        android.widget.FrameLayout.LayoutParams dlp = new android.widget.FrameLayout.LayoutParams(
                (int) d(228), ViewGroup.LayoutParams.MATCH_PARENT);
        dlp.gravity = android.view.Gravity.START | android.view.Gravity.TOP;
        drawerLp = dlp;
        shell.addView(drawer, dlp);
        drawer.setVisibility(View.GONE);
        setContentView(shell);
        updateTitle();
        updatePlusButton();
        updateStatusBarVisibility();
    }

    private TextView icon(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) d(8), (int) d(6), (int) d(8), (int) d(6));
        return t;
    }

    private TextView textBtn(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setTextColor(0xFF9DA5B4);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) d(7), (int) d(6), (int) d(7), (int) d(6));
        return t;
    }

    // ---------------------------------------------------------------- files
    private SharedPreferences prefs() {
        return getSharedPreferences("pyedit", MODE_PRIVATE);
    }

    private boolean restoreFromIntent() {
        Intent it = getIntent();
        if (it != null && Intent.ACTION_VIEW.equals(it.getAction()) && it.getData() != null) {
            openUri(it.getData());
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- 分区记忆（5.6.1）
    /** 每次布局变化 / 进后台 / 退出都记一份：格子几何 + 每个区是什么 + 焦点。 */
    /** 焦点 / 文件切换：防抖后落盘（这些变化可能连着来，不必每次都 fsync）。 */
    private void saveZoneStateSoon() {
        if (paneLayout == null || restoringZones) return;
        zoneHandler.removeCallbacks(zoneSaveLater);
        zoneHandler.postDelayed(zoneSaveLater, 400);
    }

    private void saveZoneState() {
        zoneHandler.removeCallbacks(zoneSaveLater);
        if (paneLayout == null || panes.isEmpty() || restoringZones) return;
        // 先保证「区」和「格子」一一对应：多出来的旧格子清掉、还没格子的区补一个
        // （正常情况下这一步什么也不做；只有删区/换位之后残留时才会自愈）
        paneLayout.setPanes(paneViews());
        String geo = paneLayout.saveLayout(paneViews());
        if (geo == null) {
            // 区和格子的对应关系脏了（删区/换位后残留）：按 panes 重建一次格子再存
            App.noteAppend("zone.txt", "save desync panes=" + panes.size()
                    + " cells=" + paneLayout.cellCount()
                    + " size=" + paneLayout.getWidth() + "x" + paneLayout.getHeight()
                    + " why=" + paneLayout.lastSaveError);
            paneLayout.setPanes(paneViews());
            geo = paneLayout.saveLayout(paneViews());
        }
        if (geo == null) {
            App.noteAppend("zone.txt", "save FAILED panes=" + panes.size()
                    + " cells=" + paneLayout.cellCount()
                    + " size=" + paneLayout.getWidth() + "x" + paneLayout.getHeight()
                    + " why=" + paneLayout.lastSaveError);
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Pane p : panes) {
            String kind = p.kind == KIND_TERM ? "t" : (p.kind == KIND_INTERP ? "i" : "e");
            String uri = "", name = "";
            int line = 0, col = 0;
            if (p.isEditor() && p.tabIdx >= 0 && p.tabIdx < tabs.size()) {
                Tab t = tabs.get(p.tabIdx);
                uri = t.uri == null ? "" : t.uri.toString();
                name = t.name == null ? "" : t.name;
                line = t.line;
                col = t.col;
            }
            sb.append(kind).append('\t').append(enc(uri)).append('\t').append(enc(name))
                    .append('\t').append(line).append('\t').append(col).append('\n');
        }
        // 先同步写纯文本（flush + fsync）：被系统杀掉也不会丢，恢复时优先用它
        boolean fileOk = App.writeRaw("zone-state.txt", geo + "\n" + sb);
        boolean prefOk = Prefs.setZoneState(this, geo, sb.toString(),
                Math.max(0, panes.indexOf(focusedPane)));
        App.noteAppend("zone.txt", "save ok panes=" + panes.size() + " cell=" + paneLayout.cellCount()
                + " size=" + paneLayout.getWidth() + "x" + paneLayout.getHeight()
                + " file=" + fileOk + " pref=" + prefOk + "\n  " + geo);
    }

    /** 启动时恢复上次的分区；数据不合法返回 false，让调用方走原来的「打开上次文件」。 */
    private boolean restoreZones() {
        // 优先读「同步落盘」的纯文本（最新、且不怕进程被杀），没有再退回 SharedPreferences
        String geo = null, paneData = null, from = null;
        try {
            java.io.File f = new java.io.File(App.dir, "zone-state.txt");
            if (f.exists()) {
                InputStream in = new java.io.FileInputStream(f);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int k;
                while ((k = in.read(buf)) > 0) bos.write(buf, 0, k);
                in.close();
                String all = new String(bos.toByteArray(), StandardCharsets.UTF_8).trim();
                int nl = all.indexOf('\n');
                if (nl > 0) {
                    geo = all.substring(0, nl).trim();
                    paneData = all.substring(nl + 1).trim();
                    from = "file";
                }
            }
        } catch (Throwable ignored) {
        }
        if (geo == null || paneData == null) {
            geo = Prefs.zoneState(this);
            paneData = Prefs.zonePanes(this);
            from = "prefs";
        }
        if (geo == null || paneData == null) {
            App.noteAppend("zone.txt", "restore: no state (geo=" + (geo == null)
                    + ", panes=" + (paneData == null) + ")");
            restoringZones = false;
            return false;
        }
        App.noteAppend("zone.txt", "restore from " + from);
        String[] recs = paneData.split("\n");
        if (recs.length == 0) {
            App.noteAppend("zone.txt", "restore: no pane records");
            restoringZones = false;
            return false;
        }
        // 记录数比上限多（旧版本留下的脏数据）就只取前 MAX_ZONES 条，别整块丢掉
        int n = Math.min(recs.length, PaneLayout.MAX_ZONES);
        if (recs.length > n) {
            App.noteAppend("zone.txt", "restore: " + recs.length + " records, keep " + n);
        }
        int[] kinds = new int[n];
        String[] uris = new String[n], names = new String[n];
        int[] lines = new int[n], cols = new int[n];
        for (int i = 0; i < n; i++) {
            String[] f = recs[i].split("\t", -1);
            String kind = f.length > 0 && !f[0].isEmpty() ? f[0] : "e";
            kinds[i] = "t".equals(kind) ? KIND_TERM : ("i".equals(kind) ? KIND_INTERP : KIND_EDITOR);
            uris[i] = f.length > 1 ? dec(f[1]) : "";
            names[i] = f.length > 2 ? dec(f[2]) : "";
            lines[i] = f.length > 3 ? intOr(f[3], 0) : 0;
            cols[i] = f.length > 4 ? intOr(f[4], 0) : 0;
        }
        // 至少要有一个编辑区才恢复（很多菜单都依赖 editor 非空）
        // 至少要有一个编辑区才恢复（很多菜单都依赖 editor 非空）
        boolean hasEditor = false;
        for (int k : kinds) if (k == KIND_EDITOR) hasEditor = true;
        if (!hasEditor) {
            App.noteAppend("zone.txt", "restore: no editor pane in " + n);
            restoringZones = false;
            return false;
        }
        // 几何快照的格子数应该和区数一致；不一致就只恢复「区 + 文件」，形状退回网格
        String[] gp = geo.split(";");
        boolean geomOk = gp.length >= 4 && intOr(gp[3], -1) == n;
        if (!geomOk) {
            App.noteAppend("zone.txt", "restore: cell/pane mismatch cells="
                    + (gp.length >= 4 ? gp[3] : "?") + " panes=" + n + " -> grid");
        }
        restoringZones = true;
        disposeAllPanes();
        ArrayList<Pane> created = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Pane p;
            if (kinds[i] == KIND_TERM) {
                p = createTermPane();
            } else if (kinds[i] == KIND_INTERP) {
                p = createInterpPane();
            } else {
                p = createEditorPane();
            }
            created.add(p);
        }
        Pane firstEditor = null;
        for (Pane p : created) if (p.isEditor()) { firstEditor = p; break; }
        if (firstEditor != null) focusPane(firstEditor);
        else if (!created.isEmpty()) focusPane(created.get(0));
        if (!geomOk || !paneLayout.restoreLayout(geo, paneViews())) {
            // 形状不能用了也不能把区/文件丢掉：退回网格，区数、类型、文件照旧恢复
            App.noteAppend("zone.txt", "restore: geometry unusable -> grid, panes=" + created.size());
            paneLayout.setPanes(paneViews());
        }
        // 每个编辑区装回自己的文件
        for (int i = 0; i < created.size(); i++) {
            Pane pane = created.get(i);
            if (!pane.isEditor()) continue;
            String us = uris[i], name = names[i];
            Tab t = new Tab();
            t.uri = us.isEmpty() ? null : Uri.parse(us);
            t.name = name.isEmpty()
                    ? (t.uri == null ? Lang.s("未命名.py") : displayName(t.uri))
                    : name;
            t.line = lines[i];
            t.col = cols[i];
            if (t.uri != null) {
                try {
                    t.text = readText(t.uri);
                } catch (Exception e) {
                    // 文件被删 / 授权失效：留一个空文档，别让恢复整体失败
                    t.text = "";
                    t.uri = null;
                    toast(Lang.s("打开失败: ") + t.name);
                }
            } else {
                t.text = "";
            }
            tabs.add(t);
            bindTabToPane(pane, tabs.size() - 1);
        }
        int focus = Prefs.zoneFocus(this);
        if (focus >= 0 && focus < created.size()) focusPane(created.get(focus));
        updatePlusButton();
        updateStatusBarVisibility();
        updateTitle();
        updateStatus();
        refreshDrawerFiles();
        restoringZones = false;
        App.noteAppend("zone.txt", "restore ok panes=" + created.size() + " geom=" + geomOk
                + "\n  " + geo);
        // 把「现在真实的样子」立刻写回去：下次不会再读到旧快照/坏快照
        saveZoneState();
        return true;
    }

    /** 拆掉当前所有区（恢复分区前清场）。 */
    private void disposeAllPanes() {
        for (Pane p : panes) {
            if (p.term != null) p.term.dispose();
            if (p.repl != null) p.repl.dispose();
        }
        panes.clear();
        focusedPane = null;
        editor = null;
        curTab = -1;
        if (paneLayout != null) paneLayout.clearAll();
    }

    private Uri intentUri() {
        Intent it = getIntent();
        if (it != null && Intent.ACTION_VIEW.equals(it.getAction()) && it.getData() != null) {
            return it.getData();
        }
        return null;
    }

    /** 把文件开进指定的编辑区（恢复分区后接收外部打开的请求）。 */
    private void openUriInto(Uri uri, Pane target) {
        if (uri == null) return;
        for (int i = 0; i < tabs.size(); i++) {
            if (uri.equals(tabs.get(i).uri)) {
                if (target != null && target.isEditor()) {
                    focusPane(target);
                    bindTabToPane(target, i);
                } else {
                    requestReplace(i);
                }
                return;
            }
        }
        try {
            String text = readText(uri);
            Tab t = new Tab();
            t.name = displayName(uri);
            t.uri = uri;
            t.text = text;
            tabs.add(t);
            Pane p = target != null && target.isEditor() ? target : editTarget();
            focusPane(p);
            bindTabToPane(p, tabs.size() - 1);
            prefs().edit().putString("last_uri", uri.toString()).apply();
            addRecent(uri);
            refreshDrawerFiles();
        } catch (Exception e) {
            toast(Lang.s("打开失败: ") + e.getMessage());
        }
    }

    private static String enc(String s) {
        try {
            return java.net.URLEncoder.encode(s == null ? "" : s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String dec(String s) {
        try {
            return java.net.URLDecoder.decode(s == null ? "" : s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static int intOr(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private void loadLastOrDefault() {
        String last = prefs().getString("last_uri", null);
        if (last != null) {
            try {
                openUri(Uri.parse(last));
                return;
            } catch (Exception ignored) {
            }
        }
        loading = true;
        editor.setDocumentText(welcomeText(), true);
        loading = false;
        currentUri = null;
        currentName = "welcome.py";
        applyLanguage();
        editor.markClean();
        updateTitle();
        updateStatus();
        editor.moveCursorTo(0, 0);
        if (tabs.isEmpty()) {
            Tab t = new Tab();
            t.name = currentName;
            t.text = welcomeText();
            t.uri = null;
            tabs.add(t);
            curTab = 0;
            if (focusedPane != null && focusedPane.isEditor()) focusedPane.tabIdx = 0;
            refreshDrawerFiles();
        }
    }

    /** 只有 .py 走高亮 / 折叠 / 语法检查 / 补全，其它文本文件按 UTF-8 纯文本打开。 */
    private static boolean isPythonName(String n) {
        return n != null && n.toLowerCase(java.util.Locale.ROOT).endsWith(".py");
    }

    private void applyLanguage() {
        if (editor != null) editor.setPythonMode(isPythonName(currentName));
    }

    /** 把当前编辑区（焦点区是终端/解释器时就是最后一个编辑区）的正文写回 Tab。 */
    private void syncTabFromEditor() {
        syncPane(editTarget());
    }

    private void loadTab(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Pane target = editTarget();
        if (target == null) return;
        bindTabToPane(target, idx);
        refreshDrawerFiles();
    }

    private void switchTab(int idx) {
        requestReplace(idx);
    }

    private int pendingCloseSave = -1;

    private void closeTab(final int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Pane holder = null;
        for (Pane p : panes) if (p.tabIdx == idx) holder = p;
        if (holder != null && holder != focusedPane) {
            syncTabFromEditor();
            focusPane(holder);
        }
        if (idx == curTab) syncTabFromEditor();
        final Tab t = tabs.get(idx);
        new android.app.AlertDialog.Builder(this)
                .setMessage(Lang.s("关闭 ") + t.name + " ?")
                .setPositiveButton(Lang.s("保存并关闭"), (d, w) -> saveThenClose(idx))
                .setNegativeButton(Lang.s("不保存关闭"), (d, w) -> closeTabNow(idx))
                .setNeutralButton(Lang.s("取消"), null)
                .show();
    }

    private void saveThenClose(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Tab t = tabs.get(idx);
        if (t.uri == null) {
            pendingCloseSave = idx;
            if (idx == curTab) {
                saveAs();
            } else {
                switchTab(idx);
                saveAs();
            }
            return;
        }
        try {
            if (idx == curTab) syncTabFromEditor();
            writeUri(t.uri);
            toast(Lang.s("已保存"));
            closeTabNow(idx);
        } catch (Exception e) {
            toast(Lang.s("保存失败: ") + e.getMessage());
        }
    }

    private void closeTabNow(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Pane holder = null;
        for (Pane p : panes) if (p.tabIdx == idx) { holder = p; break; }
        tabs.remove(idx);
        for (Pane p : panes) if (p.tabIdx > idx) p.tabIdx--;
        if (holder != null) holder.tabIdx = -1;
        if (tabs.isEmpty()) {
            Tab t = new Tab();
            t.name = Lang.s("未命名.py");
            t.text = "";
            tabs.add(t);
            if (holder != null) bindTabToPane(holder, 0);
            else if (focusedPane != null) bindTabToPane(focusedPane, 0);
        } else if (holder != null) {
            bindTabToPane(holder, Math.min(idx, tabs.size() - 1));
        }
        for (Pane p : panes) {
            if (p.tabIdx >= tabs.size()) p.tabIdx = tabs.size() - 1;
        }
        if (focusedPane != null && focusedPane.tabIdx >= 0 && focusedPane.tabIdx < tabs.size()) {
            Tab ft = tabs.get(focusedPane.tabIdx);
            curTab = focusedPane.tabIdx;
            currentName = ft.name;
            currentUri = ft.uri;
        }
        refreshDrawerFiles();
        updateTitle();
        updateStatus();
    }

    private void newDocument() {
        syncTabFromEditor();
        Tab t = new Tab();
        t.name = Lang.s("未命名.py");
        t.text = "";
        tabs.add(t);
        requestReplace(tabs.size() - 1);
        prefs().edit().remove("last_uri").apply();
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            toast(Lang.s("无法打开文件选择器"));
        }
    }

    private String readText(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("open failed");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > 8 * 1024 * 1024) {
                in.close();
                throw new Exception(Lang.s("文件过大 (超过 8MB)"));
            }
            bos.write(buf, 0, n);
        }
        in.close();
        String s = new String(bos.toByteArray(), StandardCharsets.UTF_8);
        if (s.startsWith("\uFEFF")) s = s.substring(1);
        return s.replace("\r\n", "\n").replace('\r', '\n');
    }

    private void openUri(Uri uri) {
        int existing = -1;
        for (int i = 0; i < tabs.size(); i++) {
            if (uri.equals(tabs.get(i).uri)) { existing = i; break; }
        }
        if (existing >= 0) { requestReplace(existing); return; }
        try {
            String text = readText(uri);
            syncTabFromEditor();
            Tab t = new Tab();
            t.name = displayName(uri);
            t.uri = uri;
            t.text = text;
            tabs.add(t);
            requestReplace(tabs.size() - 1);
            if (panes.size() <= 1) {
                editor.markClean();
                updateTitle();
                updateStatus();
            }
            prefs().edit().putString("last_uri", uri.toString()).apply();
            addRecent(uri);
            int bad = 0;
            for (int i = 0; i < text.length(); i++) {
                if (text.charAt(i) == '\uFFFD') bad++;
            }
            if (text.indexOf('\u0000') >= 0) {
                toast(Lang.s("已按 UTF-8 打开：文件里有 NUL 字节，可能不是纯文本"));
            } else if (bad > 0) {
                toast(Lang.s("已按 UTF-8 打开（") + bad + Lang.s(" 个字符无法解码，显示为 �）"));
            } else if (panes.size() <= 1) {
                toast(Lang.s("已打开 ") + currentName);
            }
        } catch (Exception e) {
            toast(Lang.s("打开失败: ") + e.getMessage());
        }
    }

    private String displayName(Uri uri) {
        // SAF 的 lastPathSegment 经常是文档 id（如 msf:1234），要问系统拿真实文件名，
        // 否则 .py 判断会失效（= 打开 Python 文件却当成纯文本）。
        String name = null;
        try {
            android.database.Cursor c = getContentResolver().query(uri,
                    new String[]{android.provider.OpenableColumns.DISPLAY_NAME},
                    null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) name = c.getString(0);
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) {
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        if (name == null) return Lang.s("未命名.py");
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (name.contains(":")) name = name.substring(name.lastIndexOf(':') + 1);
        return name;
    }

    private void addRecent(Uri uri) {
        String entry = uri.toString() + "\t" + displayName(uri);
        String all = prefs().getString("recent", "");
        ArrayList<String> list = new ArrayList<>();
        list.add(entry);
        if (!all.isEmpty()) {
            for (String s : all.split("\n")) {
                if (s.isEmpty() || s.equals(entry)) continue;
                list.add(s);
                if (list.size() >= 8) break;
            }
        }
        prefs().edit().putString("recent", TextUtils.join("\n", list)).apply();
    }

    /** 退出前把所有「有文件路径」的脏区写盘（无路径的留给 saveAs）。 */
    private void saveAllDirty() {
        for (Pane p : panes) syncPane(p);
        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            if (!t.dirty || t.uri == null) continue;
            try {
                writeText(t.uri, t.text == null ? "" : t.text);
                t.dirty = false;
            } catch (Exception ignored) {
            }
        }
    }

    private void save() {
        if (currentUri == null) {
            saveAs();
            return;
        }
        try {
            writeUri(currentUri);
            editor.markClean();
            updateTitle();
            updateStatus();
            toast(Lang.s("已保存"));
        } catch (Exception e) {
            toast(Lang.s("保存失败: ") + e.getMessage());
        }
    }

    private void saveAs() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(isPythonName(currentName) ? "text/x-python" : "text/plain");
        i.putExtra(Intent.EXTRA_TITLE, currentName);
        try {
            startActivityForResult(i, REQ_SAVE_AS);
        } catch (Exception e) {
            toast(Lang.s("无法打开保存对话框"));
        }
    }

    private void writeUri(Uri uri) throws Exception {
        writeText(uri, editor.getText());
    }

    private void writeText(Uri uri, String text) throws Exception {
        OutputStream os = getContentResolver().openOutputStream(uri, "wt");
        if (os == null) throw new Exception("open failed");
        os.write(text.getBytes(StandardCharsets.UTF_8));
        os.flush();
        os.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        if (requestCode == REQ_OPEN) {
            openUri(uri);
        } else if (requestCode == REQ_SAVE_AS) {
            try {
                writeUri(uri);
                currentUri = uri;
                currentName = displayName(uri);
                applyLanguage();
                editor.markClean();
                updateTitle();
                updateStatus();
                prefs().edit().putString("last_uri", uri.toString()).apply();
                addRecent(uri);
                toast(Lang.s("已保存"));
                if (pendingCloseSave >= 0) {
                    int pc = pendingCloseSave;
                    pendingCloseSave = -1;
                    closeTabNow(pc);
                }
            } catch (Exception e) {
                toast(Lang.s("保存失败: ") + e.getMessage());
            }
        }
    }

    /** 当前方向的状态栏状态：底部 / 顶部 / 隐藏。 */
    private String statusBarStateLabel() {
        boolean landscape = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        boolean show = landscape ? Prefs.statusBarLandscape(this) : Prefs.statusBarPortrait(this);
        int pos = landscape ? Prefs.statusBarLandscapePos(this) : Prefs.statusBarPortraitPos(this);
        if (!show) return Lang.s("隐藏");
        return pos == Prefs.BAR_TOP ? Lang.s("顶部") : Lang.s("底部");
    }

    /** 状态栏切换（5.6.0：从顶栏挪进「常用」菜单）：底部 → 顶部 → 隐藏 → 底部。 */
    private void cycleStatusBar() {
        boolean landscape = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        boolean show = landscape ? Prefs.statusBarLandscape(this) : Prefs.statusBarPortrait(this);
        int pos = landscape ? Prefs.statusBarLandscapePos(this) : Prefs.statusBarPortraitPos(this);
        String msg;
        if (!show) {
            if (landscape) {
                Prefs.setStatusBarLandscapePos(this, Prefs.BAR_BOTTOM);
                Prefs.setStatusBarLandscape(this, true);
            } else {
                Prefs.setStatusBarPortraitPos(this, Prefs.BAR_BOTTOM);
                Prefs.setStatusBarPortrait(this, true);
            }
            msg = Lang.s("底部");
        } else if (pos == Prefs.BAR_BOTTOM) {
            if (landscape) Prefs.setStatusBarLandscapePos(this, Prefs.BAR_TOP);
            else Prefs.setStatusBarPortraitPos(this, Prefs.BAR_TOP);
            msg = Lang.s("顶部");
        } else {
            if (landscape) Prefs.setStatusBarLandscape(this, false);
            else Prefs.setStatusBarPortrait(this, false);
            msg = Lang.s("隐藏");
        }
        updateStatusBarVisibility();
        toast(Lang.s("状态栏：") + msg);
    }

    private void showCommonMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, Lang.s("保存"));
        pm.getMenu().add(0, 2, 1, Lang.s("另存为…"));
        pm.getMenu().add(0, 3, 2, Lang.s("缩进"));
        pm.getMenu().add(0, 4, 3, Lang.s("反缩进"));
        pm.getMenu().add(0, 5, 4, Lang.s("查找 / 替换…"));
        pm.getMenu().add(0, 6, 5, Lang.s("状态栏：") + statusBarStateLabel()
                + Lang.s("（点一下切换 底部 / 顶部 / 隐藏）"));
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: save(); return true;
                case 2: saveAs(); return true;
                case 3: editor.requestFocus(); editor.indent(); return true;
                case 4: editor.requestFocus(); editor.outdent(); return true;
                case 5: editor.requestFocus(); showFindDialog(); return true;
                case 6: cycleStatusBar(); return true;
                default: return false;
            }
        });
        pm.show();
    }

    private void showFindDialog() {
        closeAllMinimaps();
        if (findBar != null) findBar.open();
    }

    // ---------------------------------------------------------------- menu
    private void showRecents() {
        String all = prefs().getString("recent", "");
        if (all.isEmpty()) {
            toast(Lang.s("暂无最近文件"));
            return;
        }
        String[] lines = all.split("\n");
        final String[] names = new String[lines.length];
        final String[] uris = new String[lines.length];
        for (int i = 0; i < lines.length; i++) {
            int tab = lines[i].indexOf('\t');
            uris[i] = tab > 0 ? lines[i].substring(0, tab) : lines[i];
            names[i] = tab > 0 ? lines[i].substring(tab + 1) : lines[i];
        }
        new AlertDialog.Builder(this)
                .setTitle(Lang.s("最近文件"))
                .setItems(names, (dlg, which) -> openUri(Uri.parse(uris[which])))
                .setNegativeButton(Lang.s("取消"), null)
                .show();
    }

    private void showProblems() {
        if (!editor.isPython()) {
            toast(Lang.s("纯文本模式没有语法检查"));
            return;
        }
        editor.ensureProblemCache();
        ArrayList<String> list = editor.problemLines();
        if (list.isEmpty()) {
            toast(Lang.s("没有发现语法问题"));
            return;
        }
        String[] arr = list.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(Lang.s("语法检查 (") + arr.length + ")")
                .setItems(arr, (dlg, which) -> {
                    int[] p = editor.problemAt(which);
                    if (p != null) {
                        editor.moveCursorTo(p[0], Math.max(0, p[1]));
                        editor.requestFocus();
                        editor.showIme();
                    }
                })
                .setNegativeButton(Lang.s("关闭"), null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- state
    @Override
    public void onEditorStateChanged() {
        updateTitle();
        updateStatus();
    }

    @Override
    public void onEditorTextChanged() {
        updateTitle();
    }

    @Override
    public void onRequestSave() {
        save();
    }

    private void updateTitle() {
        if (titleView == null) return;
        boolean dirty = editor != null && editor.isDirty();
        titleView.setText(currentName + (dirty ? " ●" : ""));
        updateButtons();
    }

    private void updateButtons() {
        if (undoBtn == null) return;
        undoBtn.setAlpha(0.9f);
        redoBtn.setAlpha(0.9f);
    }

    /** 状态栏文字同时写到底部/顶部两个实例（哪个可见由设置决定）。 */
    private void setStatusText(String text, int color) {
        if (statusView != null) {
            statusView.setText(text);
            statusView.setTextColor(color);
        }
        if (statusViewTop != null) {
            statusViewTop.setText(text);
            statusViewTop.setTextColor(color);
        }
    }

    private void updateStatus() {
        if (statusView == null || editor == null) {
            if (topStatus != null && focusedPane != null && !focusedPane.isEditor()) {
                topStatus.setText(focusedPane.kind == KIND_TERM ? Lang.s("终端") : Lang.s("解释器"));
            }
            return;
        }
        int line = Native.nativeCursorLine(editor.docHandle()) + 1;
        int col = Native.nativeCursorCol(editor.docHandle()) + 1;
        int len = Native.nativeLineCount(editor.docHandle());
        if (!editor.isPython()) {
            setStatusText(Lang.s("行 ") + line + Lang.s(", 列 ") + col + "   ·   " + len
                    + Lang.s(" 行   ·   纯文本 · UTF-8"), theme.statusText);
            if (topStatus != null) {
                topStatus.setText(Lang.s("行 ") + line + Lang.s(", 列 ") + col);
                topStatus.setTextColor(theme.statusText);
            }
            return;
        }
        int probs = editor.problemCount();
        String pl = probs > 0 ? ("✖ " + probs + Lang.s(" 个问题")) : Lang.s("✓ 无问题");
        int color = probs > 0 ? 0xFFFF8A80 : theme.statusText;
        if (theme.statusBg == 0xFFF6F8FA || theme.statusBg == 0xFFEEE8D5) {
            color = probs > 0 ? 0xFFD73A49 : theme.statusText;
        }
        setStatusText(Lang.s("行 ") + line + Lang.s(", 列 ") + col + "   ·   " + len
                + Lang.s(" 行   ·   ") + pl, color);
        if (topStatus != null) {
            // 顶栏窄，只用最紧凑的写法：行3 列5 · ✖2 / ✓
            topStatus.setText(Lang.s("行 ") + line + Lang.s(", 列 ") + col
                    + " · " + (probs > 0 ? ("✖" + probs) : "✓"));
            topStatus.setTextColor(probs > 0 ? 0xFFFF8A80 : theme.statusText);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (loading) return;
        for (Pane p : panes) syncPane(p);
        if (Prefs.autoSave(this)) {
            boolean saved = false;
            for (int i = 0; i < tabs.size(); i++) {
                Tab t = tabs.get(i);
                if (t.uri == null || !t.dirty) continue;
                try {
                    writeText(t.uri, t.text == null ? "" : t.text);
                    t.dirty = false;
                    saved = true;
                } catch (Exception ignored) {
                }
            }
            if (saved) {
                for (Pane p : panes) {
                    if (p.tabIdx >= 0 && p.tabIdx < tabs.size()) {
                        Tab t = tabs.get(p.tabIdx);
                        if (t.uri != null) p.view.markClean();
                    }
                }
                updateTitle();
            }
        }
        if (currentUri != null) {
            prefs().edit().putString("last_uri", currentUri.toString()).apply();
        }
        saveZoneState();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // 被系统回收 / 从最近任务划掉也尽量记住分区
        saveZoneState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 从后台 / 旋转回来时重新断言一次系统栏状态（5.6.0 起横竖屏都隐藏）
        Immersive.apply(this);
        theme = Theme.load(this);
        applyTheme();
        for (Pane p : panes) {
            if (p.isEditor()) {
                p.view.setSyntaxCheckEnabled(Prefs.syntaxCheck(this));
                if (p.host != null) {
                    p.host.setMinimapEnabled(Prefs.miniMap(this));
                    p.host.applyTheme(theme);
                }
            }
        }
        // 排布偏好在设置里改过就同步（不关闭任何区，只是重新排布）
        int mode = layoutMode();
        if (paneLayout != null && paneLayout.gridMode() != mode) {
            paneLayout.setGridMode(mode);
        }
        applyLanguage();
        updatePlusButton();
        updateStatusBarVisibility();
    }

    /** 把当前界面画成 PNG、base64 落到 App 目录，便于远程查看（长按标题栏触发）。 */
    private void captureUi() {
        try {
            View root = getWindow().getDecorView().getRootView();
            int w = root.getWidth(), h = root.getHeight();
            if (w <= 0 || h <= 0) {
                toast(Lang.s("界面还没绘制完"));
                return;
            }
            Bitmap full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            root.draw(new Canvas(full));
            int sw = Math.max(1, w / 2), sh = Math.max(1, h / 2);
            Bitmap half = Bitmap.createScaledBitmap(full, sw, sh, true);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            half.compress(Bitmap.CompressFormat.PNG, 100, bos);
            String b64 = android.util.Base64.encodeToString(
                    bos.toByteArray(), android.util.Base64.NO_WRAP);
            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            File out = new File(dir, "shot.b64");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(b64.getBytes("US-ASCII"));
            fos.close();
            full.recycle();
            half.recycle();
            toast(Lang.s("已导出截图 ") + (b64.length() / 1024) + " KB");
        } catch (Throwable t) {
            toast(Lang.s("截图失败: ") + t.getMessage());
        }
    }

    /** 运行面板全屏时把多区收起来（现在只剩底部运行面板会全屏）。 */
    private void onPanelFull(View panel, boolean full) {
        if (runPanel != null && runPanel != panel && runPanel.isFull()) runPanel.collapseFull();
        if (paneLayout == null) return;
        if (full) {
            paneLayout.setVisibility(View.GONE);
        } else if (runPanel == null || !runPanel.isFull()) {
            paneLayout.setVisibility(View.VISIBLE);
        }
    }

    /** 打开运行面板 / 新区之前，把它从全屏状态挤下来并恢复多区。 */
    private void collapseOtherFull(View except) {
        if (runPanel != null && runPanel != except && runPanel.isFull()) runPanel.collapseFull();
        if (paneLayout != null && (runPanel == null || !runPanel.isFull())) {
            paneLayout.setVisibility(View.VISIBLE);
        }
    }

    /** ▶ 运行：跑「当前焦点」那个区的文件；焦点在终端/解释器时就跑最后一个编辑区的文件。 */
    private void runCurrent() {
        if (runPanel == null) return;
        if (focusedPane != null && focusedPane.isEditor()) editor = focusedPane.view;
        if (editor == null) {
            toast(Lang.s("没有可运行的编辑区"));
            return;
        }
        closeAllMinimaps();
        if (runPanel.isRunning()) {
            toast(Lang.s("正在运行，先点「停止」"));
            return;
        }
        collapseOtherFull(runPanel);
        String code = editor.getText();
        File dir = new File(getCacheDir(), "run");
        if (!dir.isDirectory() && !dir.mkdirs()) {
            toast(Lang.s("无法创建运行目录"));
            return;
        }
        File script = new File(dir, "main.py");
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream(script);
            fos.write(code.getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
            toast(Lang.s("写入脚本失败: ") + e.getMessage());
            return;
        }
        String cwd = runWorkingDir();
        String libDir = getApplicationInfo().nativeLibraryDir;
        String stdlib = ensureStdlib();
        if (stdlib == null) {
            toast(Lang.s("CPython 标准库解压失败"));
            return;
        }
        String[] cmd = new String[]{new File(libDir, "libcpython.so").getAbsolutePath(),
                "-S", "-u", script.getAbsolutePath()};
        java.util.Map<String, String> env = new java.util.HashMap<>();
        String sp = SitePkgs.pathEnv(this);
        env.put("PYTHONPATH", sp.isEmpty() ? stdlib : stdlib + ":" + sp);
        env.put("PYTHONHOME", new File(getFilesDir(), "python").getAbsolutePath());
        env.put("PYTHONIOENCODING", "utf-8");
        runPanel.run(cmd, env, cwd, currentName);
        if (runPanel.getVisibility() != View.VISIBLE) runPanel.setVisibility(View.VISIBLE);
    }

    /** 首次运行时把 assets/stdlib.tar.xz（LZMA2）解成真实目录，复用 CompilerStore 的 tar.xz 解压。 */
    private String ensureStdlib() {
        File home = new File(getFilesDir(), "python");
        File lib = new File(home, "lib/python3.12");
        File marker = new File(home, ".extracted");
        if (marker.isFile() && lib.isDirectory()) {
            return lib.getAbsolutePath();
        }
        try {
            deleteRec(home);
            File libParent = new File(home, "lib");
            if (!libParent.mkdirs()) return null;
            byte[] data = readAll(getAssets().open("stdlib.tar.xz"));
            CompilerStore.extract(data, "stdlib.tar.xz", libParent);
            if (!lib.isDirectory()) return null;
            FileOutputStream mark = new FileOutputStream(marker);
            mark.close();
            return lib.getAbsolutePath();
        } catch (Exception ex) {
            return null;
        }
    }

    private static byte[] readAll(java.io.InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }

    private String runWorkingDir() {
        String pref = Prefs.termDir(this);
        if (pref != null && !pref.trim().isEmpty()) {
            return pref.trim();
        }
        if (android.os.Build.VERSION.SDK_INT >= 30
                && android.os.Environment.isExternalStorageManager()) {
            return "/sdcard";
        }
        File f = getExternalFilesDir(null);
        if (f != null) {
            if (!f.isDirectory()) f.mkdirs();
            return f.getAbsolutePath();
        }
        return getFilesDir().getAbsolutePath();
    }

    private void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        int bgc = theme.bg;
        boolean lightBg = (0.299f * android.graphics.Color.red(bgc)
                + 0.587f * android.graphics.Color.green(bgc)
                + 0.114f * android.graphics.Color.blue(bgc)) > 140f;
        int bgc2 = lightBg ? 0xFFF4F5F7 : 0xFF1E1F22;
        drawerBgUsed = bgc2;
        drawer.setBackgroundColor(bgc2);
        drawer.setPadding((int) d(14), (int) d(28), (int) d(14), (int) d(14));

        // 整个抽屉放进一个 ScrollView：菜单项 + 文件列表都能滑，不再被屏幕高度卡住
        android.widget.ScrollView drawerScroll = new android.widget.ScrollView(this);
        drawerScroll.setFillViewport(true);
        drawerScroll.setVerticalScrollBarEnabled(true);
        LinearLayout drawerCol = new LinearLayout(this);
        drawerCol.setOrientation(LinearLayout.VERTICAL);
        drawerScroll.addView(drawerCol, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        drawer.addView(drawerScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView title = new TextView(this);
        title.setText("YHHYPy");
        title.setTextSize(17);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        title.setPadding(0, 0, 0, (int) d(10));
        drawerCol.addView(title);

        final LinearLayout fileGroup = new LinearLayout(this);
        fileGroup.setOrientation(LinearLayout.VERTICAL);
        fileGroup.setVisibility(View.GONE);
        fileGroup.addView(drawerRow(Lang.s("   新建文件"), () -> {
            closeDrawer();
            newDocument();
        }));
        fileGroup.addView(drawerRow(Lang.s("   打开文件…"), () -> {
            closeDrawer();
            openPicker();
        }));
        fileGroup.addView(drawerRow(Lang.s("   最近文件…"), () -> {
            closeDrawer();
            showRecents();
        }));
        final TextView fileHead = drawerRow(Lang.s("文件 \u25B8"), () -> {});
        fileHead.setOnClickListener(v -> {
            boolean show = fileGroup.getVisibility() != View.VISIBLE;
            fileGroup.setVisibility(show ? View.VISIBLE : View.GONE);
            fileHead.setText(show ? Lang.s("文件 \u25BE") : Lang.s("文件 \u25B8"));
        });
        drawerCol.addView(fileHead);
        drawerCol.addView(fileGroup);




        drawerCol.addView(drawerRow(Lang.s("查看语法问题"), () -> {
            closeDrawer();
            showProblems();
        }));
        // 折叠子菜单：和「文件 ▸」一样的抽屉内联展开，而不是弹出菜单
        final LinearLayout foldGroup = new LinearLayout(this);
        foldGroup.setOrientation(LinearLayout.VERTICAL);
        foldGroup.setVisibility(View.GONE);
        foldGroup.addView(drawerRow("   " + Lang.s("折叠所有"), () -> {
            closeDrawer();
            editor.foldAll(EditorView.FOLD_ALL);
        }));
        foldGroup.addView(drawerRow("   " + Lang.s("折叠关键字"), () -> {
            closeDrawer();
            editor.foldAll(EditorView.FOLD_KEYWORD);
        }));
        foldGroup.addView(drawerRow("   " + Lang.s("折叠多行赋值和函数"), () -> {
            closeDrawer();
            editor.foldAll(EditorView.FOLD_MULTI_FUNC);
        }));
        foldGroup.addView(drawerRow("   " + Lang.s("展开全部"), () -> {
            closeDrawer();
            editor.unfoldAll();
        }));
        final TextView foldHead = drawerRow(Lang.s("折叠") + " \u25B8", () -> {});
        foldHead.setOnClickListener(v -> {
            boolean show = foldGroup.getVisibility() != View.VISIBLE;
            foldGroup.setVisibility(show ? View.VISIBLE : View.GONE);
            foldHead.setText(show ? Lang.s("折叠") + " \u25BE"
                    : Lang.s("折叠") + " \u25B8");
        });
        drawerCol.addView(foldHead);
        drawerCol.addView(foldGroup);
        final LinearLayout cmdGroup = new LinearLayout(this);
        cmdGroup.setOrientation(LinearLayout.VERTICAL);
        cmdGroup.setVisibility(View.GONE);
        cmdGroup.addView(drawerRow(Lang.s("   终端（Shell）"), () -> {
            closeDrawer();
            openZone(KIND_TERM);
        }));
        cmdGroup.addView(drawerRow(Lang.s("   解释器"), () -> {
            closeDrawer();
            openZone(KIND_INTERP);
        }));
        final TextView cmdHead = drawerRow(Lang.s("命令行 \u25B8"), () -> {});
        cmdHead.setOnClickListener(v -> {
            boolean show = cmdGroup.getVisibility() != View.VISIBLE;
            cmdGroup.setVisibility(show ? View.VISIBLE : View.GONE);
            cmdHead.setText(show ? Lang.s("命令行 \u25BE") : Lang.s("命令行 \u25B8"));
        });
        drawerCol.addView(cmdHead);
        drawerCol.addView(cmdGroup);
        drawerCol.addView(drawerRow(Lang.s("包管理 (pip)…"), () -> {
            closeDrawer();
            startActivity(new Intent(this, PipActivity.class));
        }));
        drawerCol.addView(drawerRow(Lang.s("设置…"), () -> {
            closeDrawer();
            startActivity(new Intent(this, SettingsActivity.class));
        }));

        TextView filesHead = new TextView(this);
        filesHead.setText(Lang.s("打开的文件"));
        filesHead.setTextSize(11);
        filesHead.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        filesHead.setPadding(0, (int) d(16), 0, (int) d(6));
        drawerCol.addView(filesHead);

        drawerFiles = new LinearLayout(this);
        drawerFiles.setOrientation(LinearLayout.VERTICAL);
        drawerCol.addView(drawerFiles);
    }

    private TextView drawerRow(String text, Runnable r) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(theme.colors[Theme.TOK_TEXT]);
        t.setPadding((int) d(8), (int) d(11), (int) d(8), (int) d(11));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void openDrawer() {
        closeAllMinimaps();
        refreshDrawerFiles();
        drawer.setVisibility(View.VISIBLE);
        drawerScrim.setVisibility(View.VISIBLE);
        drawerScrim.setAlpha(0f);
        drawer.setTranslationX(-drawer.getWidth() > 0 ? -drawer.getWidth() : -d(286));
        drawer.animate().translationX(0).setDuration(180).start();
        drawerScrim.animate().alpha(1f).setDuration(180).start();
        drawerOpen = true;
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawer.animate().translationX(-d(286)).setDuration(160)
                .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
        drawerScrim.animate().alpha(0f).setDuration(160)
                .withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
        drawerOpen = false;
    }

    private void refreshDrawerFiles() {
        if (drawerFiles == null) return;
        drawerFiles.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);
            TextView row = new TextView(this);
            String where = "";
            for (int k = 0; k < panes.size(); k++) {
                if (panes.get(k).tabIdx == i) {
                    where = "  [区 " + (k + 1) + "]";
                    break;
                }
            }
            row.setText((i == curTab ? "▸ " : "   ") + t.name + (t.dirty ? " ●" : "") + where);
            row.setTextSize(12.5f);
            row.setTextColor(i == curTab ? theme.colors[Theme.TOK_STRING]
                    : theme.colors[Theme.TOK_TEXT]);
            row.setPadding((int) d(8), (int) d(9), (int) d(8), (int) d(9));
            row.setOnClickListener(v -> {
                closeDrawer();
                requestReplace(idx);
            });
            row.setOnLongClickListener(v -> {
                closeTab(idx);
                return true;
            });
            drawerFiles.addView(row);
        }
        if (tabs.isEmpty()) {
            TextView e = new TextView(this);
            e.setText(Lang.s("（暂无）"));
            e.setTextSize(11.5f);
            e.setTextColor(theme.statusText);
            e.setPadding((int) d(8), (int) d(8), 0, 0);
            drawerFiles.addView(e);
        }
    }

    /** 解释器区：把 REPL 脚本写进缓存，用这个区的运行面板跑起来（stdin 已接上）。 */
    private void startReplIn(Pane pane) {
        if (pane == null || pane.repl == null) return;
        try {
            File dir = new File(getCacheDir(), "repl");
            dir.mkdirs();
            File f = new File(dir, "repl.py");
            String src =
                    "import sys\n" +
                    "try:\n" +
                    "    sys.stdout.reconfigure(line_buffering=True)\n" +
                    "except Exception:\n" +
                    "    pass\n" +
                    Lang.s("print('YHHYPy 解释器 · 输入 exit() 退出')\n") +
                    "g = {}\n" +
                    "while True:\n" +
                    "    try:\n" +
                    "        src = input('>>> ')\n" +
                    "    except EOFError:\n" +
                    "        break\n" +
                    "    if src.strip() in ('exit()', 'quit()'):\n" +
                    "        break\n" +
                    "    try:\n" +
                    "        exec(compile(src, '<stdin>', 'single'), g)\n" +
                    "    except SystemExit:\n" +
                    "        break\n" +
                    "    except Exception as e:\n" +
                    "        print(type(e).__name__ + ': ' + str(e))\n" +
                    "    sys.stdout.flush()\n";
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            out.write(src.getBytes("UTF-8"));
            out.close();
            String[] cmd = new String[]{interpBin(), "-S", "-u", f.getAbsolutePath()};
            collapseOtherFull(null);
            pane.repl.runRepl(cmd, interpEnv(), runWorkingDir());
        } catch (Exception e) {
            toast(Lang.s("解释器启动失败: ") + e.getMessage());
        }
    }

    private String interpBin() {
        String lib = getApplicationInfo().nativeLibraryDir;
        return new File(lib, "libcpython.so").getAbsolutePath();
    }

    private java.util.Map<String, String> interpEnv() {
        String stdlib = ensureStdlib();
        java.util.Map<String, String> env = new java.util.HashMap<>();
        String sp = SitePkgs.pathEnv(this);
        if (stdlib != null) env.put("PYTHONPATH", sp.isEmpty() ? stdlib : stdlib + ":" + sp);
        env.put("PYTHONHOME", new File(getFilesDir(), "python").getAbsolutePath());
        env.put("PYTHONIOENCODING", "utf-8");
        return env;
    }

    /** 主题切换后重建抽屉（抽屉的底色/文字色在构建时写死）。 */
    private void refreshDrawerTheme() {
        if (drawer == null || shell == null || drawerLp == null) return;
        int bgc = theme.bg;
        boolean lightBg = (0.299f * android.graphics.Color.red(bgc)
                + 0.587f * android.graphics.Color.green(bgc)
                + 0.114f * android.graphics.Color.blue(bgc)) > 140f;
        int want = lightBg ? 0xFFF4F5F7 : 0xFF1E1F22;
        if (want == drawerBgUsed) return;
        boolean wasOpen = drawerOpen;
        shell.removeView(drawer);
        buildDrawer();
        shell.addView(drawer, drawerLp);
        drawer.setVisibility(wasOpen ? View.VISIBLE : View.GONE);
        drawerOpen = wasOpen;
    }

    private void applyTheme() {
        for (Pane p : panes) {
            if (p.isEditor()) {
                p.view.setTheme(theme, true);
                if (p.host != null) p.host.applyTheme(theme);
            } else if (p.term != null) {
                p.term.applyTheme(theme);
            } else if (p.repl != null) {
                p.repl.applyTheme(theme);
            }
        }
        if (paneLayout != null) {
            paneLayout.setColors(theme.bg, theme.gutterText, theme.colors[Theme.TOK_KEYWORD], 0xFFFF6B6B);
        }
        if (runPanel != null) runPanel.applyTheme(theme);
        if (findBar != null) findBar.applyTheme(theme);
        getWindow().setStatusBarColor(theme.statusBg);
        getWindow().setNavigationBarColor(theme.statusBg);
        Immersive.applyStatusBarIcons(this, theme.statusBg);
        topBar.setBackgroundColor(theme.statusBg);
        titleView.setTextColor(theme.statusBg == 0xFFFFFFFF ? 0xFF24292E : 0xFFE0E0E0);
        if (statusBar != null) statusBar.setBackgroundColor(theme.statusBg);
        if (statusBarTop != null) statusBarTop.setBackgroundColor(theme.statusBg);
        if (statusView != null) statusView.setTextColor(theme.statusText);
        if (statusViewTop != null) statusViewTop.setTextColor(theme.statusText);
        if (topStatus != null) topStatus.setTextColor(theme.statusText);
        refreshDrawerTheme();
        updateStatus();
    }

    private boolean edgeDrawerDragging;
    private View backAnimView;
    private int backAnimKind;   // 1 查找栏 2 抽屉 3 终端 4 运行面板
    private boolean backAnimActive;

    /** 预测性返回开始时决定这一下会关闭哪一层，并用跟手动画。 */
    /** 左侧行首右滑：抽屉跟着手指走。 */
    private void edgeSwipeProgress(float progress) {
        if (drawer == null) return;
        if (!edgeDrawerDragging) {
            edgeDrawerDragging = true;
            refreshDrawerFiles();
            drawer.animate().cancel();
            drawer.setVisibility(View.VISIBLE);
            drawerScrim.setVisibility(View.VISIBLE);
            drawerScrim.setAlpha(0f);
            drawer.setTranslationX(-d(228));
        }
        int w = drawer.getWidth();
        if (w <= 0) w = (int) d(228);
        drawer.setTranslationX(-w * (1f - progress));
        drawerScrim.setAlpha(progress);
    }

    private void edgeSwipeEnd(boolean open) {
        if (!edgeDrawerDragging) {
            if (open) openDrawer();
            return;
        }
        edgeDrawerDragging = false;
        if (open) {
            drawer.animate().translationX(0f).setDuration(160).start();
            drawerScrim.animate().alpha(1f).setDuration(160).start();
            drawerOpen = true;
        } else {
            drawer.animate().translationX(-d(286)).setDuration(160)
                    .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
            drawerScrim.animate().alpha(0f).setDuration(160)
                    .withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
            drawerOpen = false;
        }
    }

    private void predictiveStart() {
        backAnimView = null;
        backAnimKind = 0;
        if (findBar != null && findBar.isOpen()) {
            backAnimKind = 1;
            backAnimView = findBar;
        } else if (drawerOpen) {
            backAnimKind = 2;
            backAnimView = drawer;
        } else if (runPanel != null && runPanel.isOpen()) {
            backAnimKind = 4;
            backAnimView = runPanel;
        }
        if (backAnimView != null) backAnimView.animate().cancel();
        backAnimActive = backAnimView != null;
    }

    private void predictiveProgress(float progress) {
        if (!backAnimActive || backAnimView == null) return;
        float p = Math.max(0f, Math.min(1f, progress));
        if (backAnimKind == 2) {
            int w = drawer.getWidth();
            if (w <= 0) w = (int) d(228);
            drawer.setTranslationX(-w * p);
            drawerScrim.setAlpha(1f - p);
        } else {
            int h = backAnimView.getHeight();
            if (h <= 0) h = (int) d(160);
            backAnimView.setTranslationY(h * p);
            backAnimView.setAlpha(1f - p);
        }
    }

    private void predictiveCancel() {
        if (!backAnimActive || backAnimView == null) {
            backAnimActive = false;
            return;
        }
        if (backAnimKind == 2) {
            drawer.animate().translationX(0f).setDuration(140).start();
            drawerScrim.animate().alpha(1f).setDuration(140).start();
        } else {
            backAnimView.animate().translationY(0f).alpha(1f).setDuration(140).start();
        }
        backAnimActive = false;
    }

    private void predictiveInvoke() {
        int kind = backAnimKind;
        View v = backAnimView;
        boolean active = backAnimActive;
        backAnimActive = false;
        backAnimView = null;
        backAnimKind = 0;
        if (!active) {
            handleBack();
            return;
        }
        handleBack();
        if (kind == 2) {
            // 抽屉自己会滑出，等动画结束再复位，避免闪一下
            drawer.postDelayed(() -> {
                drawer.setTranslationX(0f);
                drawerScrim.setAlpha(1f);
            }, 220);
        } else if (v != null) {
            v.setTranslationY(0f);
            v.setAlpha(1f);
        }
    }

    /** 返回优先级：换位/替换 → 查找栏 → 抽屉 → 运行面板 → 补全 → 退出确认。 */
    private void handleBack() {
        if (paneLayout != null && paneLayout.isSwapMode()) {
            paneLayout.setSwapMode(false);
            return;
        }
        if (panePick) {
            panePick = false;
            pendingReplaceTab = -1;
            if (paneLayout != null) paneLayout.setPickMode(false);
            return;
        }
        if (anyMinimapOpen()) {
            closeAllMinimaps();
            return;
        }
        if (findBar != null && findBar.isOpen()) {
            findBar.close();
            return;
        }
        if (drawerOpen) {
            closeDrawer();
            return;
        }
        if (runPanel != null && runPanel.isOpen()) {
            runPanel.close();
            if (editor != null) editor.requestFocus();
            return;
        }
        if (editor != null && editor.completionVisible()) {
            editor.hideCompletion();
            return;
        }
        if (anyPaneDirty()) {
            new AlertDialog.Builder(this)
                    .setTitle(Lang.s("有未保存的修改"))
                    .setMessage(Lang.s("是否保存后再退出？"))
                    .setPositiveButton(Lang.s("保存"), (d, w) -> {
                        saveAllDirty();
                        if (editor != null && editor.isDirty() && currentUri == null) {
                            saveAs();
                        } else {
                            finish();
                        }
                    })
                    .setNegativeButton(Lang.s("不保存"), (d, w) -> finish())
                    .setNeutralButton(Lang.s("取消"), null)
                    .show();
            return;
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onDestroy() {
        BackCompat.unregister(this, backToken);
        backToken = null;
        // 最后一次机会（正常退出时 onPause/onStop 已经存过，这里是兜底）
        zoneHandler.removeCallbacks(zoneSaveLater);
        saveZoneState();
        super.onDestroy();
    }
}
