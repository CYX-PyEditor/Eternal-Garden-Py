package com.yhhy.pyeditor;

import android.content.Context;
import android.content.SharedPreferences;

/** 非外观类设置：语法检查、自动保存、终端默认目录。 */
public final class Prefs {

    private static final String NAME = "pyedit";

    private Prefs() {
    }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static boolean syntaxCheck(Context c) {
        return p(c).getBoolean("syntax_check", true);
    }

    public static void setSyntaxCheck(Context c, boolean v) {
        p(c).edit().putBoolean("syntax_check", v).apply();
    }

    public static boolean autoSave(Context c) {
        return p(c).getBoolean("autosave", true);
    }

    public static void setAutoSave(Context c, boolean v) {
        p(c).edit().putBoolean("autosave", v).apply();
    }

    /** 用户自带的 C 编译器目录（可为空）。 */
    public static String ccDir(Context c) {
        return p(c).getString("cc_dir", "");
    }

    public static void setCcDir(Context c, String v) {
        p(c).edit().putString("cc_dir", v == null ? "" : v).apply();
    }

    public static int completeMax(Context c) {
        return Math.max(1, Math.min(20, p(c).getInt("complete_max", 5)));
    }

    public static void setCompleteMax(Context c, int v) {
        p(c).edit().putInt("complete_max", Math.max(1, Math.min(20, v))).apply();
    }

    /** 多编辑区开关（5.4.0）。 */
    public static boolean multiPane(Context c) {
        return p(c).getBoolean("multi_pane", false);
    }

    public static void setMultiPane(Context c, boolean v) {
        p(c).edit().putBoolean("multi_pane", v).apply();
    }

    /** 底部「行/列」状态栏开关（5.5.4 回退包）。 */
    public static boolean showStatusBar(Context c) {
        return p(c).getBoolean("show_status_bar", true);
    }

    public static void setShowStatusBar(Context c, boolean v) {
        p(c).edit().putBoolean("show_status_bar", v).apply();
    }

    // ---------------- 5.6.0：底部状态栏按方向分别开关 + 顶栏（常用栏）显示

    /**
     * 横屏时是否显示底部「行/列 + 语法问题」状态栏。
     *
     * <p>5.6.0 前只有一个 {@code show_status_bar} 总开关；这里在缺省时回落到旧值，
     * 老用户升级后不会突然两边都不一样。
     */
    public static boolean statusBarLandscape(Context c) {
        SharedPreferences sp = p(c);
        return sp.getBoolean("status_bar_land", sp.getBoolean("show_status_bar", true));
    }

    public static void setStatusBarLandscape(Context c, boolean v) {
        p(c).edit().putBoolean("status_bar_land", v).apply();
    }

    /** 竖屏时是否显示底部状态栏。 */
    public static boolean statusBarPortrait(Context c) {
        SharedPreferences sp = p(c);
        return sp.getBoolean("status_bar_port", sp.getBoolean("show_status_bar", true));
    }

    public static void setStatusBarPortrait(Context c, boolean v) {
        p(c).edit().putBoolean("status_bar_port", v).apply();
    }

    // 位置：0 = 底部，1 = 顶部（横屏 / 竖屏各存一份）
    public static final int BAR_BOTTOM = 0, BAR_TOP = 1;

    /** 横屏时状态栏放哪：底部（默认）还是顶部。 */
    public static int statusBarLandscapePos(Context c) {
        return p(c).getInt("status_bar_land_pos", BAR_BOTTOM) == BAR_TOP ? BAR_TOP : BAR_BOTTOM;
    }

    public static void setStatusBarLandscapePos(Context c, int v) {
        p(c).edit().putInt("status_bar_land_pos", v == BAR_TOP ? BAR_TOP : BAR_BOTTOM).apply();
    }

    /** 竖屏时状态栏放哪：底部（默认）还是顶部。 */
    public static int statusBarPortraitPos(Context c) {
        return p(c).getInt("status_bar_port_pos", BAR_BOTTOM) == BAR_TOP ? BAR_TOP : BAR_BOTTOM;
    }

    public static void setStatusBarPortraitPos(Context c, int v) {
        p(c).edit().putInt("status_bar_port_pos", v == BAR_TOP ? BAR_TOP : BAR_BOTTOM).apply();
    }

    /** 是否在顶栏（有「常用」按钮的那一行，也就是「常用栏」）显示行/列与问题数。 */
    public static boolean statusBarInTopBar(Context c) {
        return p(c).getBoolean("status_bar_top", false);
    }

    public static void setStatusBarInTopBar(Context c, boolean v) {
        p(c).edit().putBoolean("status_bar_top", v).apply();
    }

    // ---------------- 5.6.0：多区布局（1×2 / 1×3 / 2×2）

    // 5.6.0 起排布偏好 = 每行最多几格：1×2 / 1×3 / 1×4 / 1×5 / 1×6
    public static final int LAYOUT_1X2 = 1, LAYOUT_1X3 = 2, LAYOUT_1X4 = 3,
            LAYOUT_1X5 = 4, LAYOUT_1X6 = 5;

    /** 多区排布偏好（1×2 … 1×6，手机平板都能改）。 */
    public static int zoneLayout(Context c) {
        int v = p(c).getInt("zone_layout", LAYOUT_1X2);
        if (v < LAYOUT_1X2 || v > LAYOUT_1X6) v = LAYOUT_1X2;
        return v;
    }

    public static void setZoneLayout(Context c, int v) {
        p(c).edit().putInt("zone_layout", v).apply();
    }

    // ---------------- 5.6.1：记住上次的分区（几个区、怎么分、每个区是什么）

    /** PaneLayout.saveLayout 的序列化字符串。 */
    public static String zoneState(Context c) {
        return p(c).getString("zone_state", null);
    }

    /** 每个区一行：类型 / 文件 uri / 文件名 / 光标行列（字段 URL 编码）。 */
    public static String zonePanes(Context c) {
        return p(c).getString("zone_panes", null);
    }

    public static int zoneFocus(Context c) {
        return p(c).getInt("zone_focus", 0);
    }

    /**
     * 分区记忆用 {@code commit()} 同步写：{@code apply()} 是异步落盘，
     * 被系统/最近任务划掉时排队中的写会丢，导致重开读到的是更早的旧记录。
     *
     * @return 是否成功写进磁盘
     */
    public static boolean setZoneState(Context c, String geometry, String panes, int focus) {
        return p(c).edit()
                .putString("zone_state", geometry)
                .putString("zone_panes", panes)
                .putInt("zone_focus", Math.max(0, focus))
                .commit();
    }

    public static void clearZoneState(Context c) {
        p(c).edit().remove("zone_state").remove("zone_panes").remove("zone_focus").apply();
    }

    /** 手机（smallestScreenWidthDp &lt; 600）只能用 1×2。 */
    public static boolean largeScreen(Context c) {
        return c.getResources().getConfiguration().smallestScreenWidthDp >= 600;
    }

    /** 右侧大纲导航（MiniMap）开关（5.5.0）。 */
    public static boolean miniMap(Context c) {
        return p(c).getBoolean("minimap", true);
    }

    public static void setMiniMap(Context c, boolean v) {
        p(c).edit().putBoolean("minimap", v).apply();
    }

    public static String termDir(Context c) {
        return p(c).getString("term_dir", "");
    }

    public static void setTermDir(Context c, String v) {
        p(c).edit().putString("term_dir", v == null ? "" : v.trim()).apply();
    }
}
