package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * 右侧大纲小地图（5.5.0）。
 *
 * <p>只画色块与红点，<b>不画任何文字</b>：顶层 function / class 用语法高亮里的函数色、类色，
 * 类里的方法 / 嵌套函数用同一色系压暗后的短色块表示层级；有语法错误的行按比例画红点。
 * 当前可见区域用一个很淡的框标出来。
 *
 * <p>触摸：按下 / 拖动 / 抬起都按
 * {@code targetScrollY = touchY / sidebarHeight * totalScrollHeight} 直接跳滚动位置，
 * 编辑器的 {@code scrollY} 实时跟手。
 */
class MiniMapView extends View {

    private final EditorView editor;
    private Theme theme;

    private final Paint blockPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint errPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint viewPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint viewFill = new Paint();
    private final Paint borderPaint = new Paint();
    private final RectF tmpRect = new RectF();
    private final float dp;

    private DocOutline.Item[] items = new DocOutline.Item[0];
    private int[] errLines = new int[0];
    private int totalLines = 1;
    private int lastRev = Integer.MIN_VALUE;
    private int lastProb = Integer.MIN_VALUE;
    private int bgColor, borderColor;

    MiniMapView(Context ctx, EditorView editor) {
        super(ctx);
        this.editor = editor;
        dp = ctx.getResources().getDisplayMetrics().density;
        blockPaint.setStyle(Paint.Style.FILL);
        errPaint.setStyle(Paint.Style.FILL);
        viewPaint.setStyle(Paint.Style.STROKE);
        viewPaint.setStrokeWidth(Math.max(1f, dp));
        viewFill.setStyle(Paint.Style.FILL);
        borderPaint.setStyle(Paint.Style.FILL);
        setClickable(true);
    }

    void setTheme(Theme t) {
        theme = t;
        calcColors();
        invalidate();
    }

    private void calcColors() {
        if (theme == null) return;
        bgColor = blend(theme.bg, theme.gutterText, 0.14f);
        borderColor = blend(theme.bg, theme.gutterText, 0.42f);
        borderPaint.setColor(borderColor);
        borderPaint.setAlpha(150);
        viewPaint.setColor(blend(theme.bg, theme.colors[Theme.TOK_TEXT], 0.55f));
        viewPaint.setAlpha(120);
        viewFill.setColor(theme.colors[Theme.TOK_TEXT]);
        viewFill.setAlpha(20);
    }

    private static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg2 = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg2 - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** 正文 revision / 错误数变化时重算数据；光标移动、滚动只重画。 */
    void onEditorChanged() {
        if (!isShown() || getWidth() <= 0) return;
        if (stale()) refresh();
        invalidate();
    }

    /** 打开侧边栏时强制按当前文本算一次（此时宽度可能还是 0）。 */
    void refreshNow() {
        refresh();
        invalidate();
    }

    /** 编辑器滚动位置变了：只要重画可见区域框。 */
    void onEditorScrolled() {
        invalidate();
    }

    private boolean stale() {
        return editor.revision() != lastRev || editor.problemCount() != lastProb;
    }

    private void refresh() {
        lastRev = editor.revision();
        lastProb = editor.problemCount();
        java.util.ArrayList<DocOutline.Item> list = editor.ensureOutline();
        items = list.isEmpty() ? new DocOutline.Item[0] : list.toArray(new DocOutline.Item[0]);
        totalLines = Math.max(1, editor.lineCount());
        errLines = editor.problemLineSnapshot(240);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (theme == null) return;
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (stale()) refresh();
        canvas.drawColor(bgColor);
        // 左侧分隔线：和正文明确分开
        canvas.drawRect(0, 0, Math.max(1f, dp * 0.75f), h, borderPaint);

        float pad = dp * 3f;
        float usable = Math.max(1f, h - pad * 2f);
        float unit = usable / (float) totalLines;
        float left = dp * 5f;
        float right = w - dp * 5f;
        // 大纲色块：只画矩形，不画文字
        for (DocOutline.Item it : items) {
            if (it.line >= totalLines) break;
            float y1 = pad + it.line * unit;
            if (y1 > h) break;
            float y2 = pad + (it.endLine + 1) * unit;
            float bh = Math.max(dp * 2f, y2 - y1);
            float l = it.kind == DocOutline.METHOD ? dp * 14f : left;
            float r = it.kind == DocOutline.METHOD ? right - dp * 3f : right;
            if (r <= l) r = l + dp;
            int color;
            int alpha;
            if (it.kind == DocOutline.CLASS) {
                color = theme.colors[Theme.TOK_CLASS];
                alpha = 210;
            } else if (it.kind == DocOutline.METHOD) {
                color = blend(theme.colors[Theme.TOK_DEF], theme.bg, 0.35f);
                alpha = 130;
            } else {
                color = theme.colors[Theme.TOK_DEF];
                alpha = 195;
            }
            blockPaint.setColor(color);
            blockPaint.setAlpha(alpha);
            canvas.drawRoundRect(l, y1, r, y1 + bh, dp, dp, blockPaint);
        }
        // 语法错误：按行比例画小红点（超过 240 个已按 stride 抽样）
        errPaint.setColor(theme.problem);
        errPaint.setAlpha(235);
        float ex = w - dp * 6.5f;
        float er = Math.max(dp * 1.8f, 2f);
        for (int line : errLines) {
            float cy = pad + (line + 0.5f) * unit;
            if (cy < er) cy = er;
            if (cy > h - er) cy = h - er;
            canvas.drawCircle(ex, cy, er, errPaint);
        }
        // 当前可见区域
        float content = Math.max(1f, editor.contentHeightPx());
        float vy = pad + (Math.max(0f, editor.scrollY()) / content) * usable;
        float vh = Math.max(dp * 4f, (editor.getHeight() / content) * usable);
        if (vy + vh > h - pad) vh = Math.max(dp * 4f, h - pad - vy);
        if (vy < pad) vy = pad;
        tmpRect.set(dp, vy, w - dp, vy + vh);
        canvas.drawRoundRect(tmpRect, dp * 1.5f, dp * 1.5f, viewFill);
        canvas.drawRoundRect(tmpRect, dp * 1.5f, dp * 1.5f, viewPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                jumpTo(e.getY());
                return true;
            case MotionEvent.ACTION_MOVE:
                jumpTo(e.getY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                jumpTo(e.getY());
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    /** targetScrollY = (touchY / sidebarHeight) * totalScrollHeight */
    private void jumpTo(float y) {
        float h = Math.max(1f, getHeight());
        float f = y / h;
        if (f < 0f) f = 0f;
        if (f > 1f) f = 1f;
        editor.setVerticalScroll(Math.round(f * editor.maxScrollYValue()));
        invalidate();
    }
}
