package com.yhhy.pyeditor;

import java.util.ArrayList;

/**
 * 右侧 MiniMap（大纲导航）用的代码块扫描（纯 Java，可 JVM 单测）。
 *
 * <p>只收集两类节点：
 * <ul>
 *   <li>顶层的 {@code def} / {@code async def} / {@code class}</li>
 *   <li>它们内部缩进更深的 {@code def}（类的方法 / 函数里的嵌套函数）</li>
 * </ul>
 * 字符串（含三引号）与注释里的内容不计入；每个节点的结束行按「下一条缩进 ≤ 自己的代码行」
 * 推算，所以带装饰器、多行签名、函数里夹空行/注释都不影响。结果按行号升序，
 * 最多 {@link #MAX_ITEMS} 个，避免超大文件把侧边栏画出几万个色块。
 */
final class DocOutline {

    static final int CLASS = 0, FUNC = 1, METHOD = 2;
    static final int MAX_ITEMS = 400;

    static final class Item {
        final String name;
        final int line;      // 0 基起始行
        final int endLine;   // 0 基结束行（含）
        final int kind;

        Item(String name, int line, int endLine, int kind) {
            this.name = name;
            this.line = line;
            this.endLine = endLine;
            this.kind = kind;
        }

        @Override
        public String toString() {
            return kind + ":" + name + "@" + line + "-" + endLine;
        }
    }

    private DocOutline() {
    }

    static ArrayList<Item> scan(String[] txt) {
        ArrayList<Item> out = new ArrayList<>();
        if (txt == null || txt.length == 0) return out;
        int n = txt.length;
        int[] ind = new int[n];
        boolean[] blank = new boolean[n];
        boolean[] comment = new boolean[n];
        boolean[] code = new boolean[n];
        Lex lex = new Lex();
        for (int i = 0; i < n; i++) {
            ind[i] = indent(txt[i]);
            String t = txt[i].trim();
            blank[i] = t.isEmpty();
            comment[i] = !blank[i] && t.startsWith("#");
            code[i] = !lex.scan(txt[i]);   // 行首在三引号里 → 不算代码
        }
        Item lastTop = null;
        for (int i = 0; i < n && out.size() < MAX_ITEMS; i++) {
            if (blank[i] || comment[i] || !code[i]) continue;
            String[] h = header(txt[i]);
            if (h == null) continue;
            boolean cls = h[0].equals("c");
            int end = blockEnd(i, n, ind, blank, comment, code);
            if (ind[i] == 0) {
                Item it = new Item(h[1], i, end, cls ? CLASS : FUNC);
                out.add(it);
                lastTop = it;
            } else if (lastTop != null && i <= lastTop.endLine) {
                // 只收顶层块内部的方法；模块级 if/try 里的 def 不算大纲
                out.add(new Item(h[1], i, end, METHOD));
            }
        }
        return out;
    }

    /** 返回 {kind, name}，kind 为 "c"（class）或 "f"（def）；不是定义行返回 null。 */
    private static String[] header(String raw) {
        String t = stripComment(raw).trim();
        String rest;
        boolean cls;
        if (t.startsWith("class ")) {
            cls = true;
            rest = t.substring(6);
        } else if (t.startsWith("def ")) {
            cls = false;
            rest = t.substring(4);
        } else if (t.startsWith("async def ")) {
            cls = false;
            rest = t.substring(10);
        } else {
            return null;
        }
        int i = 0;
        if (rest.isEmpty()) return null;
        char c0 = rest.charAt(0);
        if (!(Character.isLetter(c0) || c0 == '_')) return null;
        while (i < rest.length() && (Character.isLetterOrDigit(rest.charAt(i)) || rest.charAt(i) == '_')) i++;
        return new String[]{cls ? "c" : "f", rest.substring(0, i)};
    }

    /** 缩进更深的后继行都算块内；遇到缩进 ≤ 自己的代码行结束。 */
    private static int blockEnd(int i, int n, int[] ind, boolean[] blank, boolean[] comment,
                                boolean[] code) {
        int base = ind[i];
        int j = i + 1;
        while (j < n) {
            if (blank[j] || comment[j] || !code[j]) {
                j++;
                continue;
            }
            if (ind[j] <= base) break;
            j++;
        }
        int end = j - 1;
        while (end > i && (blank[end] || comment[end] || !code[end])) end--;
        return Math.max(i, end);
    }

    private static int indent(String s) {
        int k = 0;
        while (k < s.length() && (s.charAt(k) == ' ' || s.charAt(k) == '\t')) k++;
        return k;
    }

    private static String stripComment(String s) {
        boolean inStr = false;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                inStr = true;
                q = c;
            } else if (c == '#') {
                return s.substring(0, i);
            }
        }
        return s;
    }

    /** 逐行推进三引号状态：只关心「这行开头是否还在字符串里」。 */
    private static final class Lex {
        boolean inTriple;
        char q;

        boolean scan(String s) {
            boolean started = inTriple;
            int i = 0;
            while (i < s.length()) {
                char c = s.charAt(i);
                if (inTriple) {
                    if (c == '\\') {
                        i += 2;
                        continue;
                    }
                    if (c == q && i + 2 < s.length()
                            && s.charAt(i + 1) == q && s.charAt(i + 2) == q) {
                        inTriple = false;
                        q = 0;
                        i += 3;
                        continue;
                    }
                    i++;
                    continue;
                }
                if (c == '\'' || c == '"') {
                    if (i + 2 < s.length() && s.charAt(i + 1) == c && s.charAt(i + 2) == c) {
                        inTriple = true;
                        q = c;
                        i += 3;
                    } else {
                        i = skipString(s, i, c);
                    }
                    continue;
                }
                if (c == '#') break;
                i++;
            }
            return started;
        }

        private static int skipString(String s, int quote, char q) {
            int i = quote + 1;
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == '\\') {
                    i += 2;
                    continue;
                }
                if (c == q) return i + 1;
                i++;
            }
            return i;
        }
    }
}
