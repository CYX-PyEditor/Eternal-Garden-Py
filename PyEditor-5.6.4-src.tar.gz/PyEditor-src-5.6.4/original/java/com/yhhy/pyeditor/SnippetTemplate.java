package com.yhhy.pyeditor;

import java.util.ArrayList;

/**
 * 片段模板解析（多光标定位点）。
 *
 * <p>支持占位符：
 * <ul>
 *   <li>{@code ${cursor}} / 旧版的 {@code \u0001}：不带序号，按出现顺序排在带序号的后面</li>
 *   <li>{@code ${cursor1}}、{@code ${cursor2}} …：按数字从小到大</li>
 * </ul>
 * 插入时占位符会被删掉，{@link #text} 是剩下的正文，
 * {@link #offsets} 是按跳转顺序排列的占位符偏移（相对 {@link #text}）。
 */
final class SnippetTemplate {

    final String text;
    final int[] offsets;

    private SnippetTemplate(String text, int[] offsets) {
        this.text = text;
        this.offsets = offsets;
    }

    static SnippetTemplate parse(String raw) {
        if (raw == null) raw = "";
        StringBuilder clean = new StringBuilder();
        ArrayList<int[]> ev = new ArrayList<>();   // {offset, key, order}
        int i = 0;
        int n = raw.length();
        while (i < n) {
            char c = raw.charAt(i);
            if (c == Snippets.MARK) {
                ev.add(new int[]{clean.length(), 0, ev.size()});
                i++;
                continue;
            }
            if (c == '$' && raw.startsWith("${cursor", i)) {
                int j = i + "${cursor".length();
                int ds = j;
                while (j < n && Character.isDigit(raw.charAt(j))) j++;
                if (j < n && raw.charAt(j) == '}') {
                    int num = 0;
                    if (j > ds) {
                        try {
                            num = Integer.parseInt(raw.substring(ds, j));
                        } catch (Exception e) {
                            num = Integer.MAX_VALUE;
                        }
                    }
                    ev.add(new int[]{clean.length(), num, ev.size()});
                    i = j + 1;
                    continue;
                }
            }
            clean.append(c);
            i++;
        }
        // 排序：不带数字的 ${cursor}（0）是默认位置，先按出现顺序跳；
        // 然后带数字的按数字从小到大（5.4.6 修正：原来把 0 排到了最后）
        ev.sort((a, b) -> {
            boolean za = a[1] == 0, zb = b[1] == 0;
            if (za != zb) return za ? -1 : 1;
            if (!za && a[1] != b[1]) return Integer.compare(a[1], b[1]);
            return Integer.compare(a[2], b[2]);
        });
        int[] offs = new int[ev.size()];
        for (int k = 0; k < ev.size(); k++) offs[k] = ev.get(k)[0];
        return new SnippetTemplate(clean.toString(), offs);
    }

    /** 预览用：把每个占位符换成 `|`（不编译正则，避免 `\}` 之类的转义坑）。 */
    static String preview(String raw) {
        if (raw == null) raw = "";
        StringBuilder out = new StringBuilder();
        int i = 0;
        int n = raw.length();
        while (i < n) {
            char c = raw.charAt(i);
            if (c == Snippets.MARK) {
                out.append('|');
                i++;
                continue;
            }
            if (c == '$' && raw.startsWith("${cursor", i)) {
                int j = i + "${cursor".length();
                int ds = j;
                while (j < n && Character.isDigit(raw.charAt(j))) j++;
                if (j < n && raw.charAt(j) == '}') {
                    out.append('|');
                    i = j + 1;
                    continue;
                }
            }
            out.append(c);
            i++;
        }
        return out.toString();
    }

    /** 去掉所有占位符后的正文（用于判断模板是否为空）。 */
    static String plainText(String raw) {
        return parse(raw).text;
    }
}
