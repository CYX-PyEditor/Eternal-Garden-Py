package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;

/** Python 运行输出面板（CPython 独立进程）。 */
public class RunPanel extends LinearLayout {

    public interface Host {
        void onCloseRun();
    }

    private static final int MAX_CHARS = 80000;

    private Theme theme;
    private final Host host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final float density;

    private final TextView title;
    private final TextView output;
    private final ScrollView scroll;
    private final TextView runBtn;

    private final SpannableStringBuilder buf = new SpannableStringBuilder();
    private boolean flushPending;

    private volatile Process proc;
    private volatile java.io.OutputStream stdin;
    private EditText input;
    private LinearLayout inputRow;
    private int level = 5;
    private boolean full;
    private boolean wantInput;
    private FullListener fullListener;
    /** 5.6.0：作为「多区」里的解释器区（去掉 0/1/3/5/全 这些分级按钮）。 */
    private boolean zoneMode;
    private boolean replMode;
    private final java.util.ArrayList<TextView> levelViews = new java.util.ArrayList<>();
    private TextView collapseBtn;

    public interface FullListener {
        void onFullChanged(boolean full);
    }

    public RunPanel(Context ctx, Theme theme, Host host) {
        super(ctx);
        this.theme = theme;
        this.host = host;
        this.density = ctx.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setBackgroundColor(theme.statusBg);

        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(d(10), 0, d(6), 0);
        bar.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(30)));

        title = new TextView(ctx);
        title.setTextSize(11.5f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(theme.colors[Theme.TOK_STRING]);
        title.setSingleLine(true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        title.setLayoutParams(tlp);
        bar.addView(title);

        // 5.6.0：分级按钮（0/1/3/5/全）只在「底部运行面板」形态下有意义；
        // 作为多区里的解释器区时由 setZoneMode(true) 全部隐藏。
        addLevel(bar, levelBtn("0", 0));
        addLevel(bar, levelBtn("1", 1));
        addLevel(bar, levelBtn("3", 3));
        addLevel(bar, levelBtn("5", 5));
        addLevel(bar, levelBtn(Lang.s("全"), -1));
        runBtn = smallBtn(Lang.s("停止"), v -> stop());
        bar.addView(smallBtn(Lang.s("清屏"), v -> clear()));
        collapseBtn = smallBtn(Lang.s("收起"), v -> {
            if (host != null) host.onCloseRun();
        });
        bar.addView(collapseBtn);
        runBtn.setVisibility(GONE);
        bar.addView(runBtn);
        addView(bar);

        scroll = new ScrollView(ctx);
        scroll.setBackgroundColor(theme.bg);
        output = new TextView(ctx);
        output.setTextSize(11f);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextColor(theme.colors[Theme.TOK_TEXT]);
        output.setTextIsSelectable(true);
        output.setPadding(d(10), d(6), d(10), d(6));
        output.setLineSpacing(d(1.5f), 1f);
        scroll.addView(output);
        addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- 标准输入（程序里用 input() 时这里输入）
        inputRow = new LinearLayout(ctx);
        inputRow.setOrientation(HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(d(8), d(2), d(8), d(6));
        inputRow.setVisibility(GONE);

        TextView gt = new TextView(ctx);
        gt.setText(">");
        gt.setTextSize(12f);
        gt.setTypeface(Typeface.MONOSPACE);
        gt.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        gt.setPadding(0, 0, d(6), 0);
        inputRow.addView(gt);

        input = new EditText(ctx);
        input.setSingleLine(true);
        input.setTextSize(11.5f);
        input.setTypeface(Typeface.MONOSPACE);
        input.setTextColor(theme.colors[Theme.TOK_TEXT]);
        input.setHint(Lang.s("输入并回车，送给程序的 input()"));
        input.setHintTextColor(theme.gutterText);
        input.setBackground(null);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        input.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                sendLine();
                return true;
            }
            return false;
        });
        inputRow.addView(input, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        inputRow.addView(smallBtn(Lang.s("发送"), v -> sendLine()));
        addView(inputRow);

        setLevel(5);
    }

    private int d(float v) {
        return Math.round(v * density);
    }

    private TextView smallBtn(String text, OnClickListener l) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextSize(10.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(d(8), d(5), d(8), d(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(d(6));
        bg.setColor(theme.curLine);
        t.setBackground(bg);
        t.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(d(3), 0, 0, 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    public void applyTheme(Theme t) {
        theme = t;
        setBackgroundColor(t.statusBg);
        scroll.setBackgroundColor(t.bg);
        output.setTextColor(t.colors[Theme.TOK_TEXT]);
        title.setTextColor(t.colors[Theme.TOK_STRING]);
    }

    public boolean isRunning() {
        return proc != null;
    }

    public boolean isOpen() {
        return getVisibility() == VISIBLE;
    }

    public void setFullListener(FullListener l) {
        fullListener = l;
    }

    public boolean isFull() {
        return full;
    }

    private TextView levelBtn(String text, final int lv) {
        return smallBtn(text, v -> {
            if (lv < 0) {
                if (full) setLevel(level == 0 ? 3 : level);
                else enterFull();
            } else {
                setLevel(lv);
            }
        });
    }

    public void setLevel(int lv) {
        full = false;
        applyLevel(lv);
        if (fullListener != null) fullListener.onFullChanged(false);
    }

    private void applyLevel(int lv) {
        if (zoneMode) return;   // 区域形态：永远铺满自己的格子
        if (lv < 0) lv = 0;
        if (lv > 5) lv = 5;
        level = lv;
        boolean show = lv > 0;
        scroll.setVisibility(show ? VISIBLE : GONE);
        inputRow.setVisibility(show && wantInput ? VISIBLE : GONE);
        int h = lv == 0 ? 30 : lv == 1 ? 96 : lv == 3 ? 136 : 176;
        setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(h)));
    }

    /**
     * 5.6.0：作为多区里的一个「解释器区」。
     *
     * <p>区域形态下没有 0/1/3/5/全 这些分级按钮 —— 大小由分割线决定；
     * 「收起」变成关掉这个区。
     */
    public void setZoneMode(boolean on) {
        if (zoneMode == on) return;
        zoneMode = on;
        for (TextView t : levelViews) t.setVisibility(on ? GONE : VISIBLE);
        if (collapseBtn != null) collapseBtn.setText(on ? "×" : Lang.s("收起"));
        if (on) {
            setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            scroll.setVisibility(VISIBLE);
            inputRow.setVisibility(wantInput ? VISIBLE : GONE);
        } else {
            applyLevel(level);
        }
    }

    public boolean isZoneMode() {
        return zoneMode;
    }

    private void addLevel(LinearLayout bar, TextView t) {
        levelViews.add(t);
        bar.addView(t);
    }

    /** 区被销毁时调用：停掉还在跑的解释器。 */
    public void dispose() {
        stop();
    }

    public void enterFull() {
        if (zoneMode) return;
        if (full) return;
        full = true;
        scroll.setVisibility(VISIBLE);
        inputRow.setVisibility(wantInput ? VISIBLE : GONE);
        setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (fullListener != null) fullListener.onFullChanged(true);
    }

    public void collapseFull() {
        if (!full) return;
        full = false;
        applyLevel(level == 0 ? 3 : level);
    }

    public void close() {
        if (!zoneMode && full) {
            full = false;
            applyLevel(level == 0 ? 3 : level);
        }
        setVisibility(GONE);
        if (fullListener != null) fullListener.onFullChanged(false);
    }

    /** 以「解释器」形态启动 REPL（标题 / 首行都写解释器）。 */
    public void runRepl(final String[] cmd, final java.util.Map<String, String> env,
                        final String cwd) {
        replMode = true;
        try {
            run(cmd, env, cwd, Lang.s("解释器"));
        } finally {
            replMode = false;
        }
    }

    /** 运行脚本；cmd 为完整命令行（解释器 + 参数 + 脚本），env 可为 null。 */
    public void run(final String[] cmd, final java.util.Map<String, String> env,
                    final String cwd, final String displayName) {
        if (proc != null) return;
        setVisibility(VISIBLE);
        clear();
        if (replMode) {
            title.setText(Lang.s("解释器") + "  · CPython 3.12");
            append("▶ " + Lang.s("解释器") + "  · CPython 3.12\n",
                    theme.colors[Theme.TOK_COMMENT]);
        } else {
            title.setText(Lang.s("运行 · ") + displayName + "  (CPython 3.12)");
            append("▶ " + displayName + "  · CPython 3.12\n",
                    theme.colors[Theme.TOK_COMMENT]);
        }

        Process p;
        try {
            File bin = new File(cmd[0]);
            if (!bin.canExecute()) {
                append(Lang.s("解释器不可执行: ") + cmd[0] + "\n", theme.problem);
                append(Lang.s("（安装包里的解释器没有被解压出来？）\n\n"), theme.problem);
                return;
            }
            ProcessBuilder pb = new ProcessBuilder(cmd);
            if (env != null) pb.environment().putAll(env);
            if (cwd != null) {
                File d = new File(cwd);
                if (d.isDirectory()) pb.directory(d);
            }
            pb.redirectErrorStream(true);
            p = pb.start();
        } catch (Exception e) {
            append(e.getClass().getSimpleName() + ": " + e.getMessage() + "\n\n", theme.problem);
            return;
        }
        proc = p;
        try {
            stdin = p.getOutputStream();
        } catch (Exception ignored) {
        }
        runBtn.setVisibility(VISIBLE);
        wantInput = true;
        inputRow.setVisibility(zoneMode || level > 0 ? VISIBLE : GONE);

        new Thread(() -> {
            long t0 = System.currentTimeMillis();
            try {
                InputStream in = p.getInputStream();
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) {
                    final String s = new String(b, 0, n, "UTF-8");
                    ui.post(() -> append(s, theme.colors[Theme.TOK_TEXT]));
                }
            } catch (Exception ignored) {
            }
            int code = -1;
            try {
                code = p.waitFor();
            } catch (Exception ignored) {
            }
            final int rc = code;
            final long ms = System.currentTimeMillis() - t0;
            ui.post(() -> {
                append(Lang.s("\n[结束 · 退出码 ") + rc + Lang.s(" · 用时 ") + ms + " ms]\n",
                        rc == 0 ? theme.colors[Theme.TOK_COMMENT] : theme.problem);
                proc = null;
                stdin = null;
                runBtn.setVisibility(GONE);
                wantInput = false;
                inputRow.setVisibility(GONE);
            });
        }, "pye-run").start();
    }

    private void sendLine() {
        if (input == null) return;
        String t = input.getText().toString();
        java.io.OutputStream os = stdin;
        if (os == null) {
            append(Lang.s("\n[程序已结束，无法输入]\n"), theme.problem);
            return;
        }
        try {
            os.write((t + "\n").getBytes("UTF-8"));
            os.flush();
            append("> " + t + "\n", theme.colors[Theme.TOK_PARAM]);
        } catch (Exception e) {
            append(Lang.s("\n[输入失败: ") + e.getMessage() + "]\n", theme.problem);
        }
        input.setText("");
    }

    private void stop() {
        Process p = proc;
        if (p == null) return;
        try {
            p.destroy();
        } catch (Exception ignored) {
        }
        append(Lang.s("\n[已停止]\n"), theme.problem);
        proc = null;
        stdin = null;
        runBtn.setVisibility(GONE);
        wantInput = false;
        inputRow.setVisibility(GONE);
    }

    public void clear() {
        buf.clearSpans();
        buf.delete(0, buf.length());
        output.setText("");
    }

    private void append(String text, int color) {
        if (text == null || text.isEmpty()) return;
        int start = buf.length();
        buf.append(text);
        buf.setSpan(new ForegroundColorSpan(color), start, buf.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (buf.length() > MAX_CHARS) {
            buf.delete(0, buf.length() - MAX_CHARS);
        }
        if (!flushPending) {
            flushPending = true;
            ui.postDelayed(this::flush, 40);
        }
    }

    private void flush() {
        flushPending = false;
        output.setText(buf);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
}
