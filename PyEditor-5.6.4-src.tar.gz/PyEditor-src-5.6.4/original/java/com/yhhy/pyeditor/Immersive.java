package com.yhhy.pyeditor;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

/**
 * 沉浸模式（5.4.2 横屏；5.6.0 起竖屏也隐藏）。
 *
 * <p>安卓在横屏时默认不会把状态栏让给应用，代码区上方一直压着一条常驻状态栏。
 * 这里在横屏隐藏状态栏、内容使用整个高度，同时按刘海安全区给内容补左右内边距。
 *
 * <p>5.6.0：竖屏也隐藏 Android 系统状态栏（设置里顶栏已经有 App 自己的标题栏，
 * 系统那条 24dp 的栏只是浪费高度）。竖屏时按刘海的上方安全区补 top padding，
 * 保证内容不会被挖孔/灵动岛盖住。
 */
final class Immersive {

    private Immersive() {
    }

    static void apply(Activity a) {
        boolean landscape = a.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        // 每次都先清掉旧的 legacy flag，再用系统栏控制器明确 hide 一次（API 30+），
        // 低版本退回旧 flag。5.5.2 踩过的坑：legacy flag 和控制器混用会导致
        // 旋转后状态栏「偶发消失 / 偶发不消失」。
        w.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 30) {
            // 30+ 只走 WindowInsetsController
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(android.view.WindowInsets.Type.statusBars());
                c.setSystemBarsBehavior(
                        android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        applyCutoutPadding(a);
    }

    /**
     * 状态栏图标明暗：浅色主题（浅色 / Solarized 等）的 statusBg 很亮，如果还用系统的
     * 白色图标，状态栏看起来就像“消失”了。按背景亮度切 LIGHT_STATUS_BAR / dark 图标。
     */
    static void applyStatusBarIcons(Activity a, int barColor) {
        boolean light = (0.299f * android.graphics.Color.red(barColor)
                + 0.587f * android.graphics.Color.green(barColor)
                + 0.114f * android.graphics.Color.blue(barColor)) > 150f;
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                int mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        } else {
            View dv = w.getDecorView();
            int vis = dv.getSystemUiVisibility();
            if (light) vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else vis &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            dv.setSystemUiVisibility(vis);
        }
    }

    /**
     * 刘海安全区：横屏时挖孔在左右两侧，补左右内边距；竖屏（5.6.0 起状态栏也隐藏）
     * 挖孔在顶部，补 top padding，避免第一行顶栏文字被盖住。
     */
    private static void applyCutoutPadding(Activity a) {
        if (Build.VERSION.SDK_INT < 28) return;
        final View decor = a.getWindow().getDecorView();
        decor.setOnApplyWindowInsetsListener((v, insets) -> {
            android.view.DisplayCutout dc = insets.getDisplayCutout();
            int l = 0, r = 0, t = 0;
            if (dc != null) {
                l = dc.getSafeInsetLeft();
                r = dc.getSafeInsetRight();
                t = dc.getSafeInsetTop();
            }
            View content = (v instanceof ViewGroup && ((ViewGroup) v).getChildCount() > 0)
                    ? ((ViewGroup) v).getChildAt(0) : null;
            if (content != null) {
                content.setPadding(l, t + content.getPaddingTop(), r, content.getPaddingBottom());
            }
            return insets;
        });
        decor.requestApplyInsets();
    }
}
