package com.yhhy.pyeditor;

/** JNI bindings for the native editor engine. */
public final class Native {
    static {
        System.loadLibrary("c++_shared");
        System.loadLibrary("pyedit");
    }

    private Native() {}

    // ---- document ----
    public static native long nativeCreate();
    public static native void nativeDestroy(long h);
    public static native void nativeSetText(long h, String text);
    public static native String nativeGetText(long h);
    public static native int nativeLineCount(long h);
    public static native String nativeLineText(long h, int line);
    public static native int nativeLineLength(long h, int line);
    public static native int nativeLineVersion(long h, int line);
    public static native int nativeMaxLineLength(long h);
    public static native int nativeRevision(long h);
    public static native boolean nativeIsDirty(long h);
    public static native void nativeMarkClean(long h);

    // ---- rendering / analysis ----
    public static native int nativeFillRuns(long h, int fromLine, int toLine, int[] out);
    public static native int nativeProblems(long h, int[] out, boolean recheck);
    public static native String[] nativeComplete(long h, int maxItems);

    // ---- cursor / selection ----
    public static native int nativeCursorLine(long h);
    public static native int nativeCursorCol(long h);
    public static native int nativeAnchorLine(long h);
    public static native int nativeAnchorCol(long h);
    public static native boolean nativeHasSelection(long h);
    public static native void nativeSetCursor(long h, int line, int col);
    public static native void nativeSetSelection(long h, int l1, int c1, int l2, int c2);
    public static native void nativeSelectAll(long h);
    public static native void nativeSelectWord(long h, int line, int col);
    public static native void nativeSelectLine(long h, int line);
    public static native void nativeMoveHorizontal(long h, int dir, boolean extend);
    public static native void nativeMoveVertical(long h, int dir, boolean extend);
    public static native void nativeMoveLineEdge(long h, boolean toEnd, boolean extend);
    public static native String nativeSelectedText(long h);

    // ---- editing ----
    public static native boolean nativeInsertText(long h, String s);
    public static native boolean nativeInsertTyped(long h, int c);
    public static native boolean nativeBackspace(long h);
    public static native boolean nativeDeleteForward(long h);
    public static native boolean nativeNewline(long h);
    public static native boolean nativeIndent(long h, boolean outdent);
    public static native boolean nativeUndo(long h);
    public static native boolean nativeRedo(long h);
    public static native boolean nativeCanUndo(long h);
    public static native boolean nativeCanRedo(long h);

    // ---- options ----
    public static native void nativeSetOptions(long h, int tabSize, boolean autoIndent, boolean autoPair);

    // ---- snippets / folding ----
    public static native boolean nativeInsertSnippet(long h, String text, int caretOffset);
    public static native void nativeSnapNow(long h);
    public static native boolean nativeFind(long h, String needle, int fromLine, int fromCol,
                                            boolean ignoreCase, boolean wholeWord, int[] out);
    public static native boolean nativeReplaceRange(long h, int l1, int c1, int l2, int c2, String text);
    public static native boolean nativeReplaceWholeText(long h, String text, int caretLine, int caretCol);
    public static native int nativeFolds(long h, int[] out);          // 3 ints per fold: start,end,kind
    public static native String nativeFoldHeader(long h, int startLine);
}
