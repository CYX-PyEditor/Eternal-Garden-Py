package com.yhhy.pyeditor;

/**
 * 分区快照的编解码（5.6.1 · 纯 Java，不依赖 Android，可 JVM 单测）。
 *
 * <p>格式：{@code ZL1;宽,高;排布偏好;格子数;区下标,左边,右边,上边,下边;…}
 * 边是绝对像素坐标，{@code -1} 表示外框（null 边段）。
 */
final class PaneCodec {

    static final String MAGIC = "ZL1";
    static final int BORDER = -1;

    static final class Layout {
        int w, h, mode, n;
        int[] pane, l, r, t, b;
    }

    private PaneCodec() {
    }

    static String encode(int w, int h, int mode,
                         int[] pane, int[] l, int[] r, int[] t, int[] b) {
        if (pane == null) return null;
        int n = pane.length;
        if (n <= 0 || l.length != n || r.length != n || t.length != n || b.length != n) return null;
        StringBuilder sb = new StringBuilder(MAGIC).append(';');
        sb.append(w).append(',').append(h).append(';');
        sb.append(mode).append(';');
        sb.append(n).append(';');
        for (int i = 0; i < n; i++) {
            sb.append(pane[i]).append(',')
                    .append(l[i]).append(',')
                    .append(r[i]).append(',')
                    .append(t[i]).append(',')
                    .append(b[i]).append(';');
        }
        return sb.toString();
    }

    /** 解析失败（格式不对 / 数量对不上）返回 null，调用方直接退回网格。 */
    static Layout decode(String data) {
        if (data == null) return null;
        String[] parts = data.split(";");
        if (parts.length < 5 || !MAGIC.equals(parts[0].trim())) return null;
        String[] wh = parts[1].split(",");
        if (wh.length != 2) return null;
        Layout out = new Layout();
        try {
            out.w = Integer.parseInt(wh[0].trim());
            out.h = Integer.parseInt(wh[1].trim());
            out.mode = Integer.parseInt(parts[2].trim());
            out.n = Integer.parseInt(parts[3].trim());
        } catch (NumberFormatException e) {
            return null;
        }
        if (out.w <= 0 || out.h <= 0 || out.n <= 0 || out.n > 64) return null;
        if (parts.length != 4 + out.n) return null;
        out.pane = new int[out.n];
        out.l = new int[out.n];
        out.r = new int[out.n];
        out.t = new int[out.n];
        out.b = new int[out.n];
        for (int i = 0; i < out.n; i++) {
            String[] f = parts[4 + i].split(",");
            if (f.length != 5) return null;
            try {
                out.pane[i] = Integer.parseInt(f[0].trim());
                out.l[i] = Integer.parseInt(f[1].trim());
                out.r[i] = Integer.parseInt(f[2].trim());
                out.t[i] = Integer.parseInt(f[3].trim());
                out.b[i] = Integer.parseInt(f[4].trim());
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return out;
    }
}
