package com.yhhy.pyeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

/**
 * 连续赋值语句折叠（5.4.3）。
 *
 * <p>把「多行简单赋值」折成一条摘要，例如：
 * <pre>
 * a=b=c=0
 * d=0
 * e=0
 * </pre>
 * 折叠 → {@code 5 Value = int}（5 个赋值目标，类型统一是 int）。
 *
 * <p>只处理标量赋值的行：值类型是 list/dict/tuple/set 字面量的行交给 {@link FoldScan}，
 * 比较运算符、复合赋值、if/for 之类的语句都不参与。行与行之间允许空行 / 注释。
 */
final class AssignScan {

    static final class Block {
        final int start;
        final int end;
        final String summary;

        Block(int s, int e, String sum) {
            start = s;
            end = e;
            summary = sum;
        }
    }

    private static final HashSet<String> STOP = new HashSet<>(Arrays.asList(
            "if", "elif", "else", "for", "while", "def", "class", "return", "yield",
            "import", "from", "try", "except", "finally", "with", "assert", "del",
            "global", "nonlocal", "raise", "pass", "break", "continue", "lambda",
            "match", "case", "async", "await"));

    private AssignScan() {
    }

    static ArrayList<Block> scan(String[] txt) {
        ArrayList<Block> out = new ArrayList<>();
        if (txt == null || txt.length == 0) return out;
        int n = txt.length;
        int i = 0;
        while (i < n) {
            int[] first = parse(txt[i]);
            if (first == null) {
                i++;
                continue;
            }
            int firstLine = i;
            int lastAssign = i;
            int values = first[0];
            ArrayList<String> types = new ArrayList<>();
            types.add(typeName(first[1]));
            int j = i + 1;
            while (j < n) {
                if (txt[j].trim().isEmpty() || isComment(txt[j])) {
                    j++;
                    continue;
                }
                int[] li = parse(txt[j]);
                if (li == null) break;
                values += li[0];
                types.add(typeName(li[1]));
                lastAssign = j;
                j++;
            }
            if (lastAssign > firstLine) {
                out.add(new Block(firstLine, lastAssign,
                        values + " Value = " + summaryType(types)));
            }
            i = lastAssign > firstLine ? lastAssign + 1 : i + 1;
        }
        return out;
    }

    private static String typeName(int code) {
        switch (code) {
            case FoldScan.T_INT: return "int";
            case FoldScan.T_FLOAT: return "float";
            case FoldScan.T_COMPLEX: return "complex";
            case FoldScan.T_BOOL: return "bool";
            case FoldScan.T_NONE: return "None";
            case FoldScan.T_STR: return "str";
            case FoldScan.T_BYTES: return "bytes";
            default: return "Any";
        }
    }

    private static String summaryType(ArrayList<String> types) {
        ArrayList<String> uniq = new ArrayList<>();
        for (String t : types) {
            if (!uniq.contains(t)) uniq.add(t);
        }
        if (uniq.size() > 2) return "Any";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < uniq.size(); i++) {
            if (i > 0) sb.append('|');
            sb.append(uniq.get(i));
        }
        return sb.toString();
    }

    /** @return {目标个数, 类型码}；不是简单赋值返回 null */
    static int[] parse(String raw) {
        if (raw == null) return null;
        String s = stripComment(raw).trim();
        if (s.isEmpty() || s.startsWith("#") || s.startsWith("@")) return null;
        int kwEnd = 0;
        while (kwEnd < s.length() && (Character.isLetterOrDigit(s.charAt(kwEnd))
                || s.charAt(kwEnd) == '_')) kwEnd++;
        if (kwEnd > 0 && STOP.contains(s.substring(0, kwEnd))) return null;

        // 找顶层 '='（跳过字符串/括号，排除 == != <= >= 复合赋值）
        ArrayList<Integer> eq = new ArrayList<>();
        int depth = 0;
        char q = 0;
        boolean inStr = false;
        boolean inTriple = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inTriple) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q && i + 2 < s.length() && s.charAt(i + 1) == q && s.charAt(i + 2) == q) {
                    i += 2;
                    inTriple = false;
                }
                continue;
            }
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                if (i + 2 < s.length() && s.charAt(i + 1) == c && s.charAt(i + 2) == c) {
                    inTriple = true;
                    i += 2;
                } else {
                    inStr = true;
                }
                q = c;
                continue;
            }
            if (c == '(' || c == '[' || c == '{') {
                depth++;
                continue;
            }
            if (c == ')' || c == ']' || c == '}') {
                depth--;
                continue;
            }
            if (c != '=' || depth != 0) continue;
            char prev = i > 0 ? s.charAt(i - 1) : ' ';
            char next = i + 1 < s.length() ? s.charAt(i + 1) : ' ';
            if (next == '=') return null;                      // ==
            if ("!<>:+-*/%&|^".indexOf(prev) >= 0) return null; // != <= >= 复合赋值
            eq.add(i);
        }
        if (eq.isEmpty()) return null;

        String rhs = s.substring(eq.get(eq.size() - 1) + 1).trim();
        if (rhs.isEmpty()) return null;
        if (rhs.startsWith("[") || rhs.startsWith("{") || rhs.startsWith("(")) return null;
        int code = FoldScan.classifyCode(rhs);
        if (code == FoldScan.T_LIST || code == FoldScan.T_DICT || code == FoldScan.T_SET
                || code == FoldScan.T_TUPLE) return null;

        int count = 0;
        int from = 0;
        for (int k = 0; k < eq.size(); k++) {
            String seg = s.substring(from, eq.get(k)).trim();
            from = eq.get(k) + 1;
            if (seg.isEmpty()) continue;
            if (!validTargets(seg)) return null;
            for (String part : seg.split(",")) {
                if (!part.trim().isEmpty()) count++;
            }
        }
        if (count <= 0) return null;
        return new int[]{count, code};
    }

    private static boolean validTargets(String seg) {
        for (String part : seg.split(",")) {
            String t = part.trim();
            if (t.isEmpty()) continue;
            int colon = t.indexOf(':');
            if (colon >= 0) t = t.substring(0, colon).trim();
            if (!isDottedName(t)) return false;
        }
        return true;
    }

    private static boolean isDottedName(String s) {
        if (s.isEmpty()) return false;
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (!(Character.isLetter(c) || c == '_')) return false;
            i++;
            while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
            if (i == s.length()) return true;
            if (s.charAt(i) != '.') return false;
            i++;
            if (i == s.length()) return false;
        }
        return false;
    }

    private static boolean isComment(String s) {
        return s.trim().startsWith("#");
    }

    private static String stripComment(String s) {
        char q = 0;
        boolean inStr = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                inStr = true;
                q = c;
                continue;
            }
            if (c == '#') return s.substring(0, i);
        }
        return s;
    }
}
