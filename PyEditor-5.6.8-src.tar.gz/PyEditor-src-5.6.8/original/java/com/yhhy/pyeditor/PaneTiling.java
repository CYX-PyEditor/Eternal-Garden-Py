package com.yhhy.pyeditor;

/**
 * 多区几何约束（5.6.1 · 纯 Java，不依赖 Android，可跑 JVM 单测）。
 *
 * <p>PaneLayout 的格子 + 边段模型里，<b>一段分隔线移动时除了不能把自己的格子压没，
 * 也不能穿进「不属于这段线」的格子里</b>——否则那个格子会被挤穿 / 被线划开，
 * 就是用户看到的「区域穿透」。这里把全部格子做成一次快照（{@link PaneTiling}），
 * 解出某组同方向边段可以落子的整数区间 {@code [lo, hi]}：
 *
 * <ul>
 *   <li>自身最小尺寸：{@code gap + minKeep}；</li>
 *   <li>和「不属于本组」的格子保持 {@code gap} 的空隙 —— 夹紧位置正好落在对方分隔线的
 *       坐标上，等于<b>完美对齐</b>；</li>
 *   <li>{@link #anyOverlap()} 用作拖动落子后的兜底校验。</li>
 * </ul>
 *
 * <p>坐标约定与 PaneLayout.doLayout 一致：外框（{@code -1}）贴内边距，内部边段
 * {@code ± gap/2}。
 */
final class PaneTiling {

    final int n;
    final int w, h;
    final int padL, padT, padR, padB;
    final int gap, minKeep;
    /** 每个格子四条边引用的段下标，-1 = 外框。 */
    final int[] cl, cr, ct, cb;
    final boolean[] segV;
    final int[] segPos;

    PaneTiling(int w, int h, int padL, int padT, int padR, int padB,
               int gap, int minKeep,
               int[] cl, int[] cr, int[] ct, int[] cb,
               boolean[] segV, int[] segPos) {
        this.n = cl.length;
        this.w = w;
        this.h = h;
        this.padL = padL;
        this.padT = padT;
        this.padR = padR;
        this.padB = padB;
        this.gap = Math.max(0, gap);
        this.minKeep = Math.max(1, minKeep);
        this.cl = cl;
        this.cr = cr;
        this.ct = ct;
        this.cb = cb;
        this.segV = segV;
        this.segPos = segPos;
    }

    int g2() {
        return gap / 2;
    }

    int edgeL(int c) {
        return cl[c] < 0 ? padL : segPos[cl[c]];
    }

    int edgeR(int c) {
        return cr[c] < 0 ? w - padR : segPos[cr[c]];
    }

    int edgeT(int c) {
        return ct[c] < 0 ? padT : segPos[ct[c]];
    }

    int edgeB(int c) {
        return cb[c] < 0 ? h - padB : segPos[cb[c]];
    }

    int rectL(int c) {
        return cl[c] < 0 ? padL : segPos[cl[c]] + g2();
    }

    int rectR(int c) {
        return cr[c] < 0 ? w - padR : segPos[cr[c]] - g2();
    }

    int rectT(int c) {
        return ct[c] < 0 ? padT : segPos[ct[c]] + g2();
    }

    int rectB(int c) {
        return cb[c] < 0 ? h - padB : segPos[cb[c]] - g2();
    }

    boolean xOverlap(int a, int b) {
        return rectL(a) < rectR(b) && rectL(b) < rectR(a);
    }

    boolean yOverlap(int a, int b) {
        return rectT(a) < rectB(b) && rectT(b) < rectB(a);
    }

    /** 这个格子的边是否引用了正在移动的段。 */
    boolean moving(int c, boolean[] seg, boolean vertical) {
        if (vertical) {
            return (cl[c] >= 0 && seg[cl[c]]) || (cr[c] >= 0 && seg[cr[c]]);
        }
        return (ct[c] >= 0 && seg[ct[c]]) || (cb[c] >= 0 && seg[cb[c]]);
    }

    /**
     * 一组成员（同方向）一起平移时，坐标允许的闭区间。
     *
     * <p>{@code vertical=true} 时求竖线的 x；否则求横线的 y。返回值可能含
     * {@link Integer#MIN_VALUE} / {@link Integer#MAX_VALUE}（无约束）。
     */
    int[] limits(boolean[] movingSeg, boolean vertical) {
        int lo = Integer.MIN_VALUE, hi = Integer.MAX_VALUE;
        int g2 = g2();
        for (int c = 0; c < n; c++) {
            if (!moving(c, movingSeg, vertical)) continue;
            // 「往大坐标方向走」的那条边（竖线的右 / 横线的下）
            boolean loEdge = vertical
                    ? (cr[c] >= 0 && movingSeg[cr[c]])
                    : (cb[c] >= 0 && movingSeg[cb[c]]);
            // 「往小坐标方向走」的那条边（竖线的左 / 横线的上）
            boolean hiEdge = vertical
                    ? (cl[c] >= 0 && movingSeg[cl[c]])
                    : (ct[c] >= 0 && movingSeg[ct[c]]);
            if (loEdge) {
                int other = vertical ? rectL(c) : rectT(c);
                lo = Math.max(lo, other + g2 + minKeep);
            }
            if (hiEdge) {
                int other = vertical ? rectR(c) : rectB(c);
                hi = Math.min(hi, other - g2 - minKeep);
            }
            for (int d = 0; d < n; d++) {
                if (d == c) continue;
                if (moving(d, movingSeg, vertical)) continue;
                if (vertical) {
                    if (!yOverlap(c, d)) continue;
                    // 外来格子在左：左边界不能越过它（右边留 gap）
                    if (hiEdge && rectR(d) <= rectL(c)) lo = Math.max(lo, rectR(d) + g2);
                    // 外来格子在右：右边界不能越过它
                    if (loEdge && rectL(d) >= rectR(c)) hi = Math.min(hi, rectL(d) - g2);
                } else {
                    if (!xOverlap(c, d)) continue;
                    // 外来格子上方
                    if (hiEdge && rectB(d) <= rectT(c)) lo = Math.max(lo, rectB(d) + g2);
                    // 外来格子下方
                    if (loEdge && rectT(d) >= rectB(c)) hi = Math.min(hi, rectT(d) - g2);
                }
            }
        }
        if (lo > hi) lo = hi;
        return new int[]{lo, hi};
    }

    /** 一次修复动作：把第 {@code seg} 段挪到段坐标 {@code pos}。 */
    static final class Fix {
        final int seg;
        final int pos;

        Fix(int seg, int pos) {
            this.seg = seg;
            this.pos = pos;
        }
    }

    /**
     * 合法划分 = 没有重叠单位、没有空洞单位。
     * （格子比 minKeep 小、甚至被压成 0 宽度只作为修复时的次要惩罚，不算不合法——
     *  拖动夹紧本来就会到 minKeep，不能因为一个细格子就把整块布局扔掉。）
     */
    boolean valid() {
        return overlapUnits() == 0 && holeUnits() == 0;
    }

    /** 修复时用的连续打分：重叠 ≫ 空洞 ≫ 压扁的格子（越小越好）。 */
    int score() {
        return overlapUnits() * 1000000 + holeUnits() * 1000 + degenerate();
    }

    private int[] unitCounts() {
        int[] xs = boundaries(true), ys = boundaries(false);
        int ov = 0, holes = 0;
        for (int j = 0; j + 1 < ys.length; j++) {
            for (int i = 0; i + 1 < xs.length; i++) {
                int cnt = 0;
                for (int c = 0; c < n; c++) {
                    if (edgeL(c) <= xs[i] && edgeR(c) >= xs[i + 1]
                            && edgeT(c) <= ys[j] && edgeB(c) >= ys[j + 1]) {
                        cnt++;
                    }
                }
                if (cnt == 0) holes++;
                else if (cnt > 1) ov += cnt - 1;
            }
        }
        return new int[]{ov, holes};
    }

    int overlapUnits() {
        return unitCounts()[0];
    }

    int holeUnits() {
        return unitCounts()[1];
    }

    /** 被压成 0 / 负尺寸的格子数。 */
    int degenerate() {
        int bad = 0;
        for (int c = 0; c < n; c++) {
            if (rectR(c) - rectL(c) < 1 || rectB(c) - rectT(c) < 1) bad++;
        }
        return bad;
    }

    /** 当前布局的所有边界（含外框），用于把容器切成一格一格的单位。 */
    int[] boundaries(boolean vertical) {
        java.util.TreeSet<Integer> set = new java.util.TreeSet<>();
        if (vertical) {
            set.add(padL);
            set.add(w - padR);
            for (int c = 0; c < n; c++) {
                set.add(edgeL(c));
                set.add(edgeR(c));
            }
        } else {
            set.add(padT);
            set.add(h - padB);
            for (int c = 0; c < n; c++) {
                set.add(edgeT(c));
                set.add(edgeB(c));
            }
        }
        int[] out = new int[set.size()];
        int i = 0;
        for (int v : set) out[i++] = v;
        return out;
    }

    /** 某段线可以挪到的候选坐标（同方向的所有边界）。 */
    int[] candidates(int seg) {
        return boundaries(segV[seg]);
    }

    private PaneTiling withPos(int[] pos) {
        return new PaneTiling(w, h, padL, padT, padR, padB, gap, minKeep,
                cl, cr, ct, cb, segV, pos);
    }

    /**
     * 把任意状态修成「无重叠、无空洞、格子不小于 minKeep」的合法划分。
     *
     * <p>做法是逐步下降打分：每一轮枚举「把某段线挪到某个已有边界」的全部动作，
     * 选让 {@link #score()} 变小最多的那个（同分取移动距离最小的），直到 0 或没有改进。
     * 空洞就是这样被邻居吃掉的（挪一条边把洞并进相邻格子）。
     *
     * @return 需要执行的动作（可能为空；非空表示原状态不合法）
     */
    static Fix[] repair(int w, int h, int padL, int padT, int padR, int padB,
                        int gap, int minKeep,
                        int[] cl, int[] cr, int[] ct, int[] cb,
                        boolean[] segV, int[] segPos, int maxRounds) {
        int[] pos = segPos.clone();
        java.util.ArrayList<Fix> out = new java.util.ArrayList<>();
        for (int round = 0; round < maxRounds; round++) {
            PaneTiling cur = new PaneTiling(w, h, padL, padT, padR, padB, gap, minKeep,
                    cl, cr, ct, cb, segV, pos);
            int base = cur.score();
            if (cur.valid()) break;
            Fix best = null;
            int bestScore = base;
            int bestDist = Integer.MAX_VALUE;
            for (int s = 0; s < pos.length; s++) {
                int[] cand = cur.candidates(s);
                for (int v : cand) {
                    if (v == pos[s]) continue;
                    int old = pos[s];
                    pos[s] = v;
                    int sc = cur.withPos(pos).score();
                    int dist = Math.abs(v - old);
                    if (sc < base && (sc < bestScore
                            || (sc == bestScore && dist < bestDist))) {
                        bestScore = sc;
                        bestDist = dist;
                        best = new Fix(s, v);
                    }
                    pos[s] = old;
                }
            }
            if (best == null) break;
            pos[best.seg] = best.pos;
            out.add(best);
        }
        return out.toArray(new Fix[0]);
    }

    /** 任意两个格子的矩形相交（真正的「区域穿透」）。 */
    boolean anyOverlap() {
        return overlapPair() != null;
    }

    /** 第一个重叠的格子对，没有就返回 null。 */
    int[] overlapPair() {
        for (int a = 0; a < n; a++) {
            for (int b = a + 1; b < n; b++) {
                if (rectL(a) < rectR(b) && rectL(b) < rectR(a)
                        && rectT(a) < rectB(b) && rectT(b) < rectB(a)) {
                    return new int[]{a, b};
                }
            }
        }
        return null;
    }

    /** 有没有格子被压成负尺寸 / 跑出容器。 */
    boolean badGeometry() {
        int maxR = w - padR, maxB = h - padB;
        for (int c = 0; c < n; c++) {
            if (rectL(c) < padL || rectT(c) < padT) return true;
            if (rectR(c) > maxR || rectB(c) > maxB) return true;
            if (rectR(c) - rectL(c) < 1) return true;
            if (rectB(c) - rectT(c) < 1) return true;
        }
        return false;
    }

    /**
     * 5.6.6：一条边段被若干格子引用，给出这些格子沿这条线方向的覆盖范围 {@code [a,b]}。
     * <ul>
     *   <li>如果范围互相重叠（有格子跨过了别的格子，典型是合并单元格），返回 {@code null}：
     *       这条线必须共享，不能拆；</li>
     *   <li>否则返回每个范围的分组号（相同范围同组）：拆成一段一段，恢复后各拖各的。</li>
     * </ul>
     * 2×2 十字就是「上排 [0,500] / 下排 [500,1000]」→ 两组。
     */
    static int[] extentGroups(int[] a, int[] b) {
        int n = a.length;
        if (n <= 0) return new int[0];
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (a[i] == a[j] && b[i] == b[j]) continue;   // 完全相同的范围 = 同一段
                if (a[i] < b[j] && a[j] < b[i]) return null;  // 部分重叠 / 包含：必须共享
            }
        }
        int[] g = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            int found = -1;
            for (int j = 0; j < i; j++) {
                if (a[i] == a[j] && b[i] == b[j]) {
                    found = g[j];
                    break;
                }
            }
            if (found < 0) found = k++;
            g[i] = found;
        }
        return g;
    }
}
