package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * 多区容器（5.6.0 · 格子 + 边段网格）。
 *
 * <p>一个「区」可以是编辑区 / 终端 / 解释器；PaneLayout 只认 View。
 *
 * <h3>数据模型（Grid Layout Matrix）</h3>
 * <ul>
 *   <li>{@link Cell}：一个区 = 一个矩形，四条边各引用一段 {@link Seg}（null = 外框）；</li>
 *   <li>{@link Seg}：一段分割线，只有方向 + **绝对像素整数坐标**，长度由引用它的格子实时推出；</li>
 *   <li>格子矩形 = 四条边段 ± gap/2，全是整数 → 同一条对齐线两边共用同一个整数，0 像素偏差；</li>
 *   <li>完美网格（每个格子正好是一个网格单元）会走 {@link #normalizeMosaic()}：
 *       把长线拆成「每一行/列自己的一段」，于是 2×2 的四段线互相独立，
 *       只有十字圆点才联动。</li>
 * </ul>
 *
 * <h3>5.6.1：不再「区域穿透」</h3>
 * <p>按段拖动时，一段线只能在自己的「走廊」里走：它不能钻进任何<b>不引用这段线</b>的格子，
 * 否则那个格子会被挤穿。允许区间由 {@link PaneTiling#limits} 精确解出，夹紧位置正好落在
 * 隔壁分隔线的坐标上（= 完美对齐）；如果一段线和同一直线上的其它段是相连的（视觉上是一条线），
 * 单独拖会被挡住时改成整条线一起动，既能继续拖也不会压坏别的格子。
 * 落子后还会用 {@link PaneTiling#anyOverlap()} 兜底校验。
 */
class PaneLayout extends ViewGroup {

    interface Callback {
        void onSqueeze(List<View> paneViews);

        void onSwap(View a, View b);

        void onPick(View paneView);

        void onSwapModeChanged(boolean on);

        /** 布局（区数 / 分割线位置 / 区类型）变了：MainActivity 借此落盘，下次启动恢复。 */
        void onLayoutChanged();
    }

    static final int MAX_ZONES = 6;
    private static final int SNAP_DP = 10;
    private static final int BUFFER_DP = 15;
    private static final int MIN_KEEP_DP = 8;
    private static final int SQUEEZE_DP = 40;

    /** 一段分割线。v=true 竖直（竖线的 x），false 水平（横线的 y）。 */
    private static final class Seg {
        boolean v;
        int pos;

        Seg(boolean v, int pos) {
            this.v = v;
            this.pos = pos;
        }
    }

    /** 一个格子（一个区）。 */
    private static final class Cell {
        View view;
        Seg l, r, t, b;
        final Rect rect = new Rect();
    }

    private final ArrayList<Cell> cells = new ArrayList<>();
    private final ArrayList<Seg> segs = new ArrayList<>();
    private Callback cb;

    private final int gap;
    private final int slop;

    private final Paint bgPaint = new Paint();
    private final Paint dividerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tintPaint = new Paint();
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strongPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int layoutMode = Prefs.LAYOUT_1X2;

    // ---------------- 恢复上次布局（5.6.1）
    private int restoreW0, restoreH0;

    // ---------------- 拖动状态机
    private static final int ST_IDLE = 0, ST_DOWN = 1, ST_DRAG = 2;
    private int dragState = ST_IDLE;
    private final ArrayList<Seg> dragV = new ArrayList<>();
    private final ArrayList<Seg> dragH = new ArrayList<>();
    private boolean crossDrag;
    /** 结构变更过程中先别回调落盘（例如挤掉：先删格子再通知外面删区，中间态别存）。 */
    private boolean quiet;
    /** 该轴这次拖的是「整条线」（单独拖会被外来格子挡住时按拖动方向自动升级）。 */
    private boolean lineV, lineH;
    private final ArrayList<Seg> lineCandV = new ArrayList<>();
    private final ArrayList<Seg> lineCandH = new ArrayList<>();
    private float downX, downY;
    private int startV, startH;
    private boolean snappedV, snappedH;
    private int snapV, snapH;
    private boolean moved, longPressDone;
    private Cell squeezeCell;

    private boolean swapMode;
    private boolean pickMode;
    private View swapSel, swapHover;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable longPressRun = () -> {
        if (dragState == ST_IDLE) return;
        longPressDone = true;
        dragState = ST_IDLE;
        clearDrag();
        setSwapMode(true);
    };

    PaneLayout(Context c) {
        super(c);
        gap = dp(8);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        dividerPaint.setColor(0xFF3A3F4B);
        dividerPaint.setStrokeWidth(dp(2));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(2));
        strongPaint.setStyle(Paint.Style.STROKE);
        strongPaint.setStrokeWidth(dp(3));
        setWillNotDraw(false);
        setClipChildren(true);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    void setColors(int bg, int divider, int accent, int warn) {
        bgPaint.setColor(bg);
        dividerPaint.setColor(divider);
        borderPaint.setColor(accent);
        strongPaint.setColor(accent);
        tintPaint.setColor(accent);
        dotPaint.setColor(accent);
        setBackgroundColor(bg);
    }

    void setCallback(Callback c) {
        cb = c;
    }

    int capacity() {
        return MAX_ZONES;
    }

    // ---------------- 排布预设
    void setGridMode(int mode) {
        if (mode < Prefs.LAYOUT_1X2 || mode > Prefs.LAYOUT_1X6) mode = Prefs.LAYOUT_1X2;
        if (mode == layoutMode) return;
        layoutMode = mode;
        applyPreset();
        invalidate();
    }

    int gridMode() {
        return layoutMode;
    }

    private int perLine() {
        if (layoutMode == Prefs.LAYOUT_1X3) return 3;
        if (layoutMode == Prefs.LAYOUT_1X4) return 4;
        if (layoutMode == Prefs.LAYOUT_1X5) return 5;
        if (layoutMode == Prefs.LAYOUT_1X6) return 6;
        return 2;
    }

    private void applyPreset() {
        ArrayList<View> views = new ArrayList<>();
        collectViews(views);
        if (views.isEmpty()) return;
        buildGrid(views);
        syncChildren();
        requestLayout();
        invalidate();
        notifyChanged();
    }

    /** 重排成网格：**每行自己的竖线、每列自己的横线**（完美马赛克，四段线互相独立）。 */
    private void buildGrid(ArrayList<View> views) {
        cells.clear();
        int n = views.size();
        if (n <= 0) return;
        if (n == 1) {
            Cell c = new Cell();
            c.view = views.get(0);
            cells.add(c);
            return;
        }
        boolean portrait = getHeight() > getWidth();
        int line = Math.min(perLine(), n);
        int landscapeRows = (n + line - 1) / line;
        int per = Math.max(1, portrait ? landscapeRows : line);
        int rows = (n + per - 1) / per;
        int w = Math.max(1, getWidth() - getPaddingLeft() - getPaddingRight());
        int h = Math.max(1, getHeight() - getPaddingTop() - getPaddingBottom());

        int[] rowY = new int[rows + 1];
        rowY[0] = getPaddingTop();
        int availH = Math.max(1, h - (rows - 1) * gap);
        for (int r = 1; r <= rows; r++) {
            rowY[r] = (r == rows) ? getPaddingTop() + h : rowY[r - 1] + Math.round((float) availH / rows);
        }
        // 行之间的横线：按列各一段（[列][行边界]）
        int maxK = per;
        Seg[][] hs = new Seg[rows + 1][maxK + 1];
        for (int r = 1; r < rows; r++) {
            for (int i = 0; i <= maxK; i++) hs[r][i] = new Seg(false, rowY[r]);
        }
        int idx = 0;
        for (int r = 0; r < rows; r++) {
            int k = Math.min(per, n - r * per);
            if (k <= 0) break;
            int availW = Math.max(1, w - (k - 1) * gap);
            int[] vx = new int[k + 1];
            vx[0] = getPaddingLeft();
            for (int i = 1; i <= k; i++) {
                vx[i] = (i == k) ? getPaddingLeft() + w : vx[i - 1] + Math.round((float) availW / k);
            }
            Seg[] vs = new Seg[k + 1];
            for (int i = 1; i < k; i++) vs[i] = new Seg(true, vx[i]);
            for (int i = 0; i < k && idx < n; i++) {
                Cell c = new Cell();
                c.view = views.get(idx++);
                c.l = i == 0 ? null : vs[i];
                c.r = i == k - 1 ? null : vs[i + 1];
                c.t = r == 0 ? null : hs[r][i];
                c.b = r == rows - 1 ? null : hs[r + 1][i];
                cells.add(c);
            }
        }
    }

    // ---------------- 增删
    void setPanes(List<View> views) {
        if (cells.isEmpty()) {
            buildGrid(new ArrayList<>(views));
        } else {
            for (int i = cells.size() - 1; i >= 0; i--) {
                if (!views.contains(cells.get(i).view)) cells.remove(i);
            }
            for (View v : views) {
                if (cellOf(v) != null) continue;
                if (cells.isEmpty()) {
                    Cell c = new Cell();
                    c.view = v;
                    cells.add(c);
                } else {
                    splitCell(cells.get(cells.size() - 1), v, true);
                }
            }
        }
        syncChildren();
        requestLayout();
        invalidate();
    }

    /** 格子数（诊断用）。 */
    int cellCount() {
        return cells.size();
    }

    /** saveLayout 失败的原因（null = 成功），给 MainActivity 写日志用。 */
    String lastSaveError;

    /** 清空全部格子（恢复布局前用）。 */
    void clearAll() {
        cells.clear();
        segs.clear();
        restoreW0 = restoreH0 = 0;
        syncChildren();
        requestLayout();
        invalidate();
    }

    // ---------------- 保存 / 恢复分区（5.6.1）
    /**
     * 序列化当前分区：容器尺寸 + 行/列排布偏好 + 段表 + 每个格子的 zone 下标与四条边段下标。
     * {@code -1} 表示外框。返回 null 表示现在还没量出尺寸 / 区列表对不上。
     *
     * <p>5.6.6 起按「段对象」存（ZL2）：2×2 十字里上排/下排竖线坐标相同但是两个对象，
     * 以前只存坐标，恢复时同坐标会被合并成一条 —— 表现为「两两线连一块、拖一条整列都动」。
     */
    String saveLayout(List<View> order) {
        lastSaveError = null;
        if (cells.isEmpty()) {
            lastSaveError = "no cells";
            return null;
        }
        if (order == null) {
            lastSaveError = "order null";
            return null;
        }
        if (getWidth() <= 0 || getHeight() <= 0) {
            lastSaveError = "size " + getWidth() + "x" + getHeight();
            return null;
        }
        doLayout();
        if (!tiling().valid()) repairTiling("save");
        int n = cells.size();
        java.util.HashMap<Seg, Integer> idx = new java.util.HashMap<>();
        ArrayList<Seg> list = new ArrayList<>();
        int[] pane = new int[n], li = new int[n], ri = new int[n], ti = new int[n], bi = new int[n];
        for (int i = 0; i < n; i++) {
            Cell c = cells.get(i);
            int oi = order.indexOf(c.view);
            if (oi < 0) return null;
            pane[i] = oi;
            li[i] = segIndex(idx, list, c.l);
            ri[i] = segIndex(idx, list, c.r);
            ti[i] = segIndex(idx, list, c.t);
            bi[i] = segIndex(idx, list, c.b);
        }
        int m = list.size();   // 单区时 m 可以是 0（四边全外框）
        int[] sv = new int[m], sp = new int[m];
        for (int j = 0; j < m; j++) {
            sv[j] = list.get(j).v ? 1 : 0;
            sp[j] = list.get(j).pos;
        }
        String out = PaneCodec.encode(getWidth(), getHeight(), layoutMode, sv, sp,
                pane, li, ri, ti, bi);
        if (out == null) lastSaveError = "encode failed";
        return out;
    }

    /** 段 → 下标（同一对象复用同一个下标，同坐标的不同对象是不同下标）。 */
    private static int segIndex(java.util.HashMap<Seg, Integer> idx, ArrayList<Seg> list, Seg s) {
        if (s == null) return PaneCodec.BORDER;
        Integer i = idx.get(s);
        if (i != null) return i;
        int n = list.size();
        idx.put(s, n);
        list.add(s);
        return n;
    }

    /**
     * 恢复上次的分区。先在「保存时的容器尺寸」下校验（越界 / 重叠 / 压扁都算非法），
     * 通过后等真实尺寸出来再等比缩放一次。
     */
    boolean restoreLayout(String data, List<View> order) {
        if (data == null || order == null) return false;
        PaneCodec.Layout lay = PaneCodec.decode(data);
        if (lay == null || lay.n > MAX_ZONES || order.size() < lay.n) return false;
        ArrayList<Cell> parsedCells = new ArrayList<>();
        ArrayList<Seg> built = new ArrayList<>();
        java.util.HashMap<String, Seg> map = new java.util.HashMap<>();
        if (lay.ver == 2) {
            for (int j = 0; j < lay.segV.length; j++) {
                built.add(new Seg(lay.segV[j] == 1, lay.segPos[j]));
            }
        }
        for (int i = 0; i < lay.n; i++) {
            if (lay.pane[i] < 0 || lay.pane[i] >= order.size()) return false;
            Cell c = new Cell();
            c.view = order.get(lay.pane[i]);
            if (lay.ver == 2) {
                c.l = lay.li[i] < 0 ? null : built.get(lay.li[i]);
                c.r = lay.ri[i] < 0 ? null : built.get(lay.ri[i]);
                c.t = lay.ti[i] < 0 ? null : built.get(lay.ti[i]);
                c.b = lay.bi[i] < 0 ? null : built.get(lay.bi[i]);
            } else {
                c.l = segFor(map, true, lay.l[i]);
                c.r = segFor(map, true, lay.r[i]);
                c.t = segFor(map, false, lay.t[i]);
                c.b = segFor(map, false, lay.b[i]);
            }
            parsedCells.add(c);
        }
        cells.clear();
        cells.addAll(parsedCells);
        segs.clear();
        if (lay.ver == 2) {
            segs.addAll(built);
        } else {
            segs.addAll(map.values());
            // 旧格式只存了坐标，同坐标的段已经被合成一条；按格子的覆盖范围拆回去，
            // 不然 2×2 十字一重开就「上排下排粘一起」。
            refineSharedSegs(lay.w, lay.h);
        }
        if (!tiling(lay.w, lay.h).valid()) {
            // 存下来的分区可能已经坏了（旧版本写的 / 缩放取整）：先修，修不好才放弃
            int n = cells.size(), m = segs.size();
            int[] cl = new int[n], cr = new int[n], ct = new int[n], cb = new int[n];
            boolean[] sv = new boolean[m];
            int[] sp = new int[m];
            fillSnapshot(cl, cr, ct, cb, sv, sp);
            PaneTiling.Fix[] fixes = PaneTiling.repair(lay.w, lay.h,
                    getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom(),
                    gap, dp(MIN_KEEP_DP), cl, cr, ct, cb, sv, sp, 32);
            for (PaneTiling.Fix f : fixes) {
                if (f.seg >= 0 && f.seg < segs.size()) segs.get(f.seg).pos = f.pos;
            }
            PaneTiling after = tiling(lay.w, lay.h);
            if (!after.valid()) {
                App.note("layout-restore-fail.txt", "restore score=" + after.score() + "\n" + data);
                cells.clear();
                segs.clear();
                restoreW0 = restoreH0 = 0;
                return false;
            }
            App.note("layout-restore-fix.txt", "restore repaired fixes=" + fixes.length
                    + " score=" + after.score() + "\n" + data);
        }
        if (lay.mode >= Prefs.LAYOUT_1X2 && lay.mode <= Prefs.LAYOUT_1X6) layoutMode = lay.mode;
        restoreW0 = lay.w;
        restoreH0 = lay.h;
        syncChildren();
        requestLayout();
        invalidate();
        return true;
    }

    private Seg segFor(java.util.HashMap<String, Seg> map, boolean vertical, int pos) {
        if (pos < 0) return null;
        String key = (vertical ? "V" : "H") + pos;
        Seg s = map.get(key);
        if (s != null) return s;
        s = new Seg(vertical, pos);
        map.put(key, s);
        return s;
    }

    /**
     * 5.6.6：旧快照（ZL1）只存坐标，恢复时同坐标的多段已经被合成了一个对象。这里按
     * 「引用它的格子覆盖范围」拆回去：范围互不重叠（首尾相接也算）时，每个范围一条段；
     * 一旦有范围互相包含（合并单元格那种），说明这条线本来就该一起动，保持共享。
     *
     * <p>不变量：拆分只改「谁引用哪个段对象」，不改任何坐标，几何完全不变。
     */
    private void refineSharedSegs(int w, int h) {
        ArrayList<Seg> out = new ArrayList<>();
        for (Seg s : segs) {
            ArrayList<Cell> refs = new ArrayList<>();
            for (Cell c : cells) {
                if ((s.v && (c.l == s || c.r == s)) || (!s.v && (c.t == s || c.b == s))) refs.add(c);
            }
            if (refs.size() <= 1) {
                out.add(s);
                continue;
            }
            int m = refs.size();
            int[] a = new int[m], b = new int[m];
            for (int i = 0; i < m; i++) {
                Cell c = refs.get(i);
                a[i] = s.v ? (c.t == null ? 0 : c.t.pos) : (c.l == null ? 0 : c.l.pos);
                b[i] = s.v ? (c.b == null ? h : c.b.pos) : (c.r == null ? w : c.r.pos);
            }
            int[] groups = PaneTiling.extentGroups(a, b);
            if (groups == null) {
                out.add(s);
                continue;
            }
            Seg[] byGroup = new Seg[m];
            for (int i = 0; i < m; i++) {
                int g = groups[i];
                Seg t = byGroup[g];
                if (t == null) {
                    t = new Seg(s.v, s.pos);
                    byGroup[g] = t;
                    out.add(t);
                }
                Cell c = refs.get(i);
                if (s.v) {
                    if (c.l == s) c.l = t;
                    else c.r = t;
                } else {
                    if (c.t == s) c.t = t;
                    else c.b = t;
                }
            }
        }
        segs.clear();
        segs.addAll(out);
    }

    /** 真实尺寸出来了：把保存时的坐标等比缩放，缩放后万一压坏了就退化成网格。 */
    private void applyPendingRestore() {
        if (restoreW0 <= 0 || restoreH0 <= 0) return;
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        int w0 = restoreW0, h0 = restoreH0;
        restoreW0 = restoreH0 = 0;
        if (w0 != w || h0 != h) {
            for (Seg s : segs) {
                s.pos = s.v ? Math.round(s.pos * (float) w / w0)
                        : Math.round(s.pos * (float) h / h0);
            }
        }
        PaneTiling t = tiling(w, h);
        if (!t.valid()) {
            int n = cells.size(), m = segs.size();
            int[] cl = new int[n], cr = new int[n], ct = new int[n], cb = new int[n];
            boolean[] sv = new boolean[m];
            int[] sp = new int[m];
            fillSnapshot(cl, cr, ct, cb, sv, sp);
            PaneTiling.Fix[] fixes = PaneTiling.repair(w, h,
                    getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom(),
                    gap, dp(MIN_KEEP_DP), cl, cr, ct, cb, sv, sp, 32);
            for (PaneTiling.Fix f : fixes) {
                if (f.seg >= 0 && f.seg < segs.size()) segs.get(f.seg).pos = f.pos;
            }
            if (!tiling(w, h).valid()) {
                ArrayList<View> views = new ArrayList<>();
                collectViews(views);
                if (!views.isEmpty()) {
                    cells.clear();
                    buildGrid(views);
                    syncChildren();
                }
            }
        }
    }

    void addZone(View v, View anchor, boolean below) {
        if (v == null || cellOf(v) != null) return;
        addView(v);
        debugDumpTo("layout-add-begin.txt", "addZone begin below=" + below);
        debugDump("addZone begin below=" + below);
        Cell a = cellOf(anchor);
        if (a == null) {
            if (cells.isEmpty()) {
                Cell c = new Cell();
                c.view = v;
                cells.add(c);
                syncChildren();
                requestLayout();
                invalidate();
                notifyChanged();
                return;
            }
            a = cells.get(cells.size() - 1);
        }
        Cell n = splitCell(a, v, below);
        equalizeBand(n);
        normalizeMosaic();
        repairTiling("addZone");
        debugDumpTo("layout-add-end.txt", "addZone end below=" + below);
        debugLogMosaic();
        syncChildren();
        requestLayout();
        invalidate();
        post(this::postAddDump);
        notifyChanged();
    }

    private Cell splitCell(Cell a, View v, boolean below) {
        Cell n = new Cell();
        n.view = v;
        if (!below) {
            Seg s = new Seg(true, (bL(a) + bR(a)) / 2);
            n.l = s;
            n.r = a.r;
            n.t = a.t;
            n.b = a.b;
            a.r = s;
        } else {
            Seg s = new Seg(false, (bT(a) + bB(a)) / 2);
            n.t = s;
            n.b = a.b;
            n.l = a.l;
            n.r = a.r;
            a.b = s;
        }
        cells.add(n);
        return n;
    }

    void removeZone(View v) {
        Cell c = cellOf(v);
        if (c == null) return;
        // 让邻居吃掉它的空间（优先左/上邻居，其次右/下）
        Seg s = c.l != null ? c.l : (c.r != null ? c.r : (c.t != null ? c.t : c.b));
        if (s != null) {
            removeCellBeside(c, s);
            return;
        }
        cells.remove(c);
        dropOrphanSegs();
        normalizeMosaic();
        repairTiling("removeZone");
        syncChildren();
        requestLayout();
        invalidate();
        notifyChanged();
    }

    private void dropOrphanSegs() {
        ArrayList<Seg> live = new ArrayList<>();
        for (Cell c : cells) {
            addLive(live, c.l);
            addLive(live, c.r);
            addLive(live, c.t);
            addLive(live, c.b);
        }
        segs.clear();
        segs.addAll(live);
    }

    private void addLive(ArrayList<Seg> live, Seg s) {
        if (s != null && !live.contains(s)) live.add(s);
    }

    /**
     * 加区之后把「新格子所在的那条带」重新等分。
     *
     * <p>5.6.1：判定改用<b>坐标</b>（矩形范围相同即同一行/列），不再要求边段对象同一 ——
     * 马赛克化之后每行/每列各有一段，同一列的格子往往引用不同对象。写位置改成事务式：
     * 先算全部目标位置、一次性写入，再校验有没有重叠，重叠就整体回滚。
     */
    private void equalizeBand(Cell ref) {
        doLayout();
        ArrayList<Cell> row = new ArrayList<>();
        for (Cell c : cells) if (sameRow(c, ref)) row.add(c);
        if (row.size() >= 2 && equalize(row, true)) return;
        ArrayList<Cell> col = new ArrayList<>();
        for (Cell c : cells) if (sameColumn(c, ref)) col.add(c);
        if (col.size() >= 2) equalize(col, false);
    }

    private boolean sameRow(Cell a, Cell b) {
        return Math.abs(bT(a) - bT(b)) <= 1 && Math.abs(bB(a) - bB(b)) <= 1;
    }

    private boolean sameColumn(Cell a, Cell b) {
        return Math.abs(bL(a) - bL(b)) <= 1 && Math.abs(bR(a) - bR(b)) <= 1;
    }

    /**
     * 把一条带等分。
     *
     * @param verticalSeg true = 等分宽度（动竖线）；false = 等分高度（动横线）
     */
    private boolean equalize(ArrayList<Cell> band, boolean verticalSeg) {
        int n = band.size();
        if (n < 2) return false;
        if (verticalSeg) band.sort((x, y) -> x.rect.left - y.rect.left);
        else band.sort((x, y) -> x.rect.top - y.rect.top);
        int start = verticalSeg
                ? (band.get(0).l == null ? getPaddingLeft() : band.get(0).l.pos + gap / 2)
                : (band.get(0).t == null ? getPaddingTop() : band.get(0).t.pos + gap / 2);
        int end = verticalSeg
                ? (band.get(n - 1).r == null ? getWidth() - getPaddingRight() : band.get(n - 1).r.pos - gap / 2)
                : (band.get(n - 1).b == null ? getHeight() - getPaddingBottom() : band.get(n - 1).b.pos - gap / 2);
        int avail = (end - start) - (n - 1) * gap;
        if (avail <= n) return false;
        int size = avail / n;
        ArrayList<Seg> touched = new ArrayList<>();
        ArrayList<Integer> old = new ArrayList<>();
        for (int i = 1; i < n; i++) {
            int target = start + i * size + i * gap - gap / 2;
            Seg a = verticalSeg ? band.get(i).l : band.get(i).t;
            Seg b = verticalSeg ? band.get(i - 1).r : band.get(i - 1).b;
            if (a != null) setTmp(touched, old, a, target);
            if (b != null && b != a) setTmp(touched, old, b, target);
        }
        if (touched.isEmpty()) return false;
        doLayout();
        if (tiling().anyOverlap()) {
            for (int i = 0; i < touched.size(); i++) touched.get(i).pos = old.get(i);
            doLayout();
            return false;
        }
        return true;
    }

    private void setTmp(ArrayList<Seg> touched, ArrayList<Integer> old, Seg s, int pos) {
        if (touched.contains(s)) return;
        touched.add(s);
        old.add(s.pos);
        s.pos = pos;
    }

    /**
     * 完美网格 → 马赛克化：把一条长线拆成「每行/每列自己的一段」。
     * 这样 2×2 里上下两段竖线、左右两段横线互相独立，四根线只由十字圆点联动。
     *
     * <p>5.6.1：先做一次**边界聚类吸附**（±eps 内视为同一条线，取均值），再判定完美网格。
     * 以前差 1~3px（均分取整 / gap 余数）就直接放弃，长线不被拆开，于是一条线管好几块；
     * 现在先吸附再重建，不会再「要么完美要么放弃」。
     */
    private void normalizeMosaic() {
        if (cells.size() < 4) return;
        doLayout();
        int eps = Math.max(2, dp(2));
        int[] xa0 = clusterEdges(true, eps);
        int[] ya0 = clusterEdges(false, eps);
        ArrayList<Seg> moved = new ArrayList<>();
        ArrayList<Integer> before = new ArrayList<>();
        for (Seg s : segs) {
            int[] arr = s.v ? xa0 : ya0;
            int best = nearest(arr, s.pos);
            if (best != s.pos && safeToSnap(s, best)) {
                moved.add(s);
                before.add(s.pos);
                s.pos = best;
            }
        }
        if (!moved.isEmpty()) {
            doLayout();
            if (tiling().anyOverlap()) {     // 吸附把格子挤重叠了：整体回滚
                for (int i = 0; i < moved.size(); i++) moved.get(i).pos = before.get(i);
                doLayout();
                return;
            }
        }
        TreeSet<Integer> xs = new TreeSet<>(), ys = new TreeSet<>();
        for (Cell c : cells) {
            xs.add(bL(c));
            xs.add(bR(c));
            ys.add(bT(c));
            ys.add(bB(c));
        }
        int cols = xs.size() - 1, rows = ys.size() - 1;
        if (rows < 2 || cols < 2) return;
        int[] xa = new int[xs.size()], ya = new int[ys.size()];
        int k = 0;
        for (int v : xs) xa[k++] = v;
        k = 0;
        for (int v : ys) ya[k++] = v;
        // 每个格子必须正好是一个网格单元，且覆盖完整
        boolean[][] used = new boolean[rows][cols];
        for (Cell c : cells) {
            int ci = indexOf(xa, bL(c)), cj = indexOf(ya, bT(c));
            if (ci < 0 || cj < 0) return;
            if (indexOf(xa, bR(c)) != ci + 1) return;
            if (indexOf(ya, bB(c)) != cj + 1) return;
            if (used[cj][ci]) return;
            used[cj][ci] = true;
        }
        for (int j = 0; j < rows; j++) for (int i = 0; i < cols; i++) if (!used[j][i]) return;
        // 重建为马赛克：竖线按行、横线按列
        Seg[][] vs = new Seg[rows][cols + 1];
        Seg[][] hs = new Seg[rows + 1][cols];
        for (int j = 0; j < rows; j++) {
            for (int i = 1; i < cols; i++) vs[j][i] = new Seg(true, xa[i]);
        }
        for (int j = 1; j < rows; j++) {
            for (int i = 0; i < cols; i++) hs[j][i] = new Seg(false, ya[j]);
        }
        for (Cell c : cells) {
            int ci = indexOf(xa, bL(c)), cj = indexOf(ya, bT(c));
            c.l = ci == 0 ? null : vs[cj][ci];
            c.r = ci == cols - 1 ? null : vs[cj][ci + 1];
            c.t = cj == 0 ? null : hs[cj][ci];
            c.b = cj == rows - 1 ? null : hs[cj + 1][ci];
        }
        dropOrphanSegs();
    }

    /** 把当前所有格子的横/竖边界按 ±eps 聚类，返回每个聚类的均值（升序）。 */
    private int[] clusterEdges(boolean vertical, int eps) {
        java.util.ArrayList<Integer> vals = new java.util.ArrayList<>();
        for (Cell c : cells) {
            vals.add(vertical ? bL(c) : bT(c));
            vals.add(vertical ? bR(c) : bB(c));
        }
        java.util.Collections.sort(vals);
        java.util.ArrayList<Integer> out = new java.util.ArrayList<>();
        int i = 0;
        while (i < vals.size()) {
            int j = i, sum = 0;
            while (j < vals.size() && vals.get(j) - vals.get(i) <= eps) {
                sum += vals.get(j);
                j++;
            }
            out.add(Math.round((float) sum / (j - i)));
            i = j;
        }
        int[] arr = new int[out.size()];
        for (int k = 0; k < arr.length; k++) arr[k] = out.get(k);
        return arr;
    }

    /** arr 里离 v 最近的值（arr 升序）。 */
    private int nearest(int[] arr, int v) {
        int best = v, bestD = Integer.MAX_VALUE;
        for (int a : arr) {
            int d = Math.abs(a - v);
            if (d < bestD) {
                bestD = d;
                best = a;
            }
        }
        return best;
    }

    /** 吸附到 pos 之后，引用这段线的格子不会被压到容不下 minKeep。 */
    private boolean safeToSnap(Seg s, int pos) {
        int minSize = gap + dp(MIN_KEEP_DP);
        for (Cell c : cells) {
            if (s.v) {
                if (c.r == s && pos < bL(c) + minSize) return false;
                if (c.l == s && pos > bR(c) - minSize) return false;
            } else {
                if (c.b == s && pos < bT(c) + minSize) return false;
                if (c.t == s && pos > bB(c) - minSize) return false;
            }
        }
        return true;
    }

    private int bL(Cell c) {
        return c.l == null ? getPaddingLeft() : c.l.pos;
    }

    private int bR(Cell c) {
        return c.r == null ? getWidth() - getPaddingRight() : c.r.pos;
    }

    private int bT(Cell c) {
        return c.t == null ? getPaddingTop() : c.t.pos;
    }

    private int bB(Cell c) {
        return c.b == null ? getHeight() - getPaddingBottom() : c.b.pos;
    }

    private int indexOf(int[] a, int v) {
        for (int i = 0; i < a.length; i++) if (Math.abs(a[i] - v) <= 2) return i;
        return -1;
    }

    private void removeCellBeside(Cell c, Seg s) {
        ArrayList<Cell> fix = new ArrayList<>();
        if (c.l == s) {
            for (Cell o : cells) if (o != c && o.r == s && overlapsV(o, c)) fix.add(o);
            for (Cell o : fix) o.r = c.r;
        } else if (c.r == s) {
            for (Cell o : cells) if (o != c && o.l == s && overlapsV(o, c)) fix.add(o);
            for (Cell o : fix) o.l = c.l;
        } else if (c.t == s) {
            for (Cell o : cells) if (o != c && o.b == s && overlapsH(o, c)) fix.add(o);
            for (Cell o : fix) o.b = c.b;
        } else if (c.b == s) {
            for (Cell o : cells) if (o != c && o.t == s && overlapsH(o, c)) fix.add(o);
            for (Cell o : fix) o.t = c.t;
        }
        cells.remove(c);
        dropOrphanSegs();
        normalizeMosaic();
        repairTiling("removeCellBeside");
        syncChildren();
        requestLayout();
        invalidate();
        notifyChanged();
    }

    private boolean overlapsV(Cell a, Cell b) {
        return a.rect.top < b.rect.bottom && b.rect.top < a.rect.bottom;
    }

    private boolean overlapsH(Cell a, Cell b) {
        return a.rect.left < b.rect.right && b.rect.left < a.rect.right;
    }

    private Cell cellOf(View v) {
        if (v == null) return null;
        for (Cell c : cells) if (c.view == v) return c;
        return null;
    }

    private void collectViews(List<View> out) {
        for (Cell c : cells) out.add(c.view);
    }

    private void syncChildren() {
        ArrayList<View> want = new ArrayList<>();
        collectViews(want);
        for (int i = getChildCount() - 1; i >= 0; i--) {
            View ch = getChildAt(i);
            if (!want.contains(ch)) removeView(ch);
        }
        for (View v : want) if (v.getParent() != this) addView(v);
    }

    // ---------------- 布局
    private void doLayout() {
        applyPendingRestore();
        int w = getWidth(), h = getHeight();
        for (Cell c : cells) {
            int l = c.l == null ? getPaddingLeft() : c.l.pos + gap / 2;
            int r = c.r == null ? w - getPaddingRight() : c.r.pos - gap / 2;
            int t = c.t == null ? getPaddingTop() : c.t.pos + gap / 2;
            int b = c.b == null ? h - getPaddingBottom() : c.b.pos - gap / 2;
            if (r < l + 1) r = l + 1;
            if (b < t + 1) b = t + 1;
            c.rect.set(l, t, r, b);
        }
        dropOrphanSegs();
    }

    private int segA(Seg s) {
        int a = Integer.MAX_VALUE;
        for (Cell c : cells) {
            boolean hit = s.v ? (c.l == s || c.r == s) : (c.t == s || c.b == s);
            if (!hit) continue;
            a = Math.min(a, s.v ? c.rect.top : c.rect.left);
        }
        return a == Integer.MAX_VALUE ? 0 : a;
    }

    private int segB(Seg s) {
        int b = Integer.MIN_VALUE;
        for (Cell c : cells) {
            boolean hit = s.v ? (c.l == s || c.r == s) : (c.t == s || c.b == s);
            if (!hit) continue;
            b = Math.max(b, s.v ? c.rect.bottom : c.rect.right);
        }
        return b == Integer.MIN_VALUE ? 0 : b;
    }

    private boolean rangesTouch(Seg a, Seg b) {
        if (a.v != b.v) return false;
        int a1 = segA(a), b1 = segB(a), a2 = segA(b), b2 = segB(b);
        int eps = gap + dp(2);
        return !(b1 < a2 - eps || b2 < a1 - eps);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        // 恢复的分区是按保存时的尺寸存的，这里等比缩放到当前尺寸
        if (restoreW0 > 0) {
            applyPendingRestore();
            requestLayout();
        }
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int h = MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(w, h);
        doLayout();
        for (Cell c : cells) {
            c.view.measure(MeasureSpec.makeMeasureSpec(Math.max(1, c.rect.width()), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1, c.rect.height()), MeasureSpec.EXACTLY));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        doLayout();
        for (Cell c : cells) {
            c.view.layout(c.rect.left, c.rect.top, c.rect.right, c.rect.bottom);
        }
    }

    // ---------------- 绘制
    @Override
    protected void dispatchDraw(Canvas c) {
        doLayout();
        c.drawRect(0, 0, getWidth(), getHeight(), bgPaint);
        super.dispatchDraw(c);
        for (Seg s : segs) {
            int a = segA(s), b = segB(s);
            if (s.v) c.drawRect(s.pos - dp(1), a, s.pos + dp(1), b, dividerPaint);
            else c.drawRect(a, s.pos - dp(1), b, s.pos + dp(1), dividerPaint);
        }
        for (Seg v : segs) {
            if (!v.v) continue;
            for (Seg h : segs) {
                if (h.v) continue;
                if (h.pos < segA(v) || h.pos > segB(v)) continue;
                if (v.pos < segA(h) || v.pos > segB(h)) continue;
                if (!hasFourQuadrants(v.pos, h.pos)) continue;
                c.drawCircle(v.pos, h.pos, dp(5), dotPaint);
            }
        }
        if (pickMode) {
            tintPaint.setAlpha(38);
            for (Cell cell : cells) {
                c.drawRect(cell.rect, tintPaint);
                c.drawRect(cell.rect, borderPaint);
            }
        }
        if (squeezeCell != null) {
            tintPaint.setAlpha(70);
            c.drawRect(squeezeCell.rect, tintPaint);
            strongPaint.setColor(0xFFFF6B6B);
            c.drawRect(squeezeCell.rect, strongPaint);
        }
        if (swapMode) {
            tintPaint.setAlpha(16);
            for (Cell cell : cells) c.drawRect(cell.rect, tintPaint);
            for (Cell cell : cells) {
                if (cell.view == swapSel) {
                    tintPaint.setAlpha(45);
                    c.drawRect(cell.rect, tintPaint);
                    c.drawRect(cell.rect, strongPaint);
                } else if (cell.view == swapHover) {
                    tintPaint.setAlpha(28);
                    c.drawRect(cell.rect, tintPaint);
                    c.drawRect(cell.rect, borderPaint);
                }
            }
        }
    }

    private boolean hasFourQuadrants(int x, int y) {
        boolean tl = false, tr = false, bl = false, br = false;
        for (Cell c : cells) {
            boolean left = c.rect.right <= x;
            boolean right = c.rect.left >= x;
            boolean top = c.rect.bottom <= y;
            boolean bottom = c.rect.top >= y;
            if (left && top) tl = true;
            if (right && top) tr = true;
            if (left && bottom) bl = true;
            if (right && bottom) br = true;
            if (tl && tr && bl && br) return true;
        }
        return tl && tr && bl && br;
    }

    // ---------------- 命中
    private View paneAt(float x, float y) {
        doLayout();
        for (Cell c : cells) {
            if (c.rect.contains((int) x, (int) y)) return c.view;
        }
        return null;
    }

    private Seg segAt(float x, float y) {
        doLayout();
        Seg best = null;
        float bestD = Float.MAX_VALUE;
        float tol = gap / 2f + dp(4);
        for (Seg s : segs) {
            int a = segA(s), b = segB(s);
            float d;
            if (s.v) {
                if (y < a - dp(2) || y > b + dp(2)) continue;
                d = Math.abs(x - s.pos);
            } else {
                if (x < a - dp(2) || x > b + dp(2)) continue;
                d = Math.abs(y - s.pos);
            }
            if (d <= tol && d < bestD) {
                bestD = d;
                best = s;
            }
        }
        return best;
    }

    private Seg[] crossAt(float x, float y) {
        doLayout();
        float best = dp(14);
        Seg[] hit = null;
        for (Seg v : segs) {
            if (!v.v) continue;
            for (Seg h : segs) {
                if (h.v) continue;
                if (h.pos < segA(v) || h.pos > segB(v)) continue;
                if (v.pos < segA(h) || v.pos > segB(h)) continue;
                if (!hasFourQuadrants(v.pos, h.pos)) continue;
                float d = (float) Math.hypot(x - v.pos, y - h.pos);
                if (d < best) {
                    best = d;
                    hit = new Seg[]{v, h};
                }
            }
        }
        return hit;
    }

    // ---------------- 选中 / 换位
    List<View> panes() {
        ArrayList<View> out = new ArrayList<>();
        collectViews(out);
        return out;
    }

    boolean isSwapMode() {
        return swapMode;
    }

    boolean isPickMode() {
        return pickMode;
    }

    void setSwapMode(boolean on) {
        if (swapMode == on) return;
        swapMode = on;
        swapSel = null;
        swapHover = null;
        dragState = ST_IDLE;
        clearDrag();
        handler.removeCallbacks(longPressRun);
        if (on) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            if (cb != null) cb.onSwapModeChanged(true);
        } else {
            if (cb != null) cb.onSwapModeChanged(false);
        }
        invalidate();
    }

    void setPickMode(boolean on) {
        if (pickMode == on) return;
        pickMode = on;
        if (on) setSwapMode(false);
        invalidate();
    }

    private void clearDrag() {
        dragV.clear();
        dragH.clear();
        lineCandV.clear();
        lineCandH.clear();
        crossDrag = false;
        lineV = false;
        lineH = false;
        snappedV = false;
        snappedH = false;
        squeezeCell = null;
    }

    // ---------------- 拖动
    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (pickMode || swapMode) return true;
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            return crossAt(e.getX(), e.getY()) != null || segAt(e.getX(), e.getY()) != null;
        }
        return dragState != ST_IDLE;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        float x = e.getX(), y = e.getY();
        if (pickMode) {
            if (action == MotionEvent.ACTION_UP) {
                View p = paneAt(x, y);
                if (p != null && cb != null) cb.onPick(p);
            }
            return true;
        }
        if (swapMode) {
            if (action == MotionEvent.ACTION_DOWN) {
                View p = paneAt(x, y);
                if (p == null) return true;
                downX = x;
                downY = y;
                if (swapSel == null) swapSel = p;
                else if (swapSel == p) swapSel = null;
                else swap(p, swapSel);
                swapHover = p;
                invalidate();
                return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                View p = paneAt(x, y);
                if (p != swapHover) {
                    swapHover = p;
                    invalidate();
                }
                return true;
            }
            if (action == MotionEvent.ACTION_UP) {
                if (swapSel != null && swapHover != null && swapHover != swapSel) swap(swapSel, swapHover);
                swapHover = null;
                invalidate();
                return true;
            }
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                clearDrag();
                doLayout();
                Seg[] cr = crossAt(x, y);
                if (cr != null) {
                    crossDrag = true;
                    addAligned(dragV, cr[0]);
                    addAligned(dragH, cr[1]);
                    lineV = dragV.size() > 1;
                    lineH = dragH.size() > 1;
                } else {
                    Seg s = segAt(x, y);
                    if (s == null) return false;
                    crossDrag = false;
                    if (s.v) {
                        dragV.add(s);
                        addAligned(lineCandV, s);
                    } else {
                        dragH.add(s);
                        addAligned(lineCandH, s);
                    }
                }
                downX = x;
                downY = y;
                startV = dragV.isEmpty() ? 0 : dragV.get(0).pos;
                startH = dragH.isEmpty() ? 0 : dragH.get(0).pos;
                moved = false;
                longPressDone = false;
                dragState = ST_DOWN;
                handler.removeCallbacks(longPressRun);
                handler.postDelayed(longPressRun, 380);
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (dragState == ST_IDLE) return true;
                // 5.6.2：手指只要动了就取消长按，别让「按住分割线歇一下」误进换位模式
                if (Math.abs(x - downX) > dp(2) || Math.abs(y - downY) > dp(2)) {
                    handler.removeCallbacks(longPressRun);
                }
                if (!moved && (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop)) {
                    moved = true;
                    dragState = ST_DRAG;
                }
                if (dragState == ST_DRAG) applyDrag(x, y);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                handler.removeCallbacks(longPressRun);
                if (dragState == ST_DRAG) applyDrag(x, y);
                if (squeezeCell != null && !longPressDone) {
                    Cell dead = squeezeCell;
                    squeezeCell = null;
                    ArrayList<View> gone = new ArrayList<>();
                    gone.add(dead.view);
                    Seg border = null;
                    for (Seg t : dragV) if (dead.l == t || dead.r == t) { border = t; break; }
                    if (border == null) for (Seg t : dragH) if (dead.t == t || dead.b == t) { border = t; break; }
                    quiet = true;
                    if (border != null) removeCellBeside(dead, border);
                    else {
                        cells.remove(dead);
                        dropOrphanSegs();
                        normalizeMosaic();
                        syncChildren();
                        requestLayout();
                        invalidate();
                    }
                    quiet = false;
                    if (cb != null && !gone.isEmpty()) cb.onSqueeze(gone);
                }
                boolean wasDrag = dragState == ST_DRAG;
                dragState = ST_IDLE;
                clearDrag();
                if (wasDrag) {
                    // 松手后整理一次：±eps 的对齐线吸附、必要时拆成马赛克，再修成合法划分
                    normalizeMosaic();
                    repairTiling("drag end");
                    syncChildren();
                    requestLayout();
                    debugDump("drag end");
                    notifyChanged();
                }
                invalidate();
                return true;
            }
        }
        return true;
    }

    /** 十字节点拖动时，把同一条直线上所有相接的段都收进来（4 块一起动）。 */
    private void addAligned(ArrayList<Seg> out, Seg seed) {
        out.add(seed);
        boolean changed = true;
        while (changed) {
            changed = false;
            for (Seg s : segs) {
                if (s.v != seed.v || out.contains(s)) continue;
                if (Math.abs(s.pos - seed.pos) > 1) continue;
                boolean touch = false;
                for (Seg o : out) {
                    if (rangesTouch(s, o)) {
                        touch = true;
                        break;
                    }
                }
                if (touch) {
                    out.add(s);
                    changed = true;
                }
            }
        }
    }

    private void applyDrag(float x, float y) {
        int[] oldV = savePos(dragV), oldH = savePos(dragH);
        if (!dragV.isEmpty()) {
            int want = startV + Math.round(x - downX);
            if (maybeUpgrade(dragV, lineCandV, true, want, lineV)) lineV = true;
            setPos(dragV, resolve(want, true));
        }
        if (!dragH.isEmpty()) {
            int want = startH + Math.round(y - downY);
            if (maybeUpgrade(dragH, lineCandH, false, want, lineH)) lineH = true;
            setPos(dragH, resolve(want, false));
        }
        doLayout();
        // 兜底：十字节点两轴一起动时解析式夹紧可能有残余，出现重叠就退回上一帧
        if (tiling().anyOverlap()) {
            restorePos(dragV, oldV);
            restorePos(dragH, oldH);
            doLayout();
            return;
        }
        requestLayout();
        updateSqueeze(x, y);
        invalidate();
    }

    private int[] savePos(ArrayList<Seg> group) {
        int[] out = new int[group.size()];
        for (int i = 0; i < out.length; i++) out[i] = group.get(i).pos;
        return out;
    }

    private void restorePos(ArrayList<Seg> group, int[] old) {
        for (int i = 0; i < old.length && i < group.size(); i++) group.get(i).pos = old[i];
    }

    private void setPos(ArrayList<Seg> group, int pos) {
        for (Seg s : group) s.pos = pos;
    }

    /**
     * 这一段线单独拖会被「不属于它的格子」挡住、而整条相连的线一起动就能继续走 ——
     * 且这次要去的方向正好在单独拖的禁区里，就升级成整条线（否则就会出现「区域穿透」）。
     * 能独立拖的方向仍然只动这一段。
     */
    private boolean maybeUpgrade(ArrayList<Seg> self, ArrayList<Seg> cand,
                                 boolean vertical, int want, boolean alreadyLine) {
        if (alreadyLine || cand.size() <= 1) return false;
        int[] solo = limitsFor(self, vertical);
        int[] all = limitsFor(cand, vertical);
        boolean blocked = want < solo[0] || want > solo[1];
        if (!blocked) return false;
        if (all[0] < solo[0] || all[1] > solo[1]) {
            self.clear();
            self.addAll(cand);
            return true;
        }
        return false;
    }

    private int resolve(int want, boolean vertical) {
        ArrayList<Seg> self = vertical ? dragV : dragH;
        int[] lim = limitsFor(self, vertical);
        int lo = lim[0], hi = lim[1];
        if (lo > hi) hi = lo;
        boolean snapped = vertical ? snappedV : snappedH;
        int snap = vertical ? snapV : snapH;
        int pos;
        if (snapped) {
            if (Math.abs(want - snap) <= dp(BUFFER_DP)) {
                pos = snap;
            } else {
                if (vertical) snappedV = false;
                else snappedH = false;
                pos = want;
            }
        } else {
            pos = want;
            Integer cand = findSnap(want, vertical, lo, hi);
            if (cand != null) {
                if (vertical) {
                    snappedV = true;
                    snapV = cand;
                } else {
                    snappedH = true;
                    snapH = cand;
                }
                pos = cand;
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            }
        }
        return Math.max(lo, Math.min(hi, pos));
    }

    private Integer findSnap(int want, boolean vertical, int lo, int hi) {
        int snapD = dp(SNAP_DP);
        Integer best = null;
        int bestD = Integer.MAX_VALUE;
        ArrayList<Seg> self = vertical ? dragV : dragH;
        for (Seg other : segs) {
            if (other.v != vertical) continue;
            if (self.contains(other)) continue;
            boolean meet = false;
            for (Seg s : self) {
                if (rangesTouch(s, other)) {
                    meet = true;
                    break;
                }
            }
            if (!meet) continue;
            int d = Math.abs(other.pos - want);
            if (d <= snapD && d < bestD) {
                bestD = d;
                best = other.pos;
            }
        }
        // 夹紧边界本身就是「和隔壁线完美对齐」的位置，靠近就吸过去
        if (lo != Integer.MIN_VALUE && Math.abs(lo - want) <= snapD && Math.abs(lo - want) < bestD) {
            bestD = Math.abs(lo - want);
            best = lo;
        }
        if (hi != Integer.MAX_VALUE && Math.abs(hi - want) <= snapD && Math.abs(hi - want) < bestD) {
            best = hi;
        }
        return best;
    }

    /** 当前格子/边段的快照，交给 PaneTiling 解「允许落子的区间」。 */
    private PaneTiling tiling() {
        doLayout();
        return tiling(getWidth(), getHeight());
    }

    /** 不解算 rect 的快照（doLayout 内部要用，避免递归）。 */
    private PaneTiling tiling(int w, int h) {
        int n = cells.size();
        int[] cl = new int[n], cr = new int[n], ct = new int[n], cb = new int[n];
        boolean[] sv = new boolean[segs.size()];
        int[] sp = new int[segs.size()];
        fillSnapshot(cl, cr, ct, cb, sv, sp);
        return new PaneTiling(w, h, getPaddingLeft(), getPaddingTop(),
                getPaddingRight(), getPaddingBottom(), gap, dp(MIN_KEEP_DP),
                cl, cr, ct, cb, sv, sp);
    }

    private void fillSnapshot(int[] cl, int[] cr, int[] ct, int[] cb, boolean[] sv, int[] sp) {
        for (int i = 0; i < segs.size(); i++) {
            sv[i] = segs.get(i).v;
            sp[i] = segs.get(i).pos;
        }
        for (int i = 0; i < cells.size(); i++) {
            Cell c = cells.get(i);
            cl[i] = segIndex(c.l);
            cr[i] = segIndex(c.r);
            ct[i] = segIndex(c.t);
            cb[i] = segIndex(c.b);
        }
    }

    /**
     * 5.6.2：把布局修正成合法划分（无重叠、无空洞、格子不小于 minKeep）。
     *
     * <p>结构操作（加区 / 挤掉 / 关区 / 均分 / 吸附）和拖动松手之后都会调用。
     * 修不好（极少）就退回网格排版，保证界面永远能用、永远能继续拖。
     *
     * @return 是否改动过布局
     */
    private boolean repairTiling(String tag) {
        if (cells.isEmpty() || getWidth() <= 0 || getHeight() <= 0) return false;
        doLayout();
        PaneTiling cur = tiling();
        if (cur.valid()) return false;
        App.note("layout-bad.txt", tag + " score=" + cur.score()
                + " overlap=" + cur.overlapUnits() + " holes=" + cur.holeUnits()
                + "\n" + snapshotText(tag));
        int n = cells.size(), m = segs.size();
        int[] cl = new int[n], cr = new int[n], ct = new int[n], cb = new int[n];
        boolean[] sv = new boolean[m];
        int[] sp = new int[m];
        fillSnapshot(cl, cr, ct, cb, sv, sp);
        PaneTiling.Fix[] fixes = PaneTiling.repair(getWidth(), getHeight(),
                getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom(),
                gap, dp(MIN_KEEP_DP), cl, cr, ct, cb, sv, sp, 32);
        for (PaneTiling.Fix f : fixes) {
            if (f.seg >= 0 && f.seg < segs.size()) segs.get(f.seg).pos = f.pos;
        }
        doLayout();
        if (!tiling().valid()) {
            App.note("layout-fail.txt", tag + "\n" + snapshotText(tag));
            ArrayList<View> views = new ArrayList<>();
            collectViews(views);
            if (!views.isEmpty()) {
                cells.clear();
                buildGrid(views);
            }
        }
        syncChildren();
        requestLayout();
        invalidate();
        return fixes.length > 0;
    }

    private int segIndex(Seg s) {
        return s == null ? -1 : segs.indexOf(s);
    }

    private int[] limitsFor(ArrayList<Seg> self, boolean vertical) {
        PaneTiling t = tiling();
        boolean[] moving = new boolean[segs.size()];
        for (Seg s : self) {
            int i = segs.indexOf(s);
            if (i >= 0) moving[i] = true;
        }
        return t.limits(moving, vertical);
    }

    private void notifyChanged() {
        if (quiet) return;
        if (cb != null) cb.onLayoutChanged();
    }

    private void updateSqueeze(float x, float y) {
        squeezeCell = null;
        if (crossDrag) return;
        int minSize = dp(SQUEEZE_DP);
        for (Seg s : dragV) {
            for (Cell c : cells) {
                if ((c.r == s || c.l == s) && c.rect.width() < minSize
                        && y >= c.rect.top && y <= c.rect.bottom) {
                    squeezeCell = c;
                    return;
                }
            }
        }
        for (Seg s : dragH) {
            for (Cell c : cells) {
                if ((c.b == s || c.t == s) && c.rect.height() < minSize
                        && x >= c.rect.left && x <= c.rect.right) {
                    squeezeCell = c;
                    return;
                }
            }
        }
    }

    private void swap(View a, View b) {
        if (a == null || b == null || a == b) return;
        Cell ca = cellOf(a), cb2 = cellOf(b);
        if (ca == null || cb2 == null) return;
        ca.view = b;
        cb2.view = a;
        swapSel = null;
        swapHover = null;
        setSwapMode(false);
        if (cb != null) cb.onSwap(a, b);
        requestLayout();
        invalidate();
        notifyChanged();
    }

    // ---------------- 诊断
    private void debugLogMosaic() {
        // 只写进 layout.txt 的附加信息（mosaic 是否成立）
        PaneTiling t = tiling();
        App.note("layout-mosaic.txt", "cells=" + cells.size()
                + " noOverlap=" + !t.anyOverlap() + " good=" + !t.badGeometry());
    }

    private void postAddDump() {
        doLayout();
        debugDump("addZone end");
    }

    void debugDump(String tag) {
        debugDumpTo("layout.txt", tag);
    }

    void debugDumpTo(String file, String tag) {
        App.note(file, snapshotText(tag));
    }

    /** 当前格子/边段的文本快照（诊断 / 修复前取证）。 */
    String snapshotText(String tag) {
        PaneTiling t = tiling();
        StringBuilder sb = new StringBuilder(tag).append('\n');
        sb.append("cells=").append(cells.size())
                .append(" overlap=").append(t.anyOverlap())
                .append(" score=").append(t.score())
                .append(" good=").append(!t.badGeometry()).append('\n');
        for (Cell c : cells) {
            sb.append("  cell rect=").append(c.rect.left).append(',').append(c.rect.top).append(',')
                    .append(c.rect.right).append(',').append(c.rect.bottom)
                    .append(" l=").append(c.l == null ? "-" : (c.l.pos + ""))
                    .append(" r=").append(c.r == null ? "-" : (c.r.pos + ""))
                    .append(" t=").append(c.t == null ? "-" : (c.t.pos + ""))
                    .append(" b=").append(c.b == null ? "-" : (c.b.pos + ""))
                    .append('\n');
        }
        sb.append("segs:\n");
        for (Seg s : segs) {
            sb.append("  ").append(s.v ? "V x=" : "H y=").append(s.pos)
                    .append(" [").append(segA(s)).append("..").append(segB(s)).append("]\n");
        }
        return sb.toString();
    }
}
