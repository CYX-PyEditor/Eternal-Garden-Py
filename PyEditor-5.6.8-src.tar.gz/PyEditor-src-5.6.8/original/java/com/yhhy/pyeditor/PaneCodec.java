package com.yhhy.pyeditor;

/**
 * 分区快照的编解码（5.6.1 · 纯 Java，不依赖 Android，可 JVM 单测）。
 *
 * <p><b>ZL2（5.6.6 起）</b>：{@code ZL2;宽,高;排布偏好;段数;格子数;竖/横,坐标;…;区下标,左段,右段,上段,下段;…}
 * 段按下标引用。同一个坐标上覆盖范围不同的两段是**两个对象**，所以 2×2 十字里
 * 「上排竖线 / 下排竖线」「左列横线 / 右列横线」恢复后仍然各拖各的，不会被粘成一条。
 * 边下标 {@code -1} 表示外框（null 边段）。
 *
 * <p><b>ZL1（旧格式，仍能读）</b>：{@code ZL1;宽,高;排布偏好;格子数;区下标,左,右,上,下;…}
 * 只存坐标；恢复时同坐标的段会先合并、再由 {@code PaneLayout#refineSharedSegs} 按格子范围拆开。
 */
final class PaneCodec {

    static final String MAGIC = "ZL1";
    static final String MAGIC_V2 = "ZL2";
    static final int BORDER = -1;

    static final class Layout {
        /** 1 = 旧格式（坐标为绝对像素），2 = 新格式（按下标引用段）。 */
        int ver = 1;
        int w, h, mode, n;
        int[] pane, l, r, t, b;
        /** ver=2：段表（dir: 1 竖 / 0 横）与每个格子的四个段下标。 */
        int[] segV, segPos;
        int[] li, ri, ti, bi;
    }

    private PaneCodec() {
    }

    /** ZL1（旧格式，保留给老的快照与单测）。 */
    static String encode(int w, int h, int mode,
                         int[] pane, int[] l, int[] r, int[] t, int[] b) {
        if (pane == null) return null;
        int n = pane.length;
        if (n <= 0 || l.length != n || r.length != n || t.length != n || b.length != n) return null;
        StringBuilder sb = new StringBuilder(MAGIC).append(';');
        sb.append(w).append(',').append(h).append(';');
        sb.append(mode).append(';');
        sb.append(n).append(';');
        for (int i = 0; i < n; i++) {
            sb.append(pane[i]).append(',')
                    .append(l[i]).append(',')
                    .append(r[i]).append(',')
                    .append(t[i]).append(',')
                    .append(b[i]).append(';');
        }
        return sb.toString();
    }

    /** ZL2：段表 + 每格四个段下标（-1 = 外框）。 */
    static String encode(int w, int h, int mode,
                         int[] segV, int[] segPos,
                         int[] pane, int[] li, int[] ri, int[] ti, int[] bi) {
        if (pane == null || segV == null || segPos == null) return null;
        int n = pane.length, m = segV.length;
        if (n <= 0 || m < 0 || segPos.length != m) return null;
        if (li.length != n || ri.length != n || ti.length != n || bi.length != n) return null;
        StringBuilder sb = new StringBuilder(MAGIC_V2).append(';');
        sb.append(w).append(',').append(h).append(';');
        sb.append(mode).append(';');
        sb.append(m).append(';');
        sb.append(n).append(';');
        for (int j = 0; j < m; j++) {
            sb.append(segV[j] == 1 ? 1 : 0).append(',').append(segPos[j]).append(';');
        }
        for (int i = 0; i < n; i++) {
            sb.append(pane[i]).append(',')
                    .append(li[i]).append(',')
                    .append(ri[i]).append(',')
                    .append(ti[i]).append(',')
                    .append(bi[i]).append(';');
        }
        return sb.toString();
    }

    /** 解析失败（格式不对 / 数量对不上 / 下标越界或方向不对）返回 null，调用方直接退回网格。 */
    static Layout decode(String data) {
        if (data == null) return null;
        String[] parts = data.split(";");
        if (parts.length >= 1 && MAGIC_V2.equals(parts[0].trim())) return decodeV2(parts);
        return decodeV1(parts);
    }

    private static Layout decodeV1(String[] parts) {
        if (parts.length < 5 || !MAGIC.equals(parts[0].trim())) return null;
        String[] wh = parts[1].split(",");
        if (wh.length != 2) return null;
        Layout out = new Layout();
        out.ver = 1;
        try {
            out.w = Integer.parseInt(wh[0].trim());
            out.h = Integer.parseInt(wh[1].trim());
            out.mode = Integer.parseInt(parts[2].trim());
            out.n = Integer.parseInt(parts[3].trim());
        } catch (NumberFormatException e) {
            return null;
        }
        if (out.w <= 0 || out.h <= 0 || out.n <= 0 || out.n > 64) return null;
        if (parts.length != 4 + out.n) return null;
        out.pane = new int[out.n];
        out.l = new int[out.n];
        out.r = new int[out.n];
        out.t = new int[out.n];
        out.b = new int[out.n];
        for (int i = 0; i < out.n; i++) {
            String[] f = parts[4 + i].split(",");
            if (f.length != 5) return null;
            try {
                out.pane[i] = Integer.parseInt(f[0].trim());
                out.l[i] = Integer.parseInt(f[1].trim());
                out.r[i] = Integer.parseInt(f[2].trim());
                out.t[i] = Integer.parseInt(f[3].trim());
                out.b[i] = Integer.parseInt(f[4].trim());
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return out;
    }

    /**
     * ZL2：{@code 0:ZL2 1:w,h 2:mode 3:段数 4:格子数 5..:段 5+段数..:格子}
     */
    private static Layout decodeV2(String[] parts) {
        if (parts.length < 6) return null;
        String[] wh = parts[1].split(",");
        if (wh.length != 2) return null;
        Layout out = new Layout();
        out.ver = 2;
        int m;
        try {
            out.w = Integer.parseInt(wh[0].trim());
            out.h = Integer.parseInt(wh[1].trim());
            out.mode = Integer.parseInt(parts[2].trim());
            m = Integer.parseInt(parts[3].trim());
            out.n = Integer.parseInt(parts[4].trim());
        } catch (NumberFormatException e) {
            return null;
        }
        if (out.w <= 0 || out.h <= 0 || out.n <= 0 || out.n > 64 || m < 0 || m > 256) return null;
        if (parts.length != 5 + m + out.n) return null;
        out.segV = new int[m];
        out.segPos = new int[m];
        for (int j = 0; j < m; j++) {
            String[] f = parts[5 + j].split(",");
            if (f.length != 2) return null;
            try {
                out.segV[j] = Integer.parseInt(f[0].trim());
                out.segPos[j] = Integer.parseInt(f[1].trim());
            } catch (NumberFormatException e) {
                return null;
            }
            if (out.segV[j] != 0 && out.segV[j] != 1) return null;
        }
        out.pane = new int[out.n];
        out.li = new int[out.n];
        out.ri = new int[out.n];
        out.ti = new int[out.n];
        out.bi = new int[out.n];
        out.l = new int[out.n];
        out.r = new int[out.n];
        out.t = new int[out.n];
        out.b = new int[out.n];
        for (int i = 0; i < out.n; i++) {
            String[] f = parts[5 + m + i].split(",");
            if (f.length != 5) return null;
            try {
                out.pane[i] = Integer.parseInt(f[0].trim());
                out.li[i] = Integer.parseInt(f[1].trim());
                out.ri[i] = Integer.parseInt(f[2].trim());
                out.ti[i] = Integer.parseInt(f[3].trim());
                out.bi[i] = Integer.parseInt(f[4].trim());
            } catch (NumberFormatException e) {
                return null;
            }
            if (!edgeOk(out, out.li[i], true) || !edgeOk(out, out.ri[i], true)
                    || !edgeOk(out, out.ti[i], false) || !edgeOk(out, out.bi[i], false)) return null;
            out.l[i] = out.li[i] < 0 ? BORDER : out.segPos[out.li[i]];
            out.r[i] = out.ri[i] < 0 ? BORDER : out.segPos[out.ri[i]];
            out.t[i] = out.ti[i] < 0 ? BORDER : out.segPos[out.ti[i]];
            out.b[i] = out.bi[i] < 0 ? BORDER : out.segPos[out.bi[i]];
        }
        return out;
    }

    /** -1 合法；否则下标要存在，且方向要和边匹配（l/r 用竖段，t/b 用横段）。 */
    private static boolean edgeOk(Layout lay, int idx, boolean vertical) {
        if (idx < 0) return idx == BORDER;
        if (idx >= lay.segV.length) return false;
        return (lay.segV[idx] == 1) == vertical;
    }
}
