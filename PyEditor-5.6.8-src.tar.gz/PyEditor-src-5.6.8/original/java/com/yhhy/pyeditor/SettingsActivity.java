package com.yhhy.pyeditor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Font / colour / behaviour settings with a live preview. */
public class SettingsActivity extends Activity {

    private static final int REQ_FONT = 2001;

    private Theme theme;
    private PreviewView preview;
    private byte[] cSrc;
    private String cSrcName = "";
    private String cLog = "";
    private TextView cLogView;
    private LinearLayout content;
    private ScrollView scroll;
    private LinearLayout root;
    private android.widget.FrameLayout pageHost;
    private Object backToken;
    private TextView titleView;

    private static final class Page {
        View view;
        int page;
        String title;

        Page(View v, int p, String t) {
            view = v;
            page = p;
            title = t;
        }
    }

    private final java.util.ArrayList<Page> stack = new java.util.ArrayList<>();
    private Page current;
    private boolean pageAnimating;
    private View predictiveView;
    private View predictiveParent;
    private boolean predictiveActive;
    private int pageGen;

    private float d(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        theme = Theme.load(this);
        buildRoot();
        int start = getIntent().getIntExtra("page", 0);
        if (start != 0) pageHost.post(() -> pushPage(start, false));
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            backToken = BackCompat.registerAnimated(this, new BackCompat.Anim() {
                @Override
                public void onStart() {
                    predictiveStart();
                }

                @Override
                public void onProgress(float progress) {
                    predictiveProgress(progress);
                }

                @Override
                public void onCancel() {
                    predictiveCancel();
                }

                @Override
                public void onInvoke() {
                    predictiveInvoke();
                }
            });
        } else {
            backToken = BackCompat.register(this, this::handleBack);
        }
    }

    private void buildRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(theme.bg);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(theme.statusBg);
        bar.setPadding((int) d(4), 0, (int) d(8), 0);
        bar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) d(46)));
        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTextColor(theme.bg == 0xFFFFFFFF ? 0xFF24292E : 0xFFE0E0E0);
        back.setPadding((int) d(12), 0, (int) d(12), (int) d(4));
        back.setOnClickListener(v -> handleBack());
        bar.addView(back);
        titleView = new TextView(this);
        titleView.setText(pageTitle(page));
        titleView.setTextSize(15);
        titleView.setTextColor(theme.bg == 0xFFFFFFFF ? 0xFF24292E : 0xFFE0E0E0);
        bar.addView(titleView);
        root.addView(bar);

        pageHost = new android.widget.FrameLayout(this);
        root.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        View home = newPageView(0);
        Page p = new Page(home, 0, pageTitle(0));
        stack.add(p);
        current = p;
        pageHost.addView(home);
        titleView.setText(p.title);
        seenSaveCount = Theme.saveCount;
        Immersive.apply(this);
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        Immersive.apply(this);
    }

    /** 返回：栈深 > 1 出栈恢复上一页，栈深 == 1 关闭设置。 */
    private void handleBack() {
        if (stack.size() > 1) {
            popPage();
            return;
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onDestroy() {
        BackCompat.unregister(this, backToken);
        backToken = null;
        super.onDestroy();
    }

    private int page = 0;
    private int seenSaveCount = 0;

    /** 0=总目录 1=个性化 2=编辑器 3=运行 4=终端 5=关于 */
    private String pageTitle(int p) {
        switch (p) {
            case 1: return Lang.s("个性化");
            case 2: return Lang.s("编辑器");
            case 3: return Lang.s("运行");
            case 4: return Lang.s("终端");
            case 5: return Lang.s("关于");
            case 6: return Lang.s("编译器");
            case 7: return Lang.s("片段");
            case 8: return Lang.s("语言");
            default: return Lang.s("设置");
        }
    }

    /** 重新填充当前页（主题变化/异步刷新用），保留滚动位置。 */
    private void rebuild() {
        if (current == null) return;
        page = current.page;
        scroll = (ScrollView) current.view;
        content = (LinearLayout) scroll.getChildAt(0);
        int y = scroll.getScrollY();
        content.removeAllViews();
        current.view.setBackgroundColor(theme.bg);
        if (titleView != null) titleView.setText(current.title);
        try {
            populate();
        } catch (Throwable t) {
            toast(Lang.s("该页加载失败：") + t);
        }
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    /** 生成一页的独立 View（ScrollView + 内容 LinearLayout）。 */
    private View newPageView(int p) {
        ScrollView sv = new ScrollView(this);
        // 整页不透明：预测返回时当前页向右滑，绝不会透出下一层的文字
        sv.setBackgroundColor(theme.bg);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding((int) d(12), (int) d(8), (int) d(12), (int) d(40));
        sv.addView(box);
        scroll = sv;
        content = box;
        page = p;
        populate();
        return sv;
    }

    /** 压栈：新页从右侧滑入，上一页在下面当背景（滑完再隐藏，保留状态）。 */
    private void pushPage(int to, boolean animate) {
        if (to == 0 || current == null || pageAnimating) return;
        pageGen++;
        Page from = current;
        View view;
        try {
            view = newPageView(to);
        } catch (Throwable t) {
            toast(Lang.s("该页加载失败：") + t);
            return;
        }
        Page p = new Page(view, to, pageTitle(to));
        pageHost.addView(view);
        stack.add(p);
        current = p;
        titleView.setText(p.title);
        from.view.setTranslationX(0f);
        from.view.setAlpha(1f);
        if (!animate) {
            syncPageVisibility();
            return;
        }
        pageAnimating = true;
        int w = pageHost.getWidth();
        if (w <= 0) w = (int) d(300);
        view.setTranslationX(w);
        view.animate().translationX(0f).setDuration(180)
                .withEndAction(() -> {
                    pageAnimating = false;
                    syncPageVisibility();
                }).start();
    }

    /** 只让 current 那一页 VISIBLE，其余页 GONE（不改变栈和状态）。 */
    private void syncPageVisibility() {
        for (Page p : stack) {
            p.view.setVisibility(p == current ? View.VISIBLE : View.GONE);
            if (p != current) {
                p.view.setTranslationX(0f);
                p.view.setAlpha(1f);
            }
        }
    }

    /** 出栈：当前页向右滑出并移除，上一页从下面露出来，恢复标题。 */
    private void popPage() {
        if (stack.size() <= 1 || pageAnimating) return;
        pageGen++;
        Page out = current;
        stack.remove(stack.size() - 1);
        Page back = stack.get(stack.size() - 1);
        back.view.setVisibility(View.VISIBLE);
        back.view.setBackgroundColor(theme.bg);
        back.view.setTranslationX(0f);
        back.view.setAlpha(1f);
        current = back;
        page = back.page;
        scroll = (ScrollView) back.view;
        content = (LinearLayout) scroll.getChildAt(0);
        titleView.setText(back.title);
        pageAnimating = true;
        int w = pageHost.getWidth();
        if (w <= 0) w = (int) d(300);
        out.view.animate().translationX(w).setDuration(180)
                .withEndAction(() -> {
                    pageHost.removeView(out.view);
                    syncPageVisibility();
                }).start();
        out.view.postDelayed(() -> pageAnimating = false, 180);
        if (back.page == 0) rebuild();
    }

    /** 预测性返回开始：把上一页先显示出来，否则子页右移后面是空白。 */
    private void predictiveStart() {
        pageGen++;
        // 手势可能打断正在跑的压栈/出栈动画：先归位并清掉孤儿页，
        // 否则 pageAnimating 一直是 true，之后所有 push/pop 都会被忽略。
        if (pageAnimating || predictiveView != null) {
            for (Page p : stack) {
                p.view.animate().cancel();
                p.view.setTranslationX(0f);
                p.view.setAlpha(1f);
            }
            removeOrphanPages();
            pageAnimating = false;
        }
        predictiveView = stack.size() > 1 ? current.view : null;
        predictiveParent = null;
        predictiveActive = predictiveView != null;
        if (!predictiveActive) return;
        predictiveView.animate().cancel();
        predictiveView.setAlpha(1f);
        if (stack.size() >= 2) {
            predictiveParent = stack.get(stack.size() - 2).view;
            predictiveParent.animate().cancel();
            predictiveParent.setBackgroundColor(theme.bg);
            predictiveParent.setVisibility(View.VISIBLE);
            predictiveParent.setTranslationX(0f);
            predictiveParent.setAlpha(1f);
        }
    }

    /** 移除 pageHost 里已经不在栈中的 View（动画被打断时留下）。 */
    private void removeOrphanPages() {
        for (int i = pageHost.getChildCount() - 1; i >= 0; i--) {
            View v = pageHost.getChildAt(i);
            boolean inStack = false;
            for (Page p : stack) {
                if (p.view == v) {
                    inStack = true;
                    break;
                }
            }
            if (!inStack) pageHost.removeView(v);
        }
    }

    private void predictiveProgress(float progress) {
        if (!predictiveActive || predictiveView == null) return;
        int w = pageHost.getWidth();
        if (w <= 0) w = (int) d(300);
        float p = Math.max(0f, Math.min(1f, progress));
        predictiveView.setTranslationX(w * p);
        // 当前页不透明、只做位移；上一页完全固定 —— 两层没有相对速度，也不会文字叠影
        predictiveView.setAlpha(1f);
        if (predictiveParent != null) {
            predictiveParent.setTranslationX(0f);
            predictiveParent.setAlpha(1f);
        }
    }

    private void predictiveCancel() {
        if (!predictiveActive || predictiveView == null) return;
        final int gen = ++pageGen;
        predictiveView.animate().translationX(0f).alpha(1f).setDuration(140)
                .withEndAction(() -> {
                    if (gen == pageGen) syncPageVisibility();
                }).start();
        predictiveParent = null;
        predictiveActive = false;
    }

    private void predictiveInvoke() {
        boolean active = predictiveActive;
        predictiveParent = null;
        predictiveActive = false;
        if (active) popPage();
        else handleBack();
    }

    private int fg() {
        return theme.bg == 0xFFFFFFFF || theme.bg == 0xFFFDF6E3 ? 0xFF24292E : 0xFFD8DEE9;
    }

    private int sub() {
        return theme.bg == 0xFFFFFFFF || theme.bg == 0xFFFDF6E3 ? 0xFF6A737D : 0xFF8B949E;
    }

    private TextView header(String s) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(12);
        tv.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        tv.setPadding(0, (int) d(14), 0, (int) d(6));
        return tv;
    }

    private TextView label(String s) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(13);
        tv.setTextColor(fg());
        return tv;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, (int) d(3), 0, (int) d(3));
        return r;
    }

    private TextView chip(String text, boolean on, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12.5f);
        tv.setPadding((int) d(12), (int) d(6), (int) d(12), (int) d(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(d(14));
        bg.setColor(on ? theme.colors[Theme.TOK_KEYWORD] : (theme.bg == 0xFFFFFFFF ? 0xFFEEEEEE : 0xFF2C313A));
        tv.setBackground(bg);
        tv.setTextColor(on ? 0xFFFFFFFF : fg());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, (int) d(8), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    private View swatch(int color) {
        View v = new View(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(d(4));
        bg.setStroke((int) d(1), theme.bg == 0xFFFFFFFF ? 0xFFBBBBBB : 0xFF555B66);
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) d(34), (int) d(24));
        lp.setMargins(0, 0, (int) d(8), 0);
        v.setLayoutParams(lp);
        return v;
    }

    private TextView miniBtn(String text, boolean on, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11.5f);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(d(4));
        bg.setColor(on ? theme.colors[Theme.TOK_KEYWORD] : (theme.bg == 0xFFFFFFFF ? 0xFFEEEEEE : 0xFF2C313A));
        tv.setBackground(bg);
        tv.setTextColor(on ? 0xFFFFFFFF : sub());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) d(26), (int) d(24));
        lp.setMargins(0, 0, (int) d(6), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    private void populate() {
        // preview
        if (page == 0) {
            content.addView(menuRow(Lang.s("个性化"), Lang.s("字体 / 字号 / 主题 / 颜色"), 1));
            content.addView(menuRow(Lang.s("编辑器"), Lang.s("行号 / 缩进 / 补全条数 / 语法检查"), 2));
            content.addView(menuRow(Lang.s("代码片段"), Lang.s("内置可改 / 自定义模板 / ") + Snippets.CURSOR + Lang.s(" 光标位置"), 7));
            content.addView(menuRow(Lang.s("终端"), Lang.s("Shizuku 授权与默认目录"), 4));
            content.addView(menuRow(Lang.s("编译器"), Lang.s("下载 / 选择 C 编译器仓库"), 6));
            content.addView(menuRow(Lang.s("关于"), Lang.s("版本与签名"), 5));
            content.addView(menuRow(Lang.s("语言 / Language"),
                    Lang.s("当前：") + langLabel(), 8));
            return;
        }

        if (page == 1) {
        preview = new PreviewView(this);
        refreshPreview();
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) d(170));
        pp.setMargins(0, 0, 0, (int) d(4));
        preview.setLayoutParams(pp);
        content.addView(preview);

        // ---- font
        content.addView(header(Lang.s("字体")));

        LinearLayout sizeRow = row();
        sizeRow.addView(label(Lang.s("字号  ") + (int) theme.fontSize));
        SeekBar sb = new SeekBar(this);
        sb.setMax(22);
        sb.setProgress((int) theme.fontSize - 8);
        sb.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView sizeVal = label(String.valueOf((int) theme.fontSize));
        ((LinearLayout) sizeRow).setGravity(Gravity.CENTER_VERTICAL);
        // replace label with value text for live update
        sizeRow.removeAllViews();
        sizeRow.addView(label(Lang.s("字号")));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sizeRow.addView(sb, slp);
        sizeRow.addView(sizeVal);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                theme.fontSize = progress + 8;
                sizeVal.setText(String.valueOf(progress + 8));
                refreshPreview();
                theme.save(SettingsActivity.this);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        content.addView(sizeRow);

        LinearLayout lsRow = row();
        lsRow.addView(label(Lang.s("行距")));
        SeekBar ls = new SeekBar(this);
        ls.setMax(24);
        ls.setProgress((int) theme.lineSpacing);
        ls.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                theme.lineSpacing = progress;
                refreshPreview();
                theme.save(SettingsActivity.this);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        lsRow.addView(ls, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        content.addView(lsRow);

        LinearLayout fontRow = row();
        fontRow.addView(label(Lang.s("字体")));
        String fam = theme.fontFamily == null ? "monospace" : theme.fontFamily;
        fontRow.addView(chip(Lang.s("等宽"), fam.equals("monospace"), v -> {
            theme.fontFamily = "monospace";
            theme.save(this);
            rebuild();
        }));
        fontRow.addView(chip(Lang.s("无衬线"), fam.equals("sans-serif"), v -> {
            theme.fontFamily = "sans-serif";
            theme.save(this);
            rebuild();
        }));
        fontRow.addView(chip(Lang.s("衬线"), fam.equals("serif"), v -> {
            theme.fontFamily = "serif";
            theme.save(this);
            rebuild();
        }));
        content.addView(fontRow);

        LinearLayout fontRow2 = row();
        fontRow2.addView(label(Lang.s("自定义")));
        fontRow2.addView(chip(fam.startsWith("file:") ? Lang.s("已载入字体") : Lang.s("载入字体文件…"),
                fam.startsWith("file:"), v -> pickFont()));
        content.addView(fontRow2);

        // ---- theme presets（5.6.0：删掉 Monokai / Solarized 两个英文主题，改为自定义主题）
        content.addView(header(Lang.s("主题预设")));
        LinearLayout presetRow = row();
        presetRow.addView(chip(Lang.s("深色"), theme.themeName.equals("深色"), v -> preset("dark")));
        presetRow.addView(chip(Lang.s("浅色"), theme.themeName.equals("浅色"), v -> preset("light")));
        presetRow.addView(chip(Lang.s("午夜蓝"), theme.themeName.equals("午夜蓝"), v -> preset("midnight")));
        presetRow.addView(chip(Lang.s("品红·浅蓝"), theme.themeName.equals("品红·浅蓝"), v -> preset("magenta")));
        android.widget.HorizontalScrollView presetScroll = new android.widget.HorizontalScrollView(this);
        presetScroll.setHorizontalScrollBarEnabled(false);
        presetScroll.addView(presetRow);
        content.addView(presetScroll);

        // ---- 自定义主题（5.6.0）：保存在 App 里，可以有多个，长按删除
        content.addView(header(Lang.s("自定义主题")));
        java.util.List<String> customNames = CustomThemes.names(this);
        LinearLayout customRow = row();
        for (final String cn : customNames) {
            TextView chip = chip(cn, cn.equals(theme.themeName), v -> applyCustomTheme(cn));
            chip.setOnLongClickListener(v -> {
                confirmDeleteCustomTheme(cn);
                return true;
            });
            customRow.addView(chip);
        }
        TextView addChip = chip(Lang.s("＋ 保存当前配色"), false, v -> promptSaveCustomTheme());
        customRow.addView(addChip);
        android.widget.HorizontalScrollView customScroll = new android.widget.HorizontalScrollView(this);
        customScroll.setHorizontalScrollBarEnabled(false);
        customScroll.addView(customRow);
        content.addView(customScroll);
        TextView ctTip = label(Lang.s("把当前整套配色（含背景 / 文字 / 高亮 / 字体）存成一个主题，存在 App 里，重启后还在；点主题名切换，长按删除。"));
        ctTip.setTextSize(10.5f);
        ctTip.setTextColor(sub());
        content.addView(ctTip);

        // ---- 行分隔线（5.5.0）
        content.addView(header(Lang.s("行分隔线")));
        content.addView(check(Lang.s("显示行分隔线"), theme.showLineDividers, b -> {
            theme.showLineDividers = b;
            theme.save(this);
            refreshPreview();
        }));
        addScalarRow(Lang.s("分隔线颜色"), () -> theme.lineDivider, c -> theme.lineDivider = c);
        TextView ldTip = label(Lang.s("默认是极淡的灰色，绘制时再压到约 30% 不透明度，按 RGB 取色。"));
        ldTip.setTextSize(10.5f);
        ldTip.setTextColor(sub());
        content.addView(ldTip);

        // ---- behaviour
        }

        if (page == 2) {
        content.addView(header(Lang.s("编辑行为")));
        content.addView(check(Lang.s("显示行号"), theme.showLineNumbers, b -> {
            theme.showLineNumbers = b;
            theme.save(this);
            refreshPreview();
        }));
        content.addView(check(Lang.s("显示缩进参考线"), theme.showGuides, b -> {
            theme.showGuides = b;
            theme.save(this);
            refreshPreview();
        }));
        content.addView(check(Lang.s("回车自动缩进"), theme.autoIndent, b -> {
            theme.autoIndent = b;
            theme.save(this);
        }));
        content.addView(check(Lang.s("自动补全括号 / 引号"), theme.autoPair, b -> {
            theme.autoPair = b;
            theme.save(this);
        }));
        LinearLayout tabRow = row();
        tabRow.addView(label(Lang.s("Tab 宽度  ")));
        for (int ts : new int[]{2, 4, 8}) {
            final int tsv = ts;
            tabRow.addView(chip(String.valueOf(ts), theme.tabSize == ts, v -> {
                theme.tabSize = tsv;
                theme.save(this);
                rebuild();
            }));
        }
        content.addView(tabRow);

        // ---- 编辑器行为（新增）
        content.addView(header(Lang.s("编辑器")));
        // 5.6.0：「行/列 + 语法错误」状态栏：按方向分别开关 + 选顶部/底部
        content.addView(label(Lang.s("行/列状态栏（行/列 + 语法问题）")));
        content.addView(check(Lang.s("横屏时显示"), Prefs.statusBarLandscape(this),
                b -> Prefs.setStatusBarLandscape(this, b)));
        LinearLayout landPos = row();
        landPos.addView(label(Lang.s("   位置  ")));
        landPos.addView(chip(Lang.s("顶部"),
                Prefs.statusBarLandscapePos(this) == Prefs.BAR_TOP, v -> {
                    Prefs.setStatusBarLandscapePos(this, Prefs.BAR_TOP);
                    rebuild();
                }));
        landPos.addView(chip(Lang.s("底部"),
                Prefs.statusBarLandscapePos(this) == Prefs.BAR_BOTTOM, v -> {
                    Prefs.setStatusBarLandscapePos(this, Prefs.BAR_BOTTOM);
                    rebuild();
                }));
        content.addView(landPos);
        content.addView(check(Lang.s("竖屏时显示"), Prefs.statusBarPortrait(this),
                b -> Prefs.setStatusBarPortrait(this, b)));
        LinearLayout portPos = row();
        portPos.addView(label(Lang.s("   位置  ")));
        portPos.addView(chip(Lang.s("顶部"),
                Prefs.statusBarPortraitPos(this) == Prefs.BAR_TOP, v -> {
                    Prefs.setStatusBarPortraitPos(this, Prefs.BAR_TOP);
                    rebuild();
                }));
        portPos.addView(chip(Lang.s("底部"),
                Prefs.statusBarPortraitPos(this) == Prefs.BAR_BOTTOM, v -> {
                    Prefs.setStatusBarPortraitPos(this, Prefs.BAR_BOTTOM);
                    rebuild();
                }));
        content.addView(portPos);
        content.addView(check(Lang.s("在常用栏中显示"), Prefs.statusBarInTopBar(this),
                b -> Prefs.setStatusBarInTopBar(this, b)));
        TextView sbTip = label(Lang.s("状态栏可以放在编辑区上方或下方，横屏 / 竖屏分别设置（比如横屏不要、竖屏放底部）；「在常用栏中显示」额外把「行 N, 列 M · ✓/✖」放进顶栏。"));
        sbTip.setTextSize(10.5f);
        sbTip.setTextColor(sub());
        content.addView(sbTip);
        content.addView(check(Lang.s("语法检查（冒号 / 括号 / 缩进）"),
                Prefs.syntaxCheck(this),
                b -> Prefs.setSyntaxCheck(this, b)));
        LinearLayout cntRow = row();
        cntRow.addView(label(Lang.s("补全条数  ")));
        int curMax = Prefs.completeMax(this);
        for (int v : new int[]{3, 5, 8, 12}) {
            final int vv = v;
            cntRow.addView(chip(String.valueOf(v), curMax == v, c -> {
                Prefs.setCompleteMax(this, vv);
                rebuild();
            }));
        }
        content.addView(cntRow);
        content.addView(check(Lang.s("切到后台自动保存已打开的文件"),
                Prefs.autoSave(this),
                b -> Prefs.setAutoSave(this, b)));

        // ---- 5.6.0：多区 + 排布（手机也完全开放）
        content.addView(header(Lang.s("多区布局")));
        content.addView(check(Lang.s("启用多区域"), Prefs.multiZone(this), b -> {
            Prefs.setMultiZone(this, b);
            toast(b ? Lang.s("已启用多区域：下次启动会恢复上次的多区布局")
                    : Lang.s("已关闭多区域：回主界面只保留第一个区"));
        }));
        TextView mpOnlyTip = label(Lang.s("关掉后回到主界面会强制回到单区：除第一个区外全部关闭；重新开启后，下次启动会恢复上次的多区布局。"));
        mpOnlyTip.setTextSize(10.5f);
        mpOnlyTip.setTextColor(sub());
        content.addView(mpOnlyTip);
        int curLayout = Prefs.zoneLayout(this);
        LinearLayout layRow = row();
        layRow.addView(chip("1×2", curLayout == Prefs.LAYOUT_1X2, v -> {
            Prefs.setZoneLayout(this, Prefs.LAYOUT_1X2);
            rebuild();
        }));
        layRow.addView(chip("1×3", curLayout == Prefs.LAYOUT_1X3, v -> {
            Prefs.setZoneLayout(this, Prefs.LAYOUT_1X3);
            rebuild();
        }));
        layRow.addView(chip("1×4", curLayout == Prefs.LAYOUT_1X4, v -> {
            Prefs.setZoneLayout(this, Prefs.LAYOUT_1X4);
            rebuild();
        }));
        layRow.addView(chip("1×5", curLayout == Prefs.LAYOUT_1X5, v -> {
            Prefs.setZoneLayout(this, Prefs.LAYOUT_1X5);
            rebuild();
        }));
        layRow.addView(chip("1×6", curLayout == Prefs.LAYOUT_1X6, v -> {
            Prefs.setZoneLayout(this, Prefs.LAYOUT_1X6);
            rebuild();
        }));
        android.widget.HorizontalScrollView layScroll = new android.widget.HorizontalScrollView(this);
        layScroll.setHorizontalScrollBarEnabled(false);
        layScroll.addView(layRow);
        content.addView(layScroll);
        TextView layTip = label(Lang.s("1×k = 每行最多 k 格（竖屏自动对调方向）：区数不超过 k 就是一条线（1×4、1×5、1×6 随便选）；超过 k 才换行，且两行/两列时另一边最多 3 格 —— 6 个区时落到 2×3 或 3×2，4 个区时 1×2 就是 2×2。最多 6 个区。切换布局不会关区，只是重新排布。"));
        layTip.setTextSize(10.5f);
        layTip.setTextColor(sub());
        content.addView(layTip);
        TextView mpTip = label(Lang.s("顶栏 + 可以新建「编辑区 / 解释器 / 终端」，最多 6 个区；拖动分割线挤到很窄可关闭，长按分割线进入换位模式。终端 / 解释器只是区，没有文件可换。"));
        mpTip.setTextSize(10.5f);
        mpTip.setTextColor(sub());
        content.addView(mpTip);

        content.addView(header(Lang.s("大纲导航")));
        content.addView(check(Lang.s("启用右侧大纲导航（MiniMap）"), Prefs.miniMap(this),
                b -> Prefs.setMiniMap(this, b)));
        TextView mmTip = label(Lang.s("在编辑区最右侧边缘向左滑呼出（已排除系统返回手势）；点正文立刻收起。只画色块与错误红点，不画文字。"));
        mmTip.setTextSize(10.5f);
        mmTip.setTextColor(sub());
        content.addView(mmTip);

        content.addView(header(Lang.s("代码片段")));
        content.addView(menuRow(Lang.s("片段管理"), Lang.s("内置可改 / 自定义 / ") + Snippets.CURSOR + Lang.s(" 光标位置"), 7));
        }

        if (page == 3) {
        content.addView(header(Lang.s("运行引擎")));
        TextView engNote = label(Lang.s("4.9 起只保留 CPython 3.12：\n")
                + Lang.s("完整语法、支持 C 扩展，启动约 150ms。终端标题栏不再有引擎切换按钮。"));
        engNote.setTextSize(12f);
        engNote.setTextColor(sub());
        content.addView(engNote);
        }

        if (page == 4) {
        // ---- 终端
        content.addView(header(Lang.s("终端 · Shizuku")));
        TextView shMode = label(ShellBridge.mode());
        shMode.setTextSize(12f);
        shMode.setTextColor(sub());
        content.addView(shMode);
        LinearLayout shRow = row();
        shRow.addView(chip(Lang.s("请求授权"), false, v -> {
            if (!ShellBridge.binderAlive()) {
                toast(Lang.s("没有检测到 Shizuku 服务，请先启动 Shizuku"));
            } else {
                ShellBridge.requestPermission();
                toast(Lang.s("已请求授权，请在弹出的窗口里允许"));
            }
        }));
        shRow.addView(chip(Lang.s("刷新状态"), false, v -> rebuild()));
        content.addView(shRow);

        LinearLayout dirRow = row();
        dirRow.addView(label(Lang.s("默认目录  ")));
        EditText dirEdit = new EditText(this);
        dirEdit.setText(Prefs.termDir(this));
        dirEdit.setHint("/sdcard");
        dirEdit.setTextSize(12.5f);
        dirEdit.setSingleLine(true);
        dirEdit.setTextColor(fg());
        dirEdit.setHintTextColor(sub());
        dirEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        dirRow.addView(dirEdit, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dirEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                Prefs.setTermDir(SettingsActivity.this, s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        content.addView(dirRow);

        }

        if (page == 1) {
        // ---- token colours
        content.addView(header(Lang.s("颜色与字形")));
        for (int i = 0; i < Theme.TOK_COUNT; i++) {
            final int tok = i;
            LinearLayout r = row();
            View sw = swatch(theme.colors[tok]);
            r.addView(sw);
            TextView name = label(Lang.s(Theme.TOK_NAMES[tok]));
            name.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            r.addView(name);
            TextView bBtn = miniBtn("B", theme.bold[tok], v -> {
                theme.bold[tok] = !theme.bold[tok];
                theme.save(this);
                rebuild();
            });
            TextView iBtn = miniBtn("I", theme.italic[tok], v -> {
                theme.italic[tok] = !theme.italic[tok];
                theme.save(this);
                rebuild();
            });
            r.addView(bBtn);
            r.addView(iBtn);
            sw.setOnClickListener(v -> ColorPickDialog.show(this, Lang.s(Theme.TOK_NAMES[tok]),
                    theme.colors[tok], c -> {
                        theme.colors[tok] = c;
                        swatchInto(sw, c);
                        theme.save(this);
                        refreshPreview();
                    }));
            content.addView(r);
        }

        content.addView(header(Lang.s("界面颜色")));
        addScalarRow(Lang.s("编辑区背景"), () -> theme.bg, c -> {
            theme.bg = c;
            root.setBackgroundColor(c);
        });
        addScalarRow(Lang.s("行号栏背景"), () -> theme.gutterBg, c -> theme.gutterBg = c);
        addScalarRow(Lang.s("行号文字"), () -> theme.gutterText, c -> theme.gutterText = c);
        addScalarRow(Lang.s("当前行高亮"), () -> theme.curLine, c -> theme.curLine = c);
        addScalarRow(Lang.s("选区背景"), () -> theme.selection, c -> theme.selection = c);
        addScalarRow(Lang.s("光标颜色"), () -> theme.caret, c -> theme.caret = c);
        addScalarRow(Lang.s("错误波浪线"), () -> theme.problem, c -> theme.problem = c);
        addScalarRow(Lang.s("参考线 · 第 1 层"), () -> theme.guideA, c -> theme.guideA = c);
        addScalarRow(Lang.s("参考线 · 最深层"), () -> theme.guideB, c -> theme.guideB = c);

        // ---- reset
        TextView reset = new TextView(this);
        reset.setText(Lang.s("恢复默认设置"));
        reset.setTextSize(13);
        reset.setGravity(Gravity.CENTER);
        reset.setPadding(0, (int) d(14), 0, (int) d(14));
        GradientDrawable rgb = new GradientDrawable();
        rgb.setCornerRadius(d(8));
        rgb.setColor(theme.bg == 0xFFFFFFFF ? 0xFFF2F2F2 : 0xFF2C313A);
        reset.setBackground(rgb);
        reset.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        reset.setOnClickListener(v -> {
            theme.copyFrom(new Theme());
            theme.save(this);
            root.setBackgroundColor(theme.bg);
            rebuild();
        });
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, (int) d(18), 0, 0);
        content.addView(reset, rlp);

        }

        if (page == 6) {
            content.addView(header(Lang.s("C 编译器仓库")));
            TextView tip = label(Lang.s("添加一个编译器压缩包的下载地址（.zip / .tar.gz），")
                    + Lang.s("下载后自动解压并识别 clang / gcc / tcc。\n")
                    + Lang.s("推荐用 Android aarch64 的预编译工具链（含 sysroot 的那种）。"));
            tip.setTextSize(11f);
            tip.setTextColor(sub());
            content.addView(tip);

            LinearLayout addRow = row();
            final EditText ccUrl = new EditText(this);
            ccUrl.setHint("https://…/clang-android-aarch64.zip");
            ccUrl.setTextSize(12);
            ccUrl.setSingleLine(true);
            addRow.addView(ccUrl, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            addRow.addView(chip(Lang.s("下载"), false, v -> {
                String u = ccUrl.getText().toString().trim();
                if (u.isEmpty()) {
                    toast(Lang.s("请输入下载地址"));
                    return;
                }
                toast(Lang.s("开始下载…"));
                new Thread(() -> {
                    try {
                        String err = CompilerStore.install(this, u);
                        runOnUiThread(() -> {
                            if (err == null) {
                                toast(Lang.s("编译器已就绪"));
                            } else {
                                showLong(Lang.s("安装失败"), err);
                            }
                            rebuild();
                        });
                    } catch (Exception e) {
                        String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
                        runOnUiThread(() -> showLong(Lang.s("下载失败"), msg));
                    }
                }).start();
            }));
            content.addView(addRow);
            LinearLayout impRow = row();
            impRow.addView(label(Lang.s("从本地导入  ")));
            impRow.addView(chip(Lang.s("选文件…"), false, v -> {
                android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 901);
            }));
            content.addView(impRow);

            content.addView(header(Lang.s("常用来源（下拉选择，自动填地址）")));
            final String[][] presets = {
                    {Lang.s("Zig 0.15.2 · aarch64-linux（自带 C 编译器 + libc）· 47 MB"),
                            "https://ziglang.org/download/0.15.2/zig-aarch64-linux-0.15.2.tar.xz"},
                    {Lang.s("Zig 0.17.0 · aarch64-linux（新版）· 50 MB"),
                            "https://ziglang.org/download/0.17.0/zig-aarch64-linux-0.17.0.tar.xz"},
                    {Lang.s("Android NDK r27c · 官方（1.1 GB，含 clang+lld+sysroot）"),
                            "https://dl.google.com/android/repository/android-ndk-r27c-linux.zip"},
                    {Lang.s("LLVM 19.1.0 · 官方 aarch64（Linux glibc 版，需配 sysroot）"),
                            "https://github.com/llvm/llvm-project/releases/download/llvmorg-19.1.0/clang+llvm-19.1.0-aarch64-linux-gnu.tar.gz"},
                    {Lang.s("TinyCC 源码 · GitHub（需自行编译）"),
                            "https://github.com/TinyCC/tinycc/archive/refs/tags/mob-0.9.27.tar.gz"},
            };
            String[] cpLabels = new String[presets.length];
            for (int i = 0; i < presets.length; i++) cpLabels[i] = presets[i][0];
            android.widget.Spinner cpSpin = new android.widget.Spinner(this);
            android.widget.ArrayAdapter<String> cpAd = new android.widget.ArrayAdapter<>(
                    this, android.R.layout.simple_spinner_item, cpLabels);
            cpAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            cpSpin.setAdapter(cpAd);
            cpSpin.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view,
                                           int position, long id) {
                    ccUrl.setText(presets[position][1]);
                }

                @Override
                public void onNothingSelected(android.widget.AdapterView<?> parent) {
                }
            });
            content.addView(cpSpin);
            TextView fmt = label(Lang.s("支持 .zip / .tar.gz / .tgz / .tar.xz；选好后点上面的「下载」"));
            fmt.setTextSize(10.5f);
            fmt.setTextColor(sub());
            content.addView(fmt);

            content.addView(header(Lang.s("已下载")));
            java.util.List<File> list = CompilerStore.installed(this);
            if (list.isEmpty()) {
                TextView e2 = label(Lang.s("（暂无）"));
                e2.setTextSize(11.5f);
                e2.setTextColor(sub());
                content.addView(e2);
            }
            for (final File d : list) {
                LinearLayout r = row();
                File bin = CompilerStore.findBinary(d);
                boolean active = d.getAbsolutePath().equals(Prefs.ccDir(this));
                TextView name = label((active ? "✓ " : "") + d.getName());
                name.setLayoutParams(new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                r.addView(name);
                r.addView(chip(active ? Lang.s("使用中") : Lang.s("启用"), false, v -> {
                    Prefs.setCcDir(this, d.getAbsolutePath());
                    rebuild();
                }));
                r.addView(chip(Lang.s("删"), false, v -> {
                    CompilerStore.deleteRec(d);
                    if (d.getAbsolutePath().equals(Prefs.ccDir(this))) Prefs.setCcDir(this, "");
                    rebuild();
                }));
                content.addView(r);
                if (bin != null) {
                    TextView bp = label("   " + bin.getName() + "  " + d.getName());
                    bp.setTextSize(10.5f);
                    bp.setTextColor(sub());
                    content.addView(bp);
                }
            }
            content.addView(header(Lang.s("Python 头文件（编译 C 扩展用）")));
            boolean hReady = PyHeaders.ready(this);
            TextView hState = label(hReady
                    ? Lang.s("已就绪：Include/*.h + Android 版 pyconfig.h")
                    : Lang.s("未就绪：需要 CPython 3.12 的 Include/*.h 和适配 Android 的 pyconfig.h"));
            hState.setTextSize(11.5f);
            hState.setTextColor(hReady ? sub() : 0xFFFF7B72);
            content.addView(hState);

            final String[][] HSRC = {
                    {Lang.s("本地导入 pyinclude-3.12.tgz（推荐 · 离线）"), ""},
                    {Lang.s("华为云 · CPython 3.12.8 源码（约 20 MB）"),
                            "https://mirrors.huaweicloud.com/python/3.12.8/Python-3.12.8.tar.xz"},
                    {Lang.s("阿里云 · CPython 3.12.8 源码（约 20 MB）"),
                            "https://mirrors.aliyun.com/python-release/source/Python-3.12.8.tar.xz"},
                    {Lang.s("python.org 官方 · CPython 3.12.8（约 20 MB）"),
                            "https://www.python.org/ftp/python/3.12.8/Python-3.12.8.tar.xz"},
                    {Lang.s("自定义地址（需含 Include + pyconfig.h）"), ""},
            };
            String[] hLabels = new String[HSRC.length];
            for (int i = 0; i < HSRC.length; i++) hLabels[i] = HSRC[i][0];
            final android.widget.Spinner hSpin = new android.widget.Spinner(this);
            android.widget.ArrayAdapter<String> hAd = new android.widget.ArrayAdapter<>(
                    this, android.R.layout.simple_spinner_item, hLabels);
            hAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            hSpin.setAdapter(hAd);
            content.addView(hSpin);

            LinearLayout hUrlRow = row();
            final EditText hUrl = new EditText(this);
            hUrl.setHint("https://…/pyinclude-3.12.tgz");
            hUrl.setTextSize(12);
            hUrl.setSingleLine(true);
            hUrlRow.addView(hUrl, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final int[] hSel = {0};
            hSpin.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view,
                                           int position, long id) {
                    hSel[0] = position;
                    hUrl.setText(HSRC[position][1]);
                    hUrl.setEnabled(position == 4);
                }

                @Override
                public void onNothingSelected(android.widget.AdapterView<?> parent) {
                }
            });
            hUrlRow.addView(chip(Lang.s("下载"), false, v -> {
                final int pos = hSel[0];
                final String u = hUrl.getText().toString().trim();
                if (pos == 0) {
                    toast(Lang.s("用下面的「从本地导入…」选 pyinclude-3.12.tgz"));
                    return;
                }
                if (u.isEmpty()) {
                    toast(Lang.s("请输入下载地址"));
                    return;
                }
                toast(Lang.s("开始下载头文件…（官方源码约 20 MB，自动只取 Include）"));
                new Thread(() -> {
                    final String err = (pos == 4)
                            ? PyHeaders.installUrl(SettingsActivity.this, u)
                            : PyHeaders.installOfficial(SettingsActivity.this, u);
                    runOnUiThread(() -> {
                        if (err == null) toast(Lang.s("头文件已就绪"));
                        else showLong(Lang.s("头文件安装失败"), err);
                        rebuild();
                    });
                }).start();
            }));
            content.addView(hUrlRow);
            LinearLayout hImpRow = row();
            hImpRow.addView(label(Lang.s("从本地导入  ")));
            hImpRow.addView(chip(Lang.s("选文件…"), false, v -> {
                android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 903);
            }));
            content.addView(hImpRow);
            TextView hTip = label(Lang.s("推荐直接用发布目录里的 pyinclude-3.12.tgz（CPython 3.12.8 + Android pyconfig，约 96 KB）"));
            hTip.setTextSize(10.5f);
            hTip.setTextColor(sub());
            content.addView(hTip);

            content.addView(header(Lang.s("编译 C 扩展（Shizuku）")));
            File ccActive = CBuilder.activeCompilerDir(this);
            File ccBin = ccActive == null ? null : CompilerStore.findBinary(ccActive);
            TextView cState = label("Shizuku：" + ShellBridge.mode()
                    + Lang.s("\n编译器：") + (ccBin == null ? Lang.s("无（先在上面的「已下载」里启用一个）") : ccBin.getName()));
            cState.setTextSize(11f);
            cState.setTextColor(sub());
            content.addView(cState);

            LinearLayout cFileRow = row();
            TextView cFileLabel = label(cSrcName.isEmpty() ? Lang.s("未选择 .c 文件") : cSrcName);
            cFileLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            cFileLabel.setTextSize(12f);
            cFileRow.addView(cFileLabel);
            cFileRow.addView(chip(Lang.s("选择 .c…"), false, v -> {
                android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 902);
            }));
            content.addView(cFileRow);
            TextView cHint = label(Lang.s("目前只支持 C 源码（.c）；.cxx / .cpp 这类 C++ 源码还不支持"));
            cHint.setTextSize(10.5f);
            cHint.setTextColor(sub());
            content.addView(cHint);

            LinearLayout cNameRow = row();
            cNameRow.addView(label(Lang.s("模块名  ")));
            final EditText cMod = new EditText(this);
            cMod.setTextSize(12.5f);
            cMod.setSingleLine(true);
            cMod.setHint("hello");
            if (!cSrcName.isEmpty()) cMod.setText(moduleFromName(cSrcName));
            cNameRow.addView(cMod, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            content.addView(cNameRow);

            LinearLayout cRunRow = row();
            cRunRow.addView(chip(Lang.s("编译并安装"), true, v -> {
                final String mod = cMod.getText().toString().trim();
                if (cSrc == null) {
                    toast(Lang.s("先选择一个 .c 文件"));
                    return;
                }
                if (!mod.matches("[A-Za-z_][A-Za-z0-9_]*")) {
                    toast(Lang.s("模块名只能字母/数字/下划线，且不能以数字开头"));
                    return;
                }
                cLog = "";
                toast(Lang.s("开始编译（首次要复制编译器，稍慢）…"));
                new Thread(() -> {
                    String err = CBuilder.compile(SettingsActivity.this, mod, cSrc,
                            line -> runOnUiThread(() -> appendCLog(line)));
                    runOnUiThread(() -> {
                        appendCLog(err == null ? Lang.s("完成：import ") + mod + Lang.s(" 通过")
                                : (Lang.s("失败：") + err));
                        toast(err == null ? Lang.s("编译成功，已安装到 site-packages") : Lang.s("编译失败，看下面的日志"));
                    });
                }).start();
            }));
            content.addView(cRunRow);

            android.widget.ScrollView cLogScroll = new android.widget.ScrollView(this);
            cLogView = new TextView(this);
            cLogView.setTextSize(10.5f);
            cLogView.setTypeface(android.graphics.Typeface.MONOSPACE);
            cLogView.setTextColor(sub());
            cLogView.setText(cLog.isEmpty() ? Lang.s("（编译日志会显示在这里）") : cLog);
            cLogScroll.addView(cLogView);
            content.addView(cLogScroll, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, (int) d(150)));
        }

        if (page == 7) {
            populateSnippets();
        }

        if (page == 8) {
            content.addView(header(Lang.s("语言 / Language")));
            TextView tip = label(Lang.s("界面语言。切换后会自动重启界面。"));
            tip.setTextSize(11f);
            tip.setTextColor(sub());
            content.addView(tip);
            String cur = Lang.pref(this);
            LinearLayout l1 = row();
            l1.addView(chip(Lang.s("跟随系统"), Lang.FOLLOW.equals(cur),
                    v -> setLang(Lang.FOLLOW)));
            content.addView(l1);
            LinearLayout l2 = row();
            l2.addView(chip("简体中文", Lang.ZH.equals(cur), v -> setLang(Lang.ZH)));
            content.addView(l2);
            LinearLayout l3 = row();
            l3.addView(chip("English", Lang.EN.equals(cur), v -> setLang(Lang.EN)));
            content.addView(l3);
        }

        if (page == 5) {
        // ---- 关于
        content.addView(header(Lang.s("关于")));
        String ver = "";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        TextView about = label("YHHYPy " + ver + Lang.s(" · Python 3.12 编辑器 + 运行环境\n")
                + Lang.s("C++ 内核 / 自绘界面 / 多编辑区 / 中英双语\n")
                + Lang.s("可直接运行 CPython 3.12 代码，支持 pip 包管理与 C 扩展编译\n")
                + Lang.s("终端经 Shizuku 以 shell（uid 2000）身份执行命令 · 签名 雨萱之华"));
        about.setTextSize(11.5f);
        about.setTextColor(sub());
        about.setPadding(0, (int) d(6), 0, (int) d(4));
        content.addView(about);
        }
    }

    // ---------------------------------------------------------------- 语言
    private String langLabel() {
        String p = Lang.pref(this);
        if (Lang.EN.equals(p)) return "English";
        if (Lang.ZH.equals(p)) return "简体中文";
        return Lang.s("跟随系统");
    }

    /** 切换界面语言：存偏好后清掉任务、重开主界面，所有界面用新语言重建。 */
    private void setLang(String code) {
        Lang.set(this, code);
        toast(Lang.s("语言已切换，正在重启界面…"));
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        } catch (Exception ignored) {
        }
        finish();
    }

    // ---------------------------------------------------------------- 片段
    private void populateSnippets() {
        try {
            populateSnippetsInner();
        } catch (Throwable t) {
            content.removeAllViews();
            content.addView(header(Lang.s("代码片段")));
            TextView err = label(Lang.s("片段页加载失败：") + t);
            err.setTextSize(11.5f);
            err.setTextColor(0xFFFF7B72);
            content.addView(err);
        }
    }

    private void populateSnippetsInner() {
        content.addView(header(Lang.s("代码片段")));
        TextView tip = label(Lang.s("补全列表里带「片段」标签的就是这些模板。")
                + Lang.s("模板里用 ") + Snippets.CURSOR + Lang.s(" 标出光标位置；多个位置写 ")
                + "${cursor1}${cursor2}… " + Lang.s("不带数字的默认位置先跳，再按数字从小到大。")
                + Lang.s("插入后光标停在第一个位置，光标右下会出现跳转按钮。点下面的条目可以修改。"));
        tip.setTextSize(11f);
        tip.setTextColor(sub());
        content.addView(tip);

        LinearLayout acts = row();
        acts.addView(chip(Lang.s("新增片段"), true, v -> editSnippet(null)));
        acts.addView(chip(Lang.s("恢复全部内置"), false, v -> confirmResetAllSnippets()));
        content.addView(acts);

        final java.util.List<String> deleted = Snippets.deletedBuiltins(this);
        if (!deleted.isEmpty()) {
            LinearLayout delRow = row();
            delRow.addView(chip(Lang.s("恢复已删除的内置 (") + deleted.size() + ")", false, v -> {
                for (String t : deleted) Snippets.resetBuiltin(this, t);
                rebuild();
            }));
            content.addView(delRow);
        }

        content.addView(header(Lang.s("内置片段（可改模板，名字固定）")));
        for (Snippets.Item it : Snippets.allBuiltins(this)) {
            if (deleted.contains(it.trigger)) continue;
            content.addView(snippetRow(it));
        }

        content.addView(header(Lang.s("自定义片段")));
        java.util.List<Snippets.Item> cs = Snippets.allCustoms(this);
        if (cs.isEmpty()) {
            TextView e = label(Lang.s("（暂无，点上面的「新增片段」）"));
            e.setTextSize(11.5f);
            e.setTextColor(sub());
            content.addView(e);
        }
        for (Snippets.Item it : cs) content.addView(snippetRow(it));
    }

    private View snippetRow(final Snippets.Item it) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding((int) d(8), (int) d(10), (int) d(8), (int) d(10));
        TextView t = new TextView(this);
        String tag = it.builtin ? (it.edited ? Lang.s("  内置 · 已改") : Lang.s("  内置")) : Lang.s("  自定义");
        t.setText(it.trigger + tag);
        t.setTextSize(13.5f);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setTextColor(theme.colors[Theme.TOK_TEXT]);
        r.addView(t);
        TextView p = new TextView(this);
        p.setText(Snippets.preview(it.body, 64));
        p.setTextSize(11f);
        p.setTextColor(sub());
        p.setSingleLine(true);
        p.setEllipsize(android.text.TextUtils.TruncateAt.END);
        r.addView(p);
        r.setOnClickListener(v -> editSnippet(it));
        return r;
    }

    /** 新增（it == null）或编辑片段。内置片段名字固定，只能改模板 / 恢复默认。 */
    private void editSnippet(final Snippets.Item it) {
        final boolean builtin = it != null && it.builtin;
        final String original = it == null ? null : it.trigger;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) d(16);
        box.setPadding(pad, (int) d(6), pad, 0);

        TextView nl = label(Lang.s("片段名"));
        nl.setTextSize(11.5f);
        nl.setTextColor(sub());
        box.addView(nl);
        final EditText nameE = new EditText(this);
        nameE.setSingleLine(true);
        nameE.setTextSize(13f);
        nameE.setText(original == null ? "" : original);
        nameE.setHint(Lang.s("例如 myloop"));
        if (builtin) {
            nameE.setEnabled(false);
            nameE.setTextColor(sub());
        }
        box.addView(nameE);

        TextView hl = label(Lang.s("模板（") + Snippets.CURSOR + Lang.s(" / ${cursor1}… = 光标位置）"));
        hl.setTextSize(11.5f);
        hl.setTextColor(sub());
        hl.setPadding(0, (int) d(10), 0, 0);
        box.addView(hl);
        final EditText bodyE = new EditText(this);
        bodyE.setTextSize(12f);
        bodyE.setTypeface(android.graphics.Typeface.MONOSPACE);
        bodyE.setGravity(Gravity.TOP | Gravity.START);
        bodyE.setMinLines(6);
        bodyE.setMaxLines(12);
        bodyE.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        bodyE.setText(Snippets.display(it == null ? "" : it.body));
        bodyE.setHint("while True:\n    " + Snippets.CURSOR);
        box.addView(bodyE);

        TextView hint = label(Lang.s("名称只能用字母 / 数字 / 下划线，不能与已有片段重名；补全里按名称匹配。")
                + (builtin ? Lang.s("\n内置片段可以改模板，也能恢复默认。") : ""));
        hint.setTextSize(10.5f);
        hint.setTextColor(sub());
        hint.setPadding(0, (int) d(8), 0, 0);
        box.addView(hint);

        android.widget.ScrollView boxSc = new android.widget.ScrollView(this);
        boxSc.addView(box);
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this)
                .setTitle(it == null ? Lang.s("新增片段") : (builtin ? Lang.s("编辑内置片段") : Lang.s("编辑片段")))
                .setView(boxSc)
                .setPositiveButton(Lang.s("保存"), null)
                .setNegativeButton(Lang.s("取消"), null);
        if (builtin) {
            b.setNeutralButton(Lang.s("恢复默认"), (d1, w) -> {
                Snippets.resetBuiltin(this, original);
                rebuild();
            });
        } else if (it != null) {
            b.setNeutralButton(Lang.s("删除"), (d1, w) -> confirmDeleteSnippet(it));
        }
        final android.app.AlertDialog dlg = b.create();
        dlg.setOnShowListener(d -> dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String err = Snippets.save(this, original, builtin,
                            nameE.getText().toString(), bodyE.getText().toString());
                    if (err != null) {
                        toast(err);
                        return;
                    }
                    dlg.dismiss();
                    rebuild();
                }));
        dlg.show();
    }

    private void confirmDeleteSnippet(final Snippets.Item it) {
        new android.app.AlertDialog.Builder(this)
                .setMessage(Lang.s("删除片段「") + it.trigger + "」？")
                .setPositiveButton(Lang.s("删除"), (d, w) -> {
                    Snippets.remove(this, it);
                    rebuild();
                })
                .setNegativeButton(Lang.s("取消"), null)
                .show();
    }

    private void confirmResetAllSnippets() {
        new android.app.AlertDialog.Builder(this)
                .setMessage(Lang.s("把所有内置片段恢复成默认模板？（自定义片段保留）"))
                .setPositiveButton(Lang.s("恢复"), (d, w) -> {
                    Snippets.resetAllBuiltins(this);
                    rebuild();
                })
                .setNegativeButton(Lang.s("取消"), null)
                .show();
    }

    private View menuRow(String name, String sub, final int to) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding((int) d(8), (int) d(12), (int) d(8), (int) d(12));
        TextView t = new TextView(this);
        t.setText(name + "   ›");
        t.setTextSize(14.5f);
        t.setTextColor(theme.colors[Theme.TOK_TEXT]);
        r.addView(t);
        TextView s2 = new TextView(this);
        s2.setText(sub);
        s2.setTextSize(11f);
        s2.setTextColor(subColor());
        r.addView(s2);
        r.setOnClickListener(v -> pushPage(to, true));
        return r;
    }

    private int subColor() {
        return sub();
    }

    private static String moduleFromName(String name) {
        if (name == null) return "";
        String n = name;
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        if (n.toLowerCase().endsWith(".c")) n = n.substring(0, n.length() - 2);
        n = n.replaceAll("[^A-Za-z0-9_]", "_");
        if (n.isEmpty() || Character.isDigit(n.charAt(0))) n = "m_" + n;
        return n;
    }

    private void appendCLog(String line) {
        cLog += line + "\n";
        if (cLog.length() > 20000) cLog = cLog.substring(cLog.length() - 20000);
        if (cLogView != null) cLogView.setText(cLog);
    }

    private static byte[] readAll(InputStream in, int max) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > max) throw new Exception(Lang.s("文件太大（上限 ") + (max / 1024) + " KB）");
        }
        in.close();
        return bo.toByteArray();
    }

    /** 预览只在「个性化」页创建；其它页的开关回调也要安全。 */
    private void refreshPreview() {
        if (preview != null) preview.setTheme(theme);
    }

    private void addScalarRow(String name, ColorGetter getter, ColorSetter setter) {
        LinearLayout r = row();
        View sw = swatch(getter.get());
        r.addView(sw);
        TextView tv = label(name);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(tv);
        sw.setOnClickListener(v -> ColorPickDialog.show(this, name, getter.get(), c -> {
            setter.set(c);
            swatchInto(sw, c);
            theme.save(this);
            refreshPreview();
        }));
        content.addView(r);
    }

    interface ColorGetter {
        int get();
    }

    interface ColorSetter {
        void set(int c);
    }

    private void swatchInto(View v, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(d(4));
        bg.setStroke((int) d(1), theme.bg == 0xFFFFFFFF ? 0xFFBBBBBB : 0xFF555B66);
        v.setBackground(bg);
    }

    private CheckBox check(String text, boolean value, CheckCallback cb) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextSize(13);
        c.setTextColor(fg());
        c.setChecked(value);
        c.setPadding(0, (int) d(2), 0, (int) d(2));
        c.setOnCheckedChangeListener((btn, b) -> cb.onChanged(b));
        return c;
    }

    interface CheckCallback {
        void onChanged(boolean b);
    }

    private void preset(String which) {
        theme.preset(which);
        theme.save(this);
        root.setBackgroundColor(theme.bg);
        rebuild();
    }

    // ------------------------------------------------ 5.6.0 自定义主题
    /** 应用一个已保存的自定义主题。 */
    private void applyCustomTheme(String name) {
        Theme t = CustomThemes.load(this, name);
        if (t == null) {
            toast(Lang.s("这个自定义主题已丢失或损坏"));
            return;
        }
        theme.copyFrom(t);
        theme.themeName = name;
        theme.save(this);
        root.setBackgroundColor(theme.bg);
        rebuild();
    }

    /** 把当前整套配色存成一个新的自定义主题（名字可重名覆盖）。 */
    private void promptSaveCustomTheme() {
        final EditText ed = new EditText(this);
        ed.setSingleLine(true);
        ed.setTextSize(14);
        String def = CustomThemes.names(this).contains(theme.themeName)
                ? theme.themeName : Lang.s("我的主题");
        ed.setText(def);
        ed.setSelection(ed.getText().length());
        ed.setPadding((int) d(10), (int) d(6), (int) d(10), (int) d(6));
        new android.app.AlertDialog.Builder(this)
                .setTitle(Lang.s("保存为自定义主题"))
                .setMessage(Lang.s("把当前整套配色存进 App。名字相同的主题会被覆盖："))
                .setView(ed)
                .setPositiveButton(Lang.s("保存"), (dlg, w) -> {
                    String n = CustomThemes.save(this, ed.getText().toString(), theme);
                    theme.themeName = n;
                    theme.save(this);
                    rebuild();
                    toast(Lang.s("已保存自定义主题：") + n);
                })
                .setNegativeButton(Lang.s("取消"), null)
                .show();
    }

    private void confirmDeleteCustomTheme(final String name) {
        new android.app.AlertDialog.Builder(this)
                .setTitle(Lang.s("删除自定义主题"))
                .setMessage(Lang.s("删除「") + name + Lang.s("」？当前配色不会被改掉。"))
                .setPositiveButton(Lang.s("删除"), (dlg, w) -> {
                    CustomThemes.delete(this, name);
                    rebuild();
                })
                .setNegativeButton(Lang.s("取消"), null)
                .show();
    }

    private void pickFont() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_FONT);
        } catch (Exception e) {
            toast(Lang.s("无法打开文件选择器"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 902 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                final byte[] b = readAll(getContentResolver().openInputStream(data.getData()), 2 * 1024 * 1024);
                cSrc = b;
                cSrcName = lastSegment(data.getData());
                toast(Lang.s("已选择 ") + cSrcName);
                rebuild();
            } catch (Exception e) {
                showLong(Lang.s("读取失败"), e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            return;
        }
        if (requestCode == 903 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            final android.net.Uri uri = data.getData();
            toast(Lang.s("正在导入头文件…"));
            new Thread(() -> {
                try {
                    java.io.File tmp = new java.io.File(getCacheDir(), lastSegment(uri));
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp);
                    java.io.InputStream in = getContentResolver().openInputStream(uri);
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
                    fo.close();
                    in.close();
                    final String err = PyHeaders.installFile(SettingsActivity.this, tmp);
                    runOnUiThread(() -> {
                        if (err == null) toast(Lang.s("头文件已就绪"));
                        else showLong(Lang.s("头文件安装失败"), err);
                        rebuild();
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> showLong(Lang.s("导入失败"),
                            e.getClass().getSimpleName() + ": " + e.getMessage()));
                }
            }).start();
            return;
        }
        if (requestCode == 901 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            final android.net.Uri uri = data.getData();
            toast(Lang.s("正在导入…"));
            new Thread(() -> {
                try {
                    java.io.File tmp = new java.io.File(getCacheDir(), "cc_import.bin");
                    java.io.InputStream in = getContentResolver().openInputStream(uri);
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp);
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
                    fo.close();
                    in.close();
                    java.io.File named = new java.io.File(getCacheDir(), lastSegment(uri));
                    if (tmp.renameTo(named)) tmp = named;
                    String err = CompilerStore.importLocal(this, tmp);
                    if (err != null) {
                        runOnUiThread(() -> showLong(Lang.s("导入失败"), err));
                    } else {
                        java.io.File d = lastDir();
                        String pen = (d == null) ? Lang.s("没有找到可执行编译器")
                                : CompilerStore.probe(CompilerStore.findBinary(d));
                        runOnUiThread(() -> {
                            if (pen == null) {
                                Prefs.setCcDir(this, d.getAbsolutePath());
                                toast(Lang.s("导入成功，已启用"));
                            } else {
                                Prefs.setCcDir(this, "");
                                showLong(Lang.s("这个版本不能直接用"), pen);
                            }
                            rebuild();
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> showLong(Lang.s("导入失败"), e.toString()));
                }
            }).start();
            return;
        }
        if (requestCode == 900) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Prefs.setCcDir(this, data.getData().toString());
                rebuild();
                toast(Lang.s("编译器目录已记录"));
            }
            return;
        }
        if (requestCode != REQ_FONT || resultCode != RESULT_OK || data == null || data.getData() == null)
            return;
        Uri uri = data.getData();
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("open failed");
            File dst = new File(getFilesDir(), "custom_font.ttf");
            OutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            theme.fontFamily = "file:" + dst.getAbsolutePath();
            theme.save(this);
            rebuild();
            toast(Lang.s("字体已载入"));
        } catch (Exception e) {
            toast(Lang.s("载入失败: ") + e.getMessage());
        }
    }

    /** 长错误用可滚动对话框显示，避免 toast 看不全。 */
    private void showLong(String title, String msg) {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(11.5f);
        tv.setTextIsSelectable(true);
        tv.setPadding((int) d(14), (int) d(10), (int) d(14), (int) d(10));
        sv.addView(tv);
        new android.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton(Lang.s("知道了"), null)
                .show();
    }

    private String lastSegment(android.net.Uri uri) {
        String p = uri.getLastPathSegment();
        return p == null ? "compiler.bin" : p.replace("/", "_");
    }

    /** 最新导入的目录（按修改时间取最新的编译器目录）。 */
    private java.io.File lastDir() {
        java.util.List<java.io.File> list = CompilerStore.installed(this);
        java.io.File best = null;
        for (java.io.File f : list) {
            if (best == null || f.lastModified() > best.lastModified()) best = f;
        }
        return best;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Immersive.apply(this);
        // 子页（个性化 / 编辑器 …）是独立 Activity：它保存后回到本页要重载，
        // 否则本页仍是旧主题。以前在 onPause 里整篇 save() 会把子页的修改覆盖掉。
        if (Theme.saveCount != seenSaveCount) {
            seenSaveCount = Theme.saveCount;
            theme = Theme.load(this);
            root.setBackgroundColor(theme.bg);
            rebuild();
        }
    }
}
