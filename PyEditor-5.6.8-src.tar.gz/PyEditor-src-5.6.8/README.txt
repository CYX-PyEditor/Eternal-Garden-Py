YHHYPy 5.6.8 源码备份（versionCode 91）

original/ 原始 Java + native + res + manifest + build.sh + tools + test + 文档
minified/ Java 压缩版（删注释/缩进/空行，单行），已 javac 验证；native 原样
不含 assets/libs/lib/build/dist/keystore（标准库 assets/stdlib.tar.xz 从 APK 里取，
或用 tools/trim_stdlib.py + tools/pack_stdlib.py 重新生成）。

相对 5.6.7/90 的变化（Java/C++ 没动，只动标准库）：
- tools/trim_stdlib.py：删 unittest/doctest/pydoc(+pydoc_data)/venv/turtle.py/cgitb.py/xmlrpc/，
  其余 494 个 .py 去注释/空行/docstring（ast 定位 + tokenize 清洗 + 逐个 compile 校验，
  单语句 body 留 pass，this.py 原样保留）。
- tools/pack_stdlib.py：GNU tar 格式（magic "ustar  \0"）+ LZMA2 preset 6 重新打包。
- assets/stdlib.tar.xz 1,688,784 -> 793,312 B；标准库解压后 12 MB -> 6.2 MB。
- APK 10,156,396 -> 9,249,903 B（8.82 MiB），SHA-256
  a5c6153abffb1c54b367b63d4d1eb22749dbf3af7b1849e16e663f03b06ca6ff。
- 单测不变：native 90 + 91；JVM 49 + 31 + 13 + 36。

versionCode 91 可覆盖 5.6.0–5.6.7（同一签名）。

重建：./build.sh；路径带中文，javac 前 export LC_ALL=C.UTF-8（build.sh 已内置）。
native 需要 /opt/asysroot/ndk-r30-clibs/ 里的静态 libc++（4 个 .a + libc/libm/libdl stub），
提取命令见 README.md「重新构建 / libc++ 静态库」。
