#!/bin/bash
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
# Build PyEditor.apk without Gradle: clang-19 (cross, static libc++) + javac + d8 + aapt + apksigner
set -e
cd "$(dirname "$0")"

SDK=/opt/android-sdk
BT=$SDK/build-tools-tmp
AJ=$SDK/platforms/android-35/android.jar
A2="qemu-x86_64-static -L /opt/x86root $SDK/build-tools-tmp/aapt2"
JDK=/usr/lib/jvm/java-17-openjdk-arm64
SR=/opt/asysroot/ndk-sysroot/data/data/com.termux/files/usr
SZ=$PWD/libs/shizuku
LIBS="$SZ/api12.jar:$SZ/aidl.jar:$SZ/shared.jar:$SZ/provider12.jar:$PWD/libs/xz.jar"
JARS="${LIBS//:/ }"
OUT=build

mkdir -p dist

echo "== native =="
mkdir -p lib/arm64-v8a
rm -f lib/arm64-v8a/libmpyrun.so lib/arm64-v8a/libc++_shared.so
# libc++ 静态库：从 NDK r30 提取（clang 21，与 /opt/asysroot/inc-cxx 的 libc++ 21 头文件同版本、
# 同为 __ndk1 ABI 命名空间）。路径可用 CXXLIB=... 覆盖，详见 README「依赖」。
CXXLIB=${CXXLIB:-/opt/asysroot/ndk-r30-clibs}
for f in libclang_rt.builtins-aarch64-android.a libc++_static.a libc++abi.a libunwind.a \
         libc.so libm.so libdl.so; do
  if [ ! -f "$CXXLIB/$f" ]; then
    echo "ERROR: 缺少 $CXXLIB/$f —— 需要从 NDK r30 提取静态 libc++（见 README「依赖」）" >&2
    exit 1
  fi
done
clang++-19 --target=aarch64-linux-android24 --sysroot=$SR -std=c++17 -O2 -fPIC -shared -nostdlib \
  -ffunction-sections -fdata-sections \
  -I /opt/asysroot/inc-arch -I /opt/asysroot/inc-cxx \
  -isystem $JDK/include -isystem $JDK/include/linux \
  -fno-exceptions -fno-rtti -fvisibility=hidden -fstack-protector-strong \
  -Wall -Wextra -Wno-unused-parameter \
  -Wl,-z,max-page-size=16384 -Wl,-z,noexecstack -Wl,-z,defs \
  -Wl,-soname,libpyedit.so -Wl,-O1 \
  -Wl,--gc-sections -Wl,--exclude-libs,ALL -Wl,--strip-debug -Wl,--icf=all \
  native/lexer.cpp native/doc.cpp native/jni.cpp \
  -o lib/arm64-v8a/libpyedit.so \
  $CXXLIB/libclang_rt.builtins-aarch64-android.a \
  $CXXLIB/libc++_static.a $CXXLIB/libc++abi.a $CXXLIB/libunwind.a \
  $CXXLIB/libc.so $CXXLIB/libm.so $CXXLIB/libdl.so
# 注：必须带上 NEEDED libc.so / libm.so / libdl.so。
# 旧版能解析 libc 符号，是因为它 NEEDED 了 libc++_shared.so，而后者 NEEDED libc；
# 现在依赖链没了，app 的“全局组”又不保证暴露 libc 符号，真机上就会
#   dlopen failed: cannot locate symbol "__sF"
# （5.6.5 第一次装机就踩到了）。补上这三个 stub 后，所有符号在链接期解析并带版本，
# 和普通 NDK 产物、以及以前的 libc++_shared.so 完全一致。
# 校验静态链接结果：不许再 NEEDED 动态 libc++，也不许漏掉 C++ 运行时符号
RE=${READELF:-llvm-readelf-19}
if $RE -d lib/arm64-v8a/libpyedit.so | grep -q 'libc++_shared'; then
  echo "ERROR: libpyedit.so 仍依赖 libc++_shared.so（静态链接失败）" >&2
  exit 1
fi
for need in libc.so libm.so libdl.so; do
  if ! $RE -d lib/arm64-v8a/libpyedit.so | grep -q "NEEDED.*\[$need\]"; then
    echo "ERROR: libpyedit.so 缺少 NEEDED $need（真机会解析不到 libc/libdl 符号）" >&2
    exit 1
  fi
done
MISSING=$($RE --dyn-syms -W lib/arm64-v8a/libpyedit.so | awk '$7=="UND"{print $8}' \
          | grep -E '^_ZNSt6__ndk1|^_ZSt|^_Znwm|^_ZdlP|^_Unwind_|^__cxa_guard' || true)
if [ -n "$MISSING" ]; then
  echo "ERROR: 以下 C++ 运行时符号没有静态链进来：" >&2
  echo "$MISSING" >&2
  exit 1
fi

echo "== interpreters =="
cp -f libs/cpython/libcpython.so lib/arm64-v8a/libcpython.so
python3 tools/fix_tls_align.py lib/arm64-v8a/libcpython.so >/dev/null

echo "== resources =="
rm -rf $OUT
mkdir -p $OUT/gen/com/yhhy/pyeditor $OUT/classes $OUT/dex
# build-tools 的 aapt2 是 x86_64，用 qemu 跑；android-35 平台 jar 才认 enableOnBackInvokedCallback
$A2 compile --dir res -o $OUT/res.zip
$A2 link -o $OUT/base.apk -I $AJ --manifest AndroidManifest.xml -A assets \
  -R $OUT/res.zip --auto-add-overlay --java $OUT/gen --min-sdk-version 24 --target-sdk-version 34

echo "== obfuscated source copy =="
rm -rf $OUT/obfuscated_java
mkdir -p $OUT/obfuscated_java/com/yhhy
cp -r java/com/yhhy/pyeditor $OUT/obfuscated_java/com/yhhy/
python3 tools/strip_java_comments.py $OUT/obfuscated_java

echo "== javac =="
find $OUT/gen $OUT/obfuscated_java -name '*.java' > $OUT/sources.txt
rm -rf $OUT/classes; mkdir -p $OUT/classes
javac -source 8 -target 8 -encoding UTF-8 -nowarn \
  -bootclasspath $AJ:$BT/core-lambda-stubs.jar \
  -classpath $AJ:$BT/core-lambda-stubs.jar:$LIBS \
  -d $OUT/classes @$OUT/sources.txt

echo "== dex (R8 obfuscate) =="
find $OUT/classes -name '*.class' > $OUT/classes.txt
rm -rf $OUT/dex; mkdir -p $OUT/dex
$JDK/bin/java -Dfile.encoding=UTF-8 -cp $BT/lib/d8.jar com.android.tools.r8.R8 \
  --release --min-api 24 --lib $AJ --pg-conf tools/proguard-rules.pro \
  --output $OUT/dex @$OUT/classes.txt $JARS
if [ -f $OUT/dex/classes2.dex ]; then echo "WARN: R8 produced multidex"; fi

echo "== package =="
python3 tools/pack.py $OUT/base.apk $OUT/unsigned.apk $OUT/dex/classes.dex lib

if [ ! -f keystore.jks ]; then
  echo "== keystore =="
  $JDK/bin/keytool -genkeypair -keystore keystore.jks -alias yuxuan -keyalg RSA \
    -keysize 2048 -validity 10000 -storepass pyedit -keypass pyedit \
    -dname "CN=雨萱之华, OU=PyEditor, O=萱意永恒, L=CN, ST=CN, C=CN" >/dev/null 2>&1
fi

echo "== sign =="
$JDK/bin/java -jar $BT/lib/apksigner.jar sign --ks keystore.jks --ks-pass pass:pyedit \
  --key-pass pass:pyedit --ks-key-alias yuxuan --min-sdk-version 24 \
  --out dist/PyEditor.apk $OUT/unsigned.apk

$JDK/bin/java -jar $BT/lib/apksigner.jar verify --min-sdk-version 24 dist/PyEditor.apk
ls -l dist/PyEditor.apk
echo "OK"
