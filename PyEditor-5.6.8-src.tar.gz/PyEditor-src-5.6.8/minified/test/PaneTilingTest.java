package com.yhhy.pyeditor;

/**
 * PaneTiling（多区几何约束）的 JVM 单测（不进 APK）。
 *
 * <pre>
 * javac -encoding UTF-8 -d /tmp/pt java/com/yhhy/pyeditor/PaneTiling.java test/PaneTilingTest.java
 * java -cp /tmp/pt com.yhhy.pyeditor.PaneTilingTest
 * </pre>
 */
public class PaneTilingTest {

    static int pass = 0, fail = 0;

    static void ok(String name, boolean cond, String detail) {
        if (cond) {
            pass++;
            System.out.println("OK   " + name);
        } else {
            fail++;
            System.out.println("FAIL " + name + "  " + detail);
        }
    }

    static final int W = 1000, H = 1200, GAP = 24, MIN = 24;

    // 段下标：0 = 上排竖线，1 = 下排竖线，2 = 左列横线，3 = 右列横线
    static final int VT = 0, VB = 1, HL = 2, HR = 3;

    /** 标准 2×2 马赛克：每行自己的竖线、每列自己的横线（5.6.0 的「按段独立」形态）。 */
    static PaneTiling mosaic() {
        int[] cl = {-1, 0, -1, 1};
        int[] cr = {0, -1, 1, -1};
        int[] ct = {-1, -1, 2, 3};
        int[] cb = {2, 3, -1, -1};
        boolean[] sv = {true, true, false, false};
        int[] sp = {500, 500, 500, 500};
        return build(cl, cr, ct, cb, sv, sp);
    }

    static PaneTiling build(int[] cl, int[] cr, int[] ct, int[] cb, boolean[] sv, int[] sp) {
        return new PaneTiling(W, H, 0, 0, 0, 0, GAP, MIN, cl, cr, ct, cb, sv, sp);
    }

    static PaneTiling moved(PaneTiling t, int seg, int pos) {
        int[] sp = t.segPos.clone();
        sp[seg] = pos;
        return build(t.cl, t.cr, t.ct, t.cb, t.segV, sp);
    }

    static boolean[] group(int... idx) {
        boolean[] b = new boolean[4];
        for (int i : idx) b[i] = true;
        return b;
    }

    static String str(int[] a) {
        return "[" + a[0] + ", " + a[1] + "]";
    }

    public static void main(String[] args) {
        // ---- 干净的 2×2：按段拖动完全自由
        PaneTiling t0 = mosaic();
        ok("2x2 无重叠", !t0.anyOverlap(), "");
        int[] limVT = t0.limits(group(VT), true);
        ok("2x2 上排竖线可自由拖", limVT[0] == 36 && limVT[1] == 964, str(limVT));
        int[] limHL = t0.limits(group(HL), false);
        ok("2x2 左列横线可自由拖", limHL[0] == 36 && limHL[1] == 1164, str(limHL));

        // ---- 把上排竖线拖到 x=300：左列比右列宽（合法阶梯）
        PaneTiling t1 = moved(t0, VT, 300);
        ok("竖线拖开后仍无重叠", !t1.anyOverlap(), "");

        // ---- 这时候单独往上拖左列横线会穿透：夹紧在右列横线的坐标上
        int[] solo = t1.limits(group(HL), false);
        ok("左列横线被右列格子挡住", solo[0] == t1.segPos[HR], "lo=" + solo[0] + " HR=" + t1.segPos[HR]);
        ok("夹紧位置 = 完美对齐", solo[0] == 500, str(solo));

        // ---- 不夹紧直接落子 = 用户看到的「区域穿透」
        PaneTiling bad = moved(t1, HL, 300);
        ok("不夹紧会产生区域穿透", bad.anyOverlap(), "overlap=" + bad.overlapPair());

        // ---- 夹紧后没有穿透
        PaneTiling good = moved(t1, HL, solo[0]);
        ok("夹紧后无穿透", !good.anyOverlap(), "");

        // ---- 整条线一起动（升级成整线）可以走更远
        int[] line = t1.limits(group(HL, HR), false);
        ok("整条横线区间更宽", line[0] < solo[0], "line=" + str(line) + " solo=" + str(solo));
        PaneTiling lineDown = moved(moved(t1, HL, line[0]), HR, line[0]);
        ok("整条线落下不穿透", !lineDown.anyOverlap(), "");

        // ---- 暴力扫一遍：任意目标位置夹紧后都不能重叠
        int bad2 = 0;
        for (int target = -200; target <= W + 200; target += 13) {
            int lo = limVT[0], hi = limVT[1];
            int pos = Math.max(lo, Math.min(hi, target));
            PaneTiling t = moved(t0, VT, pos);
            if (t.anyOverlap() || t.badGeometry()) bad2++;
        }
        for (int target = -200; target <= H + 200; target += 13) {
            int[] l = t1.limits(group(HL), false);
            int pos = Math.max(l[0], Math.min(l[1], target));
            PaneTiling t = moved(t1, HL, pos);
            if (t.anyOverlap() || t.badGeometry()) bad2++;
        }
        ok("扫 200+ 个落子位置都不穿透", bad2 == 0, "bad=" + bad2);

        // ---- 十字节点：先竖后横逐轴夹紧（运行时applyDrag 两轴同帧落子还有重叠兜底）
        int[] crossV = t0.limits(group(VT), true);
        PaneTiling afterV = moved(t0, VT, crossV[0]);
        int[] crossH = afterV.limits(group(HL), false);
        PaneTiling cross = moved(afterV, HL, crossH[0]);
        ok("十字节点逐轴夹紧不穿透", !cross.anyOverlap() && !cross.badGeometry(),
                "V=" + cross.segPos[VT] + " H=" + cross.segPos[HL]);
        PaneTiling bothMin = moved(moved(t0, VT, crossV[0]), HL, crossV[0]);
        ok("两轴同时拖到极限会重叠（所以运行时必须兜底回退）", bothMin.anyOverlap(), "");

        // ---- 三行一列的边段：最小尺寸夹紧 = gap + minKeep
        int[] cl = {-1, -1};
        int[] cr = {0, 0};
        int[] ct = {-1, 0};
        int[] cb = {0, -1};
        boolean[] sv = {true};
        int[] sp = {500};
        PaneTiling rows = build(cl, cr, ct, cb, sv, sp);
        int[] rl = rows.limits(group(0), false);
        ok("两行最小高度夹紧", rl[0] == GAP / 2 + MIN && rl[1] == H - GAP / 2 - MIN, str(rl));
        ok("两行初始无重叠", !rows.anyOverlap(), "");

        // ---- 分区快照编解码
        String enc = PaneCodec.encode(W, H, 3,
                new int[]{0, 1, 2, 3}, new int[]{-1, 500, -1, 500},
                new int[]{500, -1, 500, -1}, new int[]{-1, -1, 500, 500},
                new int[]{500, 500, -1, -1});
        PaneCodec.Layout dec = PaneCodec.decode(enc);
        ok("快照往返", dec != null && dec.w == W && dec.h == H && dec.mode == 3 && dec.n == 4
                && dec.pane[1] == 1 && dec.l[1] == 500 && dec.r[3] == -1
                && dec.t[2] == 500 && dec.b[0] == 500, enc);
        ok("快照坏数据被拒绝", PaneCodec.decode("ZL1;1000;1;1;0,1,2,3,4;") == null, "");
        ok("快照截断被拒绝", PaneCodec.decode(enc.substring(0, enc.length() - 4)) == null, "");
        ok("快照空值被拒绝", PaneCodec.decode(null) == null, "");

        // ---- 5.6.6：ZL2 按下标存段。2×2 十字里上下两根竖线坐标相同但必须是两个段，
        //      旧格式（只存坐标）恢复时会被合并成一条 —— 真机表现就是「两两线粘一块」。
        int[] v2li = {-1, 0, -1, 1};
        int[] v2ri = {0, -1, 1, -1};
        int[] v2ti = {-1, -1, 2, 3};
        int[] v2bi = {2, 3, -1, -1};
        String enc2 = PaneCodec.encode(W, H, 3,
                new int[]{1, 1, 0, 0}, new int[]{500, 500, 500, 500},
                new int[]{0, 1, 2, 3}, v2li, v2ri, v2ti, v2bi);
        PaneCodec.Layout d2 = PaneCodec.decode(enc2);
        ok("ZL2 段表往返", d2 != null && d2.ver == 2 && d2.segV.length == 4 && d2.segPos[0] == 500
                && d2.segPos[1] == 500 && d2.li[1] == 0 && d2.li[3] == 1
                && d2.r[0] == 500 && d2.t[2] == 500 && d2.b[0] == 500, String.valueOf(enc2));
        ok("ZL2 同坐标两段仍独立", d2 != null && d2.li[1] != d2.li[3]
                && d2.ti[2] != d2.ti[3], "");
        ok("ZL2 方向不匹配被拒绝",
                PaneCodec.decode("ZL2;1000,1000;3;1;1;1,500;0,-1,-1,0,-1;") == null, "");
        ok("ZL2 下标越界被拒绝",
                PaneCodec.decode("ZL2;1000,1000;3;1;1;1,500;0,5,-1,-1,-1;") == null, "");
        ok("ZL2 截断被拒绝", PaneCodec.decode(enc2.substring(0, enc2.length() - 4)) == null, "");
        // 5.6.7：单区（四边全是外框）没有边段，也必须能存/能读
        String enc1 = PaneCodec.encode(W, H, 1, new int[0], new int[0],
                new int[]{0}, new int[]{-1}, new int[]{-1}, new int[]{-1}, new int[]{-1});
        PaneCodec.Layout d1 = PaneCodec.decode(enc1);
        ok("单区 0 段快照往返", d1 != null && d1.ver == 2 && d1.n == 1 && d1.segV.length == 0
                && d1.l[0] == -1 && d1.b[0] == -1, String.valueOf(enc1));

        // ---- 真机 dump 复现：5.6.1 上真实出现过的坏布局（cell0 右边悬空 → 和 cell1 重叠）
        int[] bcl = {-1, 2, -1, -1, 2, 2};
        int[] bcr = {0, -1, 2, 2, -1, -1};
        int[] bct = {-1, -1, 1, 4, 3, 5};
        int[] bcb = {1, 3, 4, -1, 5, -1};
        boolean[] bsv = {true, false, true, false, false, false};
        int[] bsp = {877, 36, 471, 656, 1355, 1495};
        PaneTiling broken = new PaneTiling(1220, 2334, 0, 0, 0, 0, GAP, MIN, bcl, bcr, bct, bcb, bsv, bsp);
        ok("坏布局被识别（重叠）", broken.overlapUnits() > 0, "score=" + broken.score());
        PaneTiling.Fix[] plan = PaneTiling.repair(1220, 2334, 0, 0, 0, 0, GAP, MIN,
                bcl, bcr, bct, bcb, bsv, bsp.clone(), 24);
        int[] fixedPos = bsp.clone();
        for (PaneTiling.Fix f : plan) fixedPos[f.seg] = f.pos;
        PaneTiling fixed = new PaneTiling(1220, 2334, 0, 0, 0, 0, GAP, MIN, bcl, bcr, bct, bcb, bsv, fixedPos);
        ok("修复后无重叠", fixed.overlapUnits() == 0, "score=" + fixed.score());
        ok("修复后无空洞", fixed.holeUnits() == 0, "score=" + fixed.score());
        ok("修复确实改动了线段", plan.length > 0, "plan=" + plan.length);

        // ---- 空洞：两个格子中间漏了一条 → 修复把洞并回去
        int[] hcl = {-1, -1};
        int[] hcr = {-1, -1};
        int[] hct = {-1, 1};
        int[] hcb = {1, -1};
        boolean[] hsv = {false};
        int[] hsp = {500};                      // 上格底边 500，下格顶边 700 → 中间 200 空洞
        int[] hsp2 = {500, 700};
        // 两个不同的横线段：0 = 上格底边，1 = 下格顶边
        PaneTiling hole = new PaneTiling(1220, 1200, 0, 0, 0, 0, GAP, MIN,
                new int[]{-1, -1}, new int[]{-1, -1}, new int[]{-1, 1}, new int[]{0, -1},
                new boolean[]{false, false}, hsp2);
        ok("空洞被识别", hole.holeUnits() > 0, "score=" + hole.score());
        PaneTiling.Fix[] hp = PaneTiling.repair(1220, 1200, 0, 0, 0, 0, GAP, MIN,
                new int[]{-1, -1}, new int[]{-1, -1}, new int[]{-1, 1}, new int[]{0, -1},
                new boolean[]{false, false}, hsp2.clone(), 24);
        int[] hp2 = hsp2.clone();
        for (PaneTiling.Fix f : hp) hp2[f.seg] = f.pos;
        PaneTiling holeFixed = new PaneTiling(1220, 1200, 0, 0, 0, 0, GAP, MIN,
                new int[]{-1, -1}, new int[]{-1, -1}, new int[]{-1, 1}, new int[]{0, -1},
                new boolean[]{false, false}, hp2);
        ok("空洞被邻居吃掉", hp.length > 0 && holeFixed.holeUnits() == 0
                && holeFixed.overlapUnits() == 0, "score=" + holeFixed.score());

        // ---- 合法布局（阶梯/T 形）不应该被修复动到
        PaneTiling goodT = new PaneTiling(1000, 1200, 0, 0, 0, 0, GAP, MIN,
                new int[]{-1, 0, -1, 1}, new int[]{0, -1, 1, -1},
                new int[]{-1, -1, 2, 2}, new int[]{2, 2, -1, -1},
                new boolean[]{true, true, false, false},
                new int[]{300, 500, 500, 500});
        ok("合法阶梯布局 score=0", goodT.score() == 0, "score=" + goodT.score());
        ok("合法布局不需要修复", PaneTiling.repair(1000, 1200, 0, 0, 0, 0, GAP, MIN,
                goodT.cl, goodT.cr, goodT.ct, goodT.cb, goodT.segV, goodT.segPos.clone(), 24).length == 0, "");

        // ---- 5.6.6：旧快照里被合并的边段按「格子覆盖范围」拆开（2×2 十字 → 上下/左右各一段）
        int[] eg = PaneTiling.extentGroups(new int[]{0, 0, 500, 500}, new int[]{500, 500, 1000, 1000});
        ok("2×2 十字拆成两段", eg != null && eg[0] == eg[1] && eg[2] == eg[3] && eg[0] != eg[2], "");
        ok("中间有空隙也能拆", PaneTiling.extentGroups(new int[]{0, 600}, new int[]{400, 1000}) != null, "");
        ok("合并单元格保持共享",
                PaneTiling.extentGroups(new int[]{0, 500}, new int[]{1000, 1000}) == null, "");

        System.out.println();
        System.out.println("PaneTilingTest: " + pass + " pass, " + fail + " fail");
        if (fail > 0) System.exit(1);
    }
}
