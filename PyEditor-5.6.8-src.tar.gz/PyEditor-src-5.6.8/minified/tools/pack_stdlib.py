#!/usr/bin/env python3
"""把裁剪后的 stdlib 目录打成 assets/stdlib.tar.xz（GNU tar + LZMA2 preset 6）。

必须用 GNU tar 格式（magic `ustar  \\0`）：应用首次启动的解压器是按原来
`tar cJf` 的产物写的，PAX 扩展头不保证能认。

用法：
    python3 tools/pack_stdlib.py /tmp/stdlib-trim assets/stdlib.tar.xz

目录里应该有 python3.12/（和 trim_stdlib.py 的输出一致）。
"""
import os
import sys
import tarfile


def main(src_root, out_path):
    if not os.path.isdir(os.path.join(src_root, "python3.12")):
        sys.exit("输入目录里没有 python3.12/：" + src_root)
    with tarfile.open(out_path, "w:xz", preset=6, format=tarfile.GNU_FORMAT) as t:
        for dirpath, dirnames, filenames in os.walk(src_root):
            dirnames.sort()
            for d in sorted(dirnames):
                p = os.path.join(dirpath, d)
                ti = t.gettarinfo(p, os.path.relpath(p, src_root))
                ti.uid = ti.gid = 0
                ti.uname = ti.gname = ""
                ti.mode = 0o755
                ti.mtime = 0
                t.addfile(ti)
            for fn in sorted(filenames):
                p = os.path.join(dirpath, fn)
                ti = t.gettarinfo(p, os.path.relpath(p, src_root))
                ti.uid = ti.gid = 0
                ti.uname = ti.gname = ""
                ti.mode = 0o644
                ti.mtime = 0
                with open(p, "rb") as f:
                    t.addfile(ti, f)
    print("packed", out_path, os.path.getsize(out_path), "bytes")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("用法: pack_stdlib.py <stdlib_root> <out.tar.xz>")
    main(sys.argv[1], sys.argv[2])
