#!/usr/bin/env python3
"""CPython 标准库「外科手术」：删手机端用不到的模块 + 去注释/空行/docstring。

用法：
    python3 tools/trim_stdlib.py <解压出来的 stdlib 根> <输出目录>

输入目录里应该是 `python3.12/`（和 assets/stdlib.tar.xz 解压后一致）。
输出是同样结构的精简版；打包脚本再 `tar cJf assets/stdlib.tar.xz -C <输出> python3.12`。

原则：
* 只删「C 扩展根本没编进 libcpython」或用不到的模块；
* 每个 .py 改写后都用 compile() 校验，失败就保留原文件（宁可留大，不可留坏）；
* `this.py`（整个文件就是那段 Zen 的 docstring）原样保留。
"""
import ast
import io
import os
import shutil
import sys
import tokenize

# 用户点名要删的 + 因为它们才存在的依赖
DROP_DIRS = {
    "tkinter", "turtledemo",          # 没有图形界面
    "unittest", "doctest",            # 不跑单测
    "pydoc_data",                     # pydoc 的文档数据（820 KB）
    "ensurepip", "venv", "lib2to3",   # 不需要内部包管理器 / 老旧工具
    "idlelib", "distutils",
    "xmlrpc",                         # server 依赖 pydoc，client 依赖 zlib（都没了）
}
DROP_FILES = {
    "doctest.py",                     # 单测用
    "pydoc.py", "cgitb.py",           # cgitb 顶层 import pydoc，跟着一起删
    "turtle.py",                      # 依赖 tkinter
}
# 整个文件只有 docstring 的彩蛋模块，保留原样
KEEP_ASIS = {"this.py"}


def docstring_ranges(src):
    """返回 [(起始行, 结束行, 该 body 的语句数)]，行号 1-based。"""
    tree = ast.parse(src)
    out = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = getattr(node, "body", None)
        if not body:
            continue
        first = body[0]
        if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                and isinstance(first.value.value, str)):
            out.append((first.lineno, first.end_lineno, len(body)))
    return out


def strip_docstrings(src):
    ranges = sorted(docstring_ranges(src), key=lambda r: r[0], reverse=True)
    lines = src.splitlines(keepends=True)
    for start, end, body_len in ranges:
        head = lines[start - 1]
        indent = head[:len(head) - len(head.lstrip())]
        if body_len > 1:
            del lines[start - 1:end]
        else:
            # 只有 docstring 的 body：留一个 pass 保证语法
            lines[start - 1:end] = [indent + "pass\n"]
    return "".join(lines)


def strip_comments_blank(src):
    """去掉注释行和空行；多行字符串内部原样保留（不能动里面的空格）。"""
    comments = {}
    protected = set()
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            comments.setdefault(tok.start[0], tok.start[1])
        elif tok.type == tokenize.STRING and tok.end[0] > tok.start[0]:
            for ln in range(tok.start[0], tok.end[0] + 1):
                protected.add(ln)
    out = []
    for i, raw in enumerate(src.splitlines(keepends=True), 1):
        if i in protected:
            out.append(raw if raw.endswith("\n") else raw + "\n")
            continue
        line = raw.split("\n", 1)[0]
        if i in comments:
            line = line[:comments[i]]
        line = line.rstrip()
        if line:
            out.append(line + "\n")
    return "".join(out)


def process_py(src_text):
    """返回精简后的源码；语法不合法时返回 None。"""
    try:
        compile(src_text, "<orig>", "exec")
    except SyntaxError:
        return None
    try:
        step1 = strip_docstrings(src_text)
        compile(step1, "<doc>", "exec")
    except SyntaxError:
        return None
    try:
        step2 = strip_comments_blank(step1)
        compile(step2, "<comments>", "exec")
    except (SyntaxError, tokenize.TokenError, IndentationError):
        return None
    return step2


def main(src_root, dst_root):
    src_root = os.path.abspath(src_root)
    dst_root = os.path.abspath(dst_root)
    if not os.path.isdir(os.path.join(src_root, "python3.12")):
        sys.exit("输入目录里没有 python3.12/：" + src_root)
    if os.path.exists(dst_root):
        shutil.rmtree(dst_root)
    os.makedirs(dst_root)

    removed_dirs = []
    removed_files = []
    trimmed = 0
    kept_asis = 0
    failed = []

    for dirpath, dirnames, filenames in os.walk(src_root):
        rel = os.path.relpath(dirpath, src_root)
        # 模块目录/文件都在 python3.12/ 这一层
        top = rel == "python3.12"
        if top:
            for d in list(dirnames):
                if d in DROP_DIRS:
                    dirnames.remove(d)
                    removed_dirs.append(d)

        out_dir = os.path.join(dst_root, rel) if rel != "." else dst_root
        os.makedirs(out_dir, exist_ok=True)
        for fn in sorted(filenames):
            src_path = os.path.join(dirpath, fn)
            rel_file = os.path.relpath(src_path, src_root)
            base = os.path.basename(rel_file)
            if top and base in DROP_FILES:
                removed_files.append(base)
                continue
            dst_path = os.path.join(dst_root, rel_file)
            if not fn.endswith(".py") or base in KEEP_ASIS:
                shutil.copy2(src_path, dst_path)
                kept_asis += 1
                continue
            try:
                with tokenize.open(src_path) as fh:      # 按文件声明的编码读
                    text = fh.read()
            except Exception as e:                        # noqa: BLE001
                shutil.copy2(src_path, dst_path)
                failed.append((rel_file, "read: %s" % e))
                continue
            out = process_py(text)
            if out is None:
                shutil.copy2(src_path, dst_path)
                failed.append((rel_file, "syntax"))
                continue
            with open(dst_path, "w", encoding="utf-8", newline="") as fh:
                fh.write(out)
            trimmed += 1

    print("removed dirs :", ", ".join(removed_dirs) or "-")
    print("removed files:", ", ".join(removed_files) or "-")
    print("trimmed .py  :", trimmed)
    print("kept as-is   :", kept_asis)
    if failed:
        print("kept original (failed):", len(failed))
        for f, why in failed[:20]:
            print("  ", why, f)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("用法: trim_stdlib.py <src_root> <dst_root>")
    main(sys.argv[1], sys.argv[2])
