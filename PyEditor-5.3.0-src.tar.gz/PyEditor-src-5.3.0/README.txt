PyEditor 5.3.0 源码备份（2026-10-27，versionCode 68，包名 com.yhhy.pyeditor）
original/ 原始 Java + native + res + manifest + build.sh + tools + test + 文档
minified/ Java 压缩版（删注释/缩进/空行，单行），已 javac 验证；native 原样
不含 assets/libs/lib/build/dist/keystore。
重建：./build.sh（clang-19、SDK 35、JDK 17；aapt2 经 qemu 运行，带 --auto-add-overlay）
单测：javac -d /tmp/t java/com/yhhy/pyeditor/FoldScan.java \
        java/com/yhhy/pyeditor/SymbolStats.java test/ScanTest.java
      java -cp /tmp/t com.yhhy.pyeditor.ScanTest
界面文案：python3 tools/wrap_lang.py（包 Lang.s）；python3 tools/gen_lang.py（生成字典/查缺译文）
5.3.0 改动：包名 com.dsh.pyedit → com.yhhy.pyeditor（含 JNI 符号 / R8 / authority / build.sh）；
新增 Lang 中英字典（414 条）与「设置 → 语言」；res/values + res/values-zh 清单 label
