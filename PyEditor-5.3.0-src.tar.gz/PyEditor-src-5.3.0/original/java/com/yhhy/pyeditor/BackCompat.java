package com.yhhy.pyeditor;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;

/** Android 13+ 的原生返回回调封装；低版本仍走 onBackPressed。 */
final class BackCompat {

    interface Handler {
        void onBack();
    }

    /** API 34+ 预测性返回：开始 / 进度 / 取消 / 提交。 */
    interface Anim {
        void onStart();

        void onProgress(float progress);

        void onCancel();

        void onInvoke();
    }

    private BackCompat() {
    }

    /** 返回 token（API 33+ 的 OnBackInvokedCallback），低版本返回 null。 */
    static Object register(Activity a, Handler h) {
        if (Build.VERSION.SDK_INT < 33) return null;
        return Api33.register(a, h);
    }

    static void unregister(Activity a, Object token) {
        if (Build.VERSION.SDK_INT < 33 || token == null) return;
        Api33.unregister(a, token);
    }

    /** API 34+ 注册带跟手动画的返回回调；低版本退回普通回调。 */
    static Object registerAnimated(Activity a, Anim h) {
        if (Build.VERSION.SDK_INT < 34) return register(a, h::onInvoke);
        return Api34.register(a, h);
    }

    @TargetApi(34)
    private static final class Api34 {
        static Object register(Activity a, Anim h) {
            android.window.OnBackAnimationCallback cb = new android.window.OnBackAnimationCallback() {
                @Override
                public void onBackStarted(android.window.BackEvent e) {
                    h.onStart();
                }

                @Override
                public void onBackProgressed(android.window.BackEvent e) {
                    h.onProgress(e.getProgress());
                }

                @Override
                public void onBackCancelled() {
                    h.onCancel();
                }

                @Override
                public void onBackInvoked() {
                    h.onInvoke();
                }
            };
            a.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
            return cb;
        }
    }

    @TargetApi(33)
    private static final class Api33 {
        static Object register(Activity a, Handler h) {
            android.window.OnBackInvokedCallback cb = h::onBack;
            a.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
            return cb;
        }

        static void unregister(Activity a, Object token) {
            a.getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(
                    (android.window.OnBackInvokedCallback) token);
        }
    }
}
