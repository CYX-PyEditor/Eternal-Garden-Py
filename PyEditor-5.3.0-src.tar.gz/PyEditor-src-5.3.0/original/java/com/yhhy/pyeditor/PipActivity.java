package com.yhhy.pyeditor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** 纯 Python 包管理器：只收纯 Python wheel / .py / 文件夹，含二进制一律拒收。 */
public class PipActivity extends Activity {

    private static final int REQ_LOCAL = 41;
    private LinearLayout list;
    private TextView log;
    private ScrollView logScroll;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme theme = Theme.load(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(theme.bg);
        root.setPadding(dp(14), dp(14), dp(14), dp(10));

        TextView title = new TextView(this);
        title.setText(Lang.s("包管理 · 仅纯 Python"));
        title.setTextSize(16);
        title.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        title.setPadding(0, 0, 0, dp(10));
        root.addView(title);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final EditText name = new EditText(this);
        name.setHint(Lang.s("PyPI 包名，如 six / requests"));
        name.setTextSize(13);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        name.setTextColor(theme.colors[Theme.TOK_TEXT]);
        name.setHintTextColor(theme.gutterText);
        row.addView(name, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button install = new Button(this);
        install.setText(Lang.s("下载安装"));
        install.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                say(Lang.s("请输入包名"));
                return;
            }
            installFromPyPI(n);
        });
        row.addView(install);
        root.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button local = new Button(this);
        local.setText(Lang.s("导入本地 .py / .whl"));
        local.setOnClickListener(v -> pickLocal());
        row2.addView(local);
        Button refresh = new Button(this);
        refresh.setText(Lang.s("刷新"));
        refresh.setOnClickListener(v -> refreshList());
        row2.addView(refresh);
        root.addView(row2);

        TextView head = new TextView(this);
        head.setText(Lang.s("已安装"));
        head.setTextSize(12);
        head.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        head.setPadding(0, dp(10), 0, dp(4));
        root.addView(head);

        LinearLayout batch = new LinearLayout(this);
        batch.setOrientation(LinearLayout.HORIZONTAL);
        batch.setGravity(Gravity.CENTER_VERTICAL);
        TextView all = chip(Lang.s("全选"), theme, false);
        all.setOnClickListener(v -> {
            selected.clear();
            for (File d : SitePkgs.dirs(this)) selected.add(d.getName());
            refreshList();
        });
        batch.addView(all);
        TextView none = chip(Lang.s("清空"), theme, false);
        none.setOnClickListener(v -> {
            selected.clear();
            refreshList();
        });
        batch.addView(none);
        batchBtn = new Button(this);
        batchBtn.setText(Lang.s("卸载选中 (0)"));
        batchBtn.setEnabled(false);
        batchBtn.setAlpha(0.45f);
        batchBtn.setOnClickListener(v -> uninstallSelected());
        batch.addView(batchBtn);
        root.addView(batch);

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        log = new TextView(this);
        log.setTextSize(11);
        log.setTextColor(0xFF32C8FF);
        log.setPadding(0, dp(8), 0, dp(4));
        logScroll = new ScrollView(this);
        logScroll.addView(log);
        root.addView(logScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(110)));

        setContentView(root);
        refreshList();
    }

    // ------------------------------------------------------------ 列表
    private final java.util.LinkedHashSet<String> selected = new java.util.LinkedHashSet<>();
    private Button batchBtn;
    private boolean refreshing;

    /** 目录名拆成 {包名, 版本}：six-1.17.0 → six / 1.17.0；本地模块没有版本。 */
    static String[] splitNameVersion(String dirName) {
        int i = dirName.lastIndexOf('-');
        if (i > 0 && i + 1 < dirName.length() && Character.isDigit(dirName.charAt(i + 1))) {
            return new String[]{dirName.substring(0, i), dirName.substring(i + 1)};
        }
        return new String[]{dirName, ""};
    }

    private static String norm(String name) {
        return name.toLowerCase().replace('_', '-').replace(' ', '-');
    }

    private void updateBatchBtn() {
        if (batchBtn == null) return;
        batchBtn.setText(Lang.s("卸载选中 (") + selected.size() + ")");
        batchBtn.setEnabled(!selected.isEmpty());
        batchBtn.setAlpha(selected.isEmpty() ? 0.45f : 1f);
    }

    private void refreshList() {
        if (refreshing) return;
        refreshing = true;
        try {
            list.removeAllViews();
            Theme th = Theme.load(this);
            List<File> dirs = SitePkgs.dirs(this);

            java.util.Set<String> alive = new java.util.HashSet<>();
            for (File d : dirs) alive.add(d.getName());
            selected.retainAll(alive);
            updateBatchBtn();

            if (dirs.isEmpty()) {
                TextView e = new TextView(this);
                e.setText(Lang.s("（空）"));
                e.setTextSize(12);
                e.setTextColor(th.gutterText);
                list.addView(e);
                return;
            }

            java.util.Map<String, File> byName = new java.util.HashMap<>();
            for (File d : dirs) byName.put(norm(splitNameVersion(d.getName())[0]), d);

            for (final File d : dirs) {
                final String[] nv = splitNameVersion(d.getName());
                final String name = nv[0], ver = nv[1];

                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setPadding(0, dp(4), 0, dp(4));

                LinearLayout r = new LinearLayout(this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);

                android.widget.CheckBox cb = new android.widget.CheckBox(this);
                cb.setChecked(selected.contains(d.getName()));
                cb.setPadding(0, 0, dp(2), 0);
                cb.setOnCheckedChangeListener((b, on) -> {
                    if (on) selected.add(d.getName());
                    else selected.remove(d.getName());
                    updateBatchBtn();
                });
                r.addView(cb);

                LinearLayout nameCol = new LinearLayout(this);
                nameCol.setOrientation(LinearLayout.VERTICAL);
                TextView t = new TextView(this);
                t.setText(name);
                t.setTextSize(13f);
                t.setTextColor(th.colors[Theme.TOK_TEXT]);
                nameCol.addView(t);
                TextView vt = new TextView(this);
                vt.setText(ver.isEmpty() ? Lang.s("本地模块") : (Lang.s("版本 ") + ver));
                vt.setTextSize(10.5f);
                vt.setTextColor(th.gutterText);
                nameCol.addView(vt);
                r.addView(nameCol, new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                java.util.List<String> deps = requiresOf(d);
                int missing = 0;
                for (String dep : deps) if (byName.get(norm(dep)) == null) missing++;

                final LinearLayout tree = new LinearLayout(this);
                tree.setOrientation(LinearLayout.VERTICAL);
                tree.setVisibility(View.GONE);
                if (deps.isEmpty()) {
                    TextView none = new TextView(this);
                    none.setText(Lang.s("无第三方依赖"));
                    none.setTextSize(11f);
                    none.setTextColor(th.gutterText);
                    none.setPadding(dp(30), dp(1), 0, dp(3));
                    tree.addView(none);
                } else {
                    java.util.Set<String> path = new java.util.HashSet<>();
                    path.add(norm(name));
                    addDepLines(tree, d, 0, path, byName, th);
                    TextView sum = new TextView(this);
                    sum.setText(deps.size() + Lang.s(" 个直接依赖")
                            + (missing > 0 ? "，" + missing + Lang.s(" 个未安装") : Lang.s("，已全部安装")));
                    sum.setTextSize(10.5f);
                    sum.setTextColor(missing > 0 ? 0xFFFF7B72 : th.gutterText);
                    sum.setPadding(dp(30), dp(3), 0, dp(3));
                    tree.addView(sum);
                }

                if (!deps.isEmpty()) {
                    final TextView depChip = chip(Lang.s("依赖 ▼ ") + deps.size()
                            + (missing > 0 ? Lang.s(" · 缺 ") + missing : ""), th, missing > 0);
                    depChip.setOnClickListener(v -> {
                        boolean show = tree.getVisibility() != View.VISIBLE;
                        tree.setVisibility(show ? View.VISIBLE : View.GONE);
                        depChip.setText(show ? Lang.s("依赖 ▲ ") + deps.size()
                                : Lang.s("依赖 ▼ ") + deps.size());
                    });
                    r.addView(depChip);
                }

                Button del = new Button(this);
                del.setText(Lang.s("卸载"));
                del.setOnClickListener(v -> {
                    new android.app.AlertDialog.Builder(this)
                            .setMessage(Lang.s("卸载 ") + d.getName() + " ?")
                            .setNegativeButton(Lang.s("取消"), null)
                            .setPositiveButton(Lang.s("卸载"), (d2, w) -> {
                                deleteRec(d);
                                selected.remove(d.getName());
                                say(Lang.s("已卸载 ") + d.getName());
                                refreshList();
                            })
                            .show();
                });
                r.addView(del);

                col.addView(r);
                col.addView(tree);
                list.addView(col);
            }
        } finally {
            refreshing = false;
        }
    }

    private TextView chip(String text, Theme th, boolean warn) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(10.5f);
        tv.setPadding(dp(8), dp(4), dp(8), dp(4));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(9));
        bg.setColor(warn ? 0x33FF7B72 : 0xFF2C313A);
        tv.setBackground(bg);
        tv.setTextColor(warn ? 0xFFFF7B72 : th.colors[Theme.TOK_BUILTIN]);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(4), 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    /** 递归画依赖树（深度 ≤ 3，遇到环就停），已装的显版本号，未装的标红。 */
    private void addDepLines(LinearLayout box, File pkgDir, int depth,
                             java.util.Set<String> path,
                             java.util.Map<String, File> byName, Theme th) {
        java.util.List<String> deps = requiresOf(pkgDir);
        for (int i = 0; i < deps.size(); i++) {
            String dep = deps.get(i);
            File df = byName.get(norm(dep));
            boolean last = i == deps.size() - 1;
            String indent = "";
            for (int k = 0; k < depth; k++) indent += "    ";
            TextView tv = new TextView(this);
            tv.setTextSize(11f);
            String ver = df == null ? "" : splitNameVersion(df.getName())[1];
            tv.setText(indent + (last ? "└─ " : "├─ ") + dep
                    + (df == null ? Lang.s("  (未安装)") : (ver.isEmpty() ? "" : "  " + ver)));
            tv.setTextColor(df == null ? 0xFFFF7B72 : th.gutterText);
            tv.setPadding(dp(30), dp(1), 0, dp(1));
            box.addView(tv);
            if (df != null && depth < 3 && path.add(norm(dep))) {
                addDepLines(box, df, depth + 1, path, byName, th);
                path.remove(norm(dep));
            }
        }
    }

    private void uninstallSelected() {
        if (selected.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (String n : selected) sb.append("\n· ").append(n);
        final java.util.List<String> names = new java.util.ArrayList<>(selected);
        new android.app.AlertDialog.Builder(this)
                .setTitle(Lang.s("卸载 ") + names.size() + Lang.s(" 个包"))
                .setMessage(Lang.s("将被删除：") + sb + Lang.s("\n\n如果别的包依赖它们，对应的 import 会失败。"))
                .setNegativeButton(Lang.s("取消"), null)
                .setPositiveButton(Lang.s("全部卸载"), (d, w) -> {
                    for (String n : names) deleteRec(new File(SitePkgs.root(this), n));
                    selected.clear();
                    say(Lang.s("已卸载 ") + names.size() + Lang.s(" 个包"));
                    refreshList();
                })
                .show();
    }

    // ------------------------------------------------------------ PyPI
    private void installFromPyPI(final String pkg) {
        say(Lang.s("查询 ") + pkg + " …");
        new Thread(() -> {
            java.util.HashSet<String> seen = new java.util.HashSet<>();
            installTree(pkg, 0, seen);
            runOnUiThread(this::refreshList);
        }).start();
    }

    /** 递归装包 + 依赖（深度 ≤ 4，总数 ≤ 24，失败不阻断后续）。 */
    private void installTree(String pkgName, int depth, java.util.HashSet<String> seen) {
        if (depth > 4 || seen.size() > 24) return;
        String key = pkgName.toLowerCase().replace("_", "-");
        if (!seen.add(key)) return;
        if (isInstalled(pkgName)) {
            ui("· " + pkgName + Lang.s(" 已安装，跳过"));
            return;
        }
        try {
            String base = pkgName.replace("[", "").replace("]", "")
                    .split("\\s*[<>=!;]")[0].trim();
            if (base.isEmpty()) return;
            ui(Lang.s("查询 ") + base + " …");
            JSONObject meta = new JSONObject(http("https://pypi.org/pypi/" + base + "/json"));
            String ver = meta.getJSONObject("info").getString("version");
            JSONArray urls = meta.getJSONArray("urls");
            String wheel = null;
            for (int i = 0; i < urls.length(); i++) {
                JSONObject u = urls.getJSONObject(i);
                String fn = u.getString("filename");
                if (fn.endsWith(".whl")) {
                    String low = fn.toLowerCase();
                    if (low.contains("-none-any")) {
                        wheel = u.getString("url");
                        break;
                    }
                }
            }
            if (wheel == null) {
                ui(Lang.s("需要 C 编译器：") + base + Lang.s(" 只有源码包。\n→ 到 设置 → 编译器 配置一个编译器后再试"));
                return;
            }
            ui(Lang.s("下载 ") + wheel.substring(wheel.lastIndexOf('/') + 1));
            byte[] data = download(wheel);
            String dirName = base + "-" + ver;
            String err = installWheel(data, dirName);
            if (err != null) {
                ui(Lang.s("需要 C 编译器：") + err + Lang.s("\n→ 到 设置 → 编译器：先装编译器，再用「编译 C 扩展」"));
                return;
            }
            // 依赖：读 METADATA 的 Requires-Dist
            for (String dep : requiresOf(new File(SitePkgs.root(this), dirName))) {
                installTree(dep, depth + 1, seen);
            }
        } catch (Exception e) {
            ui(Lang.s("失败：") + pkgName + "：" + e.getMessage());
        }
    }

    private boolean isInstalled(String name) {
        String n = name.toLowerCase().replace("_", "-");
        for (File d : SitePkgs.dirs(this)) {
            if (d.getName().toLowerCase().replace("_", "-").startsWith(n + "-")) return true;
        }
        return false;
    }

    /** 解析已装 wheel 的 METADATA，返回纯 Python 依赖名（去版本约束、去 extras）。 */
    private java.util.List<String> requiresOf(File pkgDir) {
        java.util.List<String> out = new java.util.ArrayList<>();
        File[] kids = pkgDir.listFiles();
        if (kids == null) return out;
        for (File k : kids) {
            if (!k.isDirectory() || !k.getName().endsWith(".dist-info")) continue;
            File meta = new File(k, "METADATA");
            if (!meta.isFile()) continue;
            try {
                java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(new java.io.FileInputStream(meta), "UTF-8"));
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.startsWith("Requires-Dist:")) continue;
                    String v = line.substring("Requires-Dist:".length()).trim();
                    if (v.contains("extra ==")) continue;      // 可选依赖不管
                    int semi = v.indexOf(';');
                    if (semi >= 0) v = v.substring(0, semi).trim();
                    v = v.replaceAll("\\s*\\(.*\\)", "");     // 去掉 (>=1.0)
                    int br2 = v.indexOf('[');
                    if (br2 >= 0) v = v.substring(0, br2);
                    v = v.split("[<>=!~ ]")[0].trim();
                    if (!v.isEmpty() && out.size() < 16) out.add(v);
                }
                br.close();
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    /** 安装 wheel 字节流；返回 null 表示成功，否则返回拒收原因。 */
    private String installWheel(byte[] data, String dirName) throws Exception {
        List<String> bad = new ArrayList<>();
        ZipInputStream zin = new ZipInputStream(new BufferedInputStream(
                new java.io.ByteArrayInputStream(data)));
        ZipEntry e;
        while ((e = zin.getNextEntry()) != null) {
            String n = e.getName().toLowerCase();
            if (n.endsWith(".so") || n.endsWith(".pyd") || n.endsWith(".dll")
                    || n.endsWith(".dylib") || n.endsWith(".a")) {
                bad.add(e.getName());
            }
        }
        zin.close();
        if (!bad.isEmpty()) {
            return Lang.s("包含二进制扩展 ") + bad.get(0);
        }
        File dst = new File(SitePkgs.root(this), dirName);
        deleteRec(dst);
        dst.mkdirs();
        zin = new ZipInputStream(new BufferedInputStream(
                new java.io.ByteArrayInputStream(data)));
        String root = dst.getCanonicalPath() + File.separator;
        while ((e = zin.getNextEntry()) != null) {
            File out = new File(dst, e.getName());
            if (!out.getCanonicalPath().startsWith(root)) continue;
            if (e.isDirectory()) {
                out.mkdirs();
                continue;
            }
            File p = out.getParentFile();
            if (p != null) p.mkdirs();
            FileOutputStream fos = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = zin.read(buf)) > 0) fos.write(buf, 0, n);
            fos.close();
        }
        zin.close();
        ui(Lang.s("已安装 ") + dirName);
        ui(importTest(splitNameVersion(dirName)[0]));
        runOnUiThread(this::refreshList);
        return null;
    }

    /** 装完用 CPython 试跑一次。 */
    private String importTest(String mod) {
        String err = runImport(mod);
        if (err == null) return "import " + mod + Lang.s(" 通过（CPython 3.12）");
        return "import " + mod + Lang.s(" 失败：\n") + tail(err);
    }

    /** 返回 null 表示成功，否则返回错误输出。 */
    private String runImport(String mod) {
        try {
            String lib = getApplicationInfo().nativeLibraryDir;
            List<String> cmd = new ArrayList<>();
            cmd.add(new File(lib, "libcpython.so").getAbsolutePath());
            cmd.add("-S");
            cmd.add("-c");
            cmd.add("import " + mod);
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            java.util.Map<String, String> env = pb.environment();
            String sp = SitePkgs.pathEnv(this);
            java.io.File home = new java.io.File(getFilesDir(), "python");
            java.io.File libDir2 = new java.io.File(home, "lib/python3.12");
            env.put("PYTHONHOME", home.getAbsolutePath());
            env.put("PYTHONPATH", libDir2.isDirectory()
                    ? libDir2.getAbsolutePath() + (sp.isEmpty() ? "" : ":" + sp)
                    : sp);
            Process p = pb.start();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = p.getInputStream().read(buf)) > 0) bo.write(buf, 0, n);
            int code = p.waitFor();
            if (code == 0) return null;
            return bo.toString("UTF-8").trim();
        } catch (Exception e) {
            return Lang.s("测试异常：") + e.getMessage();
        }
    }

    private static String tail(String s) {
        if (s.length() > 400) s = s.substring(s.length() - 400);
        return s;
    }

    // ------------------------------------------------------------ 本地
    private void pickLocal() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_LOCAL);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_LOCAL || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        say(Lang.s("导入 ") + uri.getLastPathSegment() + " …");
        new Thread(() -> {
            try {
                byte[] bytes = readAll(getContentResolver().openInputStream(uri));
                String name = uri.getLastPathSegment();
                if (name == null) name = "pkg";
                if (name.toLowerCase().endsWith(".whl")) {
                    String err = installWheel(bytes, name.replace(".whl", ""));
                    if (err != null) ui(Lang.s("需要 C 编译器：") + err + Lang.s("\n→ 到 设置 → 编译器：先装编译器，再用「编译 C 扩展」"));
                } else if (name.toLowerCase().endsWith(".py")) {
                    File d = new File(SitePkgs.root(this), name.replace(".py", ""));
                    deleteRec(d);
                    d.mkdirs();
                    FileOutputStream fo = new FileOutputStream(new File(d, name));
                    fo.write(bytes);
                    fo.close();
                    ui(Lang.s("已安装 ") + name);
                    ui(importTest(name.replace(".py", "")));
                    runOnUiThread(this::refreshList);
                } else {
                    ui(Lang.s("只支持 .py 和 .whl"));
                }
            } catch (Exception e) {
                ui(Lang.s("导入失败：") + e.getMessage());
            }
        }).start();
    }

    // ------------------------------------------------------------ 工具
    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    private static byte[] download(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        InputStream in = c.getInputStream();
        byte[] b = readAll(in);
        c.disconnect();
        return b;
    }

    private static String http(String url) throws Exception {
        return new String(download(url), "UTF-8");
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }

    private void say(String s) {
        runOnUiThread(() -> {
            log.setText(s);
            scrollLogToEnd();
        });
    }

    private void ui(String s) {
        runOnUiThread(() -> {
            log.setText(log.getText() + "\n" + s);
            scrollLogToEnd();
        });
    }

    private void scrollLogToEnd() {
        if (logScroll != null) logScroll.post(() -> logScroll.fullScroll(android.view.View.FOCUS_DOWN));
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
