package com.yhhy.pyeditor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;

/** Editor appearance + behaviour settings, persisted in SharedPreferences. */
public class Theme {
    public static final int TOK_TEXT = 0, TOK_KEYWORD = 1, TOK_BUILTIN = 2, TOK_CONST = 3,
            TOK_STRING = 4, TOK_COMMENT = 5, TOK_NUMBER = 6, TOK_OPERATOR = 7, TOK_DEF = 8,
            TOK_CLASS = 9, TOK_DECORATOR = 10, TOK_SELF = 11, TOK_PARAM = 12,
            TOK_USERFUNC = 13, TOK_USERCLASS = 14, TOK_COUNT = 15;

    public static final String[] TOK_NAMES = {
            "普通文本", "关键字", "内置函数", "常量 True/None", "字符串", "注释", "数字",
            "运算符", "def 函数名", "class 类名", "装饰器 @", "self / cls", "参数名",
            "自定义函数调用", "自定义类名"
    };

    public static final int[] PRESET_DARK = {
            0xFFABB2BF, 0xFFC678DD, 0xFF61AFEF, 0xFFD19A66, 0xFF98C379, 0xFF5C6370,
            0xFFD19A66, 0xFF56B6C2, 0xFF61AFEF, 0xFFE5C07B, 0xFFE5C07B, 0xFFE06C75,
            0xFFD19A66, 0xFF61AFEF, 0xFFE5C07B
    };
    public static final int[] PRESET_LIGHT = {
            0xFF24292E, 0xFFD73A49, 0xFF6F42C1, 0xFF005CC5, 0xFF032F62, 0xFF6A737D,
            0xFF005CC5, 0xFF24292E, 0xFF6F42C1, 0xFFB31D28, 0xFF6F42C1, 0xFFE36209,
            0xFF24292E, 0xFF6F42C1, 0xFFB31D28
    };
    public static final int[] PRESET_MONOKAI = {
            0xFFF8F8F2, 0xFFF92672, 0xFF66D9EF, 0xFFAE81FF, 0xFFE6DB74, 0xFF75715E,
            0xFFAE81FF, 0xFFF92672, 0xFFA6E22E, 0xFFA6E22E, 0xFFA6E22E, 0xFFFD971F,
            0xFFFD971F, 0xFFA6E22E, 0xFFA6E22E
    };
    public static final int[] PRESET_SOLAR = {
            0xFF657B83, 0xFF859900, 0xFF268BD2, 0xFFB58900, 0xFF2AA198, 0xFF93A1A1,
            0xFFD33682, 0xFF657B83, 0xFF268BD2, 0xFFB58900, 0xFFCB4B16, 0xFFD33682,
            0xFF657B83, 0xFF268BD2, 0xFFB58900
    };
    public static final int[] PRESET_MAGENTA = {
            0xFFD8D0E8, 0xFFFF4FB8, 0xFF32C8FF, 0xFFFF9AD5, 0xFF9CD8FF, 0xFF7A6E8A,
            0xFFFF9AD5, 0xFFC8A6E8, 0xFF32C8FF, 0xFFFF4FB8, 0xFFFF9AD5, 0xFFFF8AE2,
            0xFFC8B6E8, 0xFF32C8FF, 0xFFFF4FB8
    };
    public static final int[] PRESET_MIDNIGHT = {
            0xFFC9D1D9, 0xFFFF7B72, 0xFF79C0FF, 0xFF79C0FF, 0xFFA5D6FF, 0xFF8B949E,
            0xFF79C0FF, 0xFFC9D1D9, 0xFFD2A8FF, 0xFFFFA657, 0xFFFFA657, 0xFFFFA657,
            0xFFC9D1D9, 0xFFD2A8FF, 0xFFFFA657
    };

    public final int[] colors = new int[TOK_COUNT];
    public final boolean[] bold = new boolean[TOK_COUNT];
    public final boolean[] italic = new boolean[TOK_COUNT];

    public int bg, gutterBg, gutterText, curLine, selection, caret, problem, statusBg, statusText;
    /** 缩进参考线：第 1 层颜色 → 最深层的颜色（按层数线性过渡）。 */
    public int guideA = 0xFF32C8FF, guideB = 0xFFFF0000;
    public boolean showGuides = true;
    public float fontSize = 15f;
    public float lineSpacing = 4f;
    public int tabSize = 4;
    public boolean showLineNumbers = true;
    public boolean autoIndent = true;
    public boolean autoPair = true;
    public String fontFamily = "monospace";
    public String themeName = "深色";

    private static final String PREF = "pyedit_theme";

    /** 每次 save 自增：设置子页保存后，返回上层页面时据此重载，避免用旧主题覆盖。 */
    public static int saveCount = 0;

    public Theme() {
        applyPreset(PRESET_DARK, "深色");
        bg = 0xFF282C34;
        gutterBg = 0xFF21252B;
        gutterText = 0xFF4B5263;
        curLine = 0xFF2C313A;
        selection = 0xFF3E4451;
        caret = 0xFF528BFF;
        problem = 0xFFE06C75;
        statusBg = 0xFF21252B;
        statusText = 0xFF9DA5B4;
        italic[TOK_COMMENT] = true;
        italic[TOK_SELF] = true;
        bold[TOK_CLASS] = true;
    }

    public void applyPreset(int[] pal, String name) {
        System.arraycopy(pal, 0, colors, 0, TOK_COUNT);
        for (int i = 0; i < TOK_COUNT; i++) {
            bold[i] = false;
            italic[i] = false;
        }
        themeName = name;
    }

    public void preset(String which) {
        switch (which) {
            case "light":
                applyPreset(PRESET_LIGHT, "浅色");
                bg = 0xFFFFFFFF; gutterBg = 0xFFF6F8FA; gutterText = 0xFFB0B7C0;
                curLine = 0xFFF2F5F8; selection = 0xFFCFE3FB; caret = 0xFF044289;
                problem = 0xFFD73A49; statusBg = 0xFFF6F8FA; statusText = 0xFF57606A;
                italic[TOK_COMMENT] = true; italic[TOK_SELF] = true; bold[TOK_CLASS] = true;
                break;
            case "monokai":
                applyPreset(PRESET_MONOKAI, "Monokai");
                bg = 0xFF272822; gutterBg = 0xFF1E1F1A; gutterText = 0xFF75715E;
                curLine = 0xFF3E3D32; selection = 0xFF49483E; caret = 0xFFF8F8F0;
                problem = 0xFFF92672; statusBg = 0xFF1E1F1A; statusText = 0xFFCCC5B0;
                italic[TOK_COMMENT] = true; italic[TOK_SELF] = true; italic[TOK_BUILTIN] = true;
                break;
            case "solar":
                applyPreset(PRESET_SOLAR, "Solarized");
                bg = 0xFFFDF6E3; gutterBg = 0xFFEEE8D5; gutterText = 0xFFB0AA92;
                curLine = 0xFFF5EFDC; selection = 0xFFE3DDBC; caret = 0xFF268BD2;
                problem = 0xFFDC322F; statusBg = 0xFFEEE8D5; statusText = 0xFF586E75;
                italic[TOK_COMMENT] = true; italic[TOK_SELF] = true;
                break;
            case "magenta":
                applyPreset(PRESET_MAGENTA, "品红·浅蓝");
                bg = 0xFF171022; gutterBg = 0xFF120D1B; gutterText = 0xFF5E5470;
                curLine = 0xFF241A33; selection = 0xFF3C2A52; caret = 0xFF32C8FF;
                problem = 0xFFFF5C8A; statusBg = 0xFF120D1B; statusText = 0xFF9C90B0;
                italic[TOK_COMMENT] = true; italic[TOK_SELF] = true; bold[TOK_CLASS] = true;
                break;
            case "midnight":
                applyPreset(PRESET_MIDNIGHT, "午夜蓝");
                bg = 0xFF0D1117; gutterBg = 0xFF010409; gutterText = 0xFF484F58;
                curLine = 0xFF161B22; selection = 0xFF1F3A5F; caret = 0xFF58A6FF;
                problem = 0xFFFF7B72; statusBg = 0xFF010409; statusText = 0xFF8B949E;
                italic[TOK_COMMENT] = true; bold[TOK_CLASS] = true;
                break;
            default:
                Theme d = new Theme();
                copyFrom(d);
                break;
        }
    }

    public void copyFrom(Theme o) {
        System.arraycopy(o.colors, 0, colors, 0, TOK_COUNT);
        System.arraycopy(o.bold, 0, bold, 0, TOK_COUNT);
        System.arraycopy(o.italic, 0, italic, 0, TOK_COUNT);
        bg = o.bg; gutterBg = o.gutterBg; gutterText = o.gutterText; curLine = o.curLine;
        selection = o.selection; caret = o.caret; problem = o.problem;
        statusBg = o.statusBg; statusText = o.statusText;
        guideA = o.guideA; guideB = o.guideB; showGuides = o.showGuides;
        fontSize = o.fontSize; lineSpacing = o.lineSpacing; tabSize = o.tabSize;
        showLineNumbers = o.showLineNumbers; autoIndent = o.autoIndent; autoPair = o.autoPair;
        fontFamily = o.fontFamily; themeName = o.themeName;
    }

    /** 第 level 层（1 起）参考线颜色：在 guideA..guideB 之间按 maxLevel 过渡。 */
    public int guideColor(int level, int maxLevel) {
        float t = maxLevel <= 1 ? 0f
                : (float) (level - 1) / (float) Math.max(1, maxLevel - 1);
        int r = (int) ((guideA >> 16 & 0xFF) + ((guideB >> 16 & 0xFF) - (guideA >> 16 & 0xFF)) * t);
        int g = (int) ((guideA >> 8 & 0xFF) + ((guideB >> 8 & 0xFF) - (guideA >> 8 & 0xFF)) * t);
        int b = (int) ((guideA & 0xFF) + ((guideB & 0xFF) - (guideA & 0xFF)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    // ---------------------------------------------------------------- persist
    public void save(Context ctx) {
        SharedPreferences.Editor e = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit();
        StringBuilder cs = new StringBuilder(), bs = new StringBuilder(), is = new StringBuilder();
        for (int i = 0; i < TOK_COUNT; i++) {
            if (i > 0) { cs.append(','); bs.append(','); is.append(','); }
            cs.append(String.format("%06X", colors[i] & 0xFFFFFF));
            bs.append(bold[i] ? 1 : 0);
            is.append(italic[i] ? 1 : 0);
        }
        e.putString("colors", cs.toString());
        e.putString("bold", bs.toString());
        e.putString("italic", is.toString());
        e.putInt("bg", bg);
        e.putInt("gutterBg", gutterBg);
        e.putInt("gutterText", gutterText);
        e.putInt("curLine", curLine);
        e.putInt("selection", selection);
        e.putInt("caret", caret);
        e.putInt("problem", problem);
        e.putInt("statusBg", statusBg);
        e.putInt("statusText", statusText);
        e.putInt("guideA", guideA);
        e.putInt("guideB", guideB);
        e.putBoolean("showGuides", showGuides);
        e.putFloat("fontSize", fontSize);
        e.putFloat("lineSpacing", lineSpacing);
        e.putInt("tabSize", tabSize);
        e.putBoolean("showLineNumbers", showLineNumbers);
        e.putBoolean("autoIndent", autoIndent);
        e.putBoolean("autoPair", autoPair);
        e.putString("fontFamily", fontFamily);
        e.putString("themeName", themeName);
        e.apply();
        saveCount++;
    }

    public static Theme load(Context ctx) {
        Theme t = new Theme();
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.contains("colors")) return t;
        try {
            String[] cs = p.getString("colors", "").split(",");
            String[] bs = p.getString("bold", "").split(",");
            String[] is = p.getString("italic", "").split(",");
            for (int i = 0; i < TOK_COUNT && i < cs.length; i++) {
                int raw = (int) Long.parseLong(cs[i].trim(), 16);
                t.colors[i] = 0xFF000000 | (raw & 0xFFFFFF);
                t.bold[i] = bs.length > i && bs[i].equals("1");
                t.italic[i] = is.length > i && is[i].equals("1");
            }
            t.bg = 0xFF000000 | (p.getInt("bg", t.bg) & 0xFFFFFF);
            t.gutterBg = 0xFF000000 | (p.getInt("gutterBg", t.gutterBg) & 0xFFFFFF);
            t.gutterText = 0xFF000000 | (p.getInt("gutterText", t.gutterText) & 0xFFFFFF);
            t.curLine = 0xFF000000 | (p.getInt("curLine", t.curLine) & 0xFFFFFF);
            t.selection = 0xFF000000 | (p.getInt("selection", t.selection) & 0xFFFFFF);
            t.caret = 0xFF000000 | (p.getInt("caret", t.caret) & 0xFFFFFF);
            t.problem = 0xFF000000 | (p.getInt("problem", t.problem) & 0xFFFFFF);
            t.statusBg = 0xFF000000 | (p.getInt("statusBg", t.statusBg) & 0xFFFFFF);
            t.statusText = 0xFF000000 | (p.getInt("statusText", t.statusText) & 0xFFFFFF);
            t.guideA = 0xFF000000 | (p.getInt("guideA", t.guideA) & 0xFFFFFF);
            t.guideB = 0xFF000000 | (p.getInt("guideB", t.guideB) & 0xFFFFFF);
            t.showGuides = p.getBoolean("showGuides", true);
            t.fontSize = p.getFloat("fontSize", t.fontSize);
            t.lineSpacing = p.getFloat("lineSpacing", t.lineSpacing);
            t.tabSize = p.getInt("tabSize", t.tabSize);
            t.showLineNumbers = p.getBoolean("showLineNumbers", true);
            t.autoIndent = p.getBoolean("autoIndent", true);
            t.autoPair = p.getBoolean("autoPair", true);
            t.fontFamily = p.getString("fontFamily", "monospace");
            t.themeName = p.getString("themeName", t.themeName);
        } catch (Exception ignored) {
        }
        return t;
    }

    private static Typeface cached;
    private static String cachedName;

    public Typeface typeface() {
        String f = fontFamily == null ? "monospace" : fontFamily;
        if (f.equals(cachedName) && cached != null) return cached;
        Typeface tf;
        try {
            if (f.startsWith("file:")) {
                tf = Typeface.createFromFile(f.substring(5));
            } else {
                tf = Typeface.create(f, Typeface.NORMAL);
            }
        } catch (Throwable e) {
            tf = Typeface.MONOSPACE;
        }
        if (tf == null) tf = Typeface.MONOSPACE;
        cached = tf;
        cachedName = f;
        return cached;
    }
}
