package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

/** Live preview of the current colours / font, rendered by the same native engine. */
class PreviewView extends View {
    private final long doc = Native.nativeCreate();
    private Theme theme;
    private final Paint[] paints = new Paint[Theme.TOK_COUNT];
    private final Paint bgP = new Paint();
    private final Paint gutterBgP = new Paint();
    private final Paint gutterP = new Paint();
    private int lineHeight;
    private float charW, spaceW, tabW;
    private int fmTop;
    private boolean mono = true;
    private final Paint basePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guideP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int sampleMaxLv = 1;
    private float[] wb = new float[256];
    private int[] runBuf = new int[4 * 256];
    private float[] off = new float[256];
    private final float density;

    private static final String SAMPLE =
            "import math\n"
                    + "\n"
                    + "class Circle:\n"
                    + "    def __init__(self, r=1.0):\n"
                    + "        self.r = r\n"
                    + "        self.name = \"圆\"\n"
                    + "\n"
                    + "    def area(self):  # 面积\n"
                    + "        return math.pi * self.r ** 2\n"
                    + "\n"
                    + "c = Circle(2)\n"
                    + "print(c.area())\n";

    PreviewView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        for (int i = 0; i < Theme.TOK_COUNT; i++) paints[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
        gutterP.setTextAlign(Paint.Align.RIGHT);
        Native.nativeSetText(doc, SAMPLE);
    }

    void setTheme(Theme t) {
        theme = t;
        rebuild();
        invalidate();
    }

    private void rebuild() {
        if (theme == null) return;
        Typeface tf = theme.typeface();
        float size = theme.fontSize * getResources().getDisplayMetrics().scaledDensity * 0.92f;
        for (int i = 0; i < Theme.TOK_COUNT; i++) {
            Paint p = paints[i];
            p.setTypeface(theme.bold[i] || theme.italic[i]
                    ? Typeface.create(tf, (theme.bold[i] ? Typeface.BOLD : Typeface.NORMAL)
                    | (theme.italic[i] ? Typeface.ITALIC : Typeface.NORMAL)) : tf);
            p.setTextSize(size);
            p.setColor(theme.colors[i]);
        }
        Paint base = basePaint;
        base.setTypeface(tf);
        base.setTextSize(size);
        Paint.FontMetricsInt fm = base.getFontMetricsInt();
        fmTop = fm.top;
        lineHeight = (int) (fm.bottom - fm.top + theme.lineSpacing * density * 0.7f);
        charW = base.measureText("M");
        spaceW = base.measureText(" ");
        tabW = spaceW * theme.tabSize;
        mono = !(theme.fontFamily != null && theme.fontFamily.startsWith("file:"));
        bgP.setColor(theme.bg);
        gutterBgP.setColor(theme.gutterBg);
        gutterP.setColor(theme.gutterText);
        gutterP.setTypeface(tf);
        gutterP.setTextSize(size);
        guideP.setStyle(Paint.Style.STROKE);
        guideP.setStrokeWidth(Math.max(1f, density));
        int mx = 1;
        for (String ln : SAMPLE.split("\n", -1)) {
            int ind = 0;
            while (ind < ln.length() && (ln.charAt(ind) == ' ' || ln.charAt(ind) == '\t')) ind++;
            mx = Math.max(mx, ind / Math.max(1, theme.tabSize));
        }
        sampleMaxLv = mx;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (theme == null) return;
        int w = getWidth(), h = getHeight();
        canvas.drawColor(theme.bg);
        int gutterW = (int) (gutterP.measureText("88") + 10 * density);
        canvas.drawRect(0, 0, gutterW, h, gutterBgP);
        int first = 0;
        int last = Math.min(Native.nativeLineCount(doc) - 1, h / lineHeight);
        int cnt = Native.nativeFillRuns(doc, first, last, runBuf);
        int idx = 0;
        for (int i = first; i <= last; i++) {
            String s = Native.nativeLineText(doc, i);
            int len = s.length();
            if (off.length < len + 2) off = new float[len + 2];
            off[0] = 0;
            if (len > 0) {
                if (wb.length < len) wb = new float[len + 32];
                basePaint.getTextWidths(s, 0, len, wb);
                float acc = 0;
                for (int k = 0; k < len; k++) {
                    float adv = s.charAt(k) == '\t' ? tabW : wb[k];
                    if (adv < 0) adv = 0;
                    acc += adv;
                    off[k + 1] = acc;
                }
            }
            float yTop = (float) i * lineHeight + 4 * density;
            float baseline = yTop - fmTop;
            canvas.drawText(String.valueOf(i + 1), gutterW - 4 * density,
                    baseline - fmTop * 0.02f, gutterP);
            float x0 = gutterW + 6 * density;
            if (theme.showGuides) {
                int ind = 0;
                while (ind < len && (s.charAt(ind) == ' ' || s.charAt(ind) == '\t')) ind++;
                int levels = ind / Math.max(1, theme.tabSize);
                for (int lv = 0; lv < levels; lv++) {
                    int ch = Math.min(lv * Math.max(1, theme.tabSize), len);
                    guideP.setColor(theme.guideColor(lv + 1, sampleMaxLv));
                    float gx = x0 + off[ch];
                    canvas.drawLine(gx, yTop, gx, yTop + lineHeight, guideP);
                }
            }
            while (idx < cnt && runBuf[idx] == i) {
                int st = runBuf[idx + 1], en = runBuf[idx + 2], type = runBuf[idx + 3];
                if (en > len) en = len;
                if (en > st) canvas.drawText(s, st, en, x0 + off[st], baseline, paints[type]);
                idx += 4;
            }
        }
    }
}
