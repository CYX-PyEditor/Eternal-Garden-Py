package com.yhhy.pyeditor;

import android.app.Application;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Writes crash traces to the app's external files dir so they can be inspected. */
public class App extends Application {

    public static File dir;

    @Override
    public void onCreate() {
        super.onCreate();
        Lang.init(this);
        try {
            dir = getExternalFilesDir(null);
        } catch (Throwable ignored) {
        }
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                if (dir == null) dir = getExternalFilesDir(null);
                if (dir != null) {
                    File f = new File(dir, "crash.txt");
                    FileWriter w = new FileWriter(f, false);
                    w.write(stamp() + " thread=" + t.getName() + "\n");
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    w.write(sw.toString());
                    w.close();
                }
            } catch (Throwable ignored) {
            }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static String stamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }

    static void note(String name, String text) {
        try {
            File d = dir != null ? dir : null;
            if (d == null) return;
            FileWriter w = new FileWriter(new File(d, name), false);
            w.write(stamp() + " " + text);
            w.close();
        } catch (Throwable ignored) {
        }
    }
}
