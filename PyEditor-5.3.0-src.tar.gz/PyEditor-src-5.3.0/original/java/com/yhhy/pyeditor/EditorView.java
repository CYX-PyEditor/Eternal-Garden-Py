package com.yhhy.pyeditor;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.ActionMode;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.text.TextUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.OverScroller;

import java.util.ArrayList;
import java.util.Arrays;

/** Custom drawn code editor view backed by the native engine. */
public class EditorView extends View {

    public interface Listener {
        void onEditorStateChanged();   // cursor / dirty / problem count
        void onEditorTextChanged();
        void onRequestSave();
    }

    // ---------------------------------------------------------------- state
    private long doc;
    private Theme theme = new Theme();
    private Listener listener;

    private final Paint bgPaint = new Paint();
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint[] tokPaint = new Paint[Theme.TOK_COUNT];
    private final Paint gutterBgPaint = new Paint();
    private final Paint gutterTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gutterCurPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gutterLinePaint = new Paint();
    private final Paint curLinePaint = new Paint();
    private final Paint selPaint = new Paint();
    private final Paint caretPaint = new Paint();
    private final Paint problemPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint underlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final float density;
    private int lineHeight;
    private float charW;
    private float spaceW;
    private int fmTop, fmBottom;
    private int gutterW;
    private float textPad;
    private int padTop;
    private float tabW;
    private int[] lineMaxLv = new int[0];

    private float scrollX, scrollY;
    private int maxScrollX, maxScrollY;
    private final OverScroller scroller;
    private VelocityTracker vt;
    private final int touchSlop;
    private boolean dragging, moved, selecting, longFired;
    private float downX, downY, lastX, lastY;
    private EdgeSwipeListener edgeSwipeListener;
    private boolean edgeSwipe;

    /** 行首右滑：progress 0→1 用于抽屉跟手，end 决定展开/收回。 */
    public interface EdgeSwipeListener {
        void onProgress(float progress);

        void onEnd(boolean open);
    }
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable longPressRun = this::fireLongPress;

    // buffers
    private int[] runBuf = new int[4 * 512];
    private int[] lineRunBuf = new int[4 * 64];
    private float[][] offCache;
    private int[] offCacheLen;
    private float[] widthBuf = new float[512];
    private float maxSeenW;
    private int lastCheckRev = -1;

    // ---- 折叠
    private final java.util.HashMap<Integer, Integer> foldMap = new java.util.HashMap<>();
    private final java.util.HashSet<Integer> folded = new java.util.HashSet<>();
    private int[] foldBuf = new int[3 * 64];
    private int foldRev = -1;
    private int[] rowLine = new int[0];
    private int[] lineRow = new int[0];
    private int rowCount = 0;
    private boolean rowsDirty = true;
    private long lastTapTime = 0;
    private float lastTapX = 0, lastTapY = 0;
    private final Paint foldPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint annPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ---- 行尾标注（函数被引用次数 / 类属性方法数 / 字面量元素类型）
    private final java.util.HashMap<Integer, String> annText = new java.util.HashMap<>();
    private final java.util.HashMap<Integer, String> annClick = new java.util.HashMap<>();
    private float[] annX1 = new float[0];
    private float[] annX2 = new float[0];
    private AnnListener annListener;

    /** 点击行尾标注（目前只有「被使用 N 次」）时回调，参数是要查找的名字。 */
    public interface AnnListener {
        void onAnnotationClick(String name);
    }

    public void setAnnotationListener(AnnListener l) {
        annListener = l;
    }

    /** 参考线颜色已移到 Theme（guideA → guideB 渐变），可在设置 → 个性化里改。 */
    private boolean guidesOn() {
        return theme.showGuides;
    }
    private boolean checkEnabled = true;
    /** 只有 .py 才折叠 / 高亮 / 语法检查 / 补全；其它文本按纯文本显示。 */
    private boolean pyMode = true;
    private String[] lineCache;
    private int[] lineCacheVer;
    private int[] offCacheVer;
    private int cachedRev = -1;
    private int docLines;
    private int[] probBuf = new int[5 * 64];
    private String[] numCache = new String[0];
    private int probCount = -1;
    private final Runnable checkRun = this::runCheckNow;
    private boolean caretOn = true;
    private final Runnable blinkRun = this::blinkTick;

    // composing (IME)
    private int compLine = -1, compCol = -1, compLen = 0;

    private ActionMode actionMode;
    private static final int ID_COPY = 1, ID_CUT = 2, ID_PASTE = 3, ID_ALL = 4, ID_UNDO = 5, ID_REDO = 6;
    private final ActionMode.Callback actionCb = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            menu.add(0, ID_COPY, 0, Lang.s("复制"));
            menu.add(0, ID_CUT, 1, Lang.s("剪切"));
            menu.add(0, ID_PASTE, 2, Lang.s("粘贴"));
            menu.add(0, ID_ALL, 3, Lang.s("全选"));
            menu.add(0, ID_UNDO, 4, Lang.s("撤销"));
            menu.add(0, ID_REDO, 5, Lang.s("重做"));
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            boolean sel = Native.nativeHasSelection(doc);
            MenuItem c = menu.findItem(ID_COPY);
            MenuItem x = menu.findItem(ID_CUT);
            if (c != null) c.setVisible(sel);
            if (x != null) x.setVisible(sel);
            return true;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case ID_COPY:
                    copySelection();
                    mode.finish();
                    return true;
                case ID_CUT:
                    cutSelection();
                    mode.finish();
                    return true;
                case ID_PASTE:
                    paste();
                    mode.finish();
                    return true;
                case ID_ALL:
                    selectAllText();
                    mode.invalidate();
                    return true;
                case ID_UNDO:
                    undo();
                    return true;
                case ID_REDO:
                    redo();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            actionMode = null;
        }
    };

    // completion
    private CompletionPopup popup;
    private boolean suppressCompletion;

    // ---------------------------------------------------------------- setup
    public EditorView(Context ctx) {
        super(ctx);
        density = getResources().getDisplayMetrics().density;
        scroller = new OverScroller(ctx);
        touchSlop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        textPad = dp(8);
        padTop = (int) dp(4);
        for (int i = 0; i < Theme.TOK_COUNT; i++) {
            tokPaint[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
            tokPaint[i].setTypeface(Typeface.MONOSPACE);
        }
        gutterTextPaint.setTextAlign(Paint.Align.RIGHT);
        problemPaint.setStyle(Paint.Style.STROKE);
        problemPaint.setStrokeWidth(dp(1.3f));
        underlinePaint.setStyle(Paint.Style.STROKE);
        underlinePaint.setStrokeWidth(dp(1.2f));
        setFocusable(true);
        setFocusableInTouchMode(true);
        setClickable(true);
        setLongClickable(true);
        doc = Native.nativeCreate();
        applyThemeVars();
        setBackgroundColor(theme.bg);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public long docHandle() {
        return doc;
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ---------------------------------------------------------------- theme
    public Theme theme() {
        return theme;
    }

    public void setTheme(Theme t, boolean persist) {
        theme = t;
        applyThemeVars();
        resetMetricsCaches();
        setBackgroundColor(theme.bg);
        if (persist) Native.nativeSetOptions(doc, theme.tabSize, theme.autoIndent, theme.autoPair);
        hideCompletion();
        requestLayout();
        invalidate();
    }

    private void applyThemeVars() {
        Typeface tf = theme.typeface();
        float size = theme.fontSize * getResources().getDisplayMetrics().scaledDensity;
        textPaint.setTypeface(tf);
        textPaint.setTextSize(size);
        textPaint.setColor(theme.colors[Theme.TOK_TEXT]);
        Paint.FontMetricsInt fm = textPaint.getFontMetricsInt();
        fmTop = fm.top;
        fmBottom = fm.bottom;
        lineHeight = (int) (fmBottom - fmTop + theme.lineSpacing * density);
        if (lineHeight < 4) lineHeight = 4;
        spaceW = textPaint.measureText(" ");
        charW = textPaint.measureText("M");
        if (charW <= 0) charW = spaceW;
        tabW = spaceW * theme.tabSize;
        for (int i = 0; i < Theme.TOK_COUNT; i++) {
            Paint p = tokPaint[i];
            p.setTypeface(theme.bold[i] || theme.italic[i]
                    ? Typeface.create(tf, (theme.bold[i] ? Typeface.BOLD : Typeface.NORMAL)
                    | (theme.italic[i] ? Typeface.ITALIC : Typeface.NORMAL))
                    : tf);
            p.setTextSize(size);
            p.setColor(theme.colors[i]);
        }
        bgPaint.setColor(theme.bg);
        gutterBgPaint.setColor(theme.gutterBg);
        gutterTextPaint.setColor(theme.gutterText);
        gutterLinePaint.setColor(blend(theme.bg, theme.gutterText, 0.28f));
        gutterLinePaint.setStrokeWidth(Math.max(1f, dp(1)));
        gutterTextPaint.setTypeface(tf);
        gutterTextPaint.setTextSize(size * 0.86f);
        gutterCurPaint.setColor(theme.colors[Theme.TOK_TEXT]);
        gutterCurPaint.setTypeface(Typeface.create(tf, Typeface.BOLD));
        gutterCurPaint.setTextSize(size * 0.86f);
        gutterCurPaint.setTextAlign(Paint.Align.RIGHT);
        curLinePaint.setColor(theme.curLine);
        selPaint.setColor(theme.selection);
        caretPaint.setColor(theme.caret);
        problemPaint.setColor(theme.problem);
        underlinePaint.setColor(theme.caret);
        guidePaint.setStyle(Paint.Style.STROKE);
        guidePaint.setStrokeWidth(dp(1));
        annPaint.setColor(blend(theme.colors[Theme.TOK_COMMENT], theme.bg, 0.35f));
        annPaint.setTextSize(size * 0.9f);
        annPaint.setTypeface(tf);
        foldPaint.setColor(theme.colors[Theme.TOK_COMMENT]);
        foldPaint.setTextSize(size);
        guidePaint.setStrokeWidth(Math.max(1f, dp(1)));
        foldPaint.setTypeface(theme.italic[Theme.TOK_COMMENT]
                ? Typeface.create(tf, Typeface.ITALIC) : tf);
        updateGutterWidth();
    }

    private void updateGutterWidth() {
        int n = Math.max(2, String.valueOf(Math.max(1, Native.nativeLineCount(doc))).length());
        String s = "";
        for (int i = 0; i < n; i++) s += "8";
        gutterW = theme.showLineNumbers ? (int) (gutterTextPaint.measureText(s) + dp(16)) : 0;
        textPad = dp(theme.showLineNumbers ? 8 : 10);
    }

    private float dp(float v) {
        return v * density;
    }

    private static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg2 = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg2 - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------------------------------------------------------------- text
    public void setDocumentText(String text, boolean resetScroll) {
        Native.nativeSetText(doc, text);
        Native.nativeSetOptions(doc, theme.tabSize, theme.autoIndent, theme.autoPair);
        resetMetricsCaches();
        probBuf = new int[5 * 64];
        probCount = -1;
        if (resetScroll) {
            scrollX = 0;
            scrollY = 0;
        }
        updateGutterWidth();
        scheduleCheck(0);
        invalidate();
        notifyState();
    }

    public String getText() {
        return Native.nativeGetText(doc);
    }

    public boolean isDirty() {
        return Native.nativeIsDirty(doc);
    }

    public void markClean() {
        Native.nativeMarkClean(doc);
        notifyState();
    }

    private void syncRev() {
        int r = Native.nativeRevision(doc);
        int nl = Native.nativeLineCount(doc);
        if (r != cachedRev) {
            foldText.clear();
            rowsDirty = true;
        }
        if (nl != docLines) {
            // line indices shifted: per-line versions are no longer comparable
            docLines = nl;
            lineCache = null;
            lineCacheVer = null;
            offCache = null;
            offCacheLen = null;
            offCacheVer = null;
            numCache = new String[0];
        }
        if (r != cachedRev) {
            cachedRev = r;
            maxSeenW = 0;
        }
    }

    private void resetMetricsCaches() {
        lineCache = null;
        lineCacheVer = null;
        offCache = null;
        offCacheLen = null;
        offCacheVer = null;
        numCache = new String[0];
        maxSeenW = 0;
        cachedRev = Native.nativeRevision(doc);
        docLines = Native.nativeLineCount(doc);
    }

    private String line(int i) {
        if (i < 0) return "";
        if (i >= docLines) {
            docLines = Native.nativeLineCount(doc);
            if (i >= docLines) return "";
        }
        if (lineCache == null || lineCache.length <= i) {
            int cap = Math.max(docLines + 64, i + 64);
            String[] a = new String[cap];
            int[] b = new int[cap];
            java.util.Arrays.fill(b, -1);
            if (lineCache != null) {
                System.arraycopy(lineCache, 0, a, 0, lineCache.length);
                System.arraycopy(lineCacheVer, 0, b, 0, Math.min(lineCacheVer.length, cap));
            }
            lineCache = a;
            lineCacheVer = b;
        }
        int ver = Native.nativeLineVersion(doc, i);
        if (lineCache[i] == null || lineCacheVer[i] != ver) {
            lineCache[i] = Native.nativeLineText(doc, i);
            lineCacheVer[i] = ver;
        }
        return lineCache[i];
    }

    // ---------------------------------------------------------------- draw
    @Override
    protected void onDraw(Canvas canvas) {
        if (doc == 0) return;
        syncRev();
        int n = Native.nativeLineCount(doc);
        int h = getHeight();
        int w = getWidth();
        updateGutterWidth();

        int curLine = Native.nativeCursorLine(doc);
        int curCol = Native.nativeCursorCol(doc);
        boolean hasSel = Native.nativeHasSelection(doc);
        int aL = Native.nativeAnchorLine(doc), aC = Native.nativeAnchorCol(doc);

        ensureRows();
        int totalH = rowCount * lineHeight + padTop * 2;
        maxScrollY = Math.max(0, totalH - h);
        float contentW = gutterW + textPad * 2
                + Math.max(maxSeenW, Native.nativeMaxLineLength(doc) * charW) + charW * 3;
        maxScrollX = Math.max(0, (int) (contentW - w));
        if (scrollY > maxScrollY) scrollY = maxScrollY;
        if (scrollY < 0) scrollY = 0;
        if (scrollX > maxScrollX) scrollX = maxScrollX;
        if (scrollX < 0) scrollX = 0;

        canvas.drawColor(theme.bg);
        float textLeft = gutterW + textPad - scrollX;
        float fmTopF = fmTop;

        // current line highlight
        int curRow = rowOf(curLine);
        if (curRow >= 0) {
            float y = padTop + curRow * lineHeight - scrollY;
            canvas.drawRect(gutterW, y, w, y + lineHeight, curLinePaint);
        }
        // gutter background
        if (theme.showLineNumbers) {
            canvas.drawRect(0, 0, gutterW, h, gutterBgPaint);
        }

        int first = Math.max(0, (int) ((scrollY - padTop) / lineHeight));
        int last = Math.min(rowCount - 1, (int) ((scrollY + h) / lineHeight) + 1);
        if (last < first) return;

        int cnt = 0;
        if (pyMode) {
            int need = 4 * (last - first + 2) * 14;
            if (runBuf.length < need) runBuf = new int[need];
            while (true) {
                int fromLine = rowLine[first];
                int toLine = rowLine[last];
                cnt = Native.nativeFillRuns(doc, fromLine, toLine, runBuf);
                if (cnt < runBuf.length) break;
                runBuf = new int[runBuf.length * 2];
            }
        }

        // ---- 正文区：裁剪到行号栏右侧，横向滚动时文字不会盖住行号
        canvas.save();
        canvas.clipRect(gutterW, 0, w, h);

        int idx = 0;
        for (int row = first; row <= last; row++) {
            int i = rowLine[row];
            if (i < 0 || i >= n) continue;
            String s = line(i);
            int len = s.length();
            int ver = Native.nativeLineVersion(doc, i);
            float[] off = offCached(i, len, ver);
            if (off == null) {
                off = new float[len + 2];
                buildOffsets(s, len, runBuf, cnt, idx, i, off);
                storeOff(i, len, off, ver);
            }
            if (off[len] > maxSeenW) maxSeenW = off[len];
            // 折叠隐藏的行不会进入行循环，先把它们的 token 记录跳过
            while (idx < cnt && runBuf[idx] < i) idx += 4;

            float yTop = padTop + row * lineHeight - scrollY;
            float baseline = yTop - fmTopF;
            float x0 = textLeft;

            // selection
            if (hasSel) {
                int sl = aL, sc = aC, el = curLine, ec = curCol;
                if (sl > el || (sl == el && sc > ec)) {
                    int t = sl; sl = el; el = t;
                    t = sc; sc = ec; ec = t;
                }
                if (i >= sl && i <= el) {
                    int from = (i == sl) ? Math.min(sc, len) : 0;
                    int to = (i == el) ? Math.min(ec, len) : len;
                    if (to > from) {
                        float sx = x0 + off[from];
                        float ex = x0 + off[to];
                        canvas.drawRect(sx, yTop, ex, yTop + lineHeight, selPaint);
                    }
                }
            }

            if (folded.contains(i) && foldMap.containsKey(i)) {
                if (off[len] > maxSeenW) maxSeenW = off[len];
                // 摘要保持原行缩进，并按 token 上色
                float xs = x0 + off[Math.min(lineIndent(s), len)];
                canvas.drawText("\u25B8 ", xs, baseline, foldPaint);
                xs += foldPaint.measureText("\u25B8 ");
                String sum = foldSummary(i);
                for (String seg : sum.split(" ")) {
                    if (seg.isEmpty()) continue;
                    Paint segPaint;
                    if (seg.equals("...")) {
                        segPaint = foldPaint;
                    } else if (FOLD_HDR.contains(seg) || seg.equals("import")) {
                        segPaint = tokPaint[Theme.TOK_KEYWORD];
                    } else {
                        segPaint = tokPaint[Theme.TOK_DEF];
                    }
                    canvas.drawText(seg + " ", xs, baseline, segPaint);
                    xs += segPaint.measureText(seg + " ");
                }
                while (idx < cnt && runBuf[idx] == i) idx += 4;
                continue;
            }

            // 缩进参考线（彩虹）——空行只有在其下方还有代码时才画
            if (guidesOn()) {
                boolean blankLine = s.trim().isEmpty();
                int indent = 0;
                while (indent < s.length() && (s.charAt(indent) == ' ' || s.charAt(indent) == '\t')) indent++;
                if (blankLine) {
                    int ni = nextCodeIndent(i);
                    indent = (ni > 0) ? ni : 0;
                }
                int tabCols = Math.max(1, theme.tabSize);
                int levels = indent / tabCols;
                for (int lv = 0; lv < levels; lv++) {
                    int chIdx = Math.min(lv * tabCols, len);
                    if (chIdx > 0 && s.charAt(chIdx - 1) == '\t') continue;
                    float gx = x0 + off[chIdx];
                    int mxLv = (i < lineMaxLv.length && lineMaxLv[i] > 1)
                            ? lineMaxLv[i] : Math.max(1, levels);
                    guidePaint.setColor(theme.guideColor(lv + 1, mxLv));
                    canvas.drawLine(gx, yTop, gx, yTop + lineHeight, guidePaint);
                }
            }

            // 行尾标注：函数引用次数 / 类成员数 / 容器元素类型
            if (pyMode) {
                String ann = annText.get(i);
                if (ann != null) {
                    float gap = Math.max(charW * 2, dp(12));
                    float ax = x0 + off[len] + gap;
                    canvas.drawText(ann, ax, baseline, annPaint);
                    float aw = annPaint.measureText(ann);
                    if (annX1.length <= i) {
                        int cap = Math.max(docLines, i) + 64;
                        float[] a1 = new float[cap];
                        float[] a2 = new float[cap];
                        java.util.Arrays.fill(a1, -1f);
                        if (annX1.length > 0) {
                            System.arraycopy(annX1, 0, a1, 0, annX1.length);
                            System.arraycopy(annX2, 0, a2, 0, annX2.length);
                        }
                        annX1 = a1;
                        annX2 = a2;
                    }
                    annX1[i] = annClick.containsKey(i) ? ax : -1f;
                    annX2[i] = ax + aw;
                    float rel = off[len] + gap + aw;
                    if (rel > maxSeenW) maxSeenW = rel;
                } else if (i < annX1.length) {
                    annX1[i] = -1f;
                }
            }

            // tokens
            if (!pyMode) {
                // 纯文本：整行统一颜色，不做词法着色
                drawRun(canvas, s, 0, len, x0, off, baseline, textPaint);
            } else {
                while (idx < cnt && runBuf[idx] == i) {
                    int st = runBuf[idx + 1], en = runBuf[idx + 2], type = runBuf[idx + 3];
                    if (st < 0) st = 0;
                    if (en > len) en = len;
                    if (en > st) {
                        drawRun(canvas, s, st, en, x0, off, baseline, tokPaint[type]);
                    }
                    idx += 4;
                }
            }


        }

        // problems
        drawProblems(canvas, first, last, textLeft);

        // composing underline
        if (compLine >= first && compLine <= last && compLen > 0) {
            String s = line(compLine);
            int len = s.length();
            if (compCol <= len) {
                float[] off = offsetsFor(compLine, s, len);
                int st = Math.min(compCol, len), en = Math.min(compCol + compLen, len);
                float y = padTop + Math.max(0, rowOf(compLine)) * lineHeight - scrollY
                        + lineHeight - dp(2);
                canvas.drawLine(textLeft + off[st], y, textLeft + off[en], y, underlinePaint);
            }
        }

        // caret
        if (isFocused() && caretOn) {
            String s = line(curLine);
            int len = s.length();
            int cc = Math.min(curCol, len);
            float[] off = offsetsFor(curLine, s, len);
            float cx = textLeft + off[cc];
            float yTop = padTop + Math.max(0, rowOf(curLine)) * lineHeight - scrollY;
            float hPad = Math.max(dp(1), lineHeight * 0.08f);
            canvas.drawRect(cx, yTop + hPad, cx + Math.max(dp(2), charW * 0.12f),
                    yTop + lineHeight - hPad, caretPaint);
        }

        canvas.restore();

        // ---- 行号：固定在左栏，不参与横向滚动
        if (theme.showLineNumbers) {
            canvas.drawRect(gutterW - Math.max(1f, dp(1)), 0, gutterW, h,
                    gutterLinePaint);
            Paint.FontMetricsInt gfm = gutterTextPaint.getFontMetricsInt();
            float shift = (lineHeight - (gfm.bottom - gfm.top)) / 2f - gfm.top;
            for (int row = first; row <= last; row++) {
                int i = rowLine[row];
                if (i < 0 || i >= n) continue;
                float by = padTop + row * lineHeight - scrollY + shift;
                canvas.drawText(lineNumber(i), gutterW - dp(7), by,
                        i == curLine ? gutterCurPaint : gutterTextPaint);
            }
        }
    }

    private final java.util.HashMap<Integer, String> foldText = new java.util.HashMap<>();

    private String foldSummary(int line) {
        ensureFolds();
        String v = foldText.get(line);
        return v == null ? "..." : v;
    }

    // ---------------------------------------------------------------- 折叠
    // 直接在 Java 里按缩进 + 子句算，避免 native 缓存的版本不同步
    private static final java.util.HashSet<String> FOLD_HDR = new java.util.HashSet<>(java.util.Arrays.asList(
            "def", "class", "if", "elif", "else", "for", "while", "try",
            "except", "finally", "with", "match", "case"));
    private static final java.util.HashSet<String> FOLD_CLAUSE = new java.util.HashSet<>(java.util.Arrays.asList(
            "else", "elif", "except", "finally", "case"));

    private static String stripComment(String s) {
        boolean inStr = false;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inStr) {
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') { inStr = true; q = c; }
            else if (c == '#') return s.substring(0, i);
        }
        return s;
    }

    private static int lineIndent(String s) {
        int k = 0;
        while (k < s.length() && (s.charAt(k) == ' ' || s.charAt(k) == '\t')) k++;
        return k;
    }

    /** 返回 {关键字, 是否子句} 或 null。 */
    private static String[] headerKw(String raw) {
        String s = stripComment(raw).trim();
        if (!s.endsWith(":")) return null;
        String body = s.substring(0, s.length() - 1).trim();
        if (body.isEmpty()) return null;
        int i = 0;
        while (i < body.length() && (Character.isLetterOrDigit(body.charAt(i)) || body.charAt(i) == '_')) i++;
        String kw = body.substring(0, i);
        if (kw.equals("async")) {
            int j = i;
            while (j < body.length() && body.charAt(j) == ' ') j++;
            int k = j;
            while (k < body.length() && (Character.isLetterOrDigit(body.charAt(k)) || body.charAt(k) == '_')) k++;
            kw = body.substring(j, k);
        }
        if (!FOLD_HDR.contains(kw)) return null;
        return new String[]{kw, FOLD_CLAUSE.contains(kw) ? "1" : "0"};
    }

    private static boolean isComment(String s) {
        return s.trim().startsWith("#");
    }

    /** 行首是不是块头关键字（不含 else/elif 这类子句）：用于多行函数签名的折叠。 */
    private static boolean startsBlockHeader(String raw) {
        String s = stripComment(raw).trim();
        if (s.isEmpty()) return false;
        int i = 0;
        while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
        String w = s.substring(0, i);
        if (w.equals("async")) {
            int j = i;
            while (j < s.length() && s.charAt(j) == ' ') j++;
            int k = j;
            while (k < s.length() && (Character.isLetterOrDigit(s.charAt(k)) || s.charAt(k) == '_')) k++;
            w = s.substring(j, k);
            return w.equals("def") || w.equals("for") || w.equals("with");
        }
        return w.equals("def") || w.equals("class") || w.equals("if") || w.equals("for")
                || w.equals("while") || w.equals("try") || w.equals("with") || w.equals("match");
    }

    /** 统计一行里的括号净深度（跳过字符串和注释），depth 为进入该行时的深度。 */
    private static int bracketDelta(String raw, int depth) {
        boolean inStr = false;
        char q = 0;
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '#') break;
            if (c == '\'' || c == '"') {
                inStr = true;
                q = c;
                continue;
            }
            if (c == '(' || c == '[' || c == '{') depth++;
            else if (c == ')' || c == ']' || c == '}') depth = Math.max(0, depth - 1);
        }
        return depth;
    }

    /** 多行函数签名的头部：def foo(\n a,\n): → 起止行；不是则返回 null。 */
    private static int[] multiLineHeader(String[] txt, int i, int n) {
        if (i < 0 || i >= n || !startsBlockHeader(txt[i])) return null;
        StringBuilder sb = new StringBuilder(stripComment(txt[i]));
        int depth = bracketDelta(txt[i], 0);
        int j = i;
        while (depth > 0 && j + 1 < n && j - i < 40) {
            j++;
            sb.append(' ').append(stripComment(txt[j]));
            depth = bracketDelta(txt[j], depth);
        }
        if (depth != 0 || j == i) return null;
        String joined = sb.toString().trim();
        if (!joined.endsWith(":")) return null;
        return new int[]{i, j};
    }

    private void ensureFolds() {
        if (doc == 0) return;
        syncRev();
        if (foldRev == cachedRev) return;
        foldMap.clear();
        foldText.clear();
        annText.clear();
        annClick.clear();
        if (!pyMode) {
            // 非 .py：不折叠（参考线也回到单层）
            int nn = Native.nativeLineCount(doc);
            if (lineMaxLv.length < nn) lineMaxLv = new int[nn];
            java.util.Arrays.fill(lineMaxLv, 0, Math.min(nn, lineMaxLv.length), 0);
            foldRev = cachedRev;
            rowsDirty = true;
            return;
        }
        java.util.HashMap<Integer, String> hdr = new java.util.HashMap<>();
        // 整篇一次 JNI 取回再拆行：以前每行一次 JNI + 后面还有 3 轮遍历，
        // 大文件按一次回车要几万次跨 JNI 调用，这是换行卡顿的主因。
        String all = Native.nativeGetText(doc);
        String[] txt = all.isEmpty() ? new String[]{""} : all.split("\n", -1);
        int n = txt.length;
        int[] ind = new int[n];
        boolean[] blank = new boolean[n];
        String[][] kw = new String[n][];
        int[] hdrEnd = new int[n];
        boolean[] imp = new boolean[n];
        for (int i = 0; i < n; i++) {
            ind[i] = lineIndent(txt[i]);
            blank[i] = txt[i].trim().isEmpty();
            kw[i] = blank[i] ? null : headerKw(txt[i]);
            hdrEnd[i] = i;
            String t = txt[i].trim();
            imp[i] = !blank[i] && (t.startsWith("import ") || t.startsWith("from "));
        }
        // 括号跨行的函数/类/if 头：把签名拼起来看是否以 ':' 结尾
        for (int i = 0; i < n; i++) {
            if (blank[i] || kw[i] != null || isComment(txt[i])) continue;
            int[] range = multiLineHeader(txt, i, n);
            if (range == null) continue;
            StringBuilder sb = new StringBuilder();
            for (int k = range[0]; k <= range[1]; k++) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(stripComment(txt[k]));
            }
            kw[i] = headerKw(sb.toString());
            if (kw[i] != null) hdrEnd[i] = range[1];
        }
        for (int i = 0; i < n; i++) {
            if (blank[i]) continue;
            if (imp[i]) {
                int j = i;
                while (j + 1 < n && imp[j + 1]) j++;
                if (j > i) foldMap.put(i, j);
                i = j;
                continue;
            }
            if (kw[i] == null || "1".equals(kw[i][1])) continue;
            int indent = ind[i];
            int j = hdrEnd[i] + 1;
            while (j < n && (blank[j] || isComment(txt[j]) || ind[j] > indent)) j++;
            int endLine = Math.min(j - 1, n - 1);
            StringBuilder sum = new StringBuilder(kw[i][0]);
            if ((kw[i][0].equals("def") || kw[i][0].equals("class"))) {
                String t = stripComment(txt[i]).trim();
                int p = t.indexOf(kw[i][0] + " ");   // async def 时不能取到 async 后面的 def
                if (p < 0) p = t.indexOf(' ');
                if (p >= 0) {
                    int s0 = p + kw[i][0].length() + 1;
                    int e = s0;
                    while (e < t.length() && t.charAt(e) != '(' && t.charAt(e) != ':' && t.charAt(e) != ' ') e++;
                    if (e > s0) sum.append(' ').append(t, s0, e);
                }
            }
            while (j < n && !blank[j] && !isComment(txt[j]) && ind[j] == indent
                    && kw[j] != null && "1".equals(kw[j][1])) {
                sum.append(" ... ").append(kw[j][0]);
                int k = j + 1;
                while (k < n && (blank[k] || isComment(txt[k]) || ind[k] > indent)) k++;
                endLine = Math.min(k - 1, n - 1);
                j = k;
            }
            while (endLine > i && blank[endLine]) endLine--;
            if (endLine > i) {
                foldMap.put(i, endLine);
                sum.append(" ...");
                hdr.put(i, sum.toString());
            }
        }
        // 多行 list / dict / tuple / set 字面量：折叠成 `xxx = dict[str, int] ...`
        // 单行字面量不折叠，只给行尾类型标注（`list[int, str]`）
        for (FoldScan.Block b : FoldScan.scan(txt)) {
            // 单行：行尾标注类型，同时也可折叠（折叠后这一行变成摘要）
            if (b.end == b.start) annText.put(b.start, b.typeText);
            if (!foldMap.containsKey(b.start)) {
                foldMap.put(b.start, b.end);
                hdr.put(b.start, b.summary);
            }
        }
        // 顶层自定义函数：被引用次数；顶层类：属性 / 方法个数
        for (SymbolStats.Sym sym : SymbolStats.scan(txt)) {
            if (sym.cls) {
                annText.put(sym.line, sym.attrs + Lang.s(" 个属性 · ") + sym.methods + Lang.s(" 个方法"));
            } else {
                annText.put(sym.line, Lang.s("被使用 ") + sym.uses + Lang.s(" 次"));
                annClick.put(sym.line, sym.name);
            }
        }
        for (Integer k : foldMap.keySet()) {
            if (!hdr.containsKey(k)) hdr.put(k, "import ...");
        }
        foldText.putAll(hdr);
        int tabc = Math.max(1, theme.tabSize);
        if (lineMaxLv.length < n) lineMaxLv = new int[n];
        java.util.Arrays.fill(lineMaxLv, 0, n, 0);
        // 先按块统一层级（块内所有行同色）
        for (java.util.Map.Entry<Integer, Integer> e : foldMap.entrySet()) {
            int s0 = e.getKey(), e0 = e.getValue();
            int mx = 1;
            for (int k = s0; k <= e0 && k < n; k++) {
                int lv = lineIndent(txt[k]) / tabc;
                if (lv > mx) mx = lv;
            }
            for (int k = s0; k <= e0 && k < n; k++) {
                if (lineMaxLv[k] < mx) lineMaxLv[k] = mx;
            }
        }
        // 空行没有代码，层级沿用上下最近的代码行，避免同一根竖线中途换色
        int last = 0;
        for (int k = 0; k < n; k++) {
            String t = txt[k];
            if (t.trim().isEmpty()) {
                if (lineMaxLv[k] == 0) lineMaxLv[k] = last;
            } else {
                last = lineMaxLv[k];
            }
        }
        int next = 0;
        for (int k = n - 1; k >= 0; k--) {
            String t = txt[k];
            if (t.trim().isEmpty()) {
                if (lineMaxLv[k] == 0) lineMaxLv[k] = next;
            } else {
                next = lineMaxLv[k];
            }
        }
        foldRev = cachedRev;
        rowsDirty = true;
    }

    private void ensureRows() {
        ensureFolds();
        if (!rowsDirty && !rowsRevStale()) return;
        int n = Math.max(docLines, Native.nativeLineCount(doc));
        if (lineRow.length < n + 1) {
            lineRow = new int[n + 64];
            rowLine = new int[n + 64];
        }
        java.util.Arrays.fill(lineRow, -1);
        rowCount = 0;
        for (int i = 0; i < n && rowCount < rowLine.length; ) {
            rowLine[rowCount] = i;
            lineRow[i] = rowCount;
            rowCount++;
            Integer end = foldMap.get(i);
            if (end != null && folded.contains(i) && end > i) {
                i = end + 1;
            } else {
                i++;
            }
        }
        rowsDirty = false;
        rowsRev = cachedRev;
    }

    private int rowsRev = -1;

    /** 下一个非空行的缩进；没有则为 -1。 */
    private int nextCodeIndent(int line) {
        int n = Native.nativeLineCount(doc);
        for (int k = line + 1; k < n; k++) {
            String t = line(k);
            if (t.trim().isEmpty()) continue;
            int ind = 0;
            while (ind < t.length() && (t.charAt(ind) == ' ' || t.charAt(ind) == '\t')) ind++;
            return ind;
        }
        return -1;
    }

    private boolean hasCodeBelow(int line) {
        int n = Native.nativeLineCount(doc);
        for (int k = line + 1; k < n && k < line + 40; k++) {
            if (!Native.nativeLineText(doc, k).trim().isEmpty()) return true;
        }
        return false;
    }

    private int rowOf(int line) {
        if (line < 0 || line >= lineRow.length) return -1;
        return lineRow[line];
    }

    private boolean rowsRevStale() {
        return rowsRev != cachedRev;
    }

    private void toggleFoldAt(int line) {
        ensureFolds();
        Integer end = foldMap.get(line);
        if (end == null) return;
        if (folded.contains(line)) {
            folded.remove(line);
        } else {
            // 展开外层，否则展开了也看不见内容；子层的折叠状态保留（记忆）
            for (java.util.Map.Entry<Integer, Integer> e : foldMap.entrySet()) {
                if (e.getKey() < line && line <= e.getValue()) folded.remove(e.getKey());
            }
            folded.add(line);
        }
        rowsDirty = true;
        ensureRows();
        invalidate();
        notifyState();
    }

    private boolean foldAllOn;

    public void toggleFoldAll() {
        ensureFolds();
        foldAllOn = !foldAllOn;
        folded.clear();
        if (foldAllOn) folded.addAll(foldMap.keySet());
        rowsDirty = true;
        ensureRows();
        invalidate();
    }

    // ---------------------------------------------------------------- 查找
    public boolean findNext(String needle, int fromLine, int fromCol,
                            boolean ignoreCase, boolean wholeWord, int[] out) {
        boolean ok = Native.nativeFind(doc, needle, fromLine, fromCol, ignoreCase, wholeWord, out);
        if (ok) ensureVisibleCursor();
        return ok;
    }

    /** 整篇文本（用于跨行 / 正则查找，UTF-16 下标与原生一致）。 */
    public String text() {
        return Native.nativeGetText(doc);
    }

    /** 全部替换：一次性写回整篇，只产生一个撤销步骤。 */
    public void replaceWholeText(String text, int caretLine, int caretCol) {
        Native.nativeReplaceWholeText(doc, text, caretLine, caretCol);
        refreshAfterEdit();
        ensureVisibleCursor();
        invalidate();
        notifyState();
    }

    public void selectRange(int l1, int c1, int l2, int c2) {
        Native.nativeSetSelection(doc, l1, c1, l2, c2);
        ensureVisibleCursor();
        invalidate();
        notifyState();
    }

    /** 选中内容与查询串一致才替换，避免误替换。 */
    public boolean replaceSelectedIfMatch(String q, String r, boolean ignoreCase, boolean wholeWord) {
        if (!Native.nativeHasSelection(doc)) return false;
        String sel = Native.nativeSelectedText(doc);
        boolean match = ignoreCase ? sel.equalsIgnoreCase(q) : sel.equals(q);
        if (!match) return false;
        Native.nativeReplaceRange(doc, 0, 0, 0, 0, r) ;
        return true;
    }

    public int replaceAll(String q, String r, boolean ignoreCase, boolean wholeWord) {
        int count = 0;
        int[] out = new int[3];
        int fl = 0, fc = 0;
        while (count < 5000 && Native.nativeFind(doc, q, fl, fc, ignoreCase, wholeWord, out)) {
            Native.nativeReplaceRange(doc, out[0], out[1], out[0], out[2], r);
            count++;
            fl = out[0];
            fc = out[1] + r.length();
        }
        if (count > 0) {
            refreshAfterEdit();
            invalidate();
            notifyState();
        }
        return count;
    }

    public boolean hasFoldAt(int line) {
        ensureFolds();
        return foldMap.containsKey(line);
    }

    /** 单行折叠（key == end）被编辑时自动展开，避免改到看不见的正文。 */
    private void unfoldInlineAtCursor() {
        if (doc == 0) return;
        int l = Native.nativeCursorLine(doc);
        Integer end = foldMap.get(l);
        if (end != null && end == l && folded.remove(l)) {
            rowsDirty = true;
            invalidate();
        }
    }

    /** 光标落在被折叠的行里时，展开包含它的折叠。 */
    private void unfoldForCursor() {
        if (rowCount == 0) return;
        int l = Native.nativeCursorLine(doc);
        if (l >= 0 && l < lineRow.length && lineRow[l] >= 0) return;
        for (java.util.Map.Entry<Integer, Integer> e : foldMap.entrySet()) {
            if (e.getKey() < l && l <= e.getValue() && folded.contains(e.getKey())) {
                folded.remove(e.getKey());
                rowsDirty = true;
                ensureRows();
                invalidate();
                return;
            }
        }
    }

    private String lineNumber(int i) {
        if (i >= numCache.length) {
            int n = Math.max(Native.nativeLineCount(doc) + 64, i + 64);
            String[] a = new String[n];
            if (i < numCache.length) System.arraycopy(numCache, 0, a, 0, numCache.length);
            numCache = a;
        }
        String v = numCache[i];
        if (v == null) {
            v = String.valueOf(i + 1);
            numCache[i] = v;
        }
        return v;
    }

    private void drawRun(Canvas c, String s, int st, int en, float x0, float[] off,
                         float baseline, Paint p) {
        int i = st;
        while (i < en) {
            int j = i;
            while (j < en && s.charAt(j) != '\t') j++;
            if (j > i) c.drawText(s, i, j, x0 + off[i], baseline, p);
            i = j;
            while (i < en && s.charAt(i) == '\t') i++;
        }
    }

    /** Fills off[from+1..to] with cumulative glyph advances measured by paint p. */
    private void fillWidths(String s, int from, int to, Paint p, float[] off) {
        int n = to - from;
        if (n <= 0) return;
        if (widthBuf.length < n) widthBuf = new float[n + 64];
        p.getTextWidths(s, from, to, widthBuf);
        float acc = off[from];
        for (int i = 0; i < n; i++) {
            float w = s.charAt(from + i) == '\t' ? tabW : widthBuf[i];
            if (w < 0) w = 0;
            acc += w;
            off[from + i + 1] = acc;
        }
    }

    /** Per-character x offsets for one line, measured with the actual token paints. */
    private void buildOffsets(String s, int len, int[] runs, int cnt, int startIdx,
                              int lineNo, float[] off) {
        int lim = Math.min(len + 1, off.length - 1);
        for (int i = 0; i <= lim; i++) off[i] = 0f;
        if (!pyMode) {
            fillWidths(s, 0, len, textPaint, off);
            return;
        }
        int col = 0;
        int k = startIdx;
        while (k < cnt && runs[k] == lineNo) {
            int st = runs[k + 1], en = runs[k + 2], type = runs[k + 3];
            if (st < 0) st = 0;
            if (st > len) st = len;
            if (en > len) en = len;
            if (st > col) fillWidths(s, col, st, textPaint, off);
            if (en > st) fillWidths(s, st, en, tokPaint[type], off);
            if (en > col) col = en;
            k += 4;
        }
        if (col < len) fillWidths(s, col, len, textPaint, off);
    }

    private float[] offCached(int line, int len, int ver) {
        if (offCache == null || line < 0 || line >= offCache.length) return null;
        if (offCacheLen[line] != len || offCacheVer[line] != ver) return null;
        return offCache[line];
    }

    private void storeOff(int line, int len, float[] off, int ver) {
        if (offCache == null || line >= offCache.length) {
            int cap = Math.max(Math.max(docLines, line) + 64, 128);
            float[][] a = new float[cap][];
            int[] c = new int[cap];
            int[] v = new int[cap];
            java.util.Arrays.fill(v, -1);
            if (offCache != null) {
                int k = Math.min(offCache.length, cap);
                System.arraycopy(offCache, 0, a, 0, k);
                System.arraycopy(offCacheLen, 0, c, 0, k);
                System.arraycopy(offCacheVer, 0, v, 0, k);
            }
            offCache = a;
            offCacheLen = c;
            offCacheVer = v;
        }
        offCache[line] = off;
        offCacheLen[line] = len;
        offCacheVer[line] = ver;
    }

    /** Offsets for a line that is not currently rendered (hit test / caret). */
    private float[] offsetsFor(int line, String s, int len) {
        int ver = Native.nativeLineVersion(doc, line);
        float[] off = offCached(line, len, ver);
        if (off != null) return off;
        int cnt = 0;
        if (pyMode) {
            while (true) {
                cnt = Native.nativeFillRuns(doc, line, line, lineRunBuf);
                if (cnt < lineRunBuf.length) break;
                lineRunBuf = new int[lineRunBuf.length * 2];
            }
        }
        off = new float[len + 2];
        buildOffsets(s, len, lineRunBuf, cnt, 0, line, off);
        storeOff(line, len, off, ver);
        return off;
    }

    private void drawProblems(Canvas canvas, int first, int last, float textLeft) {
        if (probCount <= 0) return;
        Path path = null;
        for (int i = 0; i < probCount; i++) {
            int line = probBuf[i * 5];
            if (line < first || line > last) continue;
            int st = probBuf[i * 5 + 1], en = probBuf[i * 5 + 2];
            String s = line(line);
            int len = s.length();
            if (st > len) st = len;
            if (en > len) en = len;
            if (en <= st) en = Math.min(len, st + 1);
            int prow = rowOf(line);
            if (prow < 0) continue;
            float[] off = offsetsFor(line, s, len);
            float x1 = textLeft + off[Math.min(st, len)];
            float x2 = textLeft + off[Math.min(en, len)];
            if (x2 - x1 < charW) x2 = x1 + charW;
            float y = padTop + prow * lineHeight - scrollY + lineHeight - dp(1.5f);
            if (path == null) path = new Path();
            path.reset();
            float amp = dp(1.4f);
            float step = dp(2.2f);
            path.moveTo(x1, y);
            boolean up = true;
            for (float x = x1; x < x2; x += step) {
                path.lineTo(x, up ? y - amp : y);
                up = !up;
            }
            path.lineTo(x2, y);
            canvas.drawPath(path, problemPaint);
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean onCheckIsTextEditor() {
        return true;
    }

    @Override
    public InputConnection onCreateInputConnection(EditorInfo out) {
        out.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
        out.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_NONE
                | EditorInfo.IME_FLAG_NO_FULLSCREEN;
        out.initialSelStart = 0;
        out.initialSelEnd = 0;
        return new Conn(this);
    }

    private static class Conn extends BaseInputConnection {
        private final EditorView v;

        Conn(EditorView view) {
            super(view, true);
            this.v = view;
        }

        @Override
        public boolean commitText(CharSequence text, int newCursorPosition) {
            v.clearComposing();
            if (text == null) return true;
            String s = text.toString();
            if (s.length() == 1) {
                v.typeChar(s.charAt(0));
                v.afterUserInput(s);
                return true;
            }
            v.insertString(s);
            v.afterUserInput(s);
            return true;
        }

        @Override
        public boolean setComposingText(CharSequence text, int newCursorPosition) {
            v.updateComposing(text == null ? "" : text.toString());
            return true;
        }

        @Override
        public boolean setComposingRegion(int start, int end) {
            return true;
        }

        @Override
        public boolean finishComposingText() {
            v.finishComposing();
            return true;
        }

        @Override
        public boolean deleteSurroundingText(int beforeLength, int afterLength) {
            v.clearComposing();
            for (int i = 0; i < beforeLength; i++) {
                if (!v.deleteBack()) break;
            }
            for (int i = 0; i < afterLength; i++) {
                if (!v.deleteFwd()) break;
            }
            v.afterUserInput("");
            return true;
        }

        @Override
        public boolean sendKeyEvent(KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                return v.onKeyDown(event.getKeyCode(), event);
            }
            return false;
        }

        @Override
        public CharSequence getTextBeforeCursor(int n, int flags) {
            String l = v.line(Native.nativeCursorLine(v.doc));
            int c = Native.nativeCursorCol(v.doc);
            int from = Math.max(0, c - n);
            return l.substring(from, Math.min(c, l.length()));
        }

        @Override
        public CharSequence getTextAfterCursor(int n, int flags) {
            String l = v.line(Native.nativeCursorLine(v.doc));
            int c = Native.nativeCursorCol(v.doc);
            int to = Math.min(l.length(), c + n);
            return l.substring(Math.min(c, l.length()), to);
        }

        @Override
        public boolean commitCompletion(android.view.inputmethod.CompletionInfo info) {
            return true;
        }

        @Override
        public boolean commitCorrection(android.view.inputmethod.CorrectionInfo info) {
            return true;
        }

        @Override
        public boolean setSelection(int start, int end) {
            return true;
        }

        @Override
        public boolean beginBatchEdit() {
            return true;
        }

        @Override
        public boolean endBatchEdit() {
            return true;
        }

        @Override
        public CharSequence getSelectedText(int flags) {
            if (!Native.nativeHasSelection(v.doc)) return null;
            return Native.nativeSelectedText(v.doc);
        }

        @Override
        public int getCursorCapsMode(int reqModes) {
            return 0;
        }

        @Override
        public boolean performContextMenuAction(int id) {
            if (id == android.R.id.selectAll) {
                v.selectAllText();
                return true;
            }
            if (id == android.R.id.copy) return v.copySelection();
            if (id == android.R.id.cut) return v.cutSelection();
            if (id == android.R.id.paste || id == android.R.id.pasteAsPlainText) {
                v.paste();
                return true;
            }
            if (id == android.R.id.undo) {
                v.undo();
                return true;
            }
            if (id == android.R.id.redo) {
                v.redo();
                return true;
            }
            return super.performContextMenuAction(id);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        boolean shift = e.isShiftPressed();
        boolean ctrl = e.isCtrlPressed();
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (popup != null && popup.isShowing()) hideCompletion();
                Native.nativeMoveHorizontal(doc, -1, shift);
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (popup != null && popup.isShowing()) hideCompletion();
                Native.nativeMoveHorizontal(doc, 1, shift);
                break;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (popup != null && popup.isShowing()) {
                    popup.move(-1);
                    return true;
                }
                Native.nativeMoveVertical(doc, -1, shift);
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (popup != null && popup.isShowing()) {
                    popup.move(1);
                    return true;
                }
                Native.nativeMoveVertical(doc, 1, shift);
                break;
            case KeyEvent.KEYCODE_MOVE_HOME:
                Native.nativeMoveLineEdge(doc, false, shift);
                break;
            case KeyEvent.KEYCODE_MOVE_END:
                Native.nativeMoveLineEdge(doc, true, shift);
                break;
            case KeyEvent.KEYCODE_PAGE_UP:
                Native.nativeMoveVertical(doc, -pageLines(), shift);
                break;
            case KeyEvent.KEYCODE_PAGE_DOWN:
                Native.nativeMoveVertical(doc, pageLines(), shift);
                break;
            case KeyEvent.KEYCODE_DEL:
                clearComposing();
                deleteBack();
                afterUserInput("");
                break;
            case KeyEvent.KEYCODE_FORWARD_DEL:
                clearComposing();
                deleteFwd();
                afterUserInput("");
                break;
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER: {
                if (popup != null && popup.isShowing()) {
                    popup.pickCurrent();
                    return true;
                }
                clearComposing();
                Native.nativeNewline(doc);
                refreshAfterEdit();     // 之前漏了：行号/状态栏不刷新、画面要等光标闪烁才重绘
                afterUserInput("\n");
                break;
            }
            case KeyEvent.KEYCODE_TAB:
                if (popup != null && popup.isShowing()) {
                    popup.pickCurrent();
                    return true;
                }
                Native.nativeIndent(doc, shift);
                afterUserInput("");
                break;
            case KeyEvent.KEYCODE_Z:
                if (ctrl) {
                    if (shift) redo();
                    else undo();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            case KeyEvent.KEYCODE_Y:
                if (ctrl) {
                    redo();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            case KeyEvent.KEYCODE_A:
                if (ctrl) {
                    selectAllText();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            case KeyEvent.KEYCODE_C:
                if (ctrl) {
                    copySelection();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            case KeyEvent.KEYCODE_X:
                if (ctrl) {
                    cutSelection();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            case KeyEvent.KEYCODE_V:
                if (ctrl) {
                    paste();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            case KeyEvent.KEYCODE_S:
                if (ctrl) {
                    if (listener != null) listener.onRequestSave();
                    return true;
                }
                return super.onKeyDown(keyCode, e);
            default:
                break;
        }
        int uni = e.getUnicodeChar();
        if (!ctrl && !e.isAltPressed() && uni >= 32 && (e.getFlags() & KeyEvent.FLAG_SOFT_KEYBOARD) == 0) {
            clearComposing();
            char c = (char) uni;
            Native.nativeInsertTyped(doc, c);
            afterUserInput(String.valueOf(c));
            return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    private int pageLines() {
        return Math.max(1, getHeight() / lineHeight - 1);
    }

    boolean deleteBack() {
        boolean ok = Native.nativeBackspace(doc);
        if (ok) refreshAfterEdit();
        return ok;
    }

    boolean deleteFwd() {
        boolean ok = Native.nativeDeleteForward(doc);
        if (ok) refreshAfterEdit();
        return ok;
    }

    void typeChar(char c) {
        if (c == '\n' || c == '\r') {
            Native.nativeNewline(doc);
        } else {
            Native.nativeInsertTyped(doc, c);
        }
        refreshAfterEdit();
    }

    void insertString(String s) {
        if (s == null || s.isEmpty()) return;
        Native.nativeInsertText(doc, s);
        refreshAfterEdit();
    }

    void selectAllText() {
        Native.nativeSelectAll(doc);
        invalidate();
        notifyState();
    }

    int lineCount() {
        return Native.nativeLineCount(doc);
    }

    // ---------------------------------------------------------------- composing
    void clearComposing() {
        if (compLine < 0) return;
        int l = compLine, c = compCol, n = compLen;
        compLine = -1;
        compCol = -1;
        compLen = 0;
        Native.nativeSetSelection(doc, l, c, l, c + n);
        Native.nativeBackspace(doc);
        refreshAfterEdit();
    }

    void finishComposing() {
        compLine = -1;
        compCol = -1;
        compLen = 0;
        invalidate();
    }

    void updateComposing(String s) {
        clearComposing();
        if (s.isEmpty()) return;
        compLine = Native.nativeCursorLine(doc);
        compCol = Native.nativeCursorCol(doc);
        compLen = s.length();
        Native.nativeInsertText(doc, s);
        refreshAfterEdit();
    }

    // ---------------------------------------------------------------- touch
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (doc == 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                hideCompletion();
                hideSelectionToolbar();
                if (vt == null) vt = VelocityTracker.obtain();
                vt.clear();
                vt.addMovement(e);
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                dragging = false;
                moved = false;
                selecting = false;
                longFired = false;
                edgeSwipe = false;
                if (!scroller.isFinished()) scroller.abortAnimation();
                handler.postDelayed(longPressRun, 380);
                ViewParent p = getParent();
                if (p != null) p.requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (vt != null) vt.addMovement(e);
                float x = e.getX(), y = e.getY();
                float dx = x - lastX, dy = y - lastY;
                if (!moved && (Math.abs(x - downX) > touchSlop || Math.abs(y - downY) > touchSlop)) {
                    moved = true;
                    handler.removeCallbacks(longPressRun);
                }
                if (!edgeSwipe && !selecting && !longFired && scrollX <= 0
                        && !Native.nativeHasSelection(doc) && Native.nativeCursorCol(doc) == 0
                        && (x - downX) > dp(28)
                        && Math.abs(x - downX) > Math.abs(y - downY) * 1.6f) {
                    // 编辑区已在最左、光标在行首：继续往右滑没有内容可滚，交给抽屉跟手
                    edgeSwipe = true;
                    moved = true;
                    dragging = false;
                    handler.removeCallbacks(longPressRun);
                    if (edgeSwipeListener != null) edgeSwipeListener.onProgress(0f);
                    lastX = x;
                    lastY = y;
                    return true;
                }
                if (edgeSwipe) {
                    if (edgeSwipeListener != null) {
                        float ep = Math.min(1f, Math.max(0f, (x - downX) / dp(160)));
                        edgeSwipeListener.onProgress(ep);
                    }
                    lastX = x;
                    lastY = y;
                    return true;
                }
                if (selecting) {
                    int[] pos = hitTest(x, y);
                    Native.nativeSetSelection(doc, Native.nativeAnchorLine(doc),
                            Native.nativeAnchorCol(doc), pos[0], pos[1]);
                    invalidate();
                    notifyState();
                } else if (moved) {
                    dragging = true;
                    scrollBy(-dx, -dy);
                }
                lastX = x;
                lastY = y;
                return true;
            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(longPressRun);
                if (edgeSwipe) {
                    edgeSwipe = false;
                    float ep = Math.min(1f, Math.max(0f, (e.getX() - downX) / dp(160)));
                    if (edgeSwipeListener != null) edgeSwipeListener.onEnd(ep > 0.32f);
                    if (vt != null) {
                        vt.recycle();
                        vt = null;
                    }
                    return true;
                }
                if (vt != null) {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    float vx = vt.getXVelocity(), vy = vt.getYVelocity();
                    if (dragging && (Math.abs(vy) > 200 || Math.abs(vx) > 200)) {
                        scroller.fling((int) scrollX, (int) scrollY, (int) -vx, (int) -vy,
                                0, maxScrollX, 0, maxScrollY);
                        postInvalidateOnAnimation();
                    }
                    vt.recycle();
                    vt = null;
                }
                if (!moved && !longFired) {
                    int[] pos = hitTest(e.getX(), e.getY());
                    if (annListener != null && pos[0] >= 0 && pos[0] < annX1.length
                            && annX1[pos[0]] >= 0f && annClick.containsKey(pos[0])
                            && e.getX() >= annX1[pos[0]] - dp(4)
                            && e.getX() <= annX2[pos[0]] + dp(4)) {
                        annListener.onAnnotationClick(annClick.get(pos[0]));
                        return true;
                    }
                    long now = System.currentTimeMillis();
                    boolean dbl = (now - lastTapTime < 350
                            && Math.abs(e.getX() - lastTapX) < dp(30)
                            && Math.abs(e.getY() - lastTapY) < dp(30));
                    lastTapTime = now;
                    lastTapX = e.getX();
                    lastTapY = e.getY();
                    if (dbl && hasFoldAt(pos[0])) {
                        toggleFoldAt(pos[0]);
                        return true;
                    }
                    boolean gutterTap = theme.showLineNumbers && e.getX() < gutterW;
                    if (gutterTap) {
                        Native.nativeSelectLine(doc, pos[0]);
                    } else {
                        Native.nativeSetCursor(doc, pos[0], pos[1]);
                    }
                    caretOn = true;
                    handler.removeCallbacks(blinkRun);
                    handler.postDelayed(blinkRun, 530);
                    invalidate();
                    notifyState();
                    // 只有点按正文才弹键盘：滑动、长按选词、点行号栏都不弹
                    if (!gutterTap) {
                        requestFocus();
                        showIme();
                    }
                }
                selecting = false;
                dragging = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPressRun);
                if (edgeSwipe && edgeSwipeListener != null) edgeSwipeListener.onEnd(false);
                edgeSwipe = false;
                selecting = false;
                dragging = false;
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private void blinkTick() {
        caretOn = !caretOn;
        invalidate();
        if (isFocused()) handler.postDelayed(blinkRun, 530);
    }

    private void fireLongPress() {
        if (moved) return;
        longFired = true;
        selecting = true;
        int[] pos = hitTest(downX, downY);
        Native.nativeSelectWord(doc, pos[0], pos[1]);
        invalidate();
        notifyState();
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        showSelectionToolbar();
    }

    void showSelectionToolbar() {
        try {
            if (actionMode == null) {
                actionMode = startActionMode(actionCb, ActionMode.TYPE_FLOATING);
            } else {
                actionMode.invalidate();
            }
        } catch (Throwable ignored) {
            actionMode = null;
        }
    }

    private void hideSelectionToolbar() {
        if (actionMode != null) {
            try {
                actionMode.finish();
            } catch (Throwable ignored) {
            }
            actionMode = null;
        }
    }

    private int[] hitTest(float x, float y) {
        int n = Native.nativeLineCount(doc);
        ensureRows();
        int rowHit = (int) ((y + scrollY - padTop) / lineHeight);
        if (rowHit < 0) rowHit = 0;
        if (rowHit >= rowCount) rowHit = Math.max(0, rowCount - 1);
        int lineNo = (rowCount > 0 && rowHit < rowLine.length) ? rowLine[rowHit] : 0;
        if (lineNo < 0 || lineNo >= n) lineNo = Math.max(0, n - 1);
        String s = line(lineNo);
        int len = s.length();
        float[] off = offsetsFor(lineNo, s, len);
        float lx = x - (gutterW + textPad - scrollX);
        int col = 0;
        if (lx <= 0) {
            col = 0;
        } else if (lx >= off[len]) {
            col = len;
        } else {
            int lo = 0, hi = len;
            while (lo < hi) {
                int mid = (lo + hi) / 2;
                if (off[mid] < lx) lo = mid + 1;
                else hi = mid;
            }
            col = lo;
            if (col > 0) {
                float left = off[col - 1], right = off[col];
                if (lx - left < right - lx) col = col - 1;
            }
        }
        return new int[]{lineNo, col};
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_SCROLL) {
            float dy = e.getAxisValue(MotionEvent.AXIS_VSCROLL) * lineHeight * 3;
            scrollBy(0, dy);
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    private void scrollBy(float dx, float dy) {
        scrollX += dx;
        scrollY += dy;
        clampScroll();
        invalidate();
    }

    private void clampScroll() {
        if (scrollX < 0) scrollX = 0;
        if (scrollX > maxScrollX) scrollX = maxScrollX;
        if (scrollY < 0) scrollY = 0;
        if (scrollY > maxScrollY) scrollY = maxScrollY;
    }

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollX = scroller.getCurrX();
            scrollY = scroller.getCurrY();
            clampScroll();
            invalidate();
        }
    }

    @Override
    protected void onFocusChanged(boolean gainFocus, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
        handler.removeCallbacks(blinkRun);
        caretOn = true;
        if (gainFocus) handler.postDelayed(blinkRun, 530);
        invalidate();
    }

    public void showIme() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
    }

    // ---------------------------------------------------------------- editing api
    private void refreshAfterEdit() {
        syncRev();
        unfoldInlineAtCursor();
        ensureVisibleCursor();
        scheduleCheck(800);
        invalidate();
        notifyState();
        if (listener != null) listener.onEditorTextChanged();
    }

    void afterUserInput(String inserted) {
        hideSelectionToolbar();
        caretOn = true;
        handler.removeCallbacks(blinkRun);
        handler.postDelayed(blinkRun, 530);
        syncRev();
        if (inserted != null && inserted.length() == 1) {
            char c = inserted.charAt(0);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '.') {
                showCompletion(false);
                return;
            }
        }
        hideCompletion();
    }

    public void ensureVisibleCursor() {
        int line = Native.nativeCursorLine(doc);
        int col = Native.nativeCursorCol(doc);
        int h = getHeight();
        if (h == 0) return;
        ensureRows();
        unfoldForCursor();
        int row = rowOf(line);
        if (row < 0) row = 0;
        float y = padTop + row * lineHeight;
        if (y - scrollY < lineHeight * 0.5f) scrollY = y - lineHeight * 0.5f;
        if (y + lineHeight - scrollY > h - dp(4)) scrollY = y + lineHeight - h + dp(4);
        String s = line(line);
        int len = s.length();
        float[] off = offsetsFor(line, s, len);
        float cx = gutterW + textPad + off[Math.min(col, len)];
        float margin = Math.max(charW * 3, dp(24));
        if (cx - scrollX > getWidth() - margin) scrollX = cx - getWidth() + margin;
        if (cx - scrollX < gutterW + textPad) scrollX = cx - (gutterW + textPad);
        clampScroll();
    }

    public void undo() {
        if (Native.nativeUndo(doc)) {
            syncRev();
            unfoldInlineAtCursor();
            scheduleCheck(400);
            invalidate();
            notifyState();
            if (listener != null) listener.onEditorTextChanged();
        }
    }

    public void redo() {
        if (Native.nativeRedo(doc)) {
            syncRev();
            unfoldInlineAtCursor();
            scheduleCheck(400);
            invalidate();
            notifyState();
            if (listener != null) listener.onEditorTextChanged();
        }
    }

    public void indent() {
        Native.nativeIndent(doc, false);
        refreshAfterEdit();
    }

    public void outdent() {
        Native.nativeIndent(doc, true);
        refreshAfterEdit();
    }

    public void moveCursorTo(int line, int col) {
        Native.nativeSetCursor(doc, line, col);
        ensureVisibleCursor();
        invalidate();
        notifyState();
    }

    // ---------------------------------------------------------------- clipboard
    public boolean copySelection() {
        if (!Native.nativeHasSelection(doc)) return false;
        String s = Native.nativeSelectedText(doc);
        if (s == null || s.isEmpty()) return false;
        ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("python", s));
        return true;
    }

    public boolean cutSelection() {
        if (!copySelection()) return false;
        Native.nativeBackspace(doc);
        refreshAfterEdit();
        return true;
    }

    public void paste() {
        ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipData cd = cm.getPrimaryClip();
        if (cd == null || cd.getItemCount() == 0) return;
        CharSequence t = cd.getItemAt(0).coerceToText(getContext());
        if (t == null) return;
        insertString(t.toString());
    }

    public void selectAllSelection() {
        selectAllText();
    }

    // ---------------------------------------------------------------- 语言模式
    /** .py 才折叠 / 高亮 / 语法检查 / 补全；其它文本按 UTF-8 纯文本显示。 */
    public void setPythonMode(boolean py) {
        if (pyMode == py) return;
        pyMode = py;
        foldRev = -1;
        foldAllOn = false;
        folded.clear();
        foldText.clear();
        foldMap.clear();
        rowsDirty = true;
        probCount = py ? -1 : 0;
        probBuf = new int[5 * 64];
        lastCheckRev = -1;
        hideCompletion();
        resetMetricsCaches();
        if (py) scheduleCheck(0);
        invalidate();
        notifyState();
    }

    public boolean isPython() {
        return pyMode;
    }

    // ---------------------------------------------------------------- problems
    public void setSyntaxCheckEnabled(boolean on) {
        checkEnabled = on;
        if (!on) {
            probCount = 0;
            probBuf = new int[5 * 64];
            invalidate();
            notifyState();
        } else if (doc != 0) {
            scheduleCheck(0);
        }
    }

    private void scheduleCheck(int delayMs) {
        if (!checkEnabled || !pyMode) return;
        handler.removeCallbacks(checkRun);
        handler.postDelayed(checkRun, delayMs);
    }

    private void runCheckNow() {
        if (!checkEnabled || doc == 0) return;
        if (!pyMode) {
            probCount = 0;
            invalidate();
            return;
        }
        int rev = Native.nativeRevision(doc);
        if (rev == lastCheckRev) return;
        lastCheckRev = rev;
        int n = Native.nativeProblems(doc, probBuf, true);
        if (n >= probBuf.length / 5) {
            probBuf = new int[Math.max(probBuf.length * 2, (n + 16) * 5)];
            n = Native.nativeProblems(doc, probBuf, false);
        }
        probCount = n;
        invalidate();
        notifyState();
    }

    public int problemCount() {
        return Math.max(0, probCount);
    }

    public ArrayList<String> problemLines() {
        ArrayList<String> out = new ArrayList<>();
        if (probCount <= 0) return out;
        for (int i = 0; i < probCount; i++) {
            int line = probBuf[i * 5] + 1;
            int sev = probBuf[i * 5 + 3];
            int msg = probBuf[i * 5 + 4];
            out.add((sev == 0 ? "✖ " : "⚠ ") + Lang.s("行 ") + line + Lang.s(" 行: ") + Messages.text(msg));
        }
        return out;
    }

    public int[] problemAt(int index) {
        if (index < 0 || index >= probCount) return null;
        return new int[]{probBuf[index * 5], probBuf[index * 5 + 1], probBuf[index * 5 + 3]};
    }

    private void notifyState() {
        if (listener != null) listener.onEditorStateChanged();
    }

    // ---------------------------------------------------------------- completion
    public void showCompletion(boolean force) {
        if (doc == 0) return;
        if (suppressCompletion) return;
        if (!pyMode) {
            hideCompletion();
            return;
        }
        syncRev();
        int line = Native.nativeCursorLine(doc);
        int col = Native.nativeCursorCol(doc);
        String s = line(line);
        int st = col;
        while (st > 0 && isIdentChar(s.charAt(st - 1))) st--;
        String prefix = s.substring(st, Math.min(col, s.length()));
        boolean attr = st > 0 && s.charAt(st - 1) == '.';
        int max = Prefs.completeMax(getContext());

        // 原生候选里过滤掉内置片段名（kind 23），片段改由 Snippets 注册表提供，
        // 这样自定义 / 改过 / 删掉的片段都能立刻生效。
        String[] raw = Native.nativeComplete(doc, max);
        java.util.ArrayList<String> items = new java.util.ArrayList<>();
        java.util.HashSet<String> names = new java.util.HashSet<>();
        if (raw != null) {
            for (String it : raw) {
                if (it == null || it.length() < 3) continue;
                int code = (it.charAt(0) - '0') + 10 * (it.charAt(2) - '0');
                if (code == 23) continue;
                int tab = it.indexOf('\t');
                String nm = tab >= 0 ? it.substring(tab + 1) : "";
                if (!names.add(nm)) continue;
                items.add(it);
            }
        }
        if (!attr) {
            java.util.ArrayList<String> snips = new java.util.ArrayList<>();
            for (Snippets.Item sn : Snippets.all(getContext())) {
                if (!snippetMatches(sn.trigger, prefix)) continue;
                if (!names.add(sn.trigger)) continue;
                snips.add("3.2\t" + sn.trigger);
            }
            items.addAll(0, snips);
        }
        while (items.size() > max) items.remove(items.size() - 1);
        if (items.isEmpty()) {
            hideCompletion();
            return;
        }
        if (!force) {
            // don't pop up for a single exact match of what is already typed
            if (items.size() == 1) {
                String name = items.get(0).substring(items.get(0).indexOf('\t') + 1);
                if (name.equals(prefix)) {
                    hideCompletion();
                    return;
                }
            }
            if (prefix.isEmpty() && !attr) {
                hideCompletion();
                return;
            }
        }
        if (popup == null) {
            popup = new CompletionPopup(getContext());
            popup.setCallback((name, kind) -> {
                insertCompletion(name, kind);
                hideCompletion();
            });
        }
        float[] off = offsetsFor(line, s, s.length());
        float cx = gutterW + textPad - scrollX + off[Math.min(col, s.length())];
        float cy = padTop + line * lineHeight - scrollY;
        popup.show(this, items.toArray(new String[0]), prefix, Math.round(cx), Math.round(cy), lineHeight);
    }

    /** 前缀匹配：本身是前缀优先，其次包含（都忽略大小写）。 */
    private static boolean snippetMatches(String trigger, String prefix) {
        if (prefix.isEmpty()) return true;
        String t = trigger.toLowerCase();
        String p = prefix.toLowerCase();
        return t.startsWith(p) || t.contains(p);
    }

    public void hideCompletion() {
        if (popup != null) popup.dismiss();
    }

    public boolean completionVisible() {
        return popup != null && popup.isShowing();
    }

    /** 片段：先删掉已输入的前缀，再插入带占位光标的模板。 */
    private boolean insertSnippetAt(String tpl) {
        int line = Native.nativeCursorLine(doc);
        int col = Native.nativeCursorCol(doc);
        String s = line(line);
        int st = col;
        while (st > 0 && isIdentChar(s.charAt(st - 1))) st--;
        Native.nativeSetSelection(doc, line, st, line, Math.min(col, s.length()));
        Native.nativeBackspace(doc);

        String ind = "";
        int k = 0;
        while (k < s.length() && (s.charAt(k) == ' ' || s.charAt(k) == '\t')) k++;
        if (k > 0 && st > 0) ind = s.substring(0, Math.min(k, st));
        StringBuilder sb = new StringBuilder();
        int caret = -1;
        boolean first = true;
        for (String part : tpl.split("\n", -1)) {
            if (!first) sb.append('\n');
            if (!first && !ind.isEmpty() && !part.isEmpty()) sb.append(ind);
            for (int i = 0; i < part.length(); i++) {
                char c = part.charAt(i);
                if (c == '\u0001') {
                    caret = sb.length();
                } else {
                    sb.append(c);
                }
            }
            first = false;
        }
        if (caret < 0) caret = sb.length();
        Native.nativeInsertSnippet(doc, sb.toString(), caret);
        refreshAfterEdit();
        afterUserInput("");
        return true;
    }

    public void insertCompletion(String name, int kind) {
        String tpl = kind == 23 ? Snippets.template(getContext(), name) : null;
        if (tpl != null) {
            insertSnippetAt(tpl);
            return;
        }
        int line = Native.nativeCursorLine(doc);
        int col = Native.nativeCursorCol(doc);
        String s = line(line);
        int st = col;
        while (st > 0 && isIdentChar(s.charAt(st - 1))) st--;
        Native.nativeSetSelection(doc, line, st, line, Math.min(col, s.length()));
        Native.nativeInsertText(doc, name);
        refreshAfterEdit();
        afterUserInput("");
    }

    private static boolean isIdentChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    // ---------------------------------------------------------------- misc
    public void setEdgeSwipeListener(EdgeSwipeListener l) {
        edgeSwipeListener = l;
    }

    public void setVerticalScroll(int y) {
        scrollY = y;
        clampScroll();
        invalidate();
    }

    public float scrollY() {
        return scrollY;
    }

    public int lineHeightPx() {
        return lineHeight;
    }

    public void onThemePrefsChanged() {
        // re-apply engine options
        Native.nativeSetOptions(doc, theme.tabSize, theme.autoIndent, theme.autoPair);
        applyThemeVars();
        invalidate();
    }

    /** Used by the settings preview: returns colour of a token type. */
    public int tokenColor(int type) {
        return theme.colors[type];
    }

    void ensureProblemCache() {
        if (!checkEnabled || !pyMode) {
            probCount = 0;
            return;
        }
        if (probCount < 0) {
            int n = Native.nativeProblems(doc, probBuf, true);
            if (n >= probBuf.length / 5) {
                probBuf = new int[Math.max(probBuf.length * 2, (n + 16) * 5)];
                n = Native.nativeProblems(doc, probBuf, false);
            }
            probCount = n;
        }
    }

    static class Messages {
        static String text(int id) {
            switch (id) {
                case 1: return Lang.s("语句末尾缺少冒号");
                case 2: return Lang.s("括号没有闭合");
                case 3: return Lang.s("多余的右括号");
                case 4: return Lang.s("括号类型不匹配");
                case 5: return Lang.s("三引号字符串没有闭合");
                case 6: return Lang.s("缩进含有制表符 (Tab)");
                case 7: return Lang.s("缩进宽度不是设定值的倍数");
                case 8: return Lang.s("冒号后缺少缩进块");
                case 9: return Lang.s("def 缺少参数括号");
                default: return Lang.s("语法问题");
            }
        }
    }
}
