package com.yhhy.pyeditor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * 自定义函数 / 类的使用统计（纯 Java，可在 JVM 上单测）。
 *
 * <ul>
 *   <li>函数：被引用次数（全文标识符出现次数 - def 那一处）</li>
 *   <li>类：属性个数（{@code self.x =} / {@code self.x:} 以及类体同级的 {@code x = ...}）
 *       与方法个数（类体同级的 {@code def}）</li>
 * </ul>
 * 字符串、三引号字符串、注释里的内容不计入。
 */
final class SymbolStats {

    static final class Sym {
        final String name;
        final int line;
        final boolean cls;
        final int uses;
        final int attrs;
        final int methods;

        Sym(String n, int l, boolean c, int u, int a, int m) {
            name = n;
            line = l;
            cls = c;
            uses = u;
            attrs = a;
            methods = m;
        }
    }

    private static final class Tok {
        final String name;
        final int col;

        Tok(String n, int c) {
            name = n;
            col = c;
        }
    }

    private static final class State {
        boolean inTriple;
        char q;
    }

    private SymbolStats() {
    }

    static ArrayList<Sym> scan(String[] txt) {
        ArrayList<Sym> out = new ArrayList<>();
        if (txt == null || txt.length == 0) return out;
        int n = txt.length;

        ArrayList<ArrayList<Tok>> toks = new ArrayList<>(n);
        boolean[] codeLine = new boolean[n];
        HashMap<String, Integer> count = new HashMap<>();
        State st = new State();
        for (int i = 0; i < n; i++) {
            boolean startedInTriple = st.inTriple;
            ArrayList<Tok> ts = new ArrayList<>();
            scanLine(txt[i], st, ts);
            toks.add(ts);
            codeLine[i] = !startedInTriple;
            for (Tok t : ts) {
                Integer old = count.get(t.name);
                count.put(t.name, old == null ? 1 : old + 1);
            }
        }

        for (int i = 0; i < n; i++) {
            if (!codeLine[i]) continue;
            String line = txt[i];
            String t = line.trim();
            if (t.isEmpty() || t.startsWith("#")) continue;
            boolean isClass = false;
            int nameAt = -1;
            if (t.startsWith("def ")) {
                nameAt = line.indexOf("def ") + 4;
            } else if (t.startsWith("async def ")) {
                nameAt = line.indexOf("async def ") + 10;
            } else if (t.startsWith("class ")) {
                isClass = true;
                nameAt = line.indexOf("class ") + 6;
            }
            if (nameAt < 0) continue;
            String name = identAt(line, nameAt);
            if (name == null) continue;
            if (indent(line) != 0) continue;   // 方法 / 嵌套定义算在类或外层里

            if (!isClass) {
                Integer c = count.get(name);
                int uses = (c == null ? 0 : c) - 1;
                if (uses < 0) uses = 0;
                out.add(new Sym(name, i, false, uses, 0, 0));
                continue;
            }

            int classIndent = indent(line);
            int bodyIndent = -1;
            int methods = 0;
            HashSet<String> attrs = new HashSet<>();
            for (int j = i + 1; j < n; j++) {
                String l = txt[j];
                if (l.trim().isEmpty()) continue;
                if (!codeLine[j]) continue;
                int ind = indent(l);
                if (ind <= classIndent) break;
                if (bodyIndent < 0) bodyIndent = ind;
                String t2 = l.trim();
                if (t2.startsWith("def ") || t2.startsWith("async def ")) {
                    if (ind == bodyIndent) methods++;
                    collectSelfAttrs(l, toks.get(j), attrs);
                    continue;
                }
                collectSelfAttrs(l, toks.get(j), attrs);
                if (ind == bodyIndent && !t2.startsWith("@")) {
                    String cl = classLevelAttr(l);
                    if (cl != null) attrs.add(cl);
                }
            }
            out.add(new Sym(name, i, true, 0, attrs.size(), methods));
        }
        return out;
    }

    /** self.x = / self.x: → 属性名。 */
    private static void collectSelfAttrs(String line, ArrayList<Tok> ts, HashSet<String> attrs) {
        for (Tok t : ts) {
            if (!t.name.equals("self")) continue;
            int p = skipSpaces(line, t.col + 4);
            if (p >= line.length() || line.charAt(p) != '.') continue;
            p = skipSpaces(line, p + 1);
            String attr = identAt(line, p);
            if (attr == null) continue;
            int q = skipSpaces(line, p + attr.length());
            if (q >= line.length()) continue;
            char c = line.charAt(q);
            boolean assign = c == '='
                    && (q + 1 >= line.length() || line.charAt(q + 1) != '=');
            boolean ann = c == ':'
                    && !(q + 1 < line.length() && line.charAt(q + 1) == '=');
            if (assign || ann) attrs.add(attr);
        }
    }

    /** 类体同级的 x = … / x: T = …。 */
    private static String classLevelAttr(String line) {
        int p = skipSpaces(line, 0);
        String name = identAt(line, p);
        if (name == null) return null;
        int q = skipSpaces(line, p + name.length());
        if (q >= line.length()) return null;
        char c = line.charAt(q);
        if (c == '=' && (q + 1 >= line.length() || line.charAt(q + 1) != '=')) return name;
        if (c == ':') {
            int eq = line.indexOf('=', q + 1);
            if (eq > 0 && (eq + 1 >= line.length() || line.charAt(eq + 1) != '=')) return name;
        }
        return null;
    }

    private static int indent(String s) {
        int k = 0;
        while (k < s.length() && (s.charAt(k) == ' ' || s.charAt(k) == '\t')) k++;
        return k;
    }

    private static int skipSpaces(String s, int i) {
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) i++;
        return i;
    }

    private static String identAt(String s, int i) {
        if (i < 0 || i >= s.length()) return null;
        char c = s.charAt(i);
        if (!(Character.isLetter(c) || c == '_')) return null;
        int b = i;
        i++;
        while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
        return s.substring(b, i);
    }

    /** 单行词法：只收标识符，跳过字符串 / 三引号 / 注释。 */
    private static void scanLine(String s, State st, ArrayList<Tok> out) {
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (st.inTriple) {
                if (c == '\\') {
                    i += 2;
                    continue;
                }
                if (c == st.q && i + 2 < s.length()
                        && s.charAt(i + 1) == st.q && s.charAt(i + 2) == st.q) {
                    st.inTriple = false;
                    st.q = 0;
                    i += 3;
                    continue;
                }
                i++;
                continue;
            }
            if (c == '\'' || c == '"') {
                if (i + 2 < s.length() && s.charAt(i + 1) == c && s.charAt(i + 2) == c) {
                    st.inTriple = true;
                    st.q = c;
                    i += 3;
                } else {
                    i = skipString(s, i, c);
                }
                continue;
            }
            if (c == '#') return;
            if (Character.isLetter(c) || c == '_') {
                int b = i;
                i++;
                while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
                out.add(new Tok(s.substring(b, i), b));
                continue;
            }
            i++;
        }
    }

    private static int skipString(String s, int quoteIdx, char q) {
        int i = quoteIdx + 1;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == q) return i + 1;
            i++;
        }
        return i;
    }
}
