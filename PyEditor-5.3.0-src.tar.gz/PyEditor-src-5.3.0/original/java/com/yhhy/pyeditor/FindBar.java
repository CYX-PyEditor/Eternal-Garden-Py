package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 底部查找 / 替换栏（像终端面板一样贴在编辑区下方，不挡正文）。
 * 支持结果计数、正则、跨行（\n）、全部替换单步撤销。
 */
class FindBar extends LinearLayout {

    private static final int MAX_MATCHES = 50000;

    private final MainActivity act;
    private final EditorView editor;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Theme theme;

    private TextView title, status;
    private EditText find, repl;
    private TextView chipAa, chipWord, chipRe, btnPrev, btnNext, btnReplace, btnAll, btnHide;

    private String doc = "";
    private int[] lineStarts = new int[]{0};
    private final List<int[]> matches = new ArrayList<>();
    private Pattern pattern;
    private int current = -1;
    private int lastRev = -1;

    private final Runnable countRun = () -> rebuildMatches(true);

    FindBar(MainActivity a, EditorView e) {
        super(a);
        act = a;
        editor = e;
        theme = Theme.load(a);
        setOrientation(VERTICAL);
        setBackgroundColor(theme.statusBg);
        setPadding(0, 0, 0, dp(4));

        // ---- 标题行：查找 / 替换 · 状态 · 收起
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), 0, dp(6), 0);
        bar.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        title = new TextView(a);
        title.setText(Lang.s("查找 / 替换"));
        title.setTextSize(11.5f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        bar.addView(title);

        status = new TextView(a);
        status.setTextSize(10.5f);
        status.setTextColor(0xFF32C8FF);
        status.setSingleLine(true);
        status.setGravity(Gravity.END);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        slp.setMargins(dp(8), 0, dp(6), 0);
        status.setLayoutParams(slp);
        bar.addView(status);

        btnHide = smallBtn(Lang.s("收起"), v -> close());
        bar.addView(btnHide);
        addView(bar);

        // ---- 查找行
        LinearLayout r1 = new LinearLayout(a);
        r1.setOrientation(HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        r1.setPadding(dp(10), 0, dp(10), 0);

        find = input(Lang.s("查找内容（\\n 可跨行）"));
        find.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE
                    || (ev != null && ev.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                findNext();
                return true;
            }
            return false;
        });
        r1.addView(find, new LinearLayout.LayoutParams(0, dp(34), 1f));

        chipAa = chip("Aa", true, v -> toggle(chipAa));
        chipWord = chip(Lang.s("全词"), false, v -> toggle(chipWord));
        chipRe = chip("Re", false, v -> toggle(chipRe));
        tip(chipAa, Lang.s("Aa：忽略大小写"));
        tip(chipWord, Lang.s("全词：只匹配完整单词"));
        tip(chipRe, Lang.s("Re：按正则表达式匹配（替换可用 $1 分组）"));
        r1.addView(chipAa);
        r1.addView(chipWord);
        r1.addView(chipRe);
        btnPrev = smallBtn("↑", v -> findPrev());
        btnNext = smallBtn("↓", v -> findNext());
        r1.addView(btnPrev);
        r1.addView(btnNext);
        addView(r1);

        // ---- 替换行
        LinearLayout r2 = new LinearLayout(a);
        r2.setOrientation(HORIZONTAL);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        r2.setPadding(dp(10), dp(3), dp(10), 0);

        repl = input(Lang.s("替换为（\\n \\t，正则 $1）"));
        r2.addView(repl, new LinearLayout.LayoutParams(0, dp(32), 1f));
        btnReplace = smallBtn(Lang.s("替换"), v -> replaceCurrent());
        btnAll = smallBtn(Lang.s("全部"), v -> replaceAll());
        r2.addView(btnReplace);
        r2.addView(btnAll);
        addView(r2);

        TextWatcher tw = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a2, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a2, int b, int c) {
                current = -1;
                ui.removeCallbacks(countRun);
                ui.postDelayed(countRun, 150);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        find.addTextChangedListener(tw);
    }

    // ------------------------------------------------------------ 外观
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private EditText input(String hint) {
        EditText e = new EditText(act);
        e.setHint(hint);
        e.setTextSize(12.5f);
        e.setSingleLine(true);
        e.setTextColor(theme.colors[Theme.TOK_TEXT]);
        e.setHintTextColor(theme.gutterText);
        e.setPadding(dp(8), 0, dp(8), 0);
        e.setBackground(null);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private TextView chip(String text, boolean on, OnClickListener l) {
        TextView tv = new TextView(act);
        tv.setText(text);
        tv.setTextSize(11f);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(7), dp(4), dp(7), dp(4));
        tv.setTag(on);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(26));
        lp.setMargins(dp(3), 0, 0, 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        styleChip(tv);
        return tv;
    }

    private void styleChip(TextView tv) {
        boolean on = Boolean.TRUE.equals(tv.getTag());
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setColor(on ? theme.colors[Theme.TOK_KEYWORD] : theme.curLine);
        tv.setBackground(bg);
        tv.setTextColor(on ? 0xFFFFFFFF : theme.colors[Theme.TOK_BUILTIN]);
    }

    /** 长按小开关给一句解释，避免看不懂缩写。 */
    private void tip(TextView tv, String msg) {
        tv.setOnLongClickListener(v -> {
            toast(msg);
            return true;
        });
    }

    private void toggle(TextView tv) {
        tv.setTag(!Boolean.TRUE.equals(tv.getTag()));
        styleChip(tv);
        current = -1;
        ui.removeCallbacks(countRun);
        ui.postDelayed(countRun, 60);
    }

    private TextView smallBtn(String text, OnClickListener l) {
        TextView tv = new TextView(act);
        tv.setText(text);
        tv.setTextSize(10.5f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(7), dp(4), dp(7), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setColor(theme.statusBg == 0xFF21252B ? 0xFF2C313A : theme.curLine);
        tv.setBackground(bg);
        tv.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(26));
        lp.setMargins(dp(3), 0, 0, 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    void applyTheme(Theme t) {
        theme = t;
        setBackgroundColor(theme.statusBg);
        title.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        for (EditText e : new EditText[]{find, repl}) {
            if (e == null) continue;
            e.setTextColor(theme.colors[Theme.TOK_TEXT]);
            e.setHintTextColor(theme.gutterText);
        }
        for (TextView tv : new TextView[]{chipAa, chipWord, chipRe}) {
            if (tv != null) styleChip(tv);
        }
        for (TextView tv : new TextView[]{btnPrev, btnNext, btnReplace, btnAll, btnHide}) {
            if (tv == null) continue;
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(6));
            bg.setColor(theme.statusBg == 0xFF21252B ? 0xFF2C313A : theme.curLine);
            tv.setBackground(bg);
            tv.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        }
    }

    // ------------------------------------------------------------ 开关
    boolean isOpen() {
        return getVisibility() == View.VISIBLE;
    }

    void open() {
        boolean was = isOpen();
        setVisibility(View.VISIBLE);
        if (!was) {
            String q = find.getText().toString();
            if (!q.isEmpty()) {
                ui.postDelayed(countRun, 30);
            } else {
                setStatus(Lang.s("输入查找内容"));
            }
        }
        editor.hideCompletion();
        find.requestFocus();
        find.setSelection(find.getText().length());
        post(() -> {
            InputMethodManager imm = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(find, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    /** 带初始查找串打开（行尾「被使用 N 次」标注点进来时用）。 */
    void open(String query) {
        if (query != null && !query.isEmpty()) {
            find.setText(query);
            find.setSelection(find.getText().length());
        }
        open();
    }

    void close() {
        setVisibility(View.GONE);
        InputMethodManager imm = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
        editor.requestFocus();
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    private void toast(String s) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------ 文本 / 下标
    private static int[] buildLineStarts(String s) {
        int n = 1;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') n++;
        int[] out = new int[n];
        int k = 1;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n') out[k++] = i + 1;
        }
        return out;
    }

    private int[] lineCol(String text, int[] starts, int off) {
        if (off < 0) off = 0;
        if (off > text.length()) off = text.length();
        int lo = 0, hi = starts.length - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (starts[mid] <= off) lo = mid;
            else hi = mid - 1;
        }
        return new int[]{lo, off - starts[lo]};
    }

    private int[] selection() {
        long h = editor.docHandle();
        int al = Native.nativeAnchorLine(h), ac = Native.nativeAnchorCol(h);
        int cl = Native.nativeCursorLine(h), cc = Native.nativeCursorCol(h);
        int a = lineStarts[Math.max(0, Math.min(al, lineStarts.length - 1))] + ac;
        int c = lineStarts[Math.max(0, Math.min(cl, lineStarts.length - 1))] + cc;
        if (a > doc.length()) a = doc.length();
        if (c > doc.length()) c = doc.length();
        return new int[]{Math.min(a, c), Math.max(a, c)};
    }

    // ------------------------------------------------------------ 搜索
    private static boolean isWordChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    private static boolean boundary(String s, int start, int len) {
        if (start > 0 && isWordChar(s.charAt(start - 1))) return false;
        int e = start + len;
        return e >= s.length() || !isWordChar(s.charAt(e));
    }

    static String unescape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\' || i + 1 >= s.length()) {
                sb.append(c);
                continue;
            }
            char n = s.charAt(i + 1);
            if (n == 'n') {
                sb.append('\n');
                i++;
            } else if (n == 't') {
                sb.append('\t');
                i++;
            } else if (n == 'r') {
                sb.append('\r');
                i++;
            } else if (n == '\\') {
                sb.append('\\');
                i++;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private int indexOf(String hay, String needle, int from, boolean ignoreCase) {
        if (needle.isEmpty()) return -1;
        if (!ignoreCase) return hay.indexOf(needle, from);
        int last = hay.length() - needle.length();
        for (int i = Math.max(0, from); i <= last; i++) {
            if (hay.regionMatches(true, i, needle, 0, needle.length())) return i;
        }
        return -1;
    }

    /** 文档被改过（在查找栏里替换，或用户点回编辑区改字）就重算匹配。 */
    private void ensureFresh() {
        int rev = Native.nativeRevision(editor.docHandle());
        if (rev != lastRev) rebuildMatches(true);
    }

    private void rebuildMatches(boolean showCount) {
        doc = editor.text();
        lineStarts = buildLineStarts(doc);
        matches.clear();
        pattern = null;
        lastRev = Native.nativeRevision(editor.docHandle());
        String q = find.getText().toString();
        if (q.isEmpty()) {
            current = -1;
            if (showCount) setStatus(Lang.s("输入查找内容"));
            return;
        }
        if (Boolean.TRUE.equals(chipRe.getTag())) {
            int flags = Pattern.MULTILINE
                    | (Boolean.TRUE.equals(chipAa.getTag()) ? Pattern.CASE_INSENSITIVE : 0);
            String body = q;
            if (Boolean.TRUE.equals(chipWord.getTag())) body = "(?<!\\w)(?:" + body + ")(?!\\w)";
            try {
                pattern = Pattern.compile(body, flags);
            } catch (Exception ex) {
                current = -1;
                if (showCount) setStatus(Lang.s("正则有误：") + ex.getMessage());
                return;
            }
            Matcher m = pattern.matcher(doc);
            while (matches.size() < MAX_MATCHES && m.find()) {
                matches.add(new int[]{m.start(), m.end()});
            }
        } else {
            String needle = unescape(q);
            if (needle.isEmpty()) {
                current = -1;
                if (showCount) setStatus(Lang.s("输入查找内容"));
                return;
            }
            boolean ci = Boolean.TRUE.equals(chipAa.getTag());
            boolean ww = Boolean.TRUE.equals(chipWord.getTag());
            int from = 0;
            while (matches.size() < MAX_MATCHES) {
                int i = indexOf(doc, needle, from, ci);
                if (i < 0) break;
                if (!ww || boundary(doc, i, needle.length())) {
                    matches.add(new int[]{i, i + needle.length()});
                }
                from = i + Math.max(1, needle.length());
            }
        }
        current = -1;
        if (!showCount) return;
        if (matches.isEmpty()) {
            setStatus(Lang.s("没有匹配"));
        } else {
            setStatus(Lang.s("共 ") + matches.size() + Lang.s(" 处")
                    + (matches.size() >= MAX_MATCHES ? Lang.s("（已达上限）") : ""));
        }
    }

    private void select(int idx) {
        int[] m = matches.get(idx);
        int[] a = lineCol(doc, lineStarts, m[0]);
        int[] b = lineCol(doc, lineStarts, m[1]);
        editor.selectRange(a[0], a[1], b[0], b[1]);
        current = idx;
        setStatus(Lang.s("第 ") + (idx + 1) + " / " + matches.size());
    }

    private void refreshThenSelect(int offset, boolean forward) {
        rebuildMatches(false);
        if (matches.isEmpty()) {
            setStatus(Lang.s("没有匹配"));
            return;
        }
        int idx = -1;
        if (forward) {
            for (int i = 0; i < matches.size(); i++) {
                if (matches.get(i)[0] >= offset) {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) idx = 0;
        } else {
            for (int i = matches.size() - 1; i >= 0; i--) {
                if (matches.get(i)[1] <= offset) {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) idx = matches.size() - 1;
        }
        select(idx);
    }

    private void findNext() {
        ensureFresh();
        if (matches.isEmpty()) {
            toast(Lang.s("没有找到"));
            return;
        }
        int[] sel = selection();
        int idx = -1;
        for (int i = 0; i < matches.size(); i++) {
            if (matches.get(i)[0] >= sel[1]) {
                idx = i;
                break;
            }
        }
        if (idx < 0) idx = 0;
        select(idx);
    }

    private void findPrev() {
        ensureFresh();
        if (matches.isEmpty()) {
            toast(Lang.s("没有找到"));
            return;
        }
        int[] sel = selection();
        int idx = -1;
        for (int i = matches.size() - 1; i >= 0; i--) {
            if (matches.get(i)[1] <= sel[0]) {
                idx = i;
                break;
            }
        }
        if (idx < 0) idx = matches.size() - 1;
        select(idx);
    }

    // ------------------------------------------------------------ 替换
    private String expand(String rep, Matcher m) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rep.length(); i++) {
            char c = rep.charAt(i);
            boolean dollar = c == '$';
            boolean slash = c == '\\';
            if ((dollar || slash) && i + 1 < rep.length()) {
                char n = rep.charAt(i + 1);
                if (n >= '0' && n <= '9') {
                    String v = null;
                    try {
                        v = m.group(n - '0');
                    } catch (Exception ignored) {
                    }
                    sb.append(v == null ? "" : v);
                    i++;
                    continue;
                }
                if (slash) {
                    if (n == 'n') {
                        sb.append('\n');
                        i++;
                        continue;
                    }
                    if (n == 't') {
                        sb.append('\t');
                        i++;
                        continue;
                    }
                    if (n == 'r') {
                        sb.append('\r');
                        i++;
                        continue;
                    }
                    if (n == '\\') {
                        sb.append('\\');
                        i++;
                        continue;
                    }
                }
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private Matcher matcherAt(int start) {
        Matcher m = pattern.matcher(doc);
        m.useTransparentBounds(true);
        m.region(start, doc.length());
        return m;
    }

    private void replaceCurrent() {
        ensureFresh();
        int[] sel = selection();
        int idx = -1;
        for (int i = 0; i < matches.size(); i++) {
            int[] m = matches.get(i);
            if (m[0] == sel[0] && m[1] == sel[1]) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            findNext();
            toast(Lang.s("已定位到匹配项，再点一次「替换」"));
            return;
        }
        int[] m = matches.get(idx);
        String raw = repl.getText().toString();
        String rep;
        if (pattern != null) {
            Matcher mm = matcherAt(m[0]);
            if (mm.lookingAt() && mm.start() == m[0] && mm.end() == m[1]) {
                rep = expand(raw, mm);
            } else {
                rep = unescape(raw);
            }
        } else {
            rep = unescape(raw);
        }
        String nd = doc.substring(0, m[0]) + rep + doc.substring(m[1]);
        int caret = m[0] + rep.length();
        int[] lc = lineCol(nd, buildLineStarts(nd), caret);
        editor.replaceWholeText(nd, lc[0], lc[1]);
        toast(Lang.s("已替换"));
        refreshThenSelect(caret, true);
    }

    private void replaceAll() {
        ensureFresh();
        if (matches.isEmpty()) {
            toast(Lang.s("没有找到"));
            return;
        }
        String raw = repl.getText().toString();
        StringBuilder sb = new StringBuilder();
        int last = 0, first = -1;
        if (pattern != null) {
            Matcher m = pattern.matcher(doc);
            while (m.find()) {
                sb.append(doc, last, m.start());
                if (first < 0) first = sb.length();
                sb.append(expand(raw, m));
                last = m.end();
            }
            sb.append(doc, last, doc.length());
        } else {
            String rep = unescape(raw);
            for (int[] mt : matches) {
                sb.append(doc, last, mt[0]);
                if (first < 0) first = sb.length();
                sb.append(rep);
                last = mt[1];
            }
            sb.append(doc, last, doc.length());
        }
        String nd = sb.toString();
        int caret = first < 0 ? 0 : first;
        int[] lc = lineCol(nd, buildLineStarts(nd), caret);
        int n = matches.size();
        editor.replaceWholeText(nd, lc[0], lc[1]);
        toast(Lang.s("已替换 ") + n + Lang.s(" 处"));
        rebuildMatches(false);
        if (matches.isEmpty()) {
            setStatus(Lang.s("已替换 ") + n + Lang.s(" 处，完成"));
        } else {
            setStatus(Lang.s("已替换 ") + n + Lang.s(" 处，还有 ") + matches.size()
                    + Lang.s(" 处未替换"));
        }
    }
}
