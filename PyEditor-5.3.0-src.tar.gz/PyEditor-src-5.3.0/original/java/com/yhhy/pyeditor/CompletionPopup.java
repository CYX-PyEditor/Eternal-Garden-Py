package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;

/** Small floating list of completion candidates (does not steal IME focus). */
class CompletionPopup {
    interface Callback {
        void onPick(String name, int kind);
    }

    private final Context ctx;
    private PopupWindow pw;
    private ListView lv;
    private final ArrayList<String[]> items = new ArrayList<>();
    private Callback cb;
    private int sel = 0;
    private boolean showing = false;

    CompletionPopup(Context c) {
        ctx = c;
    }

    void setCallback(Callback c) {
        cb = c;
    }

    boolean isShowing() {
        return showing && pw != null && pw.isShowing();
    }

    void dismiss() {
        showing = false;
        if (pw != null) {
            try {
                pw.dismiss();
            } catch (Exception ignored) {
            }
        }
    }

    private static String kindLabel(int kind) {
        switch (kind) {
            case 0: return Lang.s("变量");
            case 1: return Lang.s("参数");
            case 2: return Lang.s("函数");
            case 3: return Lang.s("类");
            case 4: return Lang.s("模块");
            case 5: return Lang.s("属性");
            case 20: return Lang.s("关键字");
            case 21: return Lang.s("常量");
            case 22: return Lang.s("内置");
            case 23: return Lang.s("片段");
            default: return "";
        }
    }

    private static int kindColor(int kind) {
        switch (kind) {
            case 3: return 0xFFE5C07B;
            case 2: return 0xFF61AFEF;
            case 1: return 0xFFD19A66;
            case 0: return 0xFFABB2BF;
            case 4: return 0xFF98C379;
            case 5: return 0xFF56B6C2;
            case 20: return 0xFFC678DD;
            case 21: return 0xFFD19A66;
            case 22: return 0xFF61AFEF;
            case 23: return 0xFFE5C07B;
            default: return 0xFF9DA5B4;
        }
    }

    void show(View anchor, String[] raw, String prefix, int caretX, int caretY, int lineH) {
        dismiss();
        items.clear();
        float d = ctx.getResources().getDisplayMetrics().density;
        int maxW = 0;
        for (String s : raw) {
            int tab = s.indexOf('\t');
            if (tab < 0) continue;
            int code = (s.charAt(0) - '0') + 10 * (s.charAt(2) - '0');
            String name = s.substring(tab + 1);
            items.add(new String[]{name, String.valueOf(code)});
            maxW = Math.max(maxW, name.length());
        }
        if (items.isEmpty()) return;

        int rowH = (int) (36 * d);
        int rows = Math.min(items.size(), 6);
        int width = (int) Math.min(260 * d, Math.max(150 * d, maxW * 9 * d + 90 * d));
        int height = rows * rowH + (int) (6 * d);

        ListView list = new ListView(ctx);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setVerticalScrollBarEnabled(true);
        list.setBackgroundColor(0xFF21252B);
        list.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return items.size();
            }

            @Override
            public Object getItem(int position) {
                return items.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LinearLayout row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding((int) (10 * d), 0, (int) (8 * d), 0);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setBackgroundColor(position == sel ? 0xFF3E4451 : 0xFF21252B);
                String[] it = items.get(position);
                int kind = Integer.parseInt(it[1]);
                TextView badge = new TextView(ctx);
                badge.setText(kindLabel(kind));
                badge.setTextSize(9.5f);
                badge.setTextColor(kindColor(kind));
                badge.setPadding(0, 0, (int) (6 * d), 0);
                badge.setMinWidth((int) (34 * d));
                TextView name = new TextView(ctx);
                name.setText(it[0]);
                name.setTextSize(14f);
                name.setTextColor(0xFFE6E6E6);
                name.setTypeface(android.graphics.Typeface.MONOSPACE);
                row.addView(badge);
                row.addView(name);
                return row;
            }
        });
        list.setOnItemClickListener((parent, view, position, id) -> {
            sel = position;
            pickCurrent();
        });
        lv = list;
        sel = 0;

        pw = new PopupWindow(list, width, height, false);
        pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pw.setOutsideTouchable(true);
        pw.setTouchable(true);
        pw.setFocusable(false);
        pw.setAnimationStyle(0);

        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int ax = loc[0] + caretX;
        int ay = loc[1] + caretY;
        int screenH = ctx.getResources().getDisplayMetrics().heightPixels;
        int y = ay + lineH;
        if (y + height > screenH - (int) (8 * d)) {
            y = ay - height;
            if (y < (int) (8 * d)) y = ay + lineH;
        }
        int x = Math.max((int) (4 * d), Math.min(ax - (int) (20 * d),
                ctx.getResources().getDisplayMetrics().widthPixels - width - (int) (4 * d)));
        try {
            pw.showAtLocation(anchor, Gravity.NO_GRAVITY, x, Math.max(0, y));
            showing = true;
        } catch (Exception e) {
            showing = false;
        }
    }

    void move(int dir) {
        if (items.isEmpty()) return;
        sel += dir;
        if (sel < 0) sel = 0;
        if (sel >= items.size()) sel = items.size() - 1;
        if (lv != null) {
            lv.setSelection(sel);
            lv.invalidateViews();
        }
    }

    void pickCurrent() {
        if (items.isEmpty()) return;
        String[] it = items.get(Math.max(0, Math.min(sel, items.size() - 1)));
        dismiss();
        if (cb != null) cb.onPick(it[0], Integer.parseInt(it[1]));
    }
}
