package com.yhhy.pyeditor;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** 第三方库目录：files/site-packages/<name-version>/ 每个包一个目录，便于卸载。 */
public class SitePkgs {

    public static File root(Context c) {
        File d = new File(c.getFilesDir(), "site-packages");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    /** 所有包目录（按名字排序）。 */
    public static List<File> dirs(Context c) {
        List<File> out = new ArrayList<>();
        File[] kids = root(c).listFiles();
        if (kids != null) {
            java.util.Arrays.sort(kids);
            for (File f : kids) if (f.isDirectory()) out.add(f);
        }
        return out;
    }

    /** 冒号连接的路径串，供 PYTHONPATH 使用。 */
    public static String pathEnv(Context c) {
        StringBuilder sb = new StringBuilder();
        for (File f : dirs(c)) {
            if (sb.length() > 0) sb.append(':');
            sb.append(f.getAbsolutePath());
        }
        return sb.toString();
    }

    public static boolean isEmpty(Context c) {
        return dirs(c).isEmpty();
    }
}
