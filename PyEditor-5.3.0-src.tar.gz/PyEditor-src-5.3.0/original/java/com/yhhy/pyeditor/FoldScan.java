package com.yhhy.pyeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

/**
 * 赋值语句右侧的 list / dict / tuple / set 字面量扫描：多行的用于折叠，单行的用于行尾类型标注。
 *
 * <p>纯 Java、不依赖 Android，方便在 JVM 上直接测。规则：
 * <ul>
 *   <li>只认「最外层括号」且左侧是简单赋值目标
 *       （{@code cfg = ...}、{@code self.cfg = ...}、{@code x: dict[str, int] = ...}）</li>
 *   <li>多行折叠摘要 {@code cfg = dict[str, int] ...}；单行只给类型 {@code dict[str, int]}</li>
 *   <li>元素类型最多写两种，超过两种写 {@code Any}（字典的键、值两侧各自判断）</li>
 *   <li>字符串、三引号字符串、注释里的括号不计入深度</li>
 * </ul>
 * 括号没有闭合、或左侧不是赋值目标（{@code print([}、{@code return [}）时不产出结果。
 */
final class FoldScan {

    static final class Block {
        /** 起始行（含）。 */
        final int start;
        /** 结束行（含）；单行字面量时等于 start。 */
        final int end;
        /** dict / list / tuple / set。 */
        final String kind;
        /** 行尾类型标注文本，如 {@code dict[str, int]}、{@code list[int, str]}。 */
        final String typeText;
        /** 折叠摘要；单行时为空串。 */
        final String summary;

        Block(int s, int e, String k, String t, String sum) {
            start = s;
            end = e;
            kind = k;
            typeText = t;
            summary = sum;
        }
    }

    /** 构造调用名 → 折叠里显示的类型。 */
    private static final HashMap<String, String> CTOR = new HashMap<>();

    static {
        CTOR.put("dict", "dict");
        CTOR.put("list", "list");
        CTOR.put("set", "set");
        CTOR.put("frozenset", "set");
        CTOR.put("tuple", "tuple");
        CTOR.put("defaultdict", "dict");
        CTOR.put("OrderedDict", "dict");
        CTOR.put("Counter", "dict");
    }

    private static final HashSet<String> KEYWORDS = new HashSet<>(Arrays.asList(
            "return", "yield", "await", "assert", "del", "if", "elif", "else",
            "while", "for", "in", "with", "lambda", "and", "or", "not", "is",
            "import", "from", "as", "class", "def", "try", "except", "finally",
            "raise", "pass", "break", "continue", "global", "nonlocal",
            "match", "case", "async"));

    private FoldScan() {
    }

    /**
     * 扫描整篇（已按 \n 拆好行）的赋值字面量。
     *
     * @return 按 start 升序；每个 start 最多一个
     */
    static ArrayList<Block> scan(String[] txt) {
        ArrayList<Block> out = new ArrayList<>();
        if (txt == null || txt.length == 0) return out;

        int depth = 0;
        boolean inStr = false;
        boolean inTriple = false;
        char quote = 0;
        int startLine = -1;
        char openCh = 0;
        String ctorKind = null;
        String name = null;
        StringBuilder content = new StringBuilder();

        for (int li = 0; li < txt.length; li++) {
            String s = txt[li];
            inStr = false;
            for (int ci = 0; ci < s.length(); ci++) {
                char c = s.charAt(ci);
                if (inTriple) {
                    if (depth >= 1) content.append(c);
                    if (c == '\\') {
                        if (ci + 1 < s.length() && depth >= 1) content.append(s.charAt(ci + 1));
                        ci++;
                        continue;
                    }
                    if (c == quote && ci + 2 < s.length()
                            && s.charAt(ci + 1) == quote && s.charAt(ci + 2) == quote) {
                        if (depth >= 1) content.append(c).append(c);
                        inTriple = false;
                        ci += 2;
                    }
                    continue;
                }
                if (inStr) {
                    if (depth >= 1) content.append(c);
                    if (c == '\\') {
                        if (ci + 1 < s.length() && depth >= 1) content.append(s.charAt(ci + 1));
                        ci++;
                        continue;
                    }
                    if (c == quote) inStr = false;
                    continue;
                }
                if (c == '#') break;
                if (c == '\'' || c == '"') {
                    boolean triple = ci + 2 < s.length()
                            && s.charAt(ci + 1) == c && s.charAt(ci + 2) == c;
                    if (depth >= 1) {
                        if (triple) content.append(c).append(c).append(c);
                        else content.append(c);
                    }
                    if (triple) {
                        inTriple = true;
                        quote = c;
                        ci += 2;
                    } else {
                        inStr = true;
                        quote = c;
                    }
                    continue;
                }
                if (c == '(' || c == '[' || c == '{') {
                    if (depth == 0 && startLine < 0) {
                        startLine = li;
                        openCh = c;
                        String pre = rtrim(s.substring(0, ci));
                        ctorKind = c == '(' ? ctorKindOf(pre) : null;
                        name = targetName(ctorKind == null ? pre
                                : rtrim(pre.substring(0, pre.length() - ctorKind.length())));
                        content.setLength(0);
                    } else if (depth >= 1) {
                        content.append(c);
                    }
                    depth++;
                    continue;
                }
                if (c == ')' || c == ']' || c == '}') {
                    if (depth > 0) {
                        if (depth == 1) {
                            if (startLine >= 0) {
                                finish(out, startLine, li, openCh, ctorKind, name, content.toString());
                                startLine = -1;
                                name = null;
                                ctorKind = null;
                                content.setLength(0);
                            }
                            depth--;
                        } else {
                            content.append(c);
                            depth--;
                        }
                    }
                    continue;
                }
                if (depth >= 1) content.append(c);
            }
            if (startLine >= 0 && depth >= 1) content.append(' ');
        }
        return out;
    }

    private static void finish(ArrayList<Block> out, int startLine, int endLine,
                               char openCh, String ctorKind, String name, String content) {
        if (name == null) return;
        String kind;
        if (ctorKind != null) {
            kind = CTOR.get(ctorKind);
        } else if (openCh == '[') {
            kind = "list";
        } else if (openCh == '(') {
            kind = "tuple";
        } else if (content.trim().isEmpty()) {
            kind = "dict";
        } else {
            kind = (hasTopLevelColon(content) || content.trim().startsWith("**")) ? "dict" : "set";
        }
        if (kind == null) return;
        String typeText = typeText(kind, content);
        // 单行也给摘要：折叠成同一行的 `items = list[int] ...`
        String summary = name + " = " + typeText + " ...";
        out.add(new Block(startLine, endLine, kind, typeText, summary));
    }

    // ---------------------------------------------------------------- 类型推断
    private static String typeText(String kind, String content) {
        ArrayList<String> elems = splitTopLevel(content, ',');
        if ("dict".equals(kind)) {
            ArrayList<String> keys = new ArrayList<>();
            ArrayList<String> vals = new ArrayList<>();
            for (String e : elems) {
                if (e.trim().isEmpty()) continue;
                int c = indexOfTopLevelColon(e);
                if (c < 0) {
                    keys.add("Any");
                    vals.add("Any");
                    continue;
                }
                keys.add(classify(e.substring(0, c)));
                vals.add(classify(e.substring(c + 1)));
            }
            if (keys.isEmpty()) return "dict";
            return "dict[" + sideKinds(keys, "|") + ", " + sideKinds(vals, "|") + "]";
        }
        ArrayList<String> ks = new ArrayList<>();
        for (String e : elems) {
            if (e.trim().isEmpty()) continue;
            String k = classify(e);
            if (k != null) ks.add(k);
        }
        if (ks.isEmpty()) return kind;
        return kind + "[" + sideKinds(ks, ", ") + "]";
    }

    /** 去重、保持首次出现顺序；最多两种，超过写 Any。 */
    private static String sideKinds(ArrayList<String> kinds, String sep) {
        ArrayList<String> uniq = new ArrayList<>();
        for (String k : kinds) {
            if (k == null) continue;
            boolean has = false;
            for (String u : uniq) {
                if (u.equals(k)) {
                    has = true;
                    break;
                }
            }
            if (!has) uniq.add(k);
        }
        if (uniq.isEmpty()) return "Any";
        if (uniq.size() > 2) return "Any";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < uniq.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(uniq.get(i));
        }
        return sb.toString();
    }

    /** 判断一个元素字面量的大致类型；认不出就是 Any。 */
    static String classify(String raw) {
        if (raw == null) return "Any";
        String e = raw.trim();
        while (e.length() >= 2 && e.charAt(0) == '(' && e.charAt(e.length() - 1) == ')'
                && balancedOuter(e)) {
            e = e.substring(1, e.length() - 1).trim();
        }
        if (e.isEmpty()) return "Any";
        char c0 = e.charAt(0);
        if (c0 == '\'' || c0 == '"') return "str";
        int p = 0;
        while (p < e.length() && p < 2 && "rbufRBUF".indexOf(e.charAt(p)) >= 0) p++;
        if (p > 0 && p < e.length()) {
            char q = e.charAt(p);
            if (q == '\'' || q == '"') {
                return hasPrefixLetter(e.substring(0, p), 'b') ? "bytes" : "str";
            }
        }
        if (e.equals("True") || e.equals("False")) return "bool";
        if (e.equals("None")) return "None";
        if (isIntLiteral(e)) return "int";
        if (isFloatLiteral(e)) return "float";
        if (isComplexLiteral(e)) return "complex";
        if (c0 == '[') return "list";
        if (c0 == '{') return (hasTopLevelColon(e) || e.startsWith("{**")) ? "dict" : "set";
        if (c0 == '(') return "tuple";
        return "Any";
    }

    private static boolean hasPrefixLetter(String p, char lower) {
        for (int i = 0; i < p.length(); i++) {
            if (Character.toLowerCase(p.charAt(i)) == lower) return true;
        }
        return false;
    }

    private static boolean isIntLiteral(String e) {
        return e.matches("[-+]?(0[xX][0-9a-fA-F_]+|0[bB][01_]+|0[oO][0-7_]+|[0-9][0-9_]*)");
    }

    private static boolean isFloatLiteral(String e) {
        return e.matches("[-+]?(([0-9][0-9_]*)?\\.[0-9][0-9_]*([eE][-+]?[0-9]+)?"
                + "|[0-9][0-9_]*[eE][-+]?[0-9]+|[0-9][0-9_]*\\.)");
    }

    private static boolean isComplexLiteral(String e) {
        return e.matches("[-+]?([0-9][0-9_.]*|[0-9][0-9_]*\\.[0-9][0-9_]*)[jJ]");
    }

    private static boolean balancedOuter(String e) {
        int d = 0;
        for (int i = 0; i < e.length(); i++) {
            char c = e.charAt(i);
            if (c == '(') d++;
            else if (c == ')') {
                d--;
                if (d == 0) return i == e.length() - 1;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- 文本切分
    /** 按顶层分隔符切分（跳过括号、字符串）。 */
    private static ArrayList<String> splitTopLevel(String s, char sep) {
        ArrayList<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        char q = 0;
        boolean inStr = false;
        boolean inTriple = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inTriple) {
                sb.append(c);
                if (c == '\\' && i + 1 < s.length()) {
                    sb.append(s.charAt(++i));
                    continue;
                }
                if (c == q && i + 2 < s.length() && s.charAt(i + 1) == q && s.charAt(i + 2) == q) {
                    sb.append(q).append(q);
                    i += 2;
                    inTriple = false;
                }
                continue;
            }
            if (inStr) {
                sb.append(c);
                if (c == '\\' && i + 1 < s.length()) {
                    sb.append(s.charAt(++i));
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                sb.append(c);
                if (i + 2 < s.length() && s.charAt(i + 1) == c && s.charAt(i + 2) == c) {
                    sb.append(c).append(c);
                    i += 2;
                    inTriple = true;
                } else {
                    inStr = true;
                }
                q = c;
                continue;
            }
            if (c == '(' || c == '[' || c == '{') {
                depth++;
                sb.append(c);
                continue;
            }
            if (c == ')' || c == ']' || c == '}') {
                depth--;
                sb.append(c);
                continue;
            }
            if (c == sep && depth == 0) {
                out.add(sb.toString());
                sb.setLength(0);
                continue;
            }
            sb.append(c);
        }
        if (sb.length() > 0) out.add(sb.toString());
        return out;
    }

    /** 顶层第一个冒号的下标；没有返回 -1。 */
    static int indexOfTopLevelColon(String s) {
        int depth = 0;
        char q = 0;
        boolean inStr = false;
        boolean inTriple = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inTriple) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q && i + 2 < s.length() && s.charAt(i + 1) == q && s.charAt(i + 2) == q) {
                    i += 2;
                    inTriple = false;
                }
                continue;
            }
            if (inStr) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == q) inStr = false;
                continue;
            }
            if (c == '\'' || c == '"') {
                if (i + 2 < s.length() && s.charAt(i + 1) == c && s.charAt(i + 2) == c) {
                    inTriple = true;
                    i += 2;
                } else {
                    inStr = true;
                }
                q = c;
                continue;
            }
            if (c == '(' || c == '[' || c == '{') depth++;
            else if (c == ')' || c == ']' || c == '}') depth--;
            else if (c == ':' && depth == 0) return i;
        }
        return -1;
    }

    private static boolean hasTopLevelColon(String content) {
        return indexOfTopLevelColon(content) >= 0;
    }

    // ---------------------------------------------------------------- 赋值目标
    /** 行首（括号前）以 dict( / list( … 结尾时返回构造名。 */
    private static String ctorKindOf(String pre) {
        int e = pre.length();
        int b = e;
        while (b > 0 && (Character.isLetterOrDigit(pre.charAt(b - 1)) || pre.charAt(b - 1) == '_')) b--;
        if (b == e) return null;
        String w = pre.substring(b, e);
        return CTOR.containsKey(w) ? w : null;
    }

    private static String targetName(String pre) {
        String p = rtrim(pre);
        if (!p.endsWith("=")) return null;
        if (p.length() >= 2) {
            char c = p.charAt(p.length() - 2);
            if ("=!<>+-*/%&|^~:".indexOf(c) >= 0) return null;
        }
        String left = p.substring(0, p.length() - 1).trim();
        int colon = left.indexOf(':');
        if (colon >= 0) left = left.substring(0, colon).trim();
        if (left.isEmpty()) return null;
        if (!isDottedName(left)) return null;
        if (KEYWORDS.contains(left)) return null;
        return left;
    }

    private static boolean isDottedName(String s) {
        int i = 0;
        int n = s.length();
        while (i < n) {
            char c = s.charAt(i);
            if (!(Character.isLetter(c) || c == '_')) return false;
            i++;
            while (i < n && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
            if (i == n) return true;
            if (s.charAt(i) != '.') return false;
            i++;
            if (i == n) return false;
        }
        return false;
    }

    private static String rtrim(String s) {
        int e = s.length();
        while (e > 0 && (s.charAt(e - 1) == ' ' || s.charAt(e - 1) == '\t')) e--;
        return s.substring(0, e);
    }
}
