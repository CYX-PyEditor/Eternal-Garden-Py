package com.yhhy.pyeditor;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** 编译器仓库：下载压缩包 → 解到 files/compilers/<name> → 找 bin 下的 clang/gcc/tcc。 */
public class CompilerStore {

    public static File root(Context c) {
        File d = new File(c.getFilesDir(), "compilers");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    public static List<File> installed(Context c) {
        List<File> out = new ArrayList<>();
        File[] kids = root(c).listFiles();
        if (kids != null) {
            java.util.Arrays.sort(kids);
            for (File f : kids) {
                if (f.isDirectory() && findBinary(f) != null) out.add(f);
            }
        }
        return out;
    }

    /** 在该目录（含两级子目录）里找可执行编译器。 */
    public static File findBinary(File dir) {
        String[] names = {"clang", "clang-18", "clang-19", "clang-17", "gcc", "cc", "tcc", "zig"};
        File[] kids = dir.listFiles();
        if (kids == null) return null;
        for (String n : names) {
            File f = new File(dir, n);
            if (f.isFile()) return f;
        }
        for (File k : kids) {
            if (!k.isDirectory()) continue;
            for (String n : names) {
                File f = new File(k, n);
                if (f.isFile()) return f;
            }
            for (File k2 : k.listFiles() == null ? new File[0] : k.listFiles()) {
                if (!k2.isDirectory()) continue;
                for (String n : names) {
                    File f = new File(k2, n);
                    if (f.isFile()) return f;
                }
            }
        }
        return null;
    }

    /** 通用解压（按文件名判断 zip / tar.gz / tar.xz），供 Python 头文件包复用。 */
    public static void extract(byte[] data, String name, File dst) throws Exception {
        String lower = name == null ? "" : name.toLowerCase();
        if (lower.endsWith(".zip") || lower.endsWith(".whl")) {
            unzip(data, dst);
        } else if (lower.endsWith(".tar.xz") || lower.endsWith(".txz")) {
            untarStream(new org.tukaani.xz.XZInputStream(
                    new java.io.ByteArrayInputStream(data)), dst);
        } else {
            untarGz(data, dst);
        }
    }

    /** 通用下载。 */
    public static byte[] fetch(String url) throws Exception {
        return download(url);
    }

    /** 下载并解压；返回 null 表示成功，否则错误信息。 */
    public static String install(Context c, String url) throws Exception {
        String base = url.substring(url.lastIndexOf('/') + 1);
        int dot = base.lastIndexOf('.');
        if (base.endsWith(".tar.gz") || base.endsWith(".tgz")) {
            if (dot > 0) {
                int cut = base.endsWith(".tar.gz") ? base.length() - 7 : base.length() - 4;
                base = base.substring(0, cut);
            }
        } else if (dot > 0) {
            base = base.substring(0, dot);
        }
        File dst = new File(root(c), base);
        deleteRec(dst);
        dst.mkdirs();

        byte[] data = download(url);
        if (url.endsWith(".zip") || url.endsWith(".whl")) {
            unzip(data, dst);
        } else if (url.endsWith(".tar.xz") || url.endsWith(".txz")) {
            untarStream(new org.tukaani.xz.XZInputStream(
                    new java.io.ByteArrayInputStream(data)), dst);
        } else {
            untarGz(data, dst);
        }
        if (findBinary(dst) == null) {
            return Lang.s("解压后在目录里没有找到 clang / gcc / tcc");
        }
        return null;
    }

    /** 从本地文件导入（file 已在本应用可读的位置）。 */
    public static String importLocal(Context c, java.io.File src) {
        try {
            String base = src.getName();
            String lower = base.toLowerCase();
            if (lower.endsWith(".tar.xz") || lower.endsWith(".txz")) {
                base = base.substring(0, base.lastIndexOf('.'));
                if (base.toLowerCase().endsWith(".tar")) base = base.substring(0, base.length() - 4);
            } else if (lower.endsWith(".tar.gz") || lower.endsWith(".tgz")) {
                int cut = lower.endsWith(".tgz") ? base.length() - 4 : base.length() - 7;
                base = base.substring(0, cut);
            } else if (lower.contains(".")) {
                base = base.substring(0, base.lastIndexOf('.'));
            }
            File dst = new File(root(c), base);
            deleteRec(dst);
            dst.mkdirs();
            byte[] data = readAll(new java.io.FileInputStream(src));
            if (lower.endsWith(".zip")) {
                unzip(data, dst);
            } else if (lower.endsWith(".tar.xz") || lower.endsWith(".txz")) {
                untarStream(new org.tukaani.xz.XZInputStream(
                        new java.io.ByteArrayInputStream(data)), dst);
            } else {
                untarGz(data, dst);
            }
            if (findBinary(dst) == null) return Lang.s("解压后没有找到 clang / gcc / tcc / zig");
            return null;
        } catch (Exception e) {
            return e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    /** 探活：能执行并返回 0 才算可用；返回 null 成功，否则错误说明。 */
    public static String probe(File bin) {
        try {
            bin.setExecutable(true, false);
            ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "--version");
            pb.redirectErrorStream(true);
            Process p = pb.start();
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            int n = 0;
            while ((line = br.readLine()) != null && n++ < 5) {
                sb.append(line).append('\n');
            }
            int code = p.waitFor();
            if (code == 0) return null;
            return Lang.s("退出码 ") + code + "：" + sb;
        } catch (Exception e) {
            String m = e.getMessage() == null ? "" : e.getMessage();
            if (m.contains("EACCES") || m.contains("Permission denied")) {
                return Lang.s("无法执行（Android 10+ 禁止 App 执行自身数据目录里的程序）");
            }
            return e.getClass().getSimpleName() + ": " + m;
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    private static byte[] download(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(180000);
        conn.setInstanceFollowRedirects(true);
        InputStream in = conn.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        conn.disconnect();
        return bo.toByteArray();
    }

    private static void unzip(byte[] data, File dst) throws Exception {
        ZipInputStream zin = new ZipInputStream(new java.io.ByteArrayInputStream(data));
        ZipEntry e;
        String rootPath = dst.getCanonicalPath() + File.separator;
        byte[] buf = new byte[65536];
        while ((e = zin.getNextEntry()) != null) {
            File out = new File(dst, e.getName());
            if (!out.getCanonicalPath().startsWith(rootPath)) continue;
            if (e.isDirectory()) {
                out.mkdirs();
                continue;
            }
            File p = out.getParentFile();
            if (p != null) p.mkdirs();
            FileOutputStream fo = new FileOutputStream(out);
            int n;
            while ((n = zin.read(buf)) > 0) fo.write(buf, 0, n);
            fo.close();
        }
        zin.close();
    }

    /** 极简 tar 读取（只处理普通文件 + 目录），输入先 gunzip。 */
    private static void untarGz(byte[] data, File dst) throws Exception {
        untarStream(new GZIPInputStream(new java.io.ByteArrayInputStream(data)), dst);
    }

    private static void untarStream(InputStream gz, File dst) throws Exception {
        byte[] header = new byte[512];
        String rootPath = dst.getCanonicalPath() + File.separator;
        while (true) {
            int got = readFully(gz, header, 512);
            if (got < 512) break;
            boolean zero = true;
            for (byte b : header) {
                if (b != 0) {
                    zero = false;
                    break;
                }
            }
            if (zero) break;
            String name = new String(header, 0, 100, "UTF-8").trim().replace("\0", "");
            long size = 0;
            try {
                String sz = new String(header, 124, 12, "UTF-8").trim().replace("\0", "").trim();
                if (!sz.isEmpty()) size = Long.parseLong(sz, 8);
            } catch (Exception ignored) {
            }
            char type = (char) header[156];
            if (name.startsWith("./")) name = name.substring(2);
            File out = new File(dst, name);
            if (type == '5' || name.endsWith("/")) {
                out.mkdirs();
                skip(gz, size);
            } else if (type == '0' || type == 0) {
                if (!out.getCanonicalPath().startsWith(rootPath)) {
                    skip(gz, size);
                } else {
                    File p = out.getParentFile();
                    if (p != null) p.mkdirs();
                    FileOutputStream fo = new FileOutputStream(out);
                    copy(gz, fo, size);
                    fo.close();
                }
            } else {
                skip(gz, size);
            }
            long pad = (512 - (size % 512)) % 512;
            if (pad > 0) skip(gz, pad);
        }
        gz.close();
    }

    private static int readFully(InputStream in, byte[] buf, int len) throws Exception {
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n <= 0) break;
            off += n;
        }
        return off;
    }

    private static void copy(InputStream in, FileOutputStream out, long size) throws Exception {
        byte[] buf = new byte[65536];
        long left = size;
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n <= 0) break;
            out.write(buf, 0, n);
            left -= n;
        }
    }

    private static void skip(InputStream in, long size) throws Exception {
        long left = size;
        byte[] buf = new byte[8192];
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n <= 0) break;
            left -= n;
        }
    }

    public static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }
}
