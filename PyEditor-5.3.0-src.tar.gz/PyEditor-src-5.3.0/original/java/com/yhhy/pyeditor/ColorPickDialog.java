package com.yhhy.pyeditor;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Simple colour chooser: palette grid + hex input. */
class ColorPickDialog {

    interface OnColor {
        void onColor(int color);
    }

    private static final int[] PALETTE = {
            0xFFE06C75, 0xFFC678DD, 0xFF61AFEF, 0xFF98C379, 0xFFE5C07B, 0xFF56B6C2,
            0xFFD19A66, 0xFFABB2BF, 0xFFFFFFFF, 0xFF9DA5B4, 0xFF5C6370, 0xFF282C34,
            0xFFF92672, 0xFF66D9EF, 0xFFA6E22E, 0xFFFD971F, 0xFFAE81FF, 0xFFE6DB74,
            0xFFD73A49, 0xFF6F42C1, 0xFF032F62, 0xFF005CC5, 0xFFB31D28, 0xFFFFFFFF,
            0xFF859900, 0xFF268BD2, 0xFF2AA198, 0xFFB58900, 0xFFCB4B16, 0xFF6C71C4,
            0xFFFF7B72, 0xFF79C0FF, 0xFFA5D6FF, 0xFFD2A8FF, 0xFFFFA657, 0xFF0D1117,
            0xFF32C8FF, 0xFFFF4FB8, 0xFFFF9AD5, 0xFF9CD8FF, 0xFF7A6E8A, 0xFF171022
    };

    static void show(Context ctx, String title, int initial, OnColor cb) {
        float d = ctx.getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding((int) (14 * d), (int) (10 * d), (int) (14 * d), (int) (6 * d));

        EditText hex = new EditText(ctx);
        hex.setInputType(InputType.TYPE_CLASS_TEXT);
        hex.setText(String.format("%06X", initial & 0xFFFFFF));
        hex.setHint("RRGGBB");
        hex.setTextSize(14);
        hex.setSingleLine(true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.setMargins(0, 0, 0, (int) (8 * d));
        root.addView(hex, hp);

        LinearLayout grid = new LinearLayout(ctx);
        grid.setOrientation(LinearLayout.VERTICAL);
        int perRow = 6;
        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % perRow == 0) {
                row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutParams(new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, (int) (40 * d)));
                grid.addView(row);
            }
            final int color = PALETTE[i];
            View sw = new View(ctx);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(color);
            bg.setCornerRadius(4 * d);
            bg.setStroke((int) d, 0xFF606060);
            sw.setBackground(bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (34 * d), 1f);
            lp.setMargins((int) (2 * d), (int) (3 * d), (int) (2 * d), (int) (3 * d));
            row.addView(sw, lp);
            sw.setOnClickListener(v -> {
                cb.onColor(0xFF000000 | (color & 0xFFFFFF));
                alertDismiss();
            });
        }
        root.addView(grid);

        AlertDialog dlg = new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setView(root)
                .setPositiveButton(Lang.s("确定"), (dd, w) -> {
                    try {
                        long v = Long.parseLong(hex.getText().toString().trim(), 16);
                        cb.onColor(0xFF000000 | ((int) v & 0xFFFFFF));
                    } catch (Exception ignored) {
                    }
                })
                .setNegativeButton(Lang.s("取消"), null)
                .create();
        current = dlg;
        dlg.show();
    }

    private static AlertDialog current;

    private static void alertDismiss() {
        if (current != null) {
            current.dismiss();
            current = null;
        }
    }
}
