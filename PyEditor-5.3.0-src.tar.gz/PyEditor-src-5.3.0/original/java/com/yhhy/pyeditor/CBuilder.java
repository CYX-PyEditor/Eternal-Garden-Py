package com.yhhy.pyeditor;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

/**
 * 用 Shizuku(shell) 编译单文件 C 扩展：
 * App 把源码/头文件/编译器放到外部 files 目录（shell 可读），shell 复制到 /data/local/tmp 编译，
 * 产物 .so 再由 shell 写回外部目录，App 收进 site-packages 并试 import。
 */
final class CBuilder {

    interface Log {
        void line(String s);
    }

    private CBuilder() {
    }

    static boolean canRun(Context c) {
        return ShellBridge.granted() && PyHeaders.ready(c) && activeCompiler(c) != null;
    }

    static File activeCompilerDir(Context c) {
        String dir = Prefs.ccDir(c);
        if (dir != null && !dir.trim().isEmpty()) {
            File d = new File(dir.trim());
            if (CompilerStore.findBinary(d) != null) return d;
        }
        for (File d : CompilerStore.installed(c)) {
            if (CompilerStore.findBinary(d) != null) return d;
        }
        return null;
    }

    static File activeCompiler(Context c) {
        File d = activeCompilerDir(c);
        return d == null ? null : CompilerStore.findBinary(d);
    }

    static String compile(Context c, String module, byte[] source, Log log) {
        if (!ShellBridge.granted()) {
            return Lang.s("需要 Shizuku：请到 设置 → 终端 请求授权（当前身份：") + ShellBridge.who() + "）";
        }
        if (!PyHeaders.ready(c)) {
            return Lang.s("缺少 Python 头文件：请先在下方「Python 头文件」里下载或导入 pyinclude-3.12.tgz");
        }
        File ccDir = activeCompilerDir(c);
        File bin = ccDir == null ? null : CompilerStore.findBinary(ccDir);
        if (bin == null) {
            return Lang.s("没有可用编译器：请先下载/导入一个（推荐 Zig）");
        }
        File ext = c.getExternalFilesDir(null);
        if (ext == null) return Lang.s("拿不到 App 外部目录");
        File base = new File(ext, "cbuild");
        File outDir = new File(base, "out");
        try {
            File srcDir = new File(base, "src");
            if (!srcDir.isDirectory() && !srcDir.mkdirs()) return Lang.s("无法创建源码目录");
            File src = new File(srcDir, module + ".c");
            write(src, source);
            log.line(Lang.s("源码：") + src.getName() + "（" + source.length + " B）");

            log.line(Lang.s("准备头文件…"));
            File inc = PyHeaders.copyToExternal(c, base);
            if (inc == null) return Lang.s("头文件还没准备好");

            String ccName = safeName(ccDir.getName());
            File extCc = new File(new File(base, "cc"), ccName);
            if (CompilerStore.findBinary(extCc) == null) {
                CompilerStore.deleteRec(extCc);
                if (!extCc.mkdirs() && !extCc.isDirectory()) return Lang.s("无法创建编译器目录");
                log.line(Lang.s("复制编译器到外部目录（首次较慢）…"));
                copyTree(ccDir, extCc);
            }
            String binRel = bin.getAbsolutePath().substring(ccDir.getAbsolutePath().length() + 1);
            String remoteBin = "/data/local/tmp/pye-cc/" + ccName + "/" + binRel;
            String basePath = base.getAbsolutePath();
            if (!outDir.isDirectory() && !outDir.mkdirs()) return Lang.s("无法创建产物目录");

            String target = "aarch64-linux-android24";
            String cc = quote(remoteBin);
            String baseName = bin.getName();
            if (baseName.startsWith("zig")) {
                cc += " cc -target " + target;
            } else if (baseName.contains("clang")) {
                cc += " --target=" + target;
            }
            String cmd = "set -e\n"
                    + "rm -rf /data/local/tmp/pye-build\n"
                    + "mkdir -p /data/local/tmp/pye-build /data/local/tmp/pye-cc /data/local/tmp/pye-cache\n"
                    + "cp -r " + quote(basePath + "/include") + " /data/local/tmp/pye-build/include\n"
                    + "cp " + quote(src.getAbsolutePath()) + " /data/local/tmp/pye-build/\n"
                    + "if [ ! -x " + quote(remoteBin) + " ]; then\n"
                    + "  rm -rf " + quote("/data/local/tmp/pye-cc/" + ccName) + "\n"
                    + "  cp -r " + quote(basePath + "/cc/" + ccName) + " /data/local/tmp/pye-cc/\n"
                    + "  chmod -R 755 " + quote("/data/local/tmp/pye-cc/" + ccName) + "\n"
                    + "fi\n"
                    + "export ZIG_GLOBAL_CACHE_DIR=/data/local/tmp/pye-cache\n"
                    + "export ZIG_LOCAL_CACHE_DIR=/data/local/tmp/pye-cache\n"
                    + "cd /data/local/tmp/pye-build\n"
                    + cc + " -shared -fPIC -O2 -Wl,-z,max-page-size=16384"
                    + " -Wl,--allow-shlib-undefined -I include/Include -o out.so " + module + ".c\n"
                    + "cp out.so " + quote(basePath + "/out/" + module + ".so") + "\n";

            log.line(Lang.s("开始编译…"));
            int code = runCmd(cmd, log);
            if (code != 0 && target.endsWith("24")) {
                log.line(Lang.s("这个编译器不认 -target …android24，改用 aarch64-linux-android 重试…"));
                String cmd2 = cmd.replace("-target " + target, "-target aarch64-linux-android")
                        .replace("--target=" + target, "--target=aarch64-linux-android");
                code = runCmd(cmd2, log);
            }
            log.line(Lang.s("退出码 ") + code);
            if (code != 0) {
                return Lang.s("编译失败（退出码 ") + code + Lang.s("），看上面日志");
            }
            File so = new File(outDir, module + ".so");
            if (!so.isFile() || so.length() == 0) return Lang.s("编译器没有产出 out.so");
            // 目录名不能等于模块名，否则 import 会先撞上同名 namespace 包目录，
            // 找不到里面的 .so；用 <模块>-c 与 pip 的一包一目录保持一致。
            File dstDir = new File(c.getFilesDir(), "site-packages/" + module + "-c");
            CompilerStore.deleteRec(dstDir);
            if (!dstDir.mkdirs() && !dstDir.isDirectory()) return Lang.s("无法创建安装目录");
            copyFile(so, new File(dstDir, module + ".so"));
            log.line(Lang.s("已安装：site-packages/") + module + "-c/" + module + ".so（" + so.length() + " B）");
            String test = importTest(c, module);
            log.line(test);
            return test == null ? null : test;
        } catch (Exception e) {
            return e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    // ------------------------------------------------------------ 试 import
    /** 返回 null 成功，否则错误尾部。 */
    private static String importTest(Context c, String module) {
        try {
            String lib = c.getApplicationInfo().nativeLibraryDir;
            ProcessBuilder pb = new ProcessBuilder(
                    new File(lib, "libcpython.so").getAbsolutePath(),
                    "-S", "-c", "import " + module + "; print('ok')");
            pb.redirectErrorStream(true);
            java.util.Map<String, String> env = pb.environment();
            File home = new File(c.getFilesDir(), "python");
            File libDir = new File(home, "lib/python3.12");
            env.put("PYTHONHOME", home.getAbsolutePath());
            env.put("PYTHONPATH", (libDir.isDirectory() ? libDir.getAbsolutePath() : "")
                    + (SitePkgs.pathEnv(c).isEmpty() ? "" : ":" + SitePkgs.pathEnv(c)));
            Process p = pb.start();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = p.getInputStream().read(buf)) > 0) bo.write(buf, 0, n);
            int code = p.waitFor();
            if (code == 0) return null;
            String s = bo.toString("UTF-8").trim();
            if (s.length() > 600) s = s.substring(s.length() - 600);
            return Lang.s("import 测试失败：\n") + s;
        } catch (Exception e) {
            return Lang.s("import 测试异常：") + e.getMessage();
        }
    }

    // ------------------------------------------------------------ 工具
    private static String safeName(String s) {
        return s.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static String quote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private static int runCmd(String cmd, Log log) throws Exception {
        Process p = ShellBridge.start(cmd, "/");
        Thread t1 = pump(p.getInputStream(), log);
        Thread t2 = pump(p.getErrorStream(), log);
        int code = p.waitFor();
        t1.join(2000);
        t2.join(2000);
        return code;
    }

    private static Thread pump(final InputStream in, final Log log) {
        Thread t = new Thread(() -> {
            try {
                java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(in, "UTF-8"));
                String line;
                while ((line = br.readLine()) != null) {
                    log.line(line);
                }
            } catch (Exception ignored) {
            }
        });
        t.start();
        return t;
    }

    private static void write(File f, byte[] data) throws Exception {
        File p = f.getParentFile();
        if (p != null && !p.isDirectory() && !p.mkdirs()) throw new Exception("mkdir " + p);
        FileOutputStream out = new FileOutputStream(f);
        out.write(data);
        out.close();
    }

    private static void copyFile(File src, File dst) throws Exception {
        InputStream in = new java.io.FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        in.close();
    }

    private static void copyTree(File src, File dst) throws Exception {
        if (src.isDirectory()) {
            if (!dst.isDirectory() && !dst.mkdirs()) throw new Exception("mkdir " + dst);
            File[] kids = src.listFiles();
            if (kids == null) return;
            for (File k : kids) {
                if (k.getName().equals("cache") || k.getName().equals("tmp")) continue;
                copyTree(k, new File(dst, k.getName()));
            }
        } else {
            copyFile(src, dst);
        }
    }
}
