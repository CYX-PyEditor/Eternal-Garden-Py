package com.yhhy.pyeditor;

import android.content.Context;
import android.content.pm.PackageManager;

import java.io.File;

import rikka.shizuku.Shizuku;

/** 通过 Shizuku 以 shell 身份执行命令；不可用时退回本应用身份。 */
public final class ShellBridge {

    public static final int REQ_PERMISSION = 1201;

    private ShellBridge() {
    }

    public static boolean binderAlive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean granted() {
        try {
            return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestPermission() {
        try {
            Shizuku.requestPermission(REQ_PERMISSION);
        } catch (Throwable ignored) {
        }
    }

    public static String mode() {
        if (granted()) {
            int uid = 2000;
            try {
                uid = Shizuku.getUid();
            } catch (Throwable ignored) {
            }
            return "Shizuku · uid " + uid;
        }
        if (binderAlive()) {
            return Lang.s("Shizuku 未授权 · 本应用 uid ") + android.os.Process.myUid();
        }
        return Lang.s("本应用 · uid ") + android.os.Process.myUid();
    }

    public static String who() {
        return granted() ? "shell" : Lang.s("本应用");
    }

    public static String defaultDir(Context c) {
        if (granted()) return "/sdcard";
        try {
            File f = c.getExternalFilesDir(null);
            if (f != null) {
                if (!f.isDirectory()) f.mkdirs();
                if (f.isDirectory()) return f.getAbsolutePath();
            }
        } catch (Throwable ignored) {
        }
        return c.getFilesDir().getAbsolutePath();
    }

    public static Process start(String cmd, String cwd) throws Exception {
        if (granted()) {
            return Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, cwd);
        }
        ProcessBuilder pb = new ProcessBuilder("sh", "-c", cmd);
        pb.directory(new File(cwd));
        pb.redirectErrorStream(false);
        return pb.start();
    }
}
