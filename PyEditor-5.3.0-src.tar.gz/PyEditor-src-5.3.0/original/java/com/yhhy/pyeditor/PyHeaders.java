package com.yhhy.pyeditor;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * CPython 头文件包（不打包进 APK）：用户下载 / 本地导入一次，解到 files/pyinclude/Include。
 * 需要 Include/*.h + 适配 Android 的 pyconfig.h（release/pyinclude-3.12.tgz 就是这种结构）。
 */
final class PyHeaders {

    private PyHeaders() {
    }

    static File root(Context c) {
        return new File(c.getFilesDir(), "pyinclude");
    }

    static File includeDir(Context c) {
        return new File(root(c), "Include");
    }

    static boolean ready(Context c) {
        return new File(includeDir(c), "Python.h").isFile()
                && new File(includeDir(c), "pyconfig.h").isFile();
    }

    /** 下载安装；返回 null 成功，否则错误说明。 */
    static String installUrl(Context c, String url) {
        try {
            byte[] data = CompilerStore.fetch(url);
            return install(c, data, url);
        } catch (Exception e) {
            return e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    /** 本地导入；返回 null 成功，否则错误说明。 */
    static String installFile(Context c, File src) {
        try {
            return install(c, readAll(src), src.getName());
        } catch (Exception e) {
            return e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    private static String install(Context c, byte[] data, String name) throws Exception {
        File tmp = new File(c.getCacheDir(), "pyh_extract");
        CompilerStore.deleteRec(tmp);
        if (!tmp.mkdirs() && !tmp.isDirectory()) return Lang.s("无法创建解压目录");
        CompilerStore.extract(data, name, tmp);

        File inc = findInclude(tmp, 0);
        if (inc == null) return Lang.s("压缩包里没有找到 Include/Python.h");

        File cfg = new File(inc, "pyconfig.h");
        if (!cfg.isFile()) {
            File found = findFile(tmp, "pyconfig.h", 0);
            if (found != null) copy(found, cfg);
        }
        String err = commit(c, inc);
        CompilerStore.deleteRec(tmp);
        return err;
    }

    /**
     * 官方 CPython 源码包（.tar.xz）→ 只提取 Include/，再补上 App 内置的 Android pyconfig.h。
     * 这样下拉里的官方/镜像链接不用另配 pyconfig。
     */
    static String installOfficial(Context c, String url) {
        String lower = url == null ? "" : url.toLowerCase();
        try {
            byte[] data = CompilerStore.fetch(url);
            InputStream in = (lower.contains(".xz") || lower.endsWith(".txz"))
                    ? new org.tukaani.xz.XZInputStream(new java.io.ByteArrayInputStream(data))
                    : new java.util.zip.GZIPInputStream(new java.io.ByteArrayInputStream(data));
            File tmp = new File(c.getCacheDir(), "pyh_src");
            CompilerStore.deleteRec(tmp);
            File inc = new File(tmp, "Include");
            if (!inc.mkdirs() && !inc.isDirectory()) return Lang.s("无法创建解压目录");
            int n = extractInclude(in, inc);
            in.close();
            if (n <= 0) return Lang.s("源码包里没有找到 Include/（确认是 CPython 源码 tar.xz）");
            copyAsset(c, "pyconfig-android-3.12.h", new File(inc, "pyconfig.h"));
            String err = commit(c, inc);
            CompilerStore.deleteRec(tmp);
            return err;
        } catch (Exception e) {
            return e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    /** 校验并安装到 files/pyinclude/Include。 */
    private static String commit(Context c, File inc) throws Exception {
        File cfg = new File(inc, "pyconfig.h");
        if (!new File(inc, "Python.h").isFile()) return Lang.s("头文件不完整：缺 Include/Python.h");
        if (!cfg.isFile()) {
            return Lang.s("缺少 pyconfig.h：需要适配 Android 的 CPython 3.12 头文件包（官方源码里的 host 版不行）");
        }
        File dst = root(c);
        CompilerStore.deleteRec(dst);
        File dstInc = new File(dst, "Include");
        if (!dstInc.mkdirs() && !dstInc.isDirectory()) return Lang.s("无法创建头文件目录");
        copyTree(inc, dstInc);
        if (!ready(c)) return Lang.s("解压后校验失败（Python.h / pyconfig.h 不完整）");
        return null;
    }

    private static void copyAsset(Context c, String name, File dst) throws Exception {
        InputStream in = c.getAssets().open(name);
        File p = dst.getParentFile();
        if (p != null && !p.isDirectory() && !p.mkdirs()) throw new Exception("mkdir " + p);
        java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        in.close();
    }

    // ------------------------------------------------------------ 官方源码：只解 Include/
    private static int extractInclude(InputStream in, File incDir) throws Exception {
        byte[] h = new byte[512];
        String longName = null, paxPath = null;
        int files = 0;
        while (true) {
            int got = readFully(in, h, 512);
            if (got < 512) break;
            boolean zero = true;
            for (byte b : h) {
                if (b != 0) {
                    zero = false;
                    break;
                }
            }
            if (zero) break;
            String name = field(h, 0, 100);
            long size = parseOctal(h, 124, 12);
            char type = (char) h[156];
            if (type == 'L') {
                byte[] d = readData(in, size);
                longName = trimNul(d);
                skipPad(in, size);
                continue;
            }
            if (type == 'x' || type == 'g') {
                byte[] d = readData(in, size);
                String p = paxPathOf(new String(d, "UTF-8"));
                if (p != null) paxPath = p;
                skipPad(in, size);
                continue;
            }
            String eff = paxPath != null ? paxPath : (longName != null ? longName : name);
            paxPath = null;
            longName = null;
            if (type == '0' || type == '5' || type == 0) {
                int idx = eff.indexOf("Include/");
                if (idx >= 0) {
                    String rel = eff.substring(idx + 8);
                    if (rel.endsWith("/")) rel = rel.substring(0, rel.length() - 1);
                    if (!rel.isEmpty()) {
                        File out = new File(incDir, rel);
                        if (type == '5' || eff.endsWith("/")) {
                            out.mkdirs();
                        } else {
                            File p = out.getParentFile();
                            if (p != null) p.mkdirs();
                            writeExactly(in, out, size);
                            files++;
                        }
                    } else {
                        skip(in, size);
                    }
                } else {
                    skip(in, size);
                }
            } else {
                skip(in, size);
            }
            skipPad(in, size);
        }
        return files;
    }

    private static String field(byte[] h, int off, int len) {
        String s = new String(h, off, len, java.nio.charset.StandardCharsets.UTF_8);
        int z = s.indexOf('\0');
        if (z >= 0) s = s.substring(0, z);
        return s.trim();
    }

    private static long parseOctal(byte[] h, int off, int len) {
        String s = field(h, off, len).trim();
        if (s.isEmpty()) return 0;
        try {
            return Long.parseLong(s, 8);
        } catch (Exception e) {
            return 0;
        }
    }

    private static String trimNul(byte[] d) {
        int z = 0;
        while (z < d.length && d[z] != 0) z++;
        return new String(d, 0, z, java.nio.charset.StandardCharsets.UTF_8).trim();
    }

    private static String paxPathOf(String data) {
        for (String line : data.split("\n")) {
            int sp = line.indexOf(' ');
            if (sp > 0) {
                String rec = line.substring(sp + 1);
                if (rec.startsWith("path=")) return rec.substring(5);
            }
        }
        return null;
    }

    private static int readFully(InputStream in, byte[] buf, int len) throws Exception {
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n <= 0) break;
            off += n;
        }
        return off;
    }

    private static byte[] readData(InputStream in, long size) throws Exception {
        int n = (int) Math.min(size, 1 << 20);
        byte[] d = new byte[n];
        readFully(in, d, n);
        skip(in, size - n);
        return d;
    }

    private static void writeExactly(InputStream in, File out, long size) throws Exception {
        java.io.FileOutputStream fo = new java.io.FileOutputStream(out);
        byte[] buf = new byte[65536];
        long left = size;
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n <= 0) break;
            fo.write(buf, 0, n);
            left -= n;
        }
        fo.close();
    }

    private static void skip(InputStream in, long size) throws Exception {
        byte[] buf = new byte[8192];
        long left = size;
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n <= 0) break;
            left -= n;
        }
    }

    private static void skipPad(InputStream in, long size) throws Exception {
        long pad = (512 - (size % 512)) % 512;
        if (pad > 0) skip(in, pad);
    }

    /** 把内部头文件复制到 App 外部目录，供 Shizuku(shell) 读取。 */
    static File copyToExternal(Context c, File dstParent) throws Exception {
        File src = includeDir(c);
        if (!ready(c)) return null;
        File dst = new File(dstParent, "Include");
        CompilerStore.deleteRec(dst);
        if (!dst.mkdirs() && !dst.isDirectory()) throw new Exception(Lang.s("无法创建 ") + dst);
        copyTree(src, dst);
        return dst;
    }

    // ------------------------------------------------------------ 工具
    private static File findInclude(File dir, int depth) {
        if (depth > 4) return null;
        if (new File(dir, "Python.h").isFile() && dir.getName().equals("Include")) return dir;
        File[] kids = dir.listFiles();
        if (kids == null) return null;
        for (File k : kids) {
            if (!k.isDirectory()) continue;
            File r = findInclude(k, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    private static File findFile(File dir, String name, int depth) {
        if (depth > 5) return null;
        File f = new File(dir, name);
        if (f.isFile()) return f;
        File[] kids = dir.listFiles();
        if (kids == null) return null;
        for (File k : kids) {
            if (!k.isDirectory()) continue;
            File r = findFile(k, name, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    private static void copyTree(File src, File dst) throws Exception {
        if (src.isDirectory()) {
            if (!dst.isDirectory() && !dst.mkdirs()) throw new Exception("mkdir " + dst);
            File[] kids = src.listFiles();
            if (kids == null) return;
            for (File k : kids) copyTree(k, new File(dst, k.getName()));
        } else {
            copy(src, dst);
        }
    }

    private static void copy(File src, File dst) throws Exception {
        File p = dst.getParentFile();
        if (p != null && !p.isDirectory() && !p.mkdirs()) throw new Exception("mkdir " + p);
        InputStream in = new java.io.FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        in.close();
    }

    private static byte[] readAll(File f) throws Exception {
        InputStream in = new java.io.FileInputStream(f);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }
}
