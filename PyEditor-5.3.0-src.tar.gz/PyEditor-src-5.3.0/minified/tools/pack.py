#!/usr/bin/env python3
"""Repack an aapt-produced APK, adding classes.dex + native libs with proper
zip alignment (resources.arsc stored/4-byte aligned, .so stored/16KB aligned),
then leave it ready for apksigner."""
import os
import struct
import sys
import zipfile
import zlib

DOS_TIME = 0
DOS_DATE = (1 << 5) | 1  # 1980-01-01


class Writer:
    def __init__(self, path):
        self.f = open(path, 'wb')
        self.offset = 0
        self.central = []

    def add(self, name, data, store=False, align=1):
        nb = name.encode('utf-8')
        crc = zlib.crc32(data) & 0xFFFFFFFF
        method = 0 if store else 8
        if store:
            body = data
        else:
            co = zlib.compressobj(9, zlib.DEFLATED, -15)
            body = co.compress(data) + co.flush()
        extra = b''
        if align > 1:
            cur = self.offset + 30 + len(nb)
            pad = (align - (cur % align)) % align
            if pad:
                if pad < 4:
                    pad += align
                extra = struct.pack('<HH', 0xD935, pad - 4) + b'\x00' * (pad - 4)
        hdr = struct.pack('<IHHHHHIIIHH', 0x04034B50, 20, 0, method, DOS_TIME, DOS_DATE,
                          crc, len(body), len(data), len(nb), len(extra))
        self.f.write(hdr)
        self.f.write(nb)
        self.f.write(extra)
        self.f.write(body)
        self.central.append((nb, extra, method, crc, len(body), len(data), self.offset))
        self.offset += len(hdr) + len(nb) + len(extra) + len(body)

    def close(self):
        cd_start = self.offset
        for nb, extra, method, crc, csize, usize, off in self.central:
            hdr = struct.pack('<IHHHHHHIIIHHHHHII', 0x02014B50, 20, 20, 0, method,
                              DOS_TIME, DOS_DATE, crc, csize, usize, len(nb), len(extra), 0, 0, 0, 0, off)
            self.f.write(hdr)
            self.f.write(nb)
            self.f.write(extra)
            self.offset += len(hdr) + len(nb) + len(extra)
        size = self.offset - cd_start
        self.f.write(struct.pack('<IHHHHIIH', 0x06054B50, 0, 0,
                                 len(self.central), len(self.central), size, cd_start, 0))
        self.f.close()


def main():
    base, out, dex, libdir = sys.argv[1:5]
    entries = []
    with zipfile.ZipFile(base, 'r') as z:
        for info in z.infolist():
            entries.append((info.filename, z.read(info.filename)))

    w = Writer(out)
    # manifest first for good measure
    order = ['AndroidManifest.xml']
    names = [n for n, _ in entries]
    for n in order:
        if n in names:
            i = names.index(n)
            name, data = entries.pop(i)
            names.pop(i)
            w.add(name, data, store=False)
    for name, data in entries:
        if name == 'resources.arsc':
            w.add(name, data, store=True, align=4)
        elif name.startswith('res/') and name.endswith('.png'):
            w.add(name, data, store=True, align=4)
        else:
            w.add(name, data, store=False)

    with open(dex, 'rb') as f:
        w.add('classes.dex', f.read(), store=False)

    for root, _dirs, files in os.walk(libdir):
        for fn in sorted(files):
            p = os.path.join(root, fn)
            arc = os.path.relpath(p, os.path.dirname(os.path.abspath(libdir)))
            with open(p, 'rb') as f:
                w.add(arc.replace(os.sep, '/'), f.read(), store=True, align=16384)
    w.close()
    print('packed', out, os.path.getsize(out), 'bytes')


if __name__ == '__main__':
    main()
