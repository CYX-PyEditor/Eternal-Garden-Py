#!/bin/bash
# 交叉编译 CPython 3.12 为 Android aarch64（静态内建常用模块）
set -e
cd /root/工作区1/cpy
SR=/opt/asysroot/ndk-sysroot/data/data/com.termux/files/usr
STUBS=/opt/asysroot/stubs
SRC=Python-3.12.8
CC="clang-19 --target=aarch64-linux-android24 --sysroot=$SR"

cat > /tmp/cpython-config.site <<'SITE'
ac_cv_file__dev_ptmx=yes
ac_cv_file__dev_ptc=no
ac_cv_buggy_getaddrinfo=no
ac_cv_func_sem_clockwait=no
ac_cv_func_close_range=no
ac_cv_func_fdwalk=no
ac_cv_func_posix_spawn=no
ac_cv_func_posix_spawnp=no
ac_cv_func_chflags=no
ac_cv_func_lchflags=no
ac_cv_func_fexecve=no
ac_cv_func_rtpspawn=no
ac_cv_func_fork1=no
ac_cv_func_plock=no
ac_cv_func_wait3=no
ac_cv_func_preadv2=no
ac_cv_func_pwritev2=no
ac_cv_func_copy_file_range=no
ac_cv_func_confstr=no
ac_cv_func_getloadavg=no
ac_cv_func_memfd_create=no
ac_cv_func_mremap=no
ac_cv_func_lutimes=no
ac_cv_func_shm_open=no
SITE

rm -rf $SRC && tar xzf Python-3.12.8.tgz && cd $SRC

# 只保留能在 bionic 上编出来的模块
cat > Modules/Setup.local <<'MODS'
*static*
array arraymodule.c
_bisect _bisectmodule.c
_heapq _heapqmodule.c
_json _json.c
_opcode _opcode.c
_queue _queuemodule.c
_random _randommodule.c
_struct _struct.c
math mathmodule.c
cmath cmathmodule.c
_datetime _datetimemodule.c
binascii binascii.c
unicodedata unicodedata.c
fcntl fcntlmodule.c
mmap mmapmodule.c
_posixsubprocess _posixsubprocess.c
resource resource.c
select selectmodule.c
termios termios.c
MODS
printf '# Android: 只用 Modules/Setup.local 里列出的模块\n' > Modules/Setup.stdlib.in

CONFIG_SITE=/tmp/cpython-config.site ./configure \
  --host=aarch64-linux-android --build=aarch64-linux-gnu \
  --with-build-python=/usr/bin/python3 \
  --disable-shared --without-ensurepip --disable-ipv6 \
  --prefix=/root/工作区1/cpy/inst \
  CC="$CC" \
  CFLAGS="-fPIE -O2 -fno-emulated-tls -I/opt/asysroot/inc-arch" \
  LDFLAGS="-pie -L$STUBS -Wl,--unresolved-symbols=ignore-all -nodefaultlibs" \
  LIBS="-lc -lm -ldl" > /tmp/cpy-conf.log 2>&1 || { tail -30 /tmp/cpy-conf.log; exit 1; }

# 兜底：仍被误判的 glibc/BSD 符号
for m in HAVE_SEM_CLOCKWAIT HAVE_CLOSE_RANGE HAVE_FDWALK HAVE_POSIX_SPAWN HAVE_POSIX_SPAWNP \
         HAVE_CHFLAGS HAVE_LCHFLAGS HAVE_FEXECVE HAVE_RTPSPAWN HAVE_PREADV2 HAVE_PWRITEV2 \
         HAVE_COPY_FILE_RANGE HAVE_CONFSTR HAVE_GETLOADAVG HAVE_MEMFD_CREATE HAVE_MREMAP \
         HAVE_LUTIMES HAVE_SHM_OPEN; do
  sed -i "s|^#define $m 1|/* #undef $m */|" pyconfig.h
done

# bionic 没有 setpwent/getpwent：pwd.getpwall()/grp.getgrall() 在 Android 上返回空表
python3 - <<'PATCH'
def patch(path, start_fn, end_fn):
    s = open(path).read()
    if "#ifndef __ANDROID__" in s:
        return
    s = s.replace(start_fn, "#ifndef __ANDROID__\n" + start_fn, 1)
    s = s.replace(end_fn, end_fn.replace("\n    return", "\n#endif\n    return", 1), 1)
    open(path, 'w').write(s)
patch('Modules/pwdmodule.c',
      "    setpwent();\n    while ((p = getpwent()) != NULL) {",
      "    endpwent();\n    return d;\n}")
patch('Modules/grpmodule.c',
      "    setgrent();\n    while ((p = getgrent()) != NULL) {",
      "    endgrent();\n    return d;\n}")
PATCH

make -j6 > /tmp/cpy-make.log 2>&1 || { grep -E "error:" /tmp/cpy-make.log | head -20; exit 1; }
cp python python.stripped && (strip python.stripped 2>/dev/null || llvm-strip-19 python.stripped)
ls -lh python.stripped
echo CPYTHON_BUILD_OK
