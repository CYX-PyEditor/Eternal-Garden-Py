import zlib, struct, math, os

S = 192
px = [[(0,0,0,0) for _ in range(S)] for _ in range(S)]

def blend(dst, src):
    sr,sg,sb,sa = src
    if sa == 0: return dst
    a = sa/255.0
    dr,dg,db,da = dst
    return (int(sr*a+dr*(1-a)), int(sg*a+dg*(1-a)), int(sb*a+db*(1-a)), max(da, sa))

def rrect(x0,y0,x1,y1,r,color):
    for y in range(int(y0), int(y1)+1):
        for x in range(int(x0), int(x1)+1):
            dx = 0; dy = 0
            if x < x0+r: dx = x0+r-x
            elif x > x1-r: dx = x-(x1-r)
            if y < y0+r: dy = y0+r-y
            elif y > y1-r: dy = y-(y1-r)
            if dx*dx+dy*dy <= r*r + 0.5:
                if 0 <= x < S and 0 <= y < S:
                    px[y][x] = blend(px[y][x], color)

def seg(x1,y1,x2,y2,w,color):
    x1,y1,x2,y2 = map(float,(x1,y1,x2,y2))
    n = int(max(abs(x2-x1),abs(y2-y1))*2)+2
    for i in range(n+1):
        t = i/n
        cx = x1+(x2-x1)*t; cy = y1+(y2-y1)*t
        r = w/2.0
        for y in range(int(cy-r)-1, int(cy+r)+2):
            for x in range(int(cx-r)-1, int(cx+r)+2):
                if 0 <= x < S and 0 <= y < S:
                    if (x-cx)**2+(y-cy)**2 <= r*r:
                        px[y][x] = blend(px[y][x], color)

# background
rrect(0,0,S-1,S-1,44,(30,33,39,255))
rrect(6,6,S-7,S-7,40,(40,44,52,255))
# green chevron ">"
green = (152,195,121,255)
seg(58,58,112,96,17,green)
seg(112,96,58,134,17,green)
# blue underscore
blue = (97,175,239,255)
seg(104,132,138,132,17,blue)
# small "py" dots
rrect(104,56,120,72,7,(198,120,221,255))
rrect(126,56,142,72,7,(229,192,123,255))

raw = b''
for y in range(S):
    raw += b'\x00' + bytes(sum(([r,g,b,a] for r,g,b,a in px[y]), []))
def chunk(t, d):
    c = t + d
    return struct.pack('>I', len(d)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
png = b'\x89PNG\r\n\x1a\n'
png += chunk(b'IHDR', struct.pack('>IIBBBBB', S, S, 8, 6, 0, 0, 0))
png += chunk(b'IDAT', zlib.compress(raw, 9))
png += chunk(b'IEND', b'')
out = os.path.join(os.path.dirname(__file__), '..', 'res', 'mipmap-xxxhdpi', 'ic_launcher.png')
open(out,'wb').write(png)
print("wrote", os.path.abspath(out), len(png), "bytes")
