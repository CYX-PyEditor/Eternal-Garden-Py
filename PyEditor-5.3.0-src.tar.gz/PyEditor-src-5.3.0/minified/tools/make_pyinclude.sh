#!/bin/bash
# 从 CPython 交叉编译源码里打包 Include/ + pyconfig.h → assets/pyinclude.tgz
# 编译 C 扩展时解到 /data/local/tmp/pye-build/include/Include
set -e
cd "$(dirname "$0")/.."
SRC=/root/工作区1/cpy/Python-3.12.8
TMP=$(mktemp -d)
mkdir -p "$TMP/Include"
cp -r "$SRC"/Include/. "$TMP/Include/"   # 含 cpython/ 与 internal/ 子目录
cp "$SRC/pyconfig.h" "$TMP/Include/pyconfig.h"
mkdir -p assets
tar czf assets/pyinclude.tgz -C "$TMP" Include
rm -rf "$TMP"
ls -l assets/pyinclude.tgz
