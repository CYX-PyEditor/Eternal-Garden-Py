#!/usr/bin/env python3
"""Bionic 要求 aarch64 可执行文件的 PT_TLS p_align >= 64，交叉链接出来通常是 8，这里改掉。"""
import struct
import sys

path = sys.argv[1]
data = bytearray(open(path, 'rb').read())
assert data[:4] == b'\x7fELF' and data[4] == 2, "not ELF64"
phoff = struct.unpack_from('<Q', data, 0x20)[0]
phentsize = struct.unpack_from('<H', data, 0x36)[0]
phnum = struct.unpack_from('<H', data, 0x38)[0]
fixed = 0
for i in range(phnum):
    off = phoff + i * phentsize
    p_type = struct.unpack_from('<I', data, off)[0]
    if p_type == 7:  # PT_TLS
        align = struct.unpack_from('<Q', data, off + 48)[0]
        if align < 64:
            struct.pack_into('<Q', data, off + 48, 64)
            fixed += 1
            print(f"PT_TLS align {align} -> 64")
open(path, 'wb').write(data)
print("patched" if fixed else "no change needed")
