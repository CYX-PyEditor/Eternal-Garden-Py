#!/usr/bin/env python3
"""Java 源码压缩：删注释、去缩进、删空行，最后按行合并成单行（字符串常量原样保留）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strip_java_comments import strip

def minify(src):
    s = strip(src)
    parts = []
    for line in s.split('\n'):
        line = line.strip()
        if line:
            parts.append(line)
    return ' '.join(parts) + '\n'

def main(src_root, dst_root):
    n = 0
    for dp, _, fs in os.walk(src_root):
        for f in fs:
            if not f.endswith('.java'):
                continue
            src = os.path.join(dp, f)
            rel = os.path.relpath(src, src_root)
            dst = os.path.join(dst_root, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(src, encoding='utf-8') as fh:
                s = fh.read()
            with open(dst, 'w', encoding='utf-8') as fh:
                fh.write(minify(s))
            n += 1
    print('minified java:', n)

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
