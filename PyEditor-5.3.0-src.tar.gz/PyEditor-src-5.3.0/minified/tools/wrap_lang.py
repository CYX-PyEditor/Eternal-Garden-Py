#!/usr/bin/env python3
"""把 Java 源码里的中文字面量包成 Lang.s("…")。

规则：
- 只处理 java/com/yhhy/pyeditor/*.java，跳过 Lang.java（字典）、Theme.java（内部标识）、
  PreviewView.java（示例代码内容）
- 跳过注释里的引号
- 跳过 `.equals("…")` 这类比较用的字面量（主题名等内部值要保持稳定）
- 跳过已经包过 Lang.s( 的
"""
import glob
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'java', 'com', 'yhhy', 'pyeditor')
SKIP_FILES = {'Lang.java', 'Theme.java', 'PreviewView.java'}
CJK = re.compile(r'[\u4e00-\u9fff]')


def rewrite(text):
    out = []
    i = 0
    n = len(text)
    wrapped = 0
    while i < n:
        c = text[i]
        # 行注释
        if text.startswith('//', i):
            j = text.find('\n', i)
            if j < 0:
                out.append(text[i:])
                break
            out.append(text[i:j])
            i = j
            continue
        # 块注释
        if text.startswith('/*', i):
            j = text.find('*/', i + 2)
            if j < 0:
                out.append(text[i:])
                break
            out.append(text[i:j + 2])
            i = j + 2
            continue
        # 字符串
        if c == '"':
            j = i + 1
            while j < n:
                if text[j] == '\\':
                    j += 2
                    continue
                if text[j] == '"':
                    break
                j += 1
            if j >= n:
                out.append(text[i:])
                break
            content = text[i + 1:j]
            before = ''.join(out)[-24:]
            skip = bool(re.search(r'(\.\s*equals\s*\(\s*|Lang\.s\(\s*)$', before))
            if CJK.search(content) and not skip:
                out.append('Lang.s("' + content + '")')
                wrapped += 1
            else:
                out.append(text[i:j + 1])
            i = j + 1
            continue
        # 字符字面量
        if c == "'":
            j = i + 1
            while j < n:
                if text[j] == '\\':
                    j += 2
                    continue
                if text[j] == "'":
                    break
                j += 1
            out.append(text[i:j + 1])
            i = j + 1
            continue
        out.append(c)
        i += 1
    return ''.join(out), wrapped


def main():
    total = 0
    for path in sorted(glob.glob(os.path.join(SRC, '*.java'))):
        name = os.path.basename(path)
        if name in SKIP_FILES:
            continue
        with open(path, encoding='utf-8') as f:
            src = f.read()
        new, cnt = rewrite(src)
        if new != src:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(new)
            print(f'{name}: wrapped {cnt}')
            total += cnt
    print('total wrapped:', total)


if __name__ == '__main__':
    main()
