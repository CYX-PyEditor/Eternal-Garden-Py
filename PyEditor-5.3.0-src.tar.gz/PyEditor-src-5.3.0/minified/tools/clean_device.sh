#!/bin/bash
# 清掉手机上 Download/DSHA 里旧的 PyEditor 安装包（导出新包前先跑一次）
S=/root/dsh-bin/adb-shell
LIST=$($S "ls /sdcard/Download/DSHA" 2>/dev/null)
echo "$LIST" | grep -iE '^PyEditor.*\.apk' | while IFS= read -r f; do
  [ -z "$f" ] && continue
  $S "rm \"/sdcard/Download/DSHA/$f\"" >/dev/null 2>&1 && echo "removed: $f"
done
