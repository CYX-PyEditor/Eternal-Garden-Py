#!/usr/bin/env python3
"""删除 Java 源码里的注释（保留字符串/字符常量），供混淆构建使用。"""
import sys, os, re

def strip(src):
    out = []
    i, n = 0, len(src)
    state = 'code'  # code | line | block | str | chr
    while i < n:
        c = src[i]
        if state == 'code':
            if c == '/' and i + 1 < n and src[i + 1] == '/':
                state = 'line'; i += 2; continue
            if c == '/' and i + 1 < n and src[i + 1] == '*':
                state = 'block'; i += 2; continue
            if c == '"':
                state = 'str'; out.append(c); i += 1; continue
            if c == "'":
                state = 'chr'; out.append(c); i += 1; continue
            out.append(c); i += 1; continue
        if state == 'line':
            if c == '\n':
                out.append('\n'); state = 'code'
            i += 1; continue
        if state == 'block':
            if c == '*' and i + 1 < n and src[i + 1] == '/':
                state = 'code'; i += 2; continue
            if c == '\n':
                out.append('\n')
            i += 1; continue
        if state == 'str':
            out.append(c)
            if c == '\\' and i + 1 < n:
                out.append(src[i + 1]); i += 2; continue
            if c == '"':
                state = 'code'
            i += 1; continue
        if state == 'chr':
            out.append(c)
            if c == '\\' and i + 1 < n:
                out.append(src[i + 1]); i += 2; continue
            if c == "'":
                state = 'code'
            i += 1; continue
    return ''.join(out)

def main(root):
    count = 0
    for dp, _, fs in os.walk(root):
        for f in fs:
            if not f.endswith('.java'):
                continue
            p = os.path.join(dp, f)
            with open(p, encoding='utf-8') as fh:
                s = fh.read()
            t = strip(s)
            if t != s:
                with open(p, 'w', encoding='utf-8') as fh:
                    fh.write(t)
                count += 1
    print('stripped comments:', count)

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'build/obfuscated_java')
