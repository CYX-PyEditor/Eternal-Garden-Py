// JNI bridge: com.yhhy.pyeditor.Native  <->  pe::Doc
#include <jni.h>

#include <cstdint>
#include <vector>

#include "engine.h"

using namespace pe;

static U16 toU16(JNIEnv* env, jstring js) {
    if (!js) return U16();
    jsize n = env->GetStringLength(js);
    const jchar* p = env->GetStringChars(js, nullptr);
    U16 s(reinterpret_cast<const char16_t*>(p), (size_t)n);
    env->ReleaseStringChars(js, p);
    return s;
}

static jstring toJava(JNIEnv* env, const U16& s) {
    return env->NewString(reinterpret_cast<const jchar*>(s.data()), (jsize)s.size());
}

static Doc* D(jlong h) { return reinterpret_cast<Doc*>(static_cast<intptr_t>(h)); }

#define CONCAT2(a, b) a##b
#define CONCAT(a, b) CONCAT2(a, b)
#define PKG(name) CONCAT(Java_com_yhhy_pyeditor_Native_, name)

extern "C" {

JNIEXPORT jlong JNICALL PKG(nativeCreate)(JNIEnv*, jclass) {
    return static_cast<jlong>(reinterpret_cast<intptr_t>(new Doc()));
}

JNIEXPORT void JNICALL PKG(nativeDestroy)(JNIEnv*, jclass, jlong h) { delete D(h); }

JNIEXPORT void JNICALL PKG(nativeSetText)(JNIEnv* env, jclass, jlong h, jstring text) {
    D(h)->setText(toU16(env, text));
}

JNIEXPORT jstring JNICALL PKG(nativeGetText)(JNIEnv* env, jclass, jlong h) {
    return toJava(env, D(h)->getText());
}

JNIEXPORT jint JNICALL PKG(nativeLineCount)(JNIEnv*, jclass, jlong h) { return D(h)->lineCount(); }

JNIEXPORT jstring JNICALL PKG(nativeLineText)(JNIEnv* env, jclass, jlong h, jint i) {
    Doc* d = D(h);
    if (i < 0 || i >= d->lineCount()) return env->NewStringUTF("");
    return toJava(env, d->lineText(i));
}

JNIEXPORT jint JNICALL PKG(nativeLineVersion)(JNIEnv*, jclass, jlong h, jint i) {
    return (jint)D(h)->lineVersion(i);
}

JNIEXPORT jint JNICALL PKG(nativeLineLength)(JNIEnv*, jclass, jlong h, jint i) {
    return D(h)->lineLength(i);
}

JNIEXPORT jint JNICALL PKG(nativeMaxLineLength)(JNIEnv*, jclass, jlong h) { return D(h)->maxLineLength(); }

JNIEXPORT jint JNICALL PKG(nativeRevision)(JNIEnv*, jclass, jlong h) { return (jint)D(h)->revision(); }

JNIEXPORT jboolean JNICALL PKG(nativeIsDirty)(JNIEnv*, jclass, jlong h) { return D(h)->isDirty(); }

JNIEXPORT void JNICALL PKG(nativeMarkClean)(JNIEnv*, jclass, jlong h) { D(h)->markClean(); }

JNIEXPORT jint JNICALL PKG(nativeFillRuns)(JNIEnv* env, jclass, jlong h, jint from, jint to, jintArray out) {
    if (!out) return 0;
    jsize len = env->GetArrayLength(out);
    jint* buf = env->GetIntArrayElements(out, nullptr);
    int n = D(h)->fillRuns(from, to, reinterpret_cast<int32_t*>(buf), len);
    env->ReleaseIntArrayElements(out, buf, 0);
    return n;
}

JNIEXPORT jint JNICALL PKG(nativeProblems)(JNIEnv* env, jclass, jlong h, jintArray out, jboolean recheck) {
    Prob* p = nullptr;
    int n = D(h)->problems(recheck == JNI_TRUE, p);
    if (!out || !p) return 0;
    jsize cap = env->GetArrayLength(out) / 5;
    if (n > cap) n = cap;
    jint* buf = env->GetIntArrayElements(out, nullptr);
    for (int i = 0; i < n; i++) {
        buf[i * 5 + 0] = (jint)p[i].line;
        buf[i * 5 + 1] = (jint)p[i].start;
        buf[i * 5 + 2] = (jint)p[i].end;
        buf[i * 5 + 3] = (jint)p[i].sev;
        buf[i * 5 + 4] = (jint)p[i].id;
    }
    env->ReleaseIntArrayElements(out, buf, 0);
    return n;
}

JNIEXPORT jobjectArray JNICALL PKG(nativeComplete)(JNIEnv* env, jclass, jlong h, jint maxItems) {
    std::vector<Candidate> v = D(h)->complete(maxItems);
    jclass strCls = env->FindClass("java/lang/String");
    jobjectArray arr = env->NewObjectArray((jsize)v.size(), strCls, nullptr);
    for (size_t i = 0; i < v.size(); i++) {
        U16 s;
        s += (char16_t)('0' + (v[i].kind % 10));
        s += (char16_t)('.');
        s += (char16_t)('0' + (v[i].kind / 10));
        s += u'\t';
        s += v[i].name;
        jstring js = toJava(env, s);
        env->SetObjectArrayElement(arr, (jsize)i, js);
        env->DeleteLocalRef(js);
    }
    return arr;
}

JNIEXPORT jboolean JNICALL PKG(nativeFind)(JNIEnv* env, jclass, jlong h, jstring needle,
                                            jint fromLine, jint fromCol,
                                            jboolean ignoreCase, jboolean wholeWord,
                                            jintArray out) {
    int o[3] = {0, 0, 0};
    bool ok = D(h)->find(toU16(env, needle), (int)fromLine, (int)fromCol,
                        ignoreCase == JNI_TRUE, wholeWord == JNI_TRUE, o);
    if (!ok) return JNI_FALSE;
    if (out) {
        jint v[3] = {o[0], o[1], o[2]};
        env->SetIntArrayRegion(out, 0, 3, v);
    }
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL PKG(nativeReplaceRange)(JNIEnv* env, jclass, jlong h,
                                                    jint l1, jint c1, jint l2, jint c2,
                                                    jstring text) {
    return D(h)->replaceRange((int)l1, (int)c1, (int)l2, (int)c2, toU16(env, text))
            ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL PKG(nativeReplaceWholeText)(JNIEnv* env, jclass, jlong h,
                                                       jstring text, jint caretLine, jint caretCol) {
    return D(h)->replaceWholeText(toU16(env, text), (int)caretLine, (int)caretCol)
            ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL PKG(nativeInsertSnippet)(JNIEnv* env, jclass, jlong h, jstring text, jint caret) {
    return D(h)->insertSnippet(toU16(env, text), (int)caret) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL PKG(nativeFolds)(JNIEnv* env, jclass, jlong h, jintArray out) {
    if (!out) return 0;
    const std::vector<Fold>& f = D(h)->folds();
    jsize cap = env->GetArrayLength(out) / 3;
    int n = (int)f.size();
    if (n > cap) n = (int)cap;
    jint* buf = env->GetIntArrayElements(out, nullptr);
    for (int i = 0; i < n; i++) {
        buf[i * 3 + 0] = f[i].start;
        buf[i * 3 + 1] = f[i].end;
        buf[i * 3 + 2] = f[i].kind;
    }
    env->ReleaseIntArrayElements(out, buf, 0);
    return n;
}

JNIEXPORT jstring JNICALL PKG(nativeFoldHeader)(JNIEnv* env, jclass, jlong h, jint line) {
    return toJava(env, D(h)->foldHeaderText(line));
}

JNIEXPORT jint JNICALL PKG(nativeCursorLine)(JNIEnv*, jclass, jlong h) { return D(h)->curLine(); }
JNIEXPORT jint JNICALL PKG(nativeCursorCol)(JNIEnv*, jclass, jlong h) { return D(h)->curCol(); }
JNIEXPORT jint JNICALL PKG(nativeAnchorLine)(JNIEnv*, jclass, jlong h) { return D(h)->anchorLine(); }
JNIEXPORT jint JNICALL PKG(nativeAnchorCol)(JNIEnv*, jclass, jlong h) { return D(h)->anchorCol(); }
JNIEXPORT jboolean JNICALL PKG(nativeHasSelection)(JNIEnv*, jclass, jlong h) {
    return D(h)->hasSelection() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL PKG(nativeSetCursor)(JNIEnv*, jclass, jlong h, jint l, jint c) { D(h)->setCursor(l, c); }
JNIEXPORT void JNICALL PKG(nativeSetSelection)(JNIEnv*, jclass, jlong h, jint l1, jint c1, jint l2, jint c2) {
    D(h)->setSelection(l1, c1, l2, c2);
}
JNIEXPORT void JNICALL PKG(nativeSelectAll)(JNIEnv*, jclass, jlong h) { D(h)->selectAll(); }
JNIEXPORT void JNICALL PKG(nativeSelectWord)(JNIEnv*, jclass, jlong h, jint l, jint c) { D(h)->selectWord(l, c); }
JNIEXPORT void JNICALL PKG(nativeSelectLine)(JNIEnv*, jclass, jlong h, jint l) { D(h)->selectLine(l); }
JNIEXPORT void JNICALL PKG(nativeMoveHorizontal)(JNIEnv*, jclass, jlong h, jint dir, jboolean ext) {
    D(h)->moveHorizontal(dir, ext == JNI_TRUE);
}
JNIEXPORT void JNICALL PKG(nativeMoveVertical)(JNIEnv*, jclass, jlong h, jint dir, jboolean ext) {
    D(h)->moveVertical(dir, ext == JNI_TRUE);
}
JNIEXPORT void JNICALL PKG(nativeMoveLineEdge)(JNIEnv*, jclass, jlong h, jboolean toEnd, jboolean ext) {
    D(h)->moveLineEdge(toEnd == JNI_TRUE, ext == JNI_TRUE);
}

JNIEXPORT jstring JNICALL PKG(nativeSelectedText)(JNIEnv* env, jclass, jlong h) {
    return toJava(env, D(h)->selectedText());
}

JNIEXPORT jboolean JNICALL PKG(nativeInsertText)(JNIEnv* env, jclass, jlong h, jstring s) {
    return D(h)->insertText(toU16(env, s)) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL PKG(nativeInsertTyped)(JNIEnv*, jclass, jlong h, jint c) {
    return D(h)->insertTyped((char16_t)c) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL PKG(nativeBackspace)(JNIEnv*, jclass, jlong h) {
    return D(h)->backspace() ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jboolean JNICALL PKG(nativeDeleteForward)(JNIEnv*, jclass, jlong h) {
    return D(h)->deleteForward() ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jboolean JNICALL PKG(nativeNewline)(JNIEnv*, jclass, jlong h) {
    return D(h)->newline() ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jboolean JNICALL PKG(nativeIndent)(JNIEnv*, jclass, jlong h, jboolean outdent) {
    return D(h)->indentBlock(outdent == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jboolean JNICALL PKG(nativeUndo)(JNIEnv*, jclass, jlong h) { return D(h)->undo() ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT jboolean JNICALL PKG(nativeRedo)(JNIEnv*, jclass, jlong h) { return D(h)->redo() ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT jboolean JNICALL PKG(nativeCanUndo)(JNIEnv*, jclass, jlong h) {
    return D(h)->canUndo() ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jboolean JNICALL PKG(nativeCanRedo)(JNIEnv*, jclass, jlong h) {
    return D(h)->canRedo() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL PKG(nativeSetOptions)(JNIEnv*, jclass, jlong h, jint tab, jboolean ai, jboolean ap) {
    D(h)->setOptions(tab, ai == JNI_TRUE, ap == JNI_TRUE);
}

}  // extern "C"
