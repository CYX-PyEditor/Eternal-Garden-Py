// Document model: buffer, editing ops, undo, syntax check, completion, runs.
#include "engine.h"
#include <chrono>
#include <algorithm>

#include <algorithm>
#include <cstring>

namespace pe {

static inline bool isDigit16(char16_t c) { return c >= u'0' && c <= u'9'; }
static inline bool isAlpha16(char16_t c) {
    return (c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z') || c == u'_';
}
static inline bool isIdentCont(char16_t c) { return isAlpha16(c) || isDigit16(c) || c >= 0x80; }
static inline bool surIsHigh(char16_t c) { return c >= 0xD800 && c <= 0xDBFF; }
static inline bool surIsLow(char16_t c) { return c >= 0xDC00 && c <= 0xDFFF; }

static U16 tokTextOf(const U16& s, const Tok& t) { return s.substr(t.start, t.end - t.start); }

static bool isBlockHeaderKw(const U16& w) {
    return w == u"def" || w == u"class" || w == u"if" || w == u"elif" || w == u"else" ||
           w == u"for" || w == u"while" || w == u"try" || w == u"except" ||
           w == u"finally" || w == u"with" || w == u"match" || w == u"case";
}

Doc::Doc() {
    lines_.emplace_back();
    meta_.emplace_back();
    maxLen_ = 0;
}

// ------------------------------------------------------------------ document
void Doc::setText(const U16& text) {
    lines_.clear();
    meta_.clear();
    U16 cur;
    cur.reserve(128);
    for (char16_t c : text) {
        if (c == u'\r') continue;
        if (c == u'\n') {
            lines_.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    lines_.push_back(cur);
    meta_.resize(lines_.size());
    revision_++;
    foldsDirty_ = true;
    dirty_ = false;
    cl_ = cc_ = al_ = ac_ = 0;
    hasSel_ = false;
    vMode_ = false;
    desiredCol_ = 0;
    undo_.clear();
    redo_.clear();
    undoTotal_ = 0;
    typingBurst_ = false;
    symDirty_ = true;
    probsDirty_ = true;
    maxLen_ = 0;
    for (auto& l : lines_) {
        if ((int)l.size() > maxLen_) maxLen_ = (int)l.size();
    }
    retokenize(0);
    probsDirty_ = true;
}

U16 Doc::getText() const {
    U16 out;
    for (size_t i = 0; i < lines_.size(); i++) {
        if (i) out += u'\n';
        out += lines_[i];
    }
    return out;
}

void Doc::retokenize(int fromLine) {
    const int n = (int)lines_.size();
    if (n <= 0) return;
    if (fromLine < 0) fromLine = 0;
    if (fromLine >= n) return;
    uint8_t st = (fromLine == 0) ? 0 : meta_[fromLine - 1].strEnd;
    int32_t dp = (fromLine == 0) ? 0 : meta_[fromLine - 1].depthEnd;

    for (int i = fromLine; i < n; i++) {
        LineData& m = meta_[i];
        bool had = m.rev != 0;
        uint8_t oldEnd = m.strEnd;
        int32_t oldDepth = m.depthEnd;
        m.toks.clear();
        m.syms.clear();
        uint8_t nst = st;
        int32_t ndp = dp;
        tokenizeLine(lines_[i], nst, ndp, m.toks, m.syms, i);
        m.strStart = st;
        m.strEnd = nst;
        m.depthStart = dp;
        m.depthEnd = ndp;
        m.rev = revision_;
        m.blank = m.toks.empty();
        int32_t ind = 0;
        const U16& L = lines_[i];
        for (size_t k = 0; k < L.size(); k++) {
            char16_t c = L[k];
            if (c == u' ') ind++;
            else if (c == u'\t') ind += tabSize_ - (ind % tabSize_);
            else break;
        }
        m.indent = ind;
        st = nst;
        dp = ndp;
        if (had && i > fromLine && oldEnd == nst && oldDepth == ndp) break;
    }
    symDirty_ = true;
    probsDirty_ = true;
}

void Doc::clampCursor() {
    if (cl_ < 0) cl_ = 0;
    if (cl_ >= (int)lines_.size()) cl_ = (int)lines_.size() - 1;
    if (cc_ < 0) cc_ = 0;
    if (cc_ > (int)lines_[cl_].size()) cc_ = (int)lines_[cl_].size();
    if (al_ < 0) al_ = 0;
    if (al_ >= (int)lines_.size()) al_ = (int)lines_.size() - 1;
    if (ac_ < 0) ac_ = 0;
    if (ac_ > (int)lines_[al_].size()) ac_ = (int)lines_[al_].size();
}

void Doc::touchMaxLen(int line) {
    if (lines_.size() <= 3000) {
        maxLen_ = 0;
        for (auto& l : lines_) {
            if ((int)l.size() > maxLen_) maxLen_ = (int)l.size();
        }
        return;
    }
    if (line >= 0 && line < (int)lines_.size() && (int)lines_[line].size() > maxLen_) {
        maxLen_ = (int)lines_[line].size();
    }
}

void Doc::afterEdit(int firstLine) {
    if (meta_.size() != lines_.size()) meta_.resize(lines_.size());
    revision_++;
    foldsDirty_ = true;
    dirty_ = true;
    clampCursor();
    if (firstLine >= 0) retokenize(firstLine);
    touchMaxLen(firstLine);
}

// ------------------------------------------------------------------ undo
void Doc::trimUndo() {
    while (undo_.size() > 120U) {
        undoTotal_ -= undo_.front().bytes;
        undo_.erase(undo_.begin());
    }
    while (undoTotal_ > (size_t)24 * 1024 * 1024 && undo_.size() > 1) {
        undoTotal_ -= undo_.front().bytes;
        undo_.erase(undo_.begin());
    }
}

void Doc::snap(bool typing) {
    long long now = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    // 连续输入/删除：同一段操作只落一个快照；停顿超过 100ms 才另起一段
    bool sameBurst = typing && typingBurst_ && !undo_.empty();
    if (sameBurst && now - lastEditMs_ < 100) {
        lastEditMs_ = now;
        return;
    }
    lastEditMs_ = now;
    lastSnapMs_ = now;
    typingBurst_ = typing;
    Snap s;
    s.text = getText();
    s.cl = cl_;
    s.cc = cc_;
    s.al = al_;
    s.ac = ac_;
    s.sel = hasSel_;
    s.bytes = s.text.size() * 2 + 64;
    undoTotal_ += s.bytes;
    undo_.push_back(std::move(s));
    redo_.clear();
    trimUndo();
}

void Doc::loadJoined(const U16& text) {
    lines_.clear();
    meta_.clear();
    U16 cur;
    cur.reserve(128);
    for (char16_t c : text) {
        if (c == u'\r') continue;
        if (c == u'\n') {
            lines_.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    lines_.push_back(cur);
    meta_.resize(lines_.size());
    maxLen_ = 0;
    for (auto& l : lines_) {
        if ((int)l.size() > maxLen_) maxLen_ = (int)l.size();
    }
    revision_++;
    foldsDirty_ = true;
    dirty_ = true;
    clampCursor();
    retokenize(0);
}

bool Doc::undo() {
    if (undo_.empty()) return false;
    Snap cur;
    cur.text = getText();
    cur.cl = cl_;
    cur.cc = cc_;
    cur.al = al_;
    cur.ac = ac_;
    cur.sel = hasSel_;
    cur.bytes = cur.text.size() * 2 + 64;
    redo_.push_back(std::move(cur));

    Snap s = std::move(undo_.back());
    undo_.pop_back();
    undoTotal_ -= s.bytes;
    typingBurst_ = false;
    vMode_ = false;
    loadJoined(s.text);
    cl_ = s.cl;
    cc_ = s.cc;
    al_ = s.al;
    ac_ = s.ac;
    hasSel_ = s.sel;
    clampCursor();
    probsDirty_ = true;
    return true;
}

bool Doc::redo() {
    if (redo_.empty()) return false;
    Snap cur;
    cur.text = getText();
    cur.cl = cl_;
    cur.cc = cc_;
    cur.al = al_;
    cur.ac = ac_;
    cur.sel = hasSel_;
    cur.bytes = cur.text.size() * 2 + 64;
    undoTotal_ += cur.bytes;
    undo_.push_back(std::move(cur));

    Snap s = std::move(redo_.back());
    redo_.pop_back();
    typingBurst_ = false;
    vMode_ = false;
    loadJoined(s.text);
    cl_ = s.cl;
    cc_ = s.cc;
    al_ = s.al;
    ac_ = s.ac;
    hasSel_ = s.sel;
    clampCursor();
    probsDirty_ = true;
    trimUndo();
    return true;
}

// ------------------------------------------------------------------ cursor
void Doc::setCursor(int line, int col) {
    hasSel_ = false;
    cl_ = line;
    cc_ = col;
    al_ = line;
    ac_ = col;
    vMode_ = false;
    clampCursor();
    desiredCol_ = cc_;
}

void Doc::setSelection(int l1, int c1, int l2, int c2) {
    al_ = l1;
    ac_ = c1;
    cl_ = l2;
    cc_ = c2;
    hasSel_ = !(l1 == l2 && c1 == c2);
    vMode_ = false;
    clampCursor();
    desiredCol_ = cc_;
}

void Doc::normalizeSel(int& l1, int& c1, int& l2, int& c2) const {
    if (al_ < cl_ || (al_ == cl_ && ac_ <= cc_)) {
        l1 = al_; c1 = ac_; l2 = cl_; c2 = cc_;
    } else {
        l1 = cl_; c1 = cc_; l2 = al_; c2 = ac_;
    }
    if (l1 > l2 || (l1 == l2 && c1 > c2)) {
        std::swap(l1, l2);
        std::swap(c1, c2);
    }
    if (l1 < 0) l1 = 0;
    if (l1 >= (int)lines_.size()) l1 = (int)lines_.size() - 1;
    if (l2 >= (int)lines_.size()) l2 = (int)lines_.size() - 1;
    if (c1 < 0) c1 = 0;
    if (c1 > (int)lines_[l1].size()) c1 = (int)lines_[l1].size();
    if (c2 < 0) c2 = 0;
    if (c2 > (int)lines_[l2].size()) c2 = (int)lines_[l2].size();
}

void Doc::selectAll() {
    al_ = 0;
    ac_ = 0;
    cl_ = (int)lines_.size() - 1;
    cc_ = (int)lines_.back().size();
    hasSel_ = true;
}

void Doc::selectLine(int line) {
    if (line < 0 || line >= (int)lines_.size()) return;
    al_ = line;
    ac_ = 0;
    cl_ = line;
    cc_ = (int)lines_[line].size();
    hasSel_ = true;
}

void Doc::selectWord(int line, int col) {
    if (line < 0 || line >= (int)lines_.size()) return;
    const U16& L = lines_[line];
    if (col > (int)L.size()) col = (int)L.size();
    int a = col, b = col;
    while (a > 0 && isIdentCont(L[a - 1])) a--;
    while (b < (int)L.size() && isIdentCont(L[b])) b++;
    if (a == b) {
        // no word: select nothing
        setCursor(line, col);
        return;
    }
    al_ = line;
    ac_ = a;
    cl_ = line;
    cc_ = b;
    hasSel_ = true;
}

void Doc::moveHorizontal(int dir, bool extend) {
    vMode_ = false;
    if (!extend && hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        if (dir < 0) { cl_ = l1; cc_ = c1; } else { cl_ = l2; cc_ = c2; }
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
        desiredCol_ = cc_;
        return;
    }
    if (dir < 0) {
        if (cc_ > 0) {
            const U16& L = lines_[cl_];
            cc_ -= (cc_ >= 2 && surIsLow(L[cc_ - 1]) && surIsHigh(L[cc_ - 2])) ? 2 : 1;
        } else if (cl_ > 0) {
            cl_--;
            cc_ = (int)lines_[cl_].size();
        }
    } else {
        if (cc_ < (int)lines_[cl_].size()) {
            const U16& L = lines_[cl_];
            cc_ += (surIsHigh(L[cc_]) && cc_ + 1 < (int)L.size() && surIsLow(L[cc_ + 1])) ? 2 : 1;
        } else if (cl_ + 1 < (int)lines_.size()) {
            cl_++;
            cc_ = 0;
        }
    }
    if (extend) {
        hasSel_ = true;
    } else {
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
    }
    desiredCol_ = cc_;
}

void Doc::moveVertical(int dir, bool extend) {
    if (!vMode_) {
        desiredCol_ = cc_;
        vMode_ = true;
    }
    int nl = cl_ + dir;
    if (nl < 0 || nl >= (int)lines_.size()) return;
    cl_ = nl;
    int want = desiredCol_;
    int len = (int)lines_[cl_].size();
    if (want > len) want = len;
    if (want > 0 && want < len && surIsLow(lines_[cl_][want]) && surIsHigh(lines_[cl_][want - 1])) want--;
    cc_ = want;
    if (extend) {
        hasSel_ = true;
    } else {
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
    }
}

void Doc::moveLineEdge(bool toEnd, bool extend) {
    const U16& L = lines_[cl_];
    if (toEnd) {
        cc_ = (int)L.size();
    } else {
        int first = 0;
        while (first < (int)L.size() && (L[first] == u' ' || L[first] == u'\t')) first++;
        cc_ = (cc_ == first) ? 0 : first;
    }
    vMode_ = false;
    desiredCol_ = cc_;
    if (extend) hasSel_ = true;
    else {
        hasSel_ = false;
        al_ = cl_;
        ac_ = cc_;
    }
}

U16 Doc::selectedText() const {
    if (!hasSel_) return U16();
    int l1, c1, l2, c2;
    normalizeSel(l1, c1, l2, c2);
    if (l1 == l2) return lines_[l1].substr(c1, c2 - c1);
    U16 out = lines_[l1].substr(c1);
    for (int i = l1 + 1; i < l2; i++) {
        out += u'\n';
        out += lines_[i];
    }
    out += u'\n';
    out += lines_[l2].substr(0, c2);
    return out;
}

// ------------------------------------------------------------------ editing
void Doc::put(const U16& text) {
    if (text.empty()) return;
    std::vector<U16> parts;
    size_t start = 0;
    for (size_t i = 0; i < text.size(); i++) {
        if (text[i] == u'\n') {
            parts.push_back(text.substr(start, i - start));
            start = i + 1;
        }
    }
    parts.push_back(text.substr(start));

    int startLine = cl_;
    if (parts.size() == 1) {
        lines_[cl_].insert(cc_, parts[0]);
        cc_ += (int)parts[0].size();
    } else {
        U16 head = lines_[cl_].substr(0, cc_);
        U16 tail = lines_[cl_].substr(cc_);
        lines_[cl_] = head + parts[0];
        U16 last = parts.back() + tail;
        std::vector<U16> mids;
        for (size_t i = 1; i + 1 < parts.size(); i++) mids.push_back(parts[i]);
        int insertAt = cl_ + 1;
        lines_.insert(lines_.begin() + insertAt, last);
        meta_.insert(meta_.begin() + insertAt, LineData());
        if (!mids.empty()) {
            lines_.insert(lines_.begin() + insertAt, mids.begin(), mids.end());
            meta_.insert(meta_.begin() + insertAt, mids.size(), LineData());
        }
        cl_ = startLine + (int)parts.size() - 1;
        cc_ = (int)parts.back().size();
    }
    afterEdit(startLine);
}

void Doc::eraseRange(int l1, int c1, int l2, int c2) {
    if (l1 == l2) {
        if (c2 > c1) lines_[l1].erase(c1, c2 - c1);
        cl_ = l1;
        cc_ = c1;
        afterEdit(l1);
        return;
    }
    U16 joined = lines_[l1].substr(0, c1) + lines_[l2].substr(c2);
    lines_[l1] = joined;
    lines_.erase(lines_.begin() + l1 + 1, lines_.begin() + l2 + 1);
    meta_.erase(meta_.begin() + l1 + 1, meta_.begin() + l2 + 1);
    cl_ = l1;
    cc_ = c1;
    afterEdit(l1);
}

bool Doc::insertText(const U16& s) {
    if (s.empty()) return false;
    snap(false);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    put(s);
    return true;
}

bool Doc::insertTyped(char16_t c) {
    snap(true);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    const U16& L = lines_[cl_];
    bool atEnd = (cc_ >= (int)L.size());

    if (autoPair_) {
        if (c == u')' || c == u']' || c == u'}') {
            if (!atEnd && L[cc_] == c) {
                cc_++;
                desiredCol_ = cc_;
                return true;
            }
        }
        if (c == u'(' || c == u'[' || c == u'{') {
            U16 pair;
            pair += c;
            pair += (c == u'(') ? u')' : (c == u'[') ? u']' : u'}';
            put(pair);
            cc_--;
            desiredCol_ = cc_;
            return true;
        }
        if (c == u'"' || c == u'\'') {
            char16_t prev = (cc_ > 0) ? L[cc_ - 1] : 0;
            char16_t next = atEnd ? 0 : L[cc_];
            bool prevOk = !(isIdentCont(prev) || prev == u'"' || prev == u'\'');
            bool nextOk = (atEnd || next == u' ' || next == u')' || next == u']' ||
                           next == u'}' || next == u',' || next == u':' || next == u'\t');
            if (prevOk && nextOk) {
                U16 pair;
                pair += c;
                pair += c;
                put(pair);
                cc_--;
                desiredCol_ = cc_;
                return true;
            }
        }
    }
    U16 s(1, c);
    put(s);
    desiredCol_ = cc_;
    return true;
}

bool Doc::backspace() {
    snap(true);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
        return true;
    }
    if (cc_ > 0) {
        U16& L = lines_[cl_];
        if (cc_ < (int)L.size()) {
            char16_t prev = L[cc_ - 1], next = L[cc_];
            if ((prev == u'(' && next == u')') || (prev == u'[' && next == u']') ||
                (prev == u'{' && next == u'}') || (prev == u'"' && next == u'"') ||
                (prev == u'\'' && next == u'\'')) {
                eraseRange(cl_, cc_ - 1, cl_, cc_ + 1);
                return true;
            }
        }
        int n = (cc_ >= 2 && surIsHigh(L[cc_ - 2]) && surIsLow(L[cc_ - 1])) ? 2 : 1;
        eraseRange(cl_, cc_ - n, cl_, cc_);
        return true;
    }
    if (cl_ > 0) {
        int prevLen = (int)lines_[cl_ - 1].size();
        eraseRange(cl_ - 1, prevLen, cl_, 0);
        return true;
    }
    return false;
}

bool Doc::deleteForward() {
    snap(true);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
        return true;
    }
    if (cc_ < (int)lines_[cl_].size()) {
        U16& L = lines_[cl_];
        int n = (cc_ + 1 < (int)L.size() && surIsHigh(L[cc_]) && surIsLow(L[cc_ + 1])) ? 2 : 1;
        eraseRange(cl_, cc_, cl_, cc_ + n);
        return true;
    }
    if (cl_ + 1 < (int)lines_.size()) {
        eraseRange(cl_, cc_, cl_ + 1, 0);
        return true;
    }
    return false;
}

bool Doc::newline() {
    snap(true);   // 回车也算连续输入的一批：避免每次回车整篇快照，撤销仍按输入批次合并
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    const U16& L = lines_[cl_];
    size_t k = 0;
    while (k < L.size() && (L[k] == u' ' || L[k] == u'\t')) k++;
    if (k > (size_t)cc_) k = (size_t)cc_;
    U16 ind = L.substr(0, k);
    size_t e = (size_t)cc_;
    while (e > 0 && (L[e - 1] == u' ' || L[e - 1] == u'\t')) e--;
    bool extra = autoIndent_ && e > 0 && L[e - 1] == u':';
    U16 ins = u"\n";
    ins += ind;
    if (extra) ins += U16((size_t)tabSize_, u' ');
    put(ins);
    desiredCol_ = cc_;
    return true;
}

bool Doc::indentBlock(bool outdent) {
    if (!hasSel_) {
        if (!outdent) {
            return insertText(U16((size_t)tabSize_, u' '));
        }
        const U16& L = lines_[cl_];
        int k = 0;
        while (k < tabSize_ && k < cc_ && L[cc_ - 1 - k] == u' ') k++;
        if (k == 0) return false;
        snap(false);
        eraseRange(cl_, cc_ - k, cl_, cc_);
        return true;
    }
    int l1, c1, l2, c2;
    normalizeSel(l1, c1, l2, c2);
    if (c2 == 0 && l2 > l1) l2--;
    snap(false);
    for (int i = l1; i <= l2; i++) {
        if (!outdent) {
            lines_[i].insert((size_t)0, U16((size_t)tabSize_, u' '));
        } else {
            int k = 0;
            const U16& L = lines_[i];
            while (k < tabSize_ && k < (int)L.size()) {
                if (L[k] == u' ') k++;
                else if (L[k] == u'\t') { k++; break; }
                else break;
            }
            if (k > 0) lines_[i].erase(0, k);
        }
    }
    cc_ = std::min(cc_, (int)lines_[cl_].size());
    ac_ = std::min(ac_, (int)lines_[al_].size());
    afterEdit(l1);
    return true;
}

void Doc::setOptions(int tabSize, bool autoIndent, bool autoPair) {
    if (tabSize < 1) tabSize = 1;
    if (tabSize > 16) tabSize = 16;
    tabSize_ = tabSize;
    autoIndent_ = autoIndent;
    autoPair_ = autoPair;
    meta_.assign(lines_.size(), LineData());
    retokenize(0);
}

// ------------------------------------------------------------------ symbols
void Doc::rebuildSymbols() {
    symList_.clear();
    symKind_.clear();
    attrs_.clear();
    auto prio = [](uint8_t k) -> int {
        switch (k) {
            case SK_CLASS: return 5;
            case SK_FUNC: return 4;
            case SK_MODULE: return 3;
            case SK_PARAM: return 2;
            case SK_VAR: return 1;
            default: return 0;
        }
    };
    for (int i = 0; i < (int)meta_.size(); i++) {
        for (const Sym& s : meta_[i].syms) {
            if (s.name.size() < 1) continue;
            if (s.kind == SK_ATTR) {
                attrs_.insert(s.name);
                continue;
            }
            auto it = symKind_.find(s.name);
            if (it == symKind_.end()) {
                symKind_.emplace(s.name, s.kind);
                symList_.push_back(Sym{s.name, s.kind, s.line});
            } else if (prio(s.kind) > prio(it->second)) {
                it->second = s.kind;
            }
        }
    }
    symDirty_ = false;
}

int Doc::fillRuns(int fromLine, int toLine, int32_t* out, int maxRecords) {
    if (symDirty_) rebuildSymbols();
    int cnt = 0;
    if (fromLine < 0) fromLine = 0;
    if (toLine >= (int)lines_.size()) toLine = (int)lines_.size() - 1;
    for (int i = fromLine; i <= toLine; i++) {
        const U16& L = lines_[i];
        for (const Tok& t : meta_[i].toks) {
            if (cnt + 4 > maxRecords) return cnt;
            uint8_t type = t.type;
            if (type == T_TEXT) {
                scratch_.assign(L, t.start, t.end - t.start);
                auto it = symKind_.find(scratch_);
                if (it != symKind_.end()) {
                    if (it->second == SK_FUNC) type = T_USERFUNC;
                    else if (it->second == SK_CLASS) type = T_USERCLASS;
                }
            }
            out[cnt++] = i;
            out[cnt++] = (int32_t)t.start;
            out[cnt++] = (int32_t)t.end;
            out[cnt++] = (int32_t)type;
        }
    }
    return cnt;
}

// ------------------------------------------------------------------ check
void Doc::runCheck() {
    probs_.clear();
    struct Open {
        u32 line;
        u32 col;
        char16_t ch;
    };
    std::vector<Open> stack;
    const int n = (int)lines_.size();

    for (int i = 0; i < n; i++) {
        const U16& L = lines_[i];
        LineData& m = meta_[i];
        if (m.blank) continue;

        // indentation: inside an unclosed ( [ { Python lets you align freely,
        // so only judge lines that start at bracket depth 0
        if (m.depthStart == 0) {
            size_t k = 0;
            bool tabIndent = false;
            for (; k < L.size() && (L[k] == u' ' || L[k] == u'\t'); k++) {
                if (L[k] == u'\t') tabIndent = true;
            }
            if (tabIndent) {
                probs_.push_back(Prob{(u32)i, 0, (u32)k, 1, M_TAB_INDENT});
            } else if (k > 0 && (int)k % tabSize_ != 0) {
                probs_.push_back(Prob{(u32)i, 0, (u32)k, 1, M_INDENT_STEP});
            }
        }

        // brackets
        for (const Tok& t : m.toks) {
            if (t.type != T_OPERATOR || t.end - t.start != 1) continue;
            char16_t c = L[t.start];
            if (c == u'(' || c == u'[' || c == u'{') {
                stack.push_back(Open{(u32)i, t.start, c});
            } else if (c == u')' || c == u']' || c == u'}') {
                if (stack.empty()) {
                    probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_EXTRA_CLOSE});
                } else {
                    char16_t o = stack.back().ch;
                    bool ok = (o == u'(' && c == u')') || (o == u'[' && c == u']') ||
                              (o == u'{' && c == u'}');
                    if (!ok) probs_.push_back(Prob{(u32)i, t.start, t.end, 0, M_MISMATCH_BRACKET});
                    stack.pop_back();
                }
            }
        }

        // block header checks (only when the line is complete)
        if (m.depthEnd == 0 && m.depthStart == 0) {
            size_t ti = 0;
            while (ti < m.toks.size() && m.toks[ti].type == T_COMMENT) ti++;
            if (ti < m.toks.size()) {
                const Tok& first = m.toks[ti];
                bool header = false;
                if (first.type == T_KEYWORD) header = isBlockHeaderKw(tokTextOf(L, first));
                if (!header && first.type == T_KEYWORD && tokTextOf(L, first) == u"async" &&
                    ti + 1 < m.toks.size() && m.toks[ti + 1].type == T_KEYWORD) {
                    U16 w = tokTextOf(L, m.toks[ti + 1]);
                    header = (w == u"def" || w == u"for" || w == u"with");
                }
                if (header) {
                    bool defNoParen = false;
                    if (tokTextOf(L, first) == u"def") {
                        bool hasParen = false;
                        for (const Tok& t : m.toks) {
                            if (t.type == T_OPERATOR && L[t.start] == u'(') { hasParen = true; break; }
                        }
                        defNoParen = !hasParen;
                    }
                    if (defNoParen) {
                        probs_.push_back(Prob{(u32)i, first.start, first.end, 0, M_DEF_PARENS});
                    }
                    // find a ':' at depth 0
                    int d = 0;
                    bool hasColon = false;
                    u32 colonPos = (u32)L.size();
                    for (const Tok& t : m.toks) {
                        if (t.type != T_OPERATOR) continue;
                        char16_t c = L[t.start];
                        if (c == u'(' || c == u'[' || c == u'{') d++;
                        else if (c == u')' || c == u']' || c == u'}') d--;
                        else if (d == 0 && t.end - t.start == 1 && c == u':') {
                            hasColon = true;
                            colonPos = t.start;
                            break;
                        }
                    }
                    if (!hasColon) {
                        probs_.push_back(Prob{(u32)i, (u32)L.size(), (u32)L.size(), 0, M_COLON});
                    } else {
                        // does the last code token sit right at the colon?
                        int last = -1;
                        for (int t = (int)m.toks.size() - 1; t >= 0; t--) {
                            if (m.toks[t].type == T_COMMENT) continue;
                            last = t;
                            break;
                        }
                        bool endsColon = last >= 0 && m.toks[last].type == T_OPERATOR &&
                                         m.toks[last].start == colonPos;
                        if (endsColon) {
                            // expect an indented block on the following non blank line
                            int j = i + 1;
                            while (j < n && meta_[j].blank) j++;
                            if (j >= n || meta_[j].indent <= m.indent) {
                                probs_.push_back(Prob{(u32)i, colonPos, colonPos + 1, 0, M_EXPECT_BLOCK});
                            }
                        }
                    }
                }
            }
        }
    }

    // unmatched opens
    for (size_t i = 0; i < stack.size() && i < 8; i++) {
        probs_.push_back(Prob{stack[i].line, stack[i].col, stack[i].col + 1, 0, M_OPEN_BRACKET});
    }

    // unterminated triple quoted string
    if (n > 0 && meta_[n - 1].strEnd != 0) {
        int startLine = n - 1;
        while (startLine > 0 && meta_[startLine].strStart != 0) startLine--;
        probs_.push_back(Prob{(u32)startLine, 0, 0, 0, M_UNTERM_STRING});
    }

    if (probs_.size() > 400) probs_.resize(400);
    probsDirty_ = false;
}

int Doc::problems(bool recheck, Prob*& out) {
    if (recheck || probsDirty_) runCheck();
    out = probs_.empty() ? nullptr : &probs_[0];
    return (int)probs_.size();
}

// ------------------------------------------------------------------ complete
static int matchScore(const U16& name, const U16& prefix) {
    if (prefix.empty()) return 1;
    if (name.size() < prefix.size()) {
        // subsequence only
        size_t i = 0;
        for (size_t j = 0; j < name.size() && i < prefix.size(); j++) {
            if (name[j] == prefix[i]) i++;
        }
        return 0;
    }
    bool pre = true;
    for (size_t i = 0; i < prefix.size(); i++) {
        if (name[i] != prefix[i]) { pre = false; break; }
    }
    if (pre) return (name.size() == prefix.size()) ? 4 : 3;
    bool ci = true;
    for (size_t i = 0; i < prefix.size(); i++) {
        char16_t a = name[i], b = prefix[i];
        if (a >= u'A' && a <= u'Z') a = (char16_t)(a - u'A' + u'a');
        if (b >= u'A' && b <= u'Z') b = (char16_t)(b - u'A' + u'a');
        if (a != b) { ci = false; break; }
    }
    if (ci) return 2;
    for (size_t st = 0; st + prefix.size() <= name.size(); st++) {
        bool ok = true;
        for (size_t i = 0; i < prefix.size(); i++) {
            if (name[st + i] != prefix[i]) { ok = false; break; }
        }
        if (ok) return 1;
    }
    return 0;
}

static int kindRank(uint8_t k) {
    switch (k) {
        case SK_CLASS: return 60;
        case SK_FUNC: return 55;
        case SK_PARAM: return 50;
        case SK_VAR: return 45;
        case SK_MODULE: return 40;
        case SK_ATTR: return 35;
        case SK_SNIPPET: return 70;
        case SK_KW: return 30;
        case SK_BUILTIN: return 25;
        case SK_CONST: return 20;
        default: return 0;
    }
}

std::vector<Candidate> Doc::complete(int maxItems) {
    rebuildSymbols();
    const U16& L = lines_[cl_];
    int end = cc_;
    if (end > (int)L.size()) end = (int)L.size();
    int start = end;
    while (start > 0 && isIdentCont(L[start - 1])) start--;
    U16 prefix = L.substr(start, end - start);
    bool attrMode = (start > 0 && L[start - 1] == u'.');

    std::vector<Candidate> raw;
    if (attrMode) {
        for (const U16& a : attrs_) raw.push_back(Candidate{a, SK_ATTR});
        for (const Sym& s : symList_) {
            if (s.kind == SK_FUNC || s.kind == SK_CLASS) raw.push_back(Candidate{s.name, s.kind});
        }
    } else {
        for (const Sym& s : symList_) raw.push_back(Candidate{s.name, s.kind});
        for (const U16& w : allKeywords()) raw.push_back(Candidate{w, SK_KW});
        for (const U16& w : allSnippets()) raw.push_back(Candidate{w, SK_SNIPPET});
        for (const U16& w : allConsts()) raw.push_back(Candidate{w, SK_CONST});
        for (const U16& w : allBuiltins()) raw.push_back(Candidate{w, SK_BUILTIN});
    }

    struct Ranked {
        int score;
        int rank;
        int len;
        Candidate c;
    };
    std::vector<Ranked> ranked;
    ranked.reserve(raw.size());
    std::unordered_set<U16> seen;
    for (auto& c : raw) {
        if (c.kind != SK_SNIPPET && !seen.insert(c.name).second) continue;
        int sc = matchScore(c.name, prefix);
        if (sc <= 0 && !prefix.empty()) continue;
        ranked.push_back(Ranked{sc, kindRank(c.kind), (int)c.name.size(), c});
    }
    std::sort(ranked.begin(), ranked.end(), [](const Ranked& a, const Ranked& b) {
        if (a.score != b.score) return a.score > b.score;
        if (a.rank != b.rank) return a.rank > b.rank;
        if (a.len != b.len) return a.len < b.len;
        return a.c.name < b.c.name;
    });
    // 名额分配：先每类取一个，再按排序补齐（避免 5 个变量把函数挤掉）
    std::vector<Candidate> out;
    out.reserve((size_t)maxItems);
    std::vector<char> used(ranked.size(), 0);
    std::unordered_set<int> kindsDone;
    for (size_t i = 0; i < ranked.size() && (int)out.size() < maxItems; i++) {
        int k = (int)ranked[i].c.kind;
        if (kindsDone.count(k)) continue;
        kindsDone.insert(k);
        used[i] = 1;
        out.push_back(Candidate{ranked[i].c.name, ranked[i].c.kind});
    }
    for (size_t i = 0; i < ranked.size() && (int)out.size() < maxItems; i++) {
        if (used[i]) continue;
        out.push_back(Candidate{ranked[i].c.name, ranked[i].c.kind});
    }
    return out;
}


// ------------------------------------------------------------------ snippets
bool Doc::insertSnippet(const U16& text, int caretOffset) {
    if (text.empty()) return false;
    snap(false);
    if (hasSel_) {
        int l1, c1, l2, c2;
        normalizeSel(l1, c1, l2, c2);
        hasSel_ = false;
        eraseRange(l1, c1, l2, c2);
    }
    int startLine = cl_, startCol = cc_;
    put(text);
    int tl = startLine, tc = startCol;
    int limit = std::min<int>(caretOffset, (int)text.size());
    for (int i = 0; i < limit; i++) {
        if (text[i] == u'\n') { tl++; tc = 0; }
        else tc++;
    }
    if (tl < (int)lines_.size()) {
        cl_ = tl;
        cc_ = std::min(tc, (int)lines_[tl].size());
    }
    hasSel_ = false;
    al_ = cl_;
    ac_ = cc_;
    desiredCol_ = cc_;
    return true;
}

// ------------------------------------------------------------------ find
static U16 lowerU16(const U16& s) {
    U16 o = s;
    for (auto& c : o) {
        if (c >= u'A' && c <= u'Z') c = (char16_t)(c - u'A' + u'a');
    }
    return o;
}

static bool isWordChar(char16_t c) {
    return (c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z') ||
           (c >= u'0' && c <= u'9') || c == u'_' || c > 127;
}

bool Doc::find(const U16& needle, int fromLine, int fromCol, bool ignoreCase, bool wholeWord,
               int* out3) {
    if (needle.empty()) return false;
    U16 nd = ignoreCase ? lowerU16(needle) : needle;
    int n = (int)lines_.size();
    if (fromLine < 0) fromLine = 0;
    for (int i = fromLine; i < n; i++) {
        const U16& L = lines_[i];
        U16 hay = ignoreCase ? lowerU16(L) : L;
        size_t startPos = (i == fromLine && fromCol > 0) ? (size_t)fromCol : 0;
        if (startPos > hay.size()) startPos = hay.size();
        size_t p = hay.find(nd, startPos);
        while (p != U16::npos) {
            bool ok = true;
            if (wholeWord) {
                if (p > 0 && isWordChar(L[p - 1])) ok = false;
                if (p + nd.size() < L.size() && isWordChar(L[p + nd.size()])) ok = false;
            }
            if (ok) {
                out3[0] = i;
                out3[1] = (int)p;
                out3[2] = (int)(p + nd.size());
                return true;
            }
            p = hay.find(nd, p + 1);
        }
    }
    return false;
}

bool Doc::replaceRange(int l1, int c1, int l2, int c2, const U16& text) {
    if (l1 < 0 || l1 >= (int)lines_.size()) return false;
    if (l2 < 0 || l2 >= (int)lines_.size()) return false;
    setSelection(l1, c1, l2, c2);
    if (text.empty()) {
        if (!hasSel_) return false;
        return backspace();
    }
    return insertText(text);
}

bool Doc::replaceWholeText(const U16& text, int caretLine, int caretCol) {
    snap(false);              // 整篇替换算一步撤销，但不清空撤销栈
    hasSel_ = false;
    loadJoined(text);
    cl_ = caretLine;
    cc_ = caretCol;
    clampCursor();
    al_ = cl_;
    ac_ = cc_;
    desiredCol_ = cc_;
    vMode_ = false;
    hasSel_ = false;
    return true;
}

// ------------------------------------------------------------------ folds
static bool isClauseKw(const U16& w) {
    return w == u"else" || w == u"elif" || w == u"except" || w == u"finally" || w == u"case";
}

static bool isBlockKw(const U16& w) {
    return w == u"def" || w == u"class" || w == u"if" || w == u"elif" || w == u"else" ||
           w == u"for" || w == u"while" || w == u"try" || w == u"except" ||
           w == u"finally" || w == u"with" || w == u"match" || w == u"case" ||
           w == u"async";
}

// 行首关键字 + 行尾（深度 0）冒号
static bool lineHeaderKw(const U16& L, const LineData& m, U16& kw) {
    if (m.depthEnd != 0) return false;
    int t0 = 0;
    while (t0 < (int)m.toks.size() && m.toks[t0].type == T_COMMENT) t0++;
    if (t0 >= (int)m.toks.size()) return false;
    const Tok& first = m.toks[t0];
    if (first.type != T_KEYWORD) return false;
    kw = L.substr(first.start, first.end - first.start);
    if (!isBlockKw(kw)) return false;
    // 最后一个非注释 token 必须是 ':'
    int last = -1;
    for (int t = (int)m.toks.size() - 1; t >= 0; t--) {
        if (m.toks[t].type == T_COMMENT) continue;
        last = t;
        break;
    }
    if (last < 0) return false;
    const Tok& lt = m.toks[last];
    if (lt.type != T_OPERATOR || lt.end - lt.start != 1 || L[lt.start] != u':') return false;
    return true;
}

static bool lineIsImport(const U16& L, const LineData& m) {
    int t0 = 0;
    while (t0 < (int)m.toks.size() && m.toks[t0].type == T_COMMENT) t0++;
    if (t0 >= (int)m.toks.size()) return false;
    const Tok& t = m.toks[t0];
    if (t.type != T_KEYWORD) return false;
    U16 w = L.substr(t.start, t.end - t.start);
    return w == u"import" || w == u"from";
}

void Doc::computeFolds() {
    // 未 lex 的行 blank/indent 都是默认值，会把后续行整段吞进折叠区，先补齐
    for (size_t i = 0; i < meta_.size(); i++) {
        if (meta_[i].rev == 0) {
            retokenize(0);
            break;
        }
    }
    folds_.clear();
    const int n = (int)lines_.size();
    for (int i = 0; i < n; i++) {
        LineData& m = meta_[i];
        if (m.blank) continue;
        if (lineIsImport(lines_[i], m)) {
            int j = i;
            while (j + 1 < n && !meta_[j + 1].blank && lineIsImport(lines_[j + 1], meta_[j + 1])) j++;
            if (j > i) folds_.push_back(Fold{i, j, 1});
            i = j;
            continue;
        }
        U16 kw;
        if (!lineHeaderKw(lines_[i], m, kw)) continue;
        if (isClauseKw(kw)) continue;
        int indent = m.indent;
        int j = i + 1;
        while (j < n && (meta_[j].blank || meta_[j].indent > indent)) j++;
        int end = j - 1;
        // 依次吞掉 else / elif / except / finally / case 子句
        while (j < n && !meta_[j].blank && meta_[j].indent == indent) {
            U16 ckw;
            if (!lineHeaderKw(lines_[j], meta_[j], ckw) || !isClauseKw(ckw)) break;
            int k = j + 1;
            while (k < n && (meta_[k].blank || meta_[k].indent > indent)) k++;
            end = k - 1;
            j = k;
        }
        while (end > i && meta_[end].blank) end--;   // 别吞掉尾部空行
        if (end > i) folds_.push_back(Fold{i, end, 0});
    }
    foldsDirty_ = false;
}

const std::vector<Fold>& Doc::folds() {
    if (foldsDirty_) computeFolds();
    return folds_;
}

U16 Doc::foldHeaderText(int startLine) {
    if (foldsDirty_) computeFolds();
    for (const Fold& f : folds_) {
        if (f.start != startLine) continue;
        if (f.kind == 1) return U16(u"import ...");
        U16 out;
        const LineData& m = meta_[startLine];
        int t0 = 0;
        while (t0 < (int)m.toks.size() && m.toks[t0].type == T_COMMENT) t0++;
        if (t0 >= (int)m.toks.size()) return U16(u"...");
        const Tok& first = m.toks[t0];
        out = lines_[startLine].substr(first.start, first.end - first.start);
        if (out == u"def" || out == u"class") {
            if (t0 + 1 < (int)m.toks.size()) {
                const Tok& nt = m.toks[t0 + 1];
                out += u" ";
                out += lines_[startLine].substr(nt.start, nt.end - nt.start);
            }
        }
        int indent = m.indent;
        int j = f.start + 1;
        while (j <= f.end) {
            if (!meta_[j].blank && meta_[j].indent == indent) {
                U16 ckw;
                if (lineHeaderKw(lines_[j], meta_[j], ckw) && isClauseKw(ckw)) {
                    out += u" ... ";
                    out += ckw;
                }
            }
            j++;
        }
        out += u" ...";
        return out;
    }
    return U16(u"...");
}

}  // namespace pe
