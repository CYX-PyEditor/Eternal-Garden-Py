// PyEditor native engine — pure C++ core (no Android deps).
// Text is stored as UTF-16 so offsets match Java String indices exactly.
#ifndef PYEDIT_ENGINE_H
#define PYEDIT_ENGINE_H

#include <cstdint>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace pe {

typedef std::u16string U16;
typedef uint32_t u32;

// ---- token types (must match Java Theme.TOK_*) ----
enum TokType : uint8_t {
    T_TEXT = 0,
    T_KEYWORD,
    T_BUILTIN,
    T_CONST,
    T_STRING,
    T_COMMENT,
    T_NUMBER,
    T_OPERATOR,
    T_DEF,        // name after `def`
    T_CLASS,      // name after `class`
    T_DECORATOR,
    T_SELF,
    T_PARAM,
    T_USERFUNC,   // identifier that refers to a user-defined function
    T_USERCLASS,  // identifier that refers to a user-defined class
    T_COUNT
};

enum SymKind : uint8_t {
    SK_VAR = 0,
    SK_PARAM,
    SK_FUNC,
    SK_CLASS,
    SK_MODULE,
    SK_ATTR,
    // pseudo kinds used only for completion candidates
    SK_KW = 20,
    SK_CONST = 21,
    SK_BUILTIN = 22,
    SK_SNIPPET = 23
};

// ---- diagnostic messages (ids resolved to strings on the Java side) ----
enum MsgId : int16_t {
    M_NONE = 0,
    M_COLON = 1,
    M_OPEN_BRACKET = 2,
    M_EXTRA_CLOSE = 3,
    M_MISMATCH_BRACKET = 4,
    M_UNTERM_STRING = 5,
    M_TAB_INDENT = 6,
    M_INDENT_STEP = 7,
    M_EXPECT_BLOCK = 8,
    M_DEF_PARENS = 9
};

struct Tok {
    u32 start, end;
    uint8_t type;
};

struct Sym {
    U16 name;
    uint8_t kind;
    u32 line;
};

struct Prob {
    u32 line, start, end;
    int16_t sev;  // 0 error, 1 warning
    int16_t id;   // MsgId
};

struct LineData {
    uint8_t strStart = 0, strEnd = 0;  // 0 none, 1 `"""`, 2 `'''`
    int32_t depthStart = 0, depthEnd = 0;
    std::vector<Tok> toks;
    std::vector<Sym> syms;
    u32 rev = 0;
    int32_t indent = 0;
    bool blank = true;
};

struct Candidate {
    U16 name;
    uint8_t kind;
};

// 折叠区间：kind 0 = 代码块，1 = import 段
struct Fold {
    int32_t start, end;
    uint8_t kind;
};

class Doc {
public:
    Doc();

    // ---- document ----
    void setText(const U16& text);
    U16 getText() const;
    int lineCount() const { return (int)lines_.size(); }
    const U16& lineText(int i) const { return lines_[i]; }
    u32 lineVersion(int i) const {
        if (i < 0 || i >= (int)meta_.size()) return 0;
        return meta_[i].rev;
    }
    int lineLength(int i) const {
        if (i < 0 || i >= (int)lines_.size()) return 0;
        return (int)lines_[i].size();
    }
    int maxLineLength() const { return maxLen_; }
    u32 revision() const { return revision_; }
    bool isDirty() const { return dirty_; }
    void markClean() { dirty_ = false; }

    // ---- cursor / selection ----
    int curLine() const { return cl_; }
    int curCol() const { return cc_; }
    int anchorLine() const { return al_; }
    int anchorCol() const { return ac_; }
    bool hasSelection() const { return hasSel_; }
    void setCursor(int line, int col);
    void setSelection(int l1, int c1, int l2, int c2);
    void selectAll();
    void selectWord(int line, int col);
    void selectLine(int line);
    void moveHorizontal(int dir, bool extend);
    void moveVertical(int dir, bool extend);
    void moveLineEdge(bool toEnd, bool extend);
    U16 selectedText() const;

    // ---- editing ----
    bool insertText(const U16& s);
    bool insertTyped(char16_t c);
    bool backspace();
    bool deleteForward();
    bool newline();
    bool indentBlock(bool outdent);
    bool undo();
    bool redo();
    bool canUndo() const { return !undo_.empty(); }
    bool canRedo() const { return !redo_.empty(); }

    // ---- options ----
    void setOptions(int tabSize, bool autoIndent, bool autoPair);

    // ---- rendering / analysis ----
    int fillRuns(int fromLine, int toLine, int32_t* out, int maxRecords);
    int problems(bool recheck, Prob*& out);
    std::vector<Candidate> complete(int maxItems);
    bool insertSnippet(const U16& text, int caretOffset);
    bool find(const U16& needle, int fromLine, int fromCol, bool ignoreCase, bool wholeWord,
              int* out3);   // out3 = {line, start, end}，返回是否找到
    bool replaceRange(int l1, int c1, int l2, int c2, const U16& text);
    // 整篇替换（「全部替换」用）：只落一个撤销快照，光标放到 caretLine/caretCol
    bool replaceWholeText(const U16& text, int caretLine, int caretCol);
    const std::vector<Fold>& folds();
    U16 foldHeaderText(int startLine);
    void retokenize(int fromLine);

private:
    std::vector<U16> lines_;
    std::vector<LineData> meta_;
    int maxLen_ = 0;

    int cl_ = 0, cc_ = 0;
    int al_ = 0, ac_ = 0;
    bool hasSel_ = false;
    int desiredCol_ = 0;
    bool vMode_ = false;

    int tabSize_ = 4;
    bool autoIndent_ = true;
    bool autoPair_ = true;

    u32 revision_ = 1;
    bool dirty_ = false;

    struct Snap {
        U16 text;
        int cl, cc, al, ac;
        bool sel;
        size_t bytes;
    };
    std::vector<Snap> undo_, redo_;
    size_t undoTotal_ = 0;
    bool typingBurst_ = false;

    bool symDirty_ = true;
    std::vector<Sym> symList_;
    std::unordered_map<U16, uint8_t> symKind_;
    std::unordered_set<U16> attrs_;
    std::vector<Prob> probs_;
    bool probsDirty_ = true;
    long long lastSnapMs_ = 0;
    long long lastEditMs_ = 0;
    U16 scratch_;
    std::vector<Fold> folds_;
    bool foldsDirty_ = true;
    void computeFolds();

    void snap(bool typing);
    void loadJoined(const U16& text);
    void trimUndo();
    void put(const U16& s);
    void eraseRange(int l1, int c1, int l2, int c2);
    void normalizeSel(int& l1, int& c1, int& l2, int& c2) const;
    void clampCursor();
    void afterEdit(int firstLine);
    void rebuildSymbols();
    void runCheck();
    void touchMaxLen(int line);
};

const std::vector<U16>& allKeywords();
const std::vector<U16>& allConsts();
const std::vector<U16>& allBuiltins();
const std::vector<U16>& allSnippets();

bool isKeyword(const U16& s);
bool isBuiltin(const U16& s);
bool isConstName(const U16& s);
void tokenizeLine(const U16& s, uint8_t& strState, int32_t& depth,
                  std::vector<Tok>& toks, std::vector<Sym>& syms, int32_t lineNo);

}  // namespace pe

#endif
