#!/bin/bash
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
# Build PyEditor.apk without Gradle: clang-19 (cross) + javac + d8 + aapt + apksigner
set -e
cd "$(dirname "$0")"

SDK=/opt/android-sdk
BT=$SDK/build-tools-tmp
AJ=$SDK/platforms/android-35/android.jar
A2="qemu-x86_64-static -L /opt/x86root $SDK/build-tools-tmp/aapt2"
JDK=/usr/lib/jvm/java-17-openjdk-arm64
SR=/opt/asysroot/ndk-sysroot/data/data/com.termux/files/usr
SZ=$PWD/libs/shizuku
LIBS="$SZ/api12.jar:$SZ/aidl.jar:$SZ/shared.jar:$SZ/provider12.jar:$PWD/libs/xz.jar"
JARS="${LIBS//:/ }"
OUT=build

mkdir -p dist

echo "== native =="
mkdir -p lib/arm64-v8a
rm -f lib/arm64-v8a/libmpyrun.so
clang++-19 --target=aarch64-linux-android24 --sysroot=$SR -std=c++17 -O2 -fPIC -shared -nostdlib \
  -I /opt/asysroot/inc-arch -I /opt/asysroot/inc-cxx \
  -isystem $JDK/include -isystem $JDK/include/linux \
  -fno-exceptions -fno-rtti -fvisibility=hidden -fstack-protector-strong \
  -Wall -Wextra -Wno-unused-parameter \
  -Wl,-z,max-page-size=16384 -Wl,-z,noexecstack -Wl,--unresolved-symbols=ignore-all \
  -Wl,-soname,libpyedit.so -Wl,-O1 \
  native/lexer.cpp native/doc.cpp native/jni.cpp \
  -o lib/arm64-v8a/libpyedit.so -L$SR/lib -lc++_shared
cp -f $SR/lib/libc++_shared.so lib/arm64-v8a/libc++_shared.so

echo "== interpreters =="
cp -f libs/cpython/libcpython.so lib/arm64-v8a/libcpython.so
python3 tools/fix_tls_align.py lib/arm64-v8a/libcpython.so >/dev/null

echo "== resources =="
rm -rf $OUT
mkdir -p $OUT/gen/com/yhhy/pyeditor $OUT/classes $OUT/dex
# build-tools 的 aapt2 是 x86_64，用 qemu 跑；android-35 平台 jar 才认 enableOnBackInvokedCallback
$A2 compile --dir res -o $OUT/res.zip
$A2 link -o $OUT/base.apk -I $AJ --manifest AndroidManifest.xml -A assets \
  -R $OUT/res.zip --auto-add-overlay --java $OUT/gen --min-sdk-version 24 --target-sdk-version 34

echo "== obfuscated source copy =="
rm -rf $OUT/obfuscated_java
mkdir -p $OUT/obfuscated_java/com/yhhy
cp -r java/com/yhhy/pyeditor $OUT/obfuscated_java/com/yhhy/
python3 tools/strip_java_comments.py $OUT/obfuscated_java

echo "== javac =="
find $OUT/gen $OUT/obfuscated_java -name '*.java' > $OUT/sources.txt
rm -rf $OUT/classes; mkdir -p $OUT/classes
javac -source 8 -target 8 -encoding UTF-8 -nowarn \
  -bootclasspath $AJ:$BT/core-lambda-stubs.jar \
  -classpath $AJ:$BT/core-lambda-stubs.jar:$LIBS \
  -d $OUT/classes @$OUT/sources.txt

echo "== dex (R8 obfuscate) =="
find $OUT/classes -name '*.class' > $OUT/classes.txt
rm -rf $OUT/dex; mkdir -p $OUT/dex
$JDK/bin/java -Dfile.encoding=UTF-8 -cp $BT/lib/d8.jar com.android.tools.r8.R8 \
  --release --min-api 24 --lib $AJ --pg-conf tools/proguard-rules.pro \
  --output $OUT/dex @$OUT/classes.txt $JARS
if [ -f $OUT/dex/classes2.dex ]; then echo "WARN: R8 produced multidex"; fi

echo "== package =="
python3 tools/pack.py $OUT/base.apk $OUT/unsigned.apk $OUT/dex/classes.dex lib

if [ ! -f keystore.jks ]; then
  echo "== keystore =="
  $JDK/bin/keytool -genkeypair -keystore keystore.jks -alias yuxuan -keyalg RSA \
    -keysize 2048 -validity 10000 -storepass pyedit -keypass pyedit \
    -dname "CN=雨萱之华, OU=PyEditor, O=萱意永恒, L=CN, ST=CN, C=CN" >/dev/null 2>&1
fi

echo "== sign =="
$JDK/bin/java -jar $BT/lib/apksigner.jar sign --ks keystore.jks --ks-pass pass:pyedit \
  --key-pass pass:pyedit --ks-key-alias yuxuan --min-sdk-version 24 \
  --out dist/PyEditor.apk $OUT/unsigned.apk

$JDK/bin/java -jar $BT/lib/apksigner.jar verify --min-sdk-version 24 dist/PyEditor.apk
ls -l dist/PyEditor.apk
echo "OK"
