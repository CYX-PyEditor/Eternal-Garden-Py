#include <cstdio>
#include <cstring>
#include "../native/engine.h"
using namespace pe;
static const char* tname(int t){
  static const char* n[]={"TEXT","KW","BUILTIN","CONST","STRING","COMMENT","NUMBER","OP","DEF","CLASS","DECOR","SELF","PARAM","USERFUNC","USERCLASS"};
  return (t>=0&&t<T_COUNT)?n[t]:"?";
}
int main(){
  Doc d;
  U16 src = u"import os\n\n# comment\nclass Foo:\n    def bar(self, x, y=1):\n        self.x = x\n        return x  # tail\n\nf = Foo()\nprint(f.bar(1))\n";
  d.setText(src);
  printf("lines=%d maxlen=%d\n", d.lineCount(), d.maxLineLength());
  int32_t runs[2000];
  for (int i=0;i<d.lineCount();i++){
    int n = d.fillRuns(i,i,runs,2000);
    printf("L%d [%d recs] ", i, n/4);
    U16 lt = d.lineText(i);
    for(int k=0;k<n;k+=4){
      U16 s = lt.substr(runs[k+1], runs[k+2]-runs[k+1]);
      std::string a; for(char16_t c: s) a += (char)(c<128?c:'?');
      printf("{%s:%s} ", a.c_str(), tname(runs[k+3]));
    }
    printf("\n");
  }
  // completion at start of line 10
  d.setCursor(10, 0);
  auto c = d.complete(12);
  printf("complete@L10: ");
  for (auto& x : c){ std::string a; for(char16_t ch: x.name) a += (char)(ch<128?ch:'?'); printf("%s(%d) ", a.c_str(), x.kind); }
  printf("\n");
  // syntax check on a bad doc
  Doc e;
  e.setText(u"def f(x)\nif x\n    print('a'\nelse:\npass\n  y = 1\ns = '''abc\n");
  Prob* p; int pc = e.problems(true, p);
  printf("problems=%d\n", pc);
  for(int i=0;i<pc;i++) printf("  line=%u col=%u-%u sev=%d msg=%d\n", p[i].line, p[i].start, p[i].end, p[i].sev, p[i].id);
  // editing: type at end
  d.setCursor(3,0);
  d.insertTyped(u'x'); d.insertTyped(u'(');
  printf("after type L3: ");
  U16 l3 = d.lineText(3); for(char16_t ch: l3) putchar(ch<128?ch:'?'); printf("\n");
  d.backspace(); d.backspace();
  printf("after bs L3: ");
  l3 = d.lineText(3); for(char16_t ch: l3) putchar(ch<128?ch:'?'); printf("\n");
  printf("undo->%d ", (int)d.undo());
  U16 all = d.getText(); printf("rev=%u lines=%d\n", d.revision(), d.lineCount());
  (void)all;
  return 0;
}
