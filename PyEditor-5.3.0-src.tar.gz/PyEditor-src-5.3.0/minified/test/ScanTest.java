package com.yhhy.pyeditor;

import java.util.ArrayList;

/** FoldScan + SymbolStats 的 JVM 单测（不进 APK）：javac -d out 后 java com.yhhy.pyeditor.ScanTest */
public class ScanTest {
    static int pass = 0, fail = 0;

    static String[] L(String... l) { return l; }

    static void fold(String title, String[] src, int start, int end, String type, String summary) {
        ArrayList<FoldScan.Block> got = FoldScan.scan(src);
        String want = start + "-" + end + ":" + type + ":" + summary;
        String have = got.size() != 1 ? "<" + got.size() + " blocks>" :
                got.get(0).start + "-" + got.get(0).end + ":" + got.get(0).typeText + ":" + got.get(0).summary;
        if (want.equals(have)) { pass++; System.out.println("OK   " + title); }
        else { fail++; System.out.println("FAIL " + title + "\n  got  " + have + "\n  want " + want); }
    }

    static void none(String title, String[] src) {
        ArrayList<FoldScan.Block> got = FoldScan.scan(src);
        if (got.isEmpty()) { pass++; System.out.println("OK   " + title); }
        else { fail++; System.out.println("FAIL " + title + " got " + got.size() + " blocks"); }
    }

    static void sym(String title, String[] src, String expect) {
        ArrayList<SymbolStats.Sym> got = SymbolStats.scan(src);
        StringBuilder sb = new StringBuilder();
        for (SymbolStats.Sym s : got) {
            if (sb.length() > 0) sb.append(";");
            sb.append(s.name).append("@").append(s.line)
              .append(s.cls ? ("{a=" + s.attrs + ",m=" + s.methods + "}") : ("{u=" + s.uses + "}"));
        }
        if (sb.toString().equals(expect)) { pass++; System.out.println("OK   " + title); }
        else { fail++; System.out.println("FAIL " + title + "\n  got  " + sb + "\n  want " + expect); }
    }

    public static void main(String[] a) {
        // ---- 多行折叠 + 类型
        fold("dict 多行", L("cfg = {", "    'a': 1,", "    'b': 2,", "}"),
                0, 3, "dict[str, int]", "cfg = dict[str, int] ...");
        fold("dict 多行 两种值类型", L("cfg = {", "    'a': 1,", "    'b': 2.5,", "}"),
                0, 3, "dict[str, int|float]", "cfg = dict[str, int|float] ...");
        fold("tuple 多行", L("pt = (", "    1,", "    'a',", ")"),
                0, 3, "tuple[int, str]", "pt = tuple[int, str] ...");
        fold("set 多行", L("s = {", "    1,", "    2,", "}"),
                0, 3, "set[int]", "s = set[int] ...");
        fold("list 多行", L("items = [", "    1,", "    2,", "]"),
                0, 3, "list[int]", "items = list[int] ...");
        fold("dict 值嵌套 list", L("data = {", "    'k': [1, 2],", "}"),
                0, 2, "dict[str, list]", "data = dict[str, list] ...");
        fold("多行空 dict", L("d = {", "}"), 0, 1, "dict", "d = dict ...");
        fold("self 属性", L("self.cfg = {", "    'a': 1,", "}"),
                0, 2, "dict[str, int]", "self.cfg = dict[str, int] ...");
        fold("类型标注", L("x: dict[str, int] = {", "    'a': 1,", "}"),
                0, 2, "dict[str, int]", "x = dict[str, int] ...");
        fold("dict( 构造", L("cfg = dict(", "    a=1,", "    b=2,", ")"),
                0, 3, "dict[Any, Any]", "cfg = dict[Any, Any] ...");
        fold("list( 构造", L("l = list(", "    x,", ")"),
                0, 2, "list[Any]", "l = list[Any] ...");
        fold("嵌套只折最外层", L("data = {", "    'k': [", "        1,", "    ],", "}"),
                0, 4, "dict[str, list]", "data = dict[str, list] ...");

        // ---- 单行：也给类型 + 摘要（5.2.1 起单行也能折叠）
        fold("单行 list", L("items = [1, 2]"), 0, 0, "list[int]", "items = list[int] ...");
        fold("单行 混合两种", L("items = [1, 2.5]"), 0, 0, "list[int, float]", "items = list[int, float] ...");
        fold("单行 超过两种 Any", L("items = [1, 'a', True]"), 0, 0, "list[Any]", "items = list[Any] ...");
        fold("单行 tuple", L("p = (1, 'a')"), 0, 0, "tuple[int, str]", "p = tuple[int, str] ...");
        fold("单行 set", L("s = {1, 2}"), 0, 0, "set[int]", "s = set[int] ...");
        fold("单行 dict", L("d = {'a': 1}"), 0, 0, "dict[str, int]", "d = dict[str, int] ...");
        fold("单行 dict 两种键两种值", L("d = {'a': 1, 2: 'b'}"),
                0, 0, "dict[str|int, int|str]", "d = dict[str|int, int|str] ...");
        fold("单行 dict 超过两种两侧", L("d = {1: 'a', 2: 3, 3.0: True, 'k': []}"),
                0, 0, "dict[Any, Any]", "d = dict[Any, Any] ...");
        fold("空 list", L("l = []"), 0, 0, "list", "l = list ...");
        fold("空 dict", L("d = {}"), 0, 0, "dict", "d = dict ...");
        fold("bytes / str", L("l = ['x', b'y']"), 0, 0, "list[str, bytes]", "l = list[str, bytes] ...");
        fold("三种类型→Any", L("l = [True, None, 1j]"), 0, 0, "list[Any]", "l = list[Any] ...");
        fold("两种类型", L("l = [True, None]"), 0, 0, "list[bool, None]", "l = list[bool, None] ...");
        fold("十六进制 / 下划线", L("l = [1_000, -2, 0x10]"), 0, 0, "list[int]", "l = list[int] ...");
        fold("f-string", L("l = [f'a{b}']"), 0, 0, "list[str]", "l = list[str] ...");
        fold("set 展开", L("s = {*a}"), 0, 0, "set[Any]", "s = set[Any] ...");
        fold("dict 展开", L("d = {**a}"), 0, 0, "dict[Any, Any]", "d = dict[Any, Any] ...");
        fold("同一行只取第一个赋值", L("a = [1]; b = [2]"), 0, 0, "list[int]", "a = list[int] ...");

        // ---- 不该折叠/标注的
        none("比较 == 不处理", L("if x == [", "    1,", "]:", "    pass"));
        none("+= 不处理", L("x += [", "    1,", "]"));
        none("print 调用不处理", L("print([", "    1,", "])"));
        none("return 不处理", L("return [", "    1,", "]"));
        none("for..in 不处理", L("for x in [", "    1,", "]:", "    pass"));
        none("未闭合不处理", L("x = [", "    1,"));
        none("元组解包不处理", L("a, b = (", "    1,", "    2,", ")"));
        none("多行函数签名不误判", L("def f(", "    a=[", "        1,", "    ],", "):", "    pass"));
        none("字符串里的括号不干扰", L("x = '['", "y = 1"));
        none("三引号里的括号不干扰", L("s = \"\"\"", "[", "\"\"\"", "y = 1"));
        none("注释里的括号不干扰", L("x = 1  # [1, 2]"));

        // ---- 符号统计
        sym("函数被引用次数",
                L("def greet(name):", "    return 'hi ' + name", "greet('x')", "print(greet)"),
                "greet@0{u=2}");
        sym("字符串/注释里的不算引用",
                L("def f():", "    pass", "# f()", "s = \"f\"", "f()"),
                "f@0{u=1}");
        sym("类：属性 + 方法",
                L("class Greeter:",
                  "    kind = 'x'",
                  "    def __init__(self, p):",
                  "        self.prefix = p",
                  "        self.name: str = ''",
                  "    def run(self):",
                  "        return self.prefix"),
                "Greeter@0{a=3,m=2}");
        sym("嵌套函数不算方法",
                L("class A:", "    def m(self):", "        def inner():", "            pass", "        return 1"),
                "A@0{a=0,m=1}");
        sym("类文档字符串 + 类属性",
                L("class B:", "    \"\"\"doc\"\"\"", "    x = 1", "    def m(self): pass"),
                "B@0{a=1,m=1}");
        sym("async def",
                L("async def go():", "    pass", "go()"),
                "go@0{u=1}");
        sym("三引号里的 def 不算",
                L("s = \"\"\"", "def fake():", "    pass", "\"\"\""),
                "");
        sym("装饰器方法",
                L("class C:", "    @property", "    def x(self):", "        return 1"),
                "C@0{a=0,m=1}");

        System.out.println("\npass=" + pass + " fail=" + fail);
        if (fail > 0) System.exit(1);
    }
}
