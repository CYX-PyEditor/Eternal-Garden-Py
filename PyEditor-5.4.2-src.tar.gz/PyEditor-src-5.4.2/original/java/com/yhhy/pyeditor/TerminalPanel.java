package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/** 内置终端：命令优先走 Shizuku（shell 身份），否则退回本应用身份。 */
public class TerminalPanel extends LinearLayout {

    public interface Host {
        void onCloseTerminal();
    }

    private static final int MAX_CHARS = 80000;

    private Theme theme;
    private final Host host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final float density;

    private final TextView output;
    private final ScrollView scroll;
    private final EditText input;
    private final TextView modeView;
    private final TextView runBtn;
    private LinearLayout inputRow;
    private int level = 5;
    private boolean full;
    private FullListener fullListener;

    public interface FullListener {
        void onFullChanged(boolean full);
    }

    private final SpannableStringBuilder buf = new SpannableStringBuilder();
    private boolean flushPending;
    private final ArrayList<String> history = new ArrayList<>();
    private int histPos = -1;

    private String cwd;
    private boolean cwdTouched;
    private volatile Process running;
    private boolean started;

    public TerminalPanel(Context ctx, Theme theme, Host host, String initialDir) {
        super(ctx);
        this.theme = theme;
        this.host = host;
        if (initialDir != null && !initialDir.trim().isEmpty()) {
            this.cwd = initialDir.trim();
            this.cwdTouched = true;
        }
        this.density = ctx.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setBackgroundColor(theme.statusBg);

        // ---- 标题栏
        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding((int) d(10), 0, (int) d(6), 0);
        bar.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) d(30)));

        TextView title = new TextView(ctx);
        title.setText(Lang.s("终端"));
        title.setTextSize(11.5f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        bar.addView(title);

        modeView = new TextView(ctx);
        modeView.setTextSize(9.5f);
        modeView.setTextColor(theme.statusText);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mlp.setMargins((int) d(8), 0, (int) d(6), 0);
        modeView.setLayoutParams(mlp);
        modeView.setSingleLine(true);
        bar.addView(modeView);

        bar.addView(levelBtn("0", 0));
        bar.addView(levelBtn("1", 1));
        bar.addView(levelBtn("3", 3));
        bar.addView(levelBtn("5", 5));
        bar.addView(levelBtn(Lang.s("全"), -1));
        bar.addView(smallBtn(Lang.s("清"), v -> clear()));
        bar.addView(smallBtn(Lang.s("收起"), v -> {
            if (host != null) host.onCloseTerminal();
        }));
        addView(bar);

        // ---- 输出
        scroll = new ScrollView(ctx);
        scroll.setBackgroundColor(theme.bg);
        scroll.setVerticalScrollBarEnabled(true);
        output = new TextView(ctx);
        output.setTextSize(11f);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextColor(theme.colors[Theme.TOK_TEXT]);
        output.setTextIsSelectable(true);
        output.setPadding((int) d(10), (int) d(6), (int) d(10), (int) d(6));
        output.setLineSpacing(d(1.5f), 1f);
        scroll.addView(output);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scroll.setLayoutParams(slp);
        addView(scroll);

        // ---- 输入行
        inputRow = new LinearLayout(ctx);
        inputRow.setOrientation(HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding((int) d(8), (int) d(4), (int) d(8), (int) d(6));

        TextView prompt = new TextView(ctx);
        prompt.setText("$");
        prompt.setTextSize(12f);
        prompt.setTypeface(Typeface.MONOSPACE);
        prompt.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        prompt.setPadding(0, 0, (int) d(6), 0);
        inputRow.addView(prompt);

        input = new EditText(ctx);
        input.setSingleLine(true);
        input.setTextSize(11.5f);
        input.setTypeface(Typeface.MONOSPACE);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        input.setHint(Lang.s("输入命令，例如 ls -l /sdcard/Download"));
        input.setHintTextColor(theme.gutterText);
        input.setTextColor(theme.colors[Theme.TOK_TEXT]);
        input.setBackground(null);
        input.setPadding((int) d(4), (int) d(4), (int) d(4), (int) d(4));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        input.setLayoutParams(ilp);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN)) {
                submit();
                return true;
            }
            return false;
        });
        inputRow.addView(input);

        inputRow.addView(smallBtn("↑", v -> recall()));
        inputRow.addView(smallBtn("⇧/sdcard", v -> {
            input.setText("cd /sdcard");
            input.setSelection(input.getText().length());
        }));
        runBtn = smallBtn(Lang.s("执行"), v -> {
            if (running != null) {
                interrupt();
            } else {
                submit();
            }
        });
        inputRow.addView(runBtn);
        addView(inputRow);

        setLevel(5);
        updateMode();
    }

    public void setFullListener(FullListener l) {
        fullListener = l;
    }

    public boolean isFull() {
        return full;
    }

    private TextView levelBtn(String text, final int lv) {
        return smallBtn(text, v -> {
            if (lv < 0) {
                if (full) setLevel(level == 0 ? 3 : level);
                else enterFull();
            } else {
                setLevel(lv);
            }
        });
    }

    /** 0=只留标题按钮，1=1 行输出+输入行，3/5=多行输出。 */
    public void setLevel(int lv) {
        full = false;
        applyLevel(lv);
        if (fullListener != null) fullListener.onFullChanged(false);
    }

    private void applyLevel(int lv) {
        if (lv < 0) lv = 0;
        if (lv > 5) lv = 5;
        level = lv;
        boolean show = lv > 0;
        scroll.setVisibility(show ? VISIBLE : GONE);
        inputRow.setVisibility(show ? VISIBLE : GONE);
        int h = lv == 0 ? 30 : lv == 1 ? 96 : lv == 3 ? 136 : 176;
        setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) d(h)));
    }

    public void enterFull() {
        if (full) return;
        full = true;
        scroll.setVisibility(VISIBLE);
        inputRow.setVisibility(VISIBLE);
        setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (fullListener != null) fullListener.onFullChanged(true);
    }

    /** 被另一个面板挤下全屏（不回调，避免递归）。 */
    public void collapseFull() {
        if (!full) return;
        full = false;
        applyLevel(level == 0 ? 3 : level);
    }

    private int d(float v) {
        return Math.round(v * density);
    }

    private TextView smallBtn(String text, OnClickListener l) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextSize(10.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) d(8), (int) d(5), (int) d(8), (int) d(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(d(6));
        bg.setColor(theme.statusBg == 0xFF21252B ? 0xFF2C313A : theme.curLine);
        t.setBackground(bg);
        t.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins((int) d(3), 0, 0, 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    // ------------------------------------------------------------ 生命周期
    public void open() {
        setVisibility(VISIBLE);
        updateMode();
        requestFocus();
        if (!started) {
            started = true;
            append(Lang.s("YHHYPy 终端 · ") + ShellBridge.mode() + "\n", theme.colors[Theme.TOK_COMMENT]);
            append(Lang.s("命令以 ") + ShellBridge.who() + Lang.s(" 身份执行，工作目录 ") + cwd() + "\n\n",
                    theme.colors[Theme.TOK_COMMENT]);
            exec("id && pwd", false);
        }
        input.requestFocus();
        showIme();
    }

    public void close() {
        if (full) {
            full = false;
            applyLevel(level == 0 ? 3 : level);
        }
        setVisibility(GONE);
        hideIme();
        if (fullListener != null) fullListener.onFullChanged(false);
    }

    public boolean isOpen() {
        return getVisibility() == VISIBLE;
    }

    private void showIme() {
        InputMethodManager imm = (InputMethodManager) getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
    }

    private void hideIme() {
        InputMethodManager imm = (InputMethodManager) getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    public void applyTheme(Theme t) {
        theme = t;
        setBackgroundColor(t.statusBg);
        modeView.setTextColor(t.statusText);
        scroll.setBackgroundColor(t.bg);
        output.setTextColor(t.colors[Theme.TOK_TEXT]);
        input.setTextColor(t.colors[Theme.TOK_TEXT]);
        input.setHintTextColor(t.gutterText);
    }

    private String cwd() {
        if (cwd == null) {
            cwd = ShellBridge.defaultDir(getContext());
        }
        return cwd;
    }

    // ------------------------------------------------------------ 执行
    private void submit() {
        if (running != null) return;
        String cmd = input.getText().toString().trim();
        if (cmd.isEmpty()) return;
        input.setText("");
        if (cmd.startsWith("cd") && (cmd.length() == 2 || cmd.charAt(2) == ' ')) {
            cwdTouched = true;
        }
        if (history.isEmpty() || !history.get(history.size() - 1).equals(cmd)) {
            history.add(cmd);
        }
        histPos = history.size();
        append("$ " + cmd + "\n", theme.colors[Theme.TOK_KEYWORD]);
        exec(cmd, cmd.startsWith("cd") && (cmd.length() == 2 || cmd.charAt(2) == ' '));
    }

    private void recall() {
        if (history.isEmpty()) return;
        if (histPos > 0) histPos--;
        input.setText(history.get(histPos));
        input.setSelection(input.getText().length());
    }

    private void exec(final String cmd, final boolean cdMode) {
        final String command = cdMode ? cmd + " && pwd" : cmd;
        Process p;
        try {
            p = ShellBridge.start(command, cwd());
        } catch (Exception e) {
            append(e.getClass().getSimpleName() + ": " + e.getMessage() + "\n",
                    theme.problem);
            append("\n", theme.problem);
            return;
        }
        running = p;
        runBtn.setText(Lang.s("中断"));
        final StringBuilder stdout = new StringBuilder();
        new Thread(() -> {
            try {
                InputStream in = p.getInputStream();
                InputStream er = p.getErrorStream();
                OutputStream out = p.getOutputStream();
                try {
                    out.close();
                } catch (Exception ignored) {
                }
                Thread errThread = new Thread(() -> pipe(er, true, null));
                errThread.start();
                pipe(in, false, stdout);
                errThread.join();
                int code = p.waitFor();
                ui.post(() -> {
                    if (cdMode && code == 0) {
                        String dir = stdout.toString().trim();
                        if (dir.startsWith("/")) {
                            cwd = dir;
                            append("→ " + cwd + "\n", theme.colors[Theme.TOK_COMMENT]);
                        }
                    } else if (code != 0) {
                        append(Lang.s("[退出码 ") + code + "]\n", theme.problem);
                    } else if (cdMode) {
                        append(Lang.s("[目录不存在]\n"), theme.problem);
                    }
                    append("\n", theme.colors[Theme.TOK_TEXT]);
                    running = null;
                    runBtn.setText(Lang.s("执行"));
                });
            } catch (Throwable t) {
                ui.post(() -> {
                    append(t.getClass().getSimpleName() + ": " + t.getMessage() + "\n\n",
                            theme.problem);
                    running = null;
                    runBtn.setText(Lang.s("执行"));
                });
            }
        }, "pye-term").start();
    }

    private void pipe(InputStream in, boolean isErr, StringBuilder collect) {
        byte[] b = new byte[4096];
        try {
            int n;
            while ((n = in.read(b)) > 0) {
                final String s = new String(b, 0, n, "UTF-8");
                if (collect != null) collect.append(s);
                ui.post(() -> append(s, isErr ? theme.problem
                        : theme.colors[Theme.TOK_TEXT]));
            }
        } catch (Exception ignored) {
        }
    }

    private void interrupt() {
        Process p = running;
        if (p != null) {
            try {
                p.destroy();
            } catch (Exception ignored) {
            }
            append("^C\n", theme.problem);
        }
    }

    public void updateMode() {
        modeView.setText(ShellBridge.mode());
        if (!cwdTouched) cwd = null;   // 授权状态变化后重置默认目录
    }

    // ------------------------------------------------------------ 输出
    private void append(String text, int color) {
        if (text == null || text.isEmpty()) return;
        int start = buf.length();
        buf.append(text);
        buf.setSpan(new ForegroundColorSpan(color), start, buf.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (buf.length() > MAX_CHARS) {
            buf.delete(0, buf.length() - MAX_CHARS);
        }
        if (!flushPending) {
            flushPending = true;
            ui.postDelayed(this::flush, 40);
        }
    }

    private void flush() {
        flushPending = false;
        output.setText(buf);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void clear() {
        buf.clearSpans();
        buf.delete(0, buf.length());
        output.setText("");
    }
}
