package com.yhhy.pyeditor;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

/**
 * 横屏沉浸模式（5.4.2）。
 *
 * <p>安卓在横屏时默认不会把状态栏让给应用，代码区上方一直压着一条常驻状态栏。
 * 这里在横屏隐藏状态栏、内容使用整个高度，同时按刘海安全区给内容补左右内边距；
 * 竖屏恢复普通窗口（状态栏照常显示）。
 */
final class Immersive {

    private Immersive() {
    }

    static void apply(Activity a) {
        boolean landscape = a.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        if (landscape) {
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
        applyCutoutPadding(a);
    }

    /** 横屏刘海在左右两侧：给内容留安全区，避免被挖孔盖住。 */
    private static void applyCutoutPadding(Activity a) {
        if (Build.VERSION.SDK_INT < 28) return;
        final View decor = a.getWindow().getDecorView();
        decor.setOnApplyWindowInsetsListener((v, insets) -> {
            android.view.DisplayCutout dc = insets.getDisplayCutout();
            int l = 0, r = 0;
            if (dc != null) {
                l = dc.getSafeInsetLeft();
                r = dc.getSafeInsetRight();
            }
            View content = (v instanceof ViewGroup && ((ViewGroup) v).getChildCount() > 0)
                    ? ((ViewGroup) v).getChildAt(0) : null;
            if (content != null) {
                content.setPadding(l, content.getPaddingTop(), r, content.getPaddingBottom());
            }
            return insets;
        });
        decor.requestApplyInsets();
    }
}
