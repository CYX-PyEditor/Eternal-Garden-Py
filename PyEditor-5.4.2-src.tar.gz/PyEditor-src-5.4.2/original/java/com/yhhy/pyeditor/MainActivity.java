package com.yhhy.pyeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity implements EditorView.Listener {

    private static final int REQ_OPEN = 1001;
    private static final int REQ_SAVE_AS = 1002;

    private EditorView editor;
    private PaneLayout paneLayout;
    private final java.util.ArrayList<Pane> panes = new java.util.ArrayList<>();
    private Pane focusedPane;
    private TextView plusBtn;
    private boolean panePick;
    private int pendingReplaceTab = -1;
    private android.widget.FrameLayout shell;
    private View drawerScrim;
    private LinearLayout drawer;
    private LinearLayout statusBar;
    private android.widget.FrameLayout.LayoutParams drawerLp;
    private int drawerBgUsed;
    private LinearLayout drawerFiles;
    private boolean drawerOpen;
    private int drawerWidth;
    private TerminalPanel terminal;
    private RunPanel runPanel;
    private FindBar findBar;
    private Object backToken;
    private TextView titleView;
    private TextView statusView;
    private TextView undoBtn, redoBtn;
    private LinearLayout topBar;
    private Theme theme;
    /** 一个编辑区：独立 EditorView + 它当前显示的 Tab 下标（-1 表示还没绑定）。 */
    private static class Pane {
        EditorView view;
        int tabIdx = -1;
    }

    private static class Tab {
        String name;
        Uri uri;
        String text;
        int line, col;
        boolean dirty;
    }

    private final java.util.ArrayList<Tab> tabs = new java.util.ArrayList<>();
    private int curTab = -1;
    private Uri currentUri;
    private String currentName = Lang.s("未命名.py");
    private boolean loading;

    /** 欢迎文档：语言设置改了以后要重新生成，所以不做 static final。 */
    private static String welcomeText() {
        return Lang.s("# 欢迎使用 YHHYPy\n")
                + Lang.s("# 支持语法高亮 / 智能补全 / 语法检查\n\n")
                + "def greet(name):\n"
                    + "    message = \"Hello, \" + name\n"
                    + "    print(message)\n"
                    + "    return message\n\n\n"
                    + "class Greeter:\n"
                    + "    def __init__(self, prefix):\n"
                    + "        self.prefix = prefix\n\n"
                    + "    def run(self, who):\n"
                    + "        return self.prefix + who\n\n\n"
                    + "if __name__ == \"__main__\":\n"
                    + "    greet(\"Python\")\n"
                    + "    Greeter(\"> \").run(\"world\")\n";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        theme = Theme.load(this);
        getWindow().setStatusBarColor(theme.statusBg);
        getWindow().setNavigationBarColor(theme.statusBg);
        buildUi();
        editor.setSyntaxCheckEnabled(Prefs.syntaxCheck(this));
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            backToken = BackCompat.registerAnimated(this, new BackCompat.Anim() {
                @Override
                public void onStart() {
                    predictiveStart();
                }

                @Override
                public void onProgress(float progress) {
                    predictiveProgress(progress);
                }

                @Override
                public void onCancel() {
                    predictiveCancel();
                }

                @Override
                public void onInvoke() {
                    predictiveInvoke();
                }
            });
        } else {
            backToken = BackCompat.register(this, this::handleBack);
        }
        App.note("start.txt", "ok lines=" + Native.nativeLineCount(editor.docHandle()));
        try {
            Shizuku.addRequestPermissionResultListener((code, res) -> {
                if (terminal != null) terminal.updateMode();
            });
            Shizuku.addBinderReceivedListener(() -> {
                if (terminal != null && terminal.isOpen()) terminal.updateMode();
            });
        } catch (Throwable ignored) {
        }
        if (!restoreFromIntent()) {
            loadLastOrDefault();
        }
        Immersive.apply(this);
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        Immersive.apply(this);
        if (paneLayout != null) paneLayout.requestLayout();
        updateStatusBarVisibility();
    }

    private float d(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    // ---------------------------------------------------------------- 多编辑区
    /** 小屏最多 2 个区，大屏（平板）最多 4 个。 */
    private int maxPanes() {
        return getResources().getConfiguration().smallestScreenWidthDp >= 600 ? 4 : 2;
    }

    private Pane createPane() {
        final Pane p = new Pane();
        p.view = new EditorView(this);
        p.view.setTheme(theme, true);
        p.view.setSyntaxCheckEnabled(Prefs.syntaxCheck(this));
        p.view.setListener(new PaneListener(p));
        p.view.setEdgeSwipeListener(new EditorView.EdgeSwipeListener() {
            @Override
            public void onProgress(float progress) {
                edgeSwipeProgress(progress);
            }

            @Override
            public void onEnd(boolean open) {
                edgeSwipeEnd(open);
            }
        });
        p.view.setAnnotationListener(name -> {
            focusPane(p);
            if (findBar == null) return;
            findBar.setEditor(p.view);
            findBar.open(name);
        });
        p.view.setOnFocusChangeListener((vv, has) -> {
            if (has) focusPane(p);
        });
        // 点任何位置（含行号栏）都先把焦点切到这个区
        p.view.setOnTouchListener((vv, ev) -> {
            if (ev.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) focusPane(p);
            return false;
        });
        panes.add(p);
        paneLayout.setPanes(paneViews());
        if (focusedPane == null) {
            focusedPane = p;
            editor = p.view;
        }
        updatePlusButton();
        updateStatusBarVisibility();
        return p;
    }

    private java.util.List<View> paneViews() {
        java.util.ArrayList<View> out = new java.util.ArrayList<>();
        for (Pane p : panes) out.add(p.view);
        return out;
    }

    private Pane paneOf(View v) {
        for (Pane p : panes) if (p.view == v) return p;
        return null;
    }

    private final class PaneListener implements EditorView.Listener {
        private final Pane pane;

        PaneListener(Pane p) {
            pane = p;
        }

        @Override
        public void onEditorStateChanged() {
            if (loading || pane != focusedPane) return;
            updateTitle();
            updateStatus();
        }

        @Override
        public void onEditorTextChanged() {
            if (loading || pane != focusedPane) return;
            updateTitle();
        }

        @Override
        public void onRequestSave() {
            save();
        }
    }

    /** 焦点换到另一个编辑区：先保存旧区的快照，再切到新区。 */
    private void focusPane(Pane p) {
        if (p == null) return;
        if (focusedPane == p) {
            editor = p.view;
            return;
        }
        if (focusedPane != null) {
            syncPane(focusedPane);
            focusedPane.view.hideCompletion();
        }
        focusedPane = p;
        editor = p.view;
        if (p.tabIdx >= 0 && p.tabIdx < tabs.size()) {
            Tab t = tabs.get(p.tabIdx);
            curTab = p.tabIdx;
            currentName = t.name;
            currentUri = t.uri;
            editor.setPythonMode(isPythonName(t.name));
            if (!t.dirty) editor.markClean();
        }
        if (findBar != null) {
            if (findBar.isOpen()) findBar.close();
            findBar.setEditor(editor);
        }
        updateTitle();
        updateStatus();
        refreshDrawerFiles();
        if (paneLayout != null) paneLayout.invalidate();
    }

    /** 把一个区的正文/光标/脏标记写回它的 Tab 快照。 */
    private void syncPane(Pane p) {
        if (p == null || p.view == null) return;
        if (p.tabIdx < 0 || p.tabIdx >= tabs.size()) return;
        Tab t = tabs.get(p.tabIdx);
        t.text = p.view.getText();
        t.line = Native.nativeCursorLine(p.view.docHandle());
        t.col = Native.nativeCursorCol(p.view.docHandle());
        t.dirty = p.view.isDirty();
        if (p == focusedPane) {
            t.name = currentName;
            t.uri = currentUri;
        }
    }

    /** 把第 idx 个 Tab 装进指定编辑区。 */
    private void bindTabToPane(Pane p, int idx) {
        if (p == null || idx < 0 || idx >= tabs.size()) return;
        Tab t = tabs.get(idx);
        p.tabIdx = idx;
        boolean isFocused = p == focusedPane;
        loading = true;
        p.view.setDocumentText(t.text == null ? "" : t.text, true);
        loading = false;
        p.view.setPythonMode(isPythonName(t.name));
        if (!t.dirty) p.view.markClean();
        p.view.moveCursorTo(Math.max(0, t.line), Math.max(0, t.col));
        if (isFocused) {
            curTab = idx;
            currentName = t.name;
            currentUri = t.uri;
            updateTitle();
            updateStatus();
        }
    }

    private void updatePlusButton() {
        if (plusBtn == null) return;
        boolean show = Prefs.multiPane(this) && panes.size() < maxPanes();
        plusBtn.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    /** 多区时把底部「行/列」状态栏收起来，给代码让位置。 */
    private void updateStatusBarVisibility() {
        if (statusBar == null) return;
        boolean hide = Prefs.multiPane(this) || panes.size() > 1;
        statusBar.setVisibility(hide ? View.GONE : View.VISIBLE);
    }

    private void hideIme() {
        try {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            View f = getCurrentFocus();
            if (imm != null && f != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    /** + 按钮：新开一个空白编辑区。 */
    private void addPane() {
        if (!Prefs.multiPane(this) || panes.size() >= maxPanes()) return;
        syncTabFromEditor();
        Tab t = new Tab();
        t.name = Lang.s("未命名.py");
        t.text = "";
        tabs.add(t);
        Pane p = createPane();
        focusPane(p);
        bindTabToPane(p, tabs.size() - 1);
        p.view.requestFocus();
        updatePlusButton();
        updateStatusBarVisibility();
        refreshDrawerFiles();
        p.view.showIme();
    }

    /** 分割线把某个区挤没了：销毁该区（Tab 仍留在「打开的文件」里）。 */
    private void removePaneByView(View v) {
        Pane p = paneOf(v);
        if (p == null || panes.size() <= 1) return;
        syncPane(p);
        panes.remove(p);
        paneLayout.setPanes(paneViews());
        if (focusedPane == p) {
            focusedPane = null;
            focusPane(panes.get(0));
            if (editor != null) editor.requestFocus();
        }
        updatePlusButton();
        updateStatusBarVisibility();
        refreshDrawerFiles();
    }

    /** 换位：PaneLayout 已经调换了显示顺序，这里同步数据顺序。 */
    private void swapPaneViews(View a, View b) {
        Pane pa = paneOf(a), pb = paneOf(b);
        if (pa == null || pb == null) return;
        int ia = panes.indexOf(pa), ib = panes.indexOf(pb);
        panes.set(ia, pb);
        panes.set(ib, pa);
        paneLayout.setPanes(paneViews());
        refreshDrawerFiles();
    }

    /** 抽屉点文件：单区直接替换，多区进入「点哪个区替换哪个」状态。 */
    private void requestReplace(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        if (panes.size() <= 1) {
            if (idx == curTab) return;
            syncTabFromEditor();
            loadTab(idx);
            return;
        }
        pendingReplaceTab = idx;
        panePick = true;
        paneLayout.setPickMode(true);
        toast(Lang.s("点一个编辑区，把文件替换进去"));
    }

    private void onPanePicked(View v) {
        Pane target = paneOf(v);
        panePick = false;
        if (paneLayout != null) paneLayout.setPickMode(false);
        int idx = pendingReplaceTab;
        pendingReplaceTab = -1;
        if (target == null || idx < 0 || idx >= tabs.size()) return;
        for (Pane other : panes) {
            if (other != target && other.tabIdx == idx) {
                focusPane(other);
                toast(Lang.s("该文件已在其它编辑区"));
                return;
            }
        }
        focusPane(target);
        bindTabToPane(target, idx);
        target.view.requestFocus();
        refreshDrawerFiles();
        toast(Lang.s("已替换到该编辑区"));
    }

    private boolean anyPaneDirty() {
        for (Pane p : panes) if (p.view != null && p.view.isDirty()) return true;
        return false;
    }

    private void collapsePanes() {
        if (panes.size() <= 1) return;
        for (Pane p : panes) if (p != focusedPane) syncPane(p);
        Pane keep = focusedPane != null ? focusedPane : panes.get(0);
        panes.clear();
        panes.add(keep);
        paneLayout.setPanes(paneViews());
        focusPane(keep);
        refreshDrawerFiles();
        updatePlusButton();
        updateStatusBarVisibility();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(theme.bg);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(theme.statusBg);
        topBar.setPadding((int) d(4), 0, (int) d(4), 0);
        int barH = (int) d(46);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, barH));

        TextView menu = icon("☰", 20, 0xFFE0E0E0);
        menu.setOnClickListener(v -> openDrawer());
        topBar.addView(menu);

        titleView = new TextView(this);
        titleView.setTextColor(0xFFE0E0E0);
        titleView.setTextSize(13);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins((int) d(8), 0, (int) d(6), 0);
        titleView.setLayoutParams(tp);
        titleView.setOnLongClickListener(v -> {
            captureUi();
            return true;
        });
        topBar.addView(titleView);

        undoBtn = icon("↶", 20, 0xFFE0E0E0);
        undoBtn.setOnClickListener(v -> editor.undo());
        redoBtn = icon("↷", 20, 0xFFE0E0E0);
        redoBtn.setOnClickListener(v -> editor.redo());
        TextView runBtn = icon("▶", 18, 0xFF8BD17C);
        runBtn.setOnClickListener(v -> runCurrent());
        topBar.addView(runBtn);
        TextView comp = textBtn(Lang.s("补全"));
        comp.setOnClickListener(v -> {
            editor.requestFocus();
            editor.showCompletion(true);
            editor.showIme();
        });
        comp.setVisibility(View.GONE);
        TextView save = textBtn(Lang.s("保存"));
        save.setOnClickListener(v -> save());
        TextView common = textBtn(Lang.s("常用"));
        common.setOnClickListener(this::showCommonMenu);
        topBar.addView(common);
        topBar.addView(undoBtn);
        topBar.addView(redoBtn);
        TextView compBtn = textBtn(Lang.s("补全"));
        compBtn.setOnClickListener(v -> {
            editor.requestFocus();
            editor.showCompletion(true);
            editor.showIme();
        });
        topBar.addView(compBtn);
        plusBtn = textBtn("+");
        plusBtn.setTextSize(18);
        plusBtn.setPadding((int) d(8), 0, (int) d(8), 0);
        plusBtn.setOnClickListener(v -> addPane());
        plusBtn.setVisibility(View.GONE);
        topBar.addView(plusBtn);
        save.setVisibility(View.GONE);
        root.addView(topBar);

        paneLayout = new PaneLayout(this);
        paneLayout.setColors(theme.bg, theme.gutterText, theme.colors[Theme.TOK_KEYWORD], 0xFFFF6B6B);
        paneLayout.setCallback(new PaneLayout.Callback() {
            @Override
            public void onSqueeze(View v) {
                removePaneByView(v);
            }

            @Override
            public void onSwap(View a, View b) {
                swapPaneViews(a, b);
            }

            @Override
            public void onPick(View v) {
                onPanePicked(v);
            }

            @Override
            public void onSwapModeChanged(boolean on) {
                if (on) {
                    hideIme();
                    toast(Lang.s("已进入换位模式：点一个编辑区，再点另一个交换"));
                }
            }
        });
        root.addView(paneLayout, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        createPane();

        terminal = new TerminalPanel(this, theme, () -> {
            if (terminal != null) terminal.close();
        }, Prefs.termDir(this));
        terminal.setVisibility(View.GONE);
        root.addView(terminal);

        runPanel = new RunPanel(this, theme, () -> {
            if (runPanel != null) runPanel.close();
        });
        runPanel.setVisibility(View.GONE);
        root.addView(runPanel);
        terminal.setFullListener(full -> onPanelFull(terminal, full));
        runPanel.setFullListener(full -> onPanelFull(runPanel, full));

        findBar = new FindBar(this, editor);
        findBar.setVisibility(View.GONE);
        root.addView(findBar);
        // 点行尾「被使用 N 次」→ 打开查找栏并自动填好函数名
        editor.setAnnotationListener(name -> {
            if (findBar != null) findBar.open(name);
        });

        LinearLayout status = new LinearLayout(this);
        statusBar = status;
        status.setOrientation(LinearLayout.HORIZONTAL);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setBackgroundColor(theme.statusBg);
        status.setPadding((int) d(10), 0, (int) d(10), 0);
        status.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) d(24)));
        statusView = new TextView(this);
        statusView.setTextColor(theme.statusText);
        statusView.setTextSize(10.5f);
        statusView.setSingleLine(true);
        statusView.setOnClickListener(v -> showProblems());
        status.addView(statusView);
        root.addView(status);

        shell = new android.widget.FrameLayout(this);
        shell.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0x99000000);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        shell.addView(drawerScrim, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildDrawer();
        android.widget.FrameLayout.LayoutParams dlp = new android.widget.FrameLayout.LayoutParams(
                (int) d(228), ViewGroup.LayoutParams.MATCH_PARENT);
        dlp.gravity = android.view.Gravity.START | android.view.Gravity.TOP;
        drawerLp = dlp;
        shell.addView(drawer, dlp);
        drawer.setVisibility(View.GONE);
        setContentView(shell);
        updateTitle();
        updatePlusButton();
        updateStatusBarVisibility();
    }

    private TextView icon(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) d(8), (int) d(6), (int) d(8), (int) d(6));
        return t;
    }

    private TextView textBtn(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setTextColor(0xFF9DA5B4);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) d(7), (int) d(6), (int) d(7), (int) d(6));
        return t;
    }

    // ---------------------------------------------------------------- files
    private SharedPreferences prefs() {
        return getSharedPreferences("pyedit", MODE_PRIVATE);
    }

    private boolean restoreFromIntent() {
        Intent it = getIntent();
        if (it != null && Intent.ACTION_VIEW.equals(it.getAction()) && it.getData() != null) {
            openUri(it.getData());
            return true;
        }
        return false;
    }

    private void loadLastOrDefault() {
        String last = prefs().getString("last_uri", null);
        if (last != null) {
            try {
                openUri(Uri.parse(last));
                return;
            } catch (Exception ignored) {
            }
        }
        loading = true;
        editor.setDocumentText(welcomeText(), true);
        loading = false;
        currentUri = null;
        currentName = "welcome.py";
        applyLanguage();
        editor.markClean();
        updateTitle();
        updateStatus();
        editor.moveCursorTo(0, 0);
        if (tabs.isEmpty()) {
            Tab t = new Tab();
            t.name = currentName;
            t.text = welcomeText();
            t.uri = null;
            tabs.add(t);
            curTab = 0;
            if (focusedPane != null) focusedPane.tabIdx = 0;
            refreshDrawerFiles();
        }
    }

    /** 只有 .py 走高亮 / 折叠 / 语法检查 / 补全，其它文本文件按 UTF-8 纯文本打开。 */
    private static boolean isPythonName(String n) {
        return n != null && n.toLowerCase(java.util.Locale.ROOT).endsWith(".py");
    }

    private void applyLanguage() {
        if (focusedPane != null) focusedPane.view.setPythonMode(isPythonName(currentName));
        else if (editor != null) editor.setPythonMode(isPythonName(currentName));
    }

    private void syncTabFromEditor() {
        syncPane(focusedPane);
    }

    private void loadTab(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        if (focusedPane == null) return;
        bindTabToPane(focusedPane, idx);
        refreshDrawerFiles();
    }

    private void switchTab(int idx) {
        requestReplace(idx);
    }

    private int pendingCloseSave = -1;

    private void closeTab(final int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Pane holder = null;
        for (Pane p : panes) if (p.tabIdx == idx) holder = p;
        if (holder != null && holder != focusedPane) {
            syncTabFromEditor();
            focusPane(holder);
        }
        if (idx == curTab) syncTabFromEditor();
        final Tab t = tabs.get(idx);
        new android.app.AlertDialog.Builder(this)
                .setMessage(Lang.s("关闭 ") + t.name + " ?")
                .setPositiveButton(Lang.s("保存并关闭"), (d, w) -> saveThenClose(idx))
                .setNegativeButton(Lang.s("不保存关闭"), (d, w) -> closeTabNow(idx))
                .setNeutralButton(Lang.s("取消"), null)
                .show();
    }

    private void saveThenClose(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Tab t = tabs.get(idx);
        if (t.uri == null) {
            pendingCloseSave = idx;
            if (idx == curTab) {
                saveAs();
            } else {
                switchTab(idx);
                saveAs();
            }
            return;
        }
        try {
            if (idx == curTab) syncTabFromEditor();
            writeUri(t.uri);
            toast(Lang.s("已保存"));
            closeTabNow(idx);
        } catch (Exception e) {
            toast(Lang.s("保存失败: ") + e.getMessage());
        }
    }

    private void closeTabNow(int idx) {
        if (idx < 0 || idx >= tabs.size()) return;
        Pane holder = null;
        for (Pane p : panes) if (p.tabIdx == idx) { holder = p; break; }
        tabs.remove(idx);
        for (Pane p : panes) if (p.tabIdx > idx) p.tabIdx--;
        if (holder != null) holder.tabIdx = -1;
        if (tabs.isEmpty()) {
            Tab t = new Tab();
            t.name = Lang.s("未命名.py");
            t.text = "";
            tabs.add(t);
            if (holder != null) bindTabToPane(holder, 0);
            else if (focusedPane != null) bindTabToPane(focusedPane, 0);
        } else if (holder != null) {
            bindTabToPane(holder, Math.min(idx, tabs.size() - 1));
        }
        for (Pane p : panes) {
            if (p.tabIdx >= tabs.size()) p.tabIdx = tabs.size() - 1;
        }
        if (focusedPane != null && focusedPane.tabIdx >= 0 && focusedPane.tabIdx < tabs.size()) {
            Tab ft = tabs.get(focusedPane.tabIdx);
            curTab = focusedPane.tabIdx;
            currentName = ft.name;
            currentUri = ft.uri;
        }
        refreshDrawerFiles();
        updateTitle();
        updateStatus();
    }

    private void newDocument() {
        syncTabFromEditor();
        Tab t = new Tab();
        t.name = Lang.s("未命名.py");
        t.text = "";
        tabs.add(t);
        requestReplace(tabs.size() - 1);
        prefs().edit().remove("last_uri").apply();
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            toast(Lang.s("无法打开文件选择器"));
        }
    }

    private String readText(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("open failed");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > 8 * 1024 * 1024) {
                in.close();
                throw new Exception(Lang.s("文件过大 (超过 8MB)"));
            }
            bos.write(buf, 0, n);
        }
        in.close();
        String s = new String(bos.toByteArray(), StandardCharsets.UTF_8);
        if (s.startsWith("\uFEFF")) s = s.substring(1);
        return s.replace("\r\n", "\n").replace('\r', '\n');
    }

    private void openUri(Uri uri) {
        int existing = -1;
        for (int i = 0; i < tabs.size(); i++) {
            if (uri.equals(tabs.get(i).uri)) { existing = i; break; }
        }
        if (existing >= 0) { requestReplace(existing); return; }
        try {
            String text = readText(uri);
            syncTabFromEditor();
            Tab t = new Tab();
            t.name = displayName(uri);
            t.uri = uri;
            t.text = text;
            tabs.add(t);
            requestReplace(tabs.size() - 1);
            if (panes.size() <= 1) {
                editor.markClean();
                updateTitle();
                updateStatus();
            }
            prefs().edit().putString("last_uri", uri.toString()).apply();
            addRecent(uri);
            int bad = 0;
            for (int i = 0; i < text.length(); i++) {
                if (text.charAt(i) == '\uFFFD') bad++;
            }
            if (text.indexOf('\u0000') >= 0) {
                toast(Lang.s("已按 UTF-8 打开：文件里有 NUL 字节，可能不是纯文本"));
            } else if (bad > 0) {
                toast(Lang.s("已按 UTF-8 打开（") + bad + Lang.s(" 个字符无法解码，显示为 �）"));
            } else if (panes.size() <= 1) {
                toast(Lang.s("已打开 ") + currentName);
            }
        } catch (Exception e) {
            toast(Lang.s("打开失败: ") + e.getMessage());
        }
    }

    private String displayName(Uri uri) {
        // SAF 的 lastPathSegment 经常是文档 id（如 msf:1234），要问系统拿真实文件名，
        // 否则 .py 判断会失效（= 打开 Python 文件却当成纯文本）。
        String name = null;
        try {
            android.database.Cursor c = getContentResolver().query(uri,
                    new String[]{android.provider.OpenableColumns.DISPLAY_NAME},
                    null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) name = c.getString(0);
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) {
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        if (name == null) return Lang.s("未命名.py");
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (name.contains(":")) name = name.substring(name.lastIndexOf(':') + 1);
        return name;
    }

    private void addRecent(Uri uri) {
        String entry = uri.toString() + "\t" + displayName(uri);
        String all = prefs().getString("recent", "");
        ArrayList<String> list = new ArrayList<>();
        list.add(entry);
        if (!all.isEmpty()) {
            for (String s : all.split("\n")) {
                if (s.isEmpty() || s.equals(entry)) continue;
                list.add(s);
                if (list.size() >= 8) break;
            }
        }
        prefs().edit().putString("recent", TextUtils.join("\n", list)).apply();
    }

    /** 退出前把所有「有文件路径」的脏区写盘（无路径的留给 saveAs）。 */
    private void saveAllDirty() {
        for (Pane p : panes) syncPane(p);
        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            if (!t.dirty || t.uri == null) continue;
            try {
                writeText(t.uri, t.text == null ? "" : t.text);
                t.dirty = false;
            } catch (Exception ignored) {
            }
        }
    }

    private void save() {
        if (currentUri == null) {
            saveAs();
            return;
        }
        try {
            writeUri(currentUri);
            editor.markClean();
            updateTitle();
            updateStatus();
            toast(Lang.s("已保存"));
        } catch (Exception e) {
            toast(Lang.s("保存失败: ") + e.getMessage());
        }
    }

    private void saveAs() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(isPythonName(currentName) ? "text/x-python" : "text/plain");
        i.putExtra(Intent.EXTRA_TITLE, currentName);
        try {
            startActivityForResult(i, REQ_SAVE_AS);
        } catch (Exception e) {
            toast(Lang.s("无法打开保存对话框"));
        }
    }

    private void writeUri(Uri uri) throws Exception {
        writeText(uri, editor.getText());
    }

    private void writeText(Uri uri, String text) throws Exception {
        OutputStream os = getContentResolver().openOutputStream(uri, "wt");
        if (os == null) throw new Exception("open failed");
        os.write(text.getBytes(StandardCharsets.UTF_8));
        os.flush();
        os.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        if (requestCode == REQ_OPEN) {
            openUri(uri);
        } else if (requestCode == REQ_SAVE_AS) {
            try {
                writeUri(uri);
                currentUri = uri;
                currentName = displayName(uri);
                applyLanguage();
                editor.markClean();
                updateTitle();
                updateStatus();
                prefs().edit().putString("last_uri", uri.toString()).apply();
                addRecent(uri);
                toast(Lang.s("已保存"));
                if (pendingCloseSave >= 0) {
                    int pc = pendingCloseSave;
                    pendingCloseSave = -1;
                    closeTabNow(pc);
                }
            } catch (Exception e) {
                toast(Lang.s("保存失败: ") + e.getMessage());
            }
        }
    }

    private void showCommonMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, Lang.s("保存"));
        pm.getMenu().add(0, 2, 1, Lang.s("另存为…"));
        pm.getMenu().add(0, 3, 2, Lang.s("缩进"));
        pm.getMenu().add(0, 4, 3, Lang.s("反缩进"));
        pm.getMenu().add(0, 5, 4, Lang.s("查找 / 替换…"));
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: save(); return true;
                case 2: saveAs(); return true;
                case 3: editor.requestFocus(); editor.indent(); return true;
                case 4: editor.requestFocus(); editor.outdent(); return true;
                case 5: editor.requestFocus(); showFindDialog(); return true;
                default: return false;
            }
        });
        pm.show();
    }

    private void showFindDialog() {
        if (findBar != null) findBar.open();
    }

    // ---------------------------------------------------------------- menu
    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, Lang.s("新建文件"));
        pm.getMenu().add(0, 2, 1, Lang.s("打开文件…"));
        pm.getMenu().add(0, 3, 2, Lang.s("保存"));
        pm.getMenu().add(0, 4, 3, Lang.s("另存为…"));
        pm.getMenu().add(0, 5, 4, Lang.s("最近文件…"));
        android.view.SubMenu edit = pm.getMenu().addSubMenu(0, 100, 5, Lang.s("编辑"));
        edit.add(0, 6, 0, Lang.s("全选"));
        edit.add(0, 11, 1, Lang.s("复制"));
        edit.add(0, 12, 2, Lang.s("剪切"));
        edit.add(0, 13, 3, Lang.s("粘贴"));
        edit.add(0, 7, 4, Lang.s("缩进 / 反缩进"));
        edit.add(0, 8, 5, Lang.s("查看语法问题"));
        pm.getMenu().add(0, 15, 6, Lang.s("运行 ▶"));
        pm.getMenu().add(0, 14, 7, Lang.s("终端 / Shell…"));
        pm.getMenu().add(0, 9, 7, Lang.s("设置…"));
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    newDocument();
                    return true;
                case 2:
                    openPicker();
                    return true;
                case 3:
                    save();
                    return true;
                case 4:
                    saveAs();
                    return true;
                case 5:
                    showRecents();
                    return true;
                case 11:
                    if (!editor.copySelection()) toast(Lang.s("没有选中内容"));
                    return true;
                case 12:
                    if (!editor.cutSelection()) toast(Lang.s("没有选中内容"));
                    return true;
                case 13:
                    editor.paste();
                    return true;
                case 6:
                    editor.selectAllSelection();
                    return true;
                case 7:
                    showIndentMenu(anchor);
                    return true;
                case 8:
                    showProblems();
                    return true;
                case 15:
                    runCurrent();
                    return true;
                case 14:
                    toggleTerminal();
                    return true;
                case 9:
                    startActivity(new Intent(this, SettingsActivity.class));
                    return true;
                default:
                    return false;
            }
        });
        pm.show();
    }

    private void showIndentMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, Lang.s("缩进"));
        pm.getMenu().add(0, 2, 1, Lang.s("反缩进"));
        pm.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 1) editor.indent();
            else editor.outdent();
            return true;
        });
        pm.show();
    }

    private void showRecents() {
        String all = prefs().getString("recent", "");
        if (all.isEmpty()) {
            toast(Lang.s("暂无最近文件"));
            return;
        }
        String[] lines = all.split("\n");
        final String[] names = new String[lines.length];
        final String[] uris = new String[lines.length];
        for (int i = 0; i < lines.length; i++) {
            int tab = lines[i].indexOf('\t');
            uris[i] = tab > 0 ? lines[i].substring(0, tab) : lines[i];
            names[i] = tab > 0 ? lines[i].substring(tab + 1) : lines[i];
        }
        new AlertDialog.Builder(this)
                .setTitle(Lang.s("最近文件"))
                .setItems(names, (dlg, which) -> openUri(Uri.parse(uris[which])))
                .setNegativeButton(Lang.s("取消"), null)
                .show();
    }

    private void showProblems() {
        if (!editor.isPython()) {
            toast(Lang.s("纯文本模式没有语法检查"));
            return;
        }
        editor.ensureProblemCache();
        ArrayList<String> list = editor.problemLines();
        if (list.isEmpty()) {
            toast(Lang.s("没有发现语法问题"));
            return;
        }
        String[] arr = list.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(Lang.s("语法检查 (") + arr.length + ")")
                .setItems(arr, (dlg, which) -> {
                    int[] p = editor.problemAt(which);
                    if (p != null) {
                        editor.moveCursorTo(p[0], Math.max(0, p[1]));
                        editor.requestFocus();
                        editor.showIme();
                    }
                })
                .setNegativeButton(Lang.s("关闭"), null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- state
    @Override
    public void onEditorStateChanged() {
        updateTitle();
        updateStatus();
    }

    @Override
    public void onEditorTextChanged() {
        updateTitle();
    }

    @Override
    public void onRequestSave() {
        save();
    }

    private void updateTitle() {
        if (titleView == null) return;
        boolean dirty = editor != null && editor.isDirty();
        titleView.setText(currentName + (dirty ? " ●" : ""));
        updateButtons();
    }

    private void updateButtons() {
        if (undoBtn == null) return;
        undoBtn.setAlpha(0.9f);
        redoBtn.setAlpha(0.9f);
    }

    private void updateStatus() {
        if (statusView == null || editor == null) return;
        int line = Native.nativeCursorLine(editor.docHandle()) + 1;
        int col = Native.nativeCursorCol(editor.docHandle()) + 1;
        int len = Native.nativeLineCount(editor.docHandle());
        if (!editor.isPython()) {
            statusView.setText(Lang.s("行 ") + line + Lang.s(", 列 ") + col + "   ·   " + len + Lang.s(" 行   ·   纯文本 · UTF-8"));
            statusView.setTextColor(theme.statusText);
            return;
        }
        int probs = editor.problemCount();
        String pl = probs > 0 ? ("✖ " + probs + Lang.s(" 个问题")) : Lang.s("✓ 无问题");
        statusView.setText(Lang.s("行 ") + line + Lang.s(", 列 ") + col + "   ·   " + len + Lang.s(" 行   ·   ") + pl);
        statusView.setTextColor(probs > 0 ? 0xFFFF8A80 : theme.statusText);
        if (theme.statusBg == 0xFFF6F8FA || theme.statusBg == 0xFFEEE8D5) {
            statusView.setTextColor(probs > 0 ? 0xFFD73A49 : theme.statusText);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (loading) return;
        for (Pane p : panes) syncPane(p);
        if (Prefs.autoSave(this)) {
            boolean saved = false;
            for (int i = 0; i < tabs.size(); i++) {
                Tab t = tabs.get(i);
                if (t.uri == null || !t.dirty) continue;
                try {
                    writeText(t.uri, t.text == null ? "" : t.text);
                    t.dirty = false;
                    saved = true;
                } catch (Exception ignored) {
                }
            }
            if (saved) {
                for (Pane p : panes) {
                    if (p.tabIdx >= 0 && p.tabIdx < tabs.size()) {
                        Tab t = tabs.get(p.tabIdx);
                        if (t.uri != null) p.view.markClean();
                    }
                }
                updateTitle();
            }
        }
        if (currentUri != null) {
            prefs().edit().putString("last_uri", currentUri.toString()).apply();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        theme = Theme.load(this);
        applyTheme();
        for (Pane p : panes) p.view.setSyntaxCheckEnabled(Prefs.syntaxCheck(this));
        if (!Prefs.multiPane(this) && panes.size() > 1) collapsePanes();
        applyLanguage();
        updatePlusButton();
        updateStatusBarVisibility();
    }

    /** 把当前界面画成 PNG、base64 落到 App 目录，便于远程查看（长按标题栏触发）。 */
    private void captureUi() {
        try {
            View root = getWindow().getDecorView().getRootView();
            int w = root.getWidth(), h = root.getHeight();
            if (w <= 0 || h <= 0) {
                toast(Lang.s("界面还没绘制完"));
                return;
            }
            Bitmap full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            root.draw(new Canvas(full));
            int sw = Math.max(1, w / 2), sh = Math.max(1, h / 2);
            Bitmap half = Bitmap.createScaledBitmap(full, sw, sh, true);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            half.compress(Bitmap.CompressFormat.PNG, 100, bos);
            String b64 = android.util.Base64.encodeToString(
                    bos.toByteArray(), android.util.Base64.NO_WRAP);
            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            File out = new File(dir, "shot.b64");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(b64.getBytes("US-ASCII"));
            fos.close();
            full.recycle();
            half.recycle();
            toast(Lang.s("已导出截图 ") + (b64.length() / 1024) + " KB");
        } catch (Throwable t) {
            toast(Lang.s("截图失败: ") + t.getMessage());
        }
    }

    /** 同一时间只允许一个面板吞掉编辑区。 */
    private void onPanelFull(View panel, boolean full) {
        if (terminal != null && terminal != panel && terminal.isFull()) terminal.collapseFull();
        if (runPanel != null && runPanel != panel && runPanel.isFull()) runPanel.collapseFull();
        if (paneLayout == null) return;
        if (full) {
            paneLayout.setVisibility(View.GONE);
        } else if ((terminal == null || !terminal.isFull())
                && (runPanel == null || !runPanel.isFull())) {
            paneLayout.setVisibility(View.VISIBLE);
        }
    }

    /** 打开另一个面板前，把它从全屏状态挤下来并恢复编辑区。 */
    private void collapseOtherFull(View except) {
        if (terminal != null && terminal != except && terminal.isFull()) terminal.collapseFull();
        if (runPanel != null && runPanel != except && runPanel.isFull()) runPanel.collapseFull();
        if (paneLayout != null && (terminal == null || !terminal.isFull())
                && (runPanel == null || !runPanel.isFull())) {
            paneLayout.setVisibility(View.VISIBLE);
        }
    }

    private void runCurrent() {
        if (runPanel == null || editor == null) return;
        if (runPanel.isRunning()) {
            toast(Lang.s("正在运行，先点「停止」"));
            return;
        }
        collapseOtherFull(runPanel);
        String code = editor.getText();
        File dir = new File(getCacheDir(), "run");
        if (!dir.isDirectory() && !dir.mkdirs()) {
            toast(Lang.s("无法创建运行目录"));
            return;
        }
        File script = new File(dir, "main.py");
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream(script);
            fos.write(code.getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
            toast(Lang.s("写入脚本失败: ") + e.getMessage());
            return;
        }
        String cwd = runWorkingDir();
        String libDir = getApplicationInfo().nativeLibraryDir;
        String stdlib = ensureStdlib();
        if (stdlib == null) {
            toast(Lang.s("CPython 标准库解压失败"));
            return;
        }
        String[] cmd = new String[]{new File(libDir, "libcpython.so").getAbsolutePath(),
                "-S", "-u", script.getAbsolutePath()};
        java.util.Map<String, String> env = new java.util.HashMap<>();
        String sp = SitePkgs.pathEnv(this);
        env.put("PYTHONPATH", sp.isEmpty() ? stdlib : stdlib + ":" + sp);
        env.put("PYTHONHOME", new File(getFilesDir(), "python").getAbsolutePath());
        env.put("PYTHONIOENCODING", "utf-8");
        runPanel.run(cmd, env, cwd, currentName);
        if (runPanel.getVisibility() != View.VISIBLE) runPanel.setVisibility(View.VISIBLE);
    }

    /** 首次运行时把 assets/stdlib.tar.xz（LZMA2）解成真实目录，复用 CompilerStore 的 tar.xz 解压。 */
    private String ensureStdlib() {
        File home = new File(getFilesDir(), "python");
        File lib = new File(home, "lib/python3.12");
        File marker = new File(home, ".extracted");
        if (marker.isFile() && lib.isDirectory()) {
            return lib.getAbsolutePath();
        }
        try {
            deleteRec(home);
            File libParent = new File(home, "lib");
            if (!libParent.mkdirs()) return null;
            byte[] data = readAll(getAssets().open("stdlib.tar.xz"));
            CompilerStore.extract(data, "stdlib.tar.xz", libParent);
            if (!lib.isDirectory()) return null;
            FileOutputStream mark = new FileOutputStream(marker);
            mark.close();
            return lib.getAbsolutePath();
        } catch (Exception ex) {
            return null;
        }
    }

    private static byte[] readAll(java.io.InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }

    private String runWorkingDir() {
        String pref = Prefs.termDir(this);
        if (pref != null && !pref.trim().isEmpty()) {
            return pref.trim();
        }
        if (android.os.Build.VERSION.SDK_INT >= 30
                && android.os.Environment.isExternalStorageManager()) {
            return "/sdcard";
        }
        File f = getExternalFilesDir(null);
        if (f != null) {
            if (!f.isDirectory()) f.mkdirs();
            return f.getAbsolutePath();
        }
        return getFilesDir().getAbsolutePath();
    }

    private void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        int bgc = theme.bg;
        boolean lightBg = (0.299f * android.graphics.Color.red(bgc)
                + 0.587f * android.graphics.Color.green(bgc)
                + 0.114f * android.graphics.Color.blue(bgc)) > 140f;
        int bgc2 = lightBg ? 0xFFF4F5F7 : 0xFF1E1F22;
        drawerBgUsed = bgc2;
        drawer.setBackgroundColor(bgc2);
        drawer.setPadding((int) d(14), (int) d(28), (int) d(14), (int) d(14));

        // 整个抽屉放进一个 ScrollView：菜单项 + 文件列表都能滑，不再被屏幕高度卡住
        android.widget.ScrollView drawerScroll = new android.widget.ScrollView(this);
        drawerScroll.setFillViewport(true);
        drawerScroll.setVerticalScrollBarEnabled(true);
        LinearLayout drawerCol = new LinearLayout(this);
        drawerCol.setOrientation(LinearLayout.VERTICAL);
        drawerScroll.addView(drawerCol, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        drawer.addView(drawerScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView title = new TextView(this);
        title.setText("YHHYPy");
        title.setTextSize(17);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(theme.colors[Theme.TOK_KEYWORD]);
        title.setPadding(0, 0, 0, (int) d(10));
        drawerCol.addView(title);

        final LinearLayout fileGroup = new LinearLayout(this);
        fileGroup.setOrientation(LinearLayout.VERTICAL);
        fileGroup.setVisibility(View.GONE);
        fileGroup.addView(drawerRow(Lang.s("   新建文件"), () -> {
            closeDrawer();
            newDocument();
        }));
        fileGroup.addView(drawerRow(Lang.s("   打开文件…"), () -> {
            closeDrawer();
            openPicker();
        }));
        fileGroup.addView(drawerRow(Lang.s("   最近文件…"), () -> {
            closeDrawer();
            showRecents();
        }));
        final TextView fileHead = drawerRow(Lang.s("文件 \u25B8"), () -> {});
        fileHead.setOnClickListener(v -> {
            boolean show = fileGroup.getVisibility() != View.VISIBLE;
            fileGroup.setVisibility(show ? View.VISIBLE : View.GONE);
            fileHead.setText(show ? Lang.s("文件 \u25BE") : Lang.s("文件 \u25B8"));
        });
        drawerCol.addView(fileHead);
        drawerCol.addView(fileGroup);




        drawerCol.addView(drawerRow(Lang.s("查看语法问题"), () -> {
            closeDrawer();
            showProblems();
        }));
        drawerCol.addView(drawerRow(Lang.s("展开 / 折叠全部"), () -> {
            closeDrawer();
            editor.toggleFoldAll();
        }));
        final LinearLayout cmdGroup = new LinearLayout(this);
        cmdGroup.setOrientation(LinearLayout.VERTICAL);
        cmdGroup.setVisibility(View.GONE);
        cmdGroup.addView(drawerRow(Lang.s("   终端（Shell）"), () -> {
            closeDrawer();
            showTerminal();
        }));
        cmdGroup.addView(drawerRow(Lang.s("   解释器"), () -> {
            closeDrawer();
            runInterpreter();
        }));
        final TextView cmdHead = drawerRow(Lang.s("命令行 \u25B8"), () -> {});
        cmdHead.setOnClickListener(v -> {
            boolean show = cmdGroup.getVisibility() != View.VISIBLE;
            cmdGroup.setVisibility(show ? View.VISIBLE : View.GONE);
            cmdHead.setText(show ? Lang.s("命令行 \u25BE") : Lang.s("命令行 \u25B8"));
        });
        drawerCol.addView(cmdHead);
        drawerCol.addView(cmdGroup);
        drawerCol.addView(drawerRow(Lang.s("包管理 (pip)…"), () -> {
            closeDrawer();
            startActivity(new Intent(this, PipActivity.class));
        }));
        drawerCol.addView(drawerRow(Lang.s("设置…"), () -> {
            closeDrawer();
            startActivity(new Intent(this, SettingsActivity.class));
        }));

        TextView filesHead = new TextView(this);
        filesHead.setText(Lang.s("打开的文件"));
        filesHead.setTextSize(11);
        filesHead.setTextColor(theme.colors[Theme.TOK_BUILTIN]);
        filesHead.setPadding(0, (int) d(16), 0, (int) d(6));
        drawerCol.addView(filesHead);

        drawerFiles = new LinearLayout(this);
        drawerFiles.setOrientation(LinearLayout.VERTICAL);
        drawerCol.addView(drawerFiles);
    }

    private TextView drawerRow(String text, Runnable r) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(theme.colors[Theme.TOK_TEXT]);
        t.setPadding((int) d(8), (int) d(11), (int) d(8), (int) d(11));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void openDrawer() {
        refreshDrawerFiles();
        drawer.setVisibility(View.VISIBLE);
        drawerScrim.setVisibility(View.VISIBLE);
        drawerScrim.setAlpha(0f);
        drawer.setTranslationX(-drawer.getWidth() > 0 ? -drawer.getWidth() : -d(286));
        drawer.animate().translationX(0).setDuration(180).start();
        drawerScrim.animate().alpha(1f).setDuration(180).start();
        drawerOpen = true;
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawer.animate().translationX(-d(286)).setDuration(160)
                .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
        drawerScrim.animate().alpha(0f).setDuration(160)
                .withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
        drawerOpen = false;
    }

    private void refreshDrawerFiles() {
        if (drawerFiles == null) return;
        drawerFiles.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);
            TextView row = new TextView(this);
            String where = "";
            for (int k = 0; k < panes.size(); k++) {
                if (panes.get(k).tabIdx == i) {
                    where = "  [区 " + (k + 1) + "]";
                    break;
                }
            }
            row.setText((i == curTab ? "▸ " : "   ") + t.name + (t.dirty ? " ●" : "") + where);
            row.setTextSize(12.5f);
            row.setTextColor(i == curTab ? theme.colors[Theme.TOK_STRING]
                    : theme.colors[Theme.TOK_TEXT]);
            row.setPadding((int) d(8), (int) d(9), (int) d(8), (int) d(9));
            row.setOnClickListener(v -> {
                closeDrawer();
                requestReplace(idx);
            });
            row.setOnLongClickListener(v -> {
                closeTab(idx);
                return true;
            });
            drawerFiles.addView(row);
        }
        if (tabs.isEmpty()) {
            TextView e = new TextView(this);
            e.setText(Lang.s("（暂无）"));
            e.setTextSize(11.5f);
            e.setTextColor(theme.statusText);
            e.setPadding((int) d(8), (int) d(8), 0, 0);
            drawerFiles.addView(e);
        }
    }

    private void showTerminal() {
        if (terminal == null) return;
        if (!ShellBridge.granted() && ShellBridge.binderAlive()) ShellBridge.requestPermission();
        collapseOtherFull(terminal);
        terminal.open();
    }

    /** 解释器：把 re​pl 脚本写进缓存，用运行面板跑起来（stdin 已接上）。 */
    private void runInterpreter() {
        try {
            File dir = new File(getCacheDir(), "repl");
            dir.mkdirs();
            File f = new File(dir, "repl.py");
            String src =
                    "import sys\n" +
                    "try:\n" +
                    "    sys.stdout.reconfigure(line_buffering=True)\n" +
                    "except Exception:\n" +
                    "    pass\n" +
                    Lang.s("print('YHHYPy 解释器 · 输入 exit() 退出')\n") +
                    "g = {}\n" +
                    "while True:\n" +
                    "    try:\n" +
                    "        src = input('>>> ')\n" +
                    "    except EOFError:\n" +
                    "        break\n" +
                    "    if src.strip() in ('exit()', 'quit()'):\n" +
                    "        break\n" +
                    "    try:\n" +
                    "        exec(compile(src, '<stdin>', 'single'), g)\n" +
                    "    except SystemExit:\n" +
                    "        break\n" +
                    "    except Exception as e:\n" +
                    "        print(type(e).__name__ + ': ' + str(e))\n" +
                    "    sys.stdout.flush()\n";
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            out.write(src.getBytes("UTF-8"));
            out.close();
            String[] cmd = new String[]{interpBin(), "-S", "-u", f.getAbsolutePath()};
            collapseOtherFull(runPanel);
            runPanel.run(cmd, interpEnv(), runWorkingDir(), Lang.s("解释器"));
            runPanel.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            toast(Lang.s("解释器启动失败: ") + e.getMessage());
        }
    }

    private String interpBin() {
        String lib = getApplicationInfo().nativeLibraryDir;
        return new File(lib, "libcpython.so").getAbsolutePath();
    }

    private java.util.Map<String, String> interpEnv() {
        String stdlib = ensureStdlib();
        java.util.Map<String, String> env = new java.util.HashMap<>();
        String sp = SitePkgs.pathEnv(this);
        if (stdlib != null) env.put("PYTHONPATH", sp.isEmpty() ? stdlib : stdlib + ":" + sp);
        env.put("PYTHONHOME", new File(getFilesDir(), "python").getAbsolutePath());
        env.put("PYTHONIOENCODING", "utf-8");
        return env;
    }

    private void toggleTerminal() {
        if (terminal == null) return;
        if (terminal.isOpen()) {
            terminal.close();
            editor.requestFocus();
            return;
        }
        if (!ShellBridge.granted() && ShellBridge.binderAlive()) {
            ShellBridge.requestPermission();
        }
        collapseOtherFull(terminal);
        terminal.open();
    }

    /** 主题切换后重建抽屉（抽屉的底色/文字色在构建时写死）。 */
    private void refreshDrawerTheme() {
        if (drawer == null || shell == null || drawerLp == null) return;
        int bgc = theme.bg;
        boolean lightBg = (0.299f * android.graphics.Color.red(bgc)
                + 0.587f * android.graphics.Color.green(bgc)
                + 0.114f * android.graphics.Color.blue(bgc)) > 140f;
        int want = lightBg ? 0xFFF4F5F7 : 0xFF1E1F22;
        if (want == drawerBgUsed) return;
        boolean wasOpen = drawerOpen;
        shell.removeView(drawer);
        buildDrawer();
        shell.addView(drawer, drawerLp);
        drawer.setVisibility(wasOpen ? View.VISIBLE : View.GONE);
        drawerOpen = wasOpen;
    }

    private void applyTheme() {
        for (Pane p : panes) p.view.setTheme(theme, true);
        if (paneLayout != null) {
            paneLayout.setColors(theme.bg, theme.gutterText, theme.colors[Theme.TOK_KEYWORD], 0xFFFF6B6B);
        }
        if (terminal != null) terminal.applyTheme(theme);
        if (runPanel != null) runPanel.applyTheme(theme);
        if (findBar != null) findBar.applyTheme(theme);
        getWindow().setStatusBarColor(theme.statusBg);
        getWindow().setNavigationBarColor(theme.statusBg);
        topBar.setBackgroundColor(theme.statusBg);
        titleView.setTextColor(theme.statusBg == 0xFFFFFFFF ? 0xFF24292E : 0xFFE0E0E0);
        if (statusBar != null) statusBar.setBackgroundColor(theme.statusBg);
        statusView.setTextColor(theme.statusText);
        refreshDrawerTheme();
        updateStatus();
    }

    private boolean edgeDrawerDragging;
    private View backAnimView;
    private int backAnimKind;   // 1 查找栏 2 抽屉 3 终端 4 运行面板
    private boolean backAnimActive;

    /** 预测性返回开始时决定这一下会关闭哪一层，并用跟手动画。 */
    /** 左侧行首右滑：抽屉跟着手指走。 */
    private void edgeSwipeProgress(float progress) {
        if (drawer == null) return;
        if (!edgeDrawerDragging) {
            edgeDrawerDragging = true;
            refreshDrawerFiles();
            drawer.animate().cancel();
            drawer.setVisibility(View.VISIBLE);
            drawerScrim.setVisibility(View.VISIBLE);
            drawerScrim.setAlpha(0f);
            drawer.setTranslationX(-d(228));
        }
        int w = drawer.getWidth();
        if (w <= 0) w = (int) d(228);
        drawer.setTranslationX(-w * (1f - progress));
        drawerScrim.setAlpha(progress);
    }

    private void edgeSwipeEnd(boolean open) {
        if (!edgeDrawerDragging) {
            if (open) openDrawer();
            return;
        }
        edgeDrawerDragging = false;
        if (open) {
            drawer.animate().translationX(0f).setDuration(160).start();
            drawerScrim.animate().alpha(1f).setDuration(160).start();
            drawerOpen = true;
        } else {
            drawer.animate().translationX(-d(286)).setDuration(160)
                    .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
            drawerScrim.animate().alpha(0f).setDuration(160)
                    .withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
            drawerOpen = false;
        }
    }

    private void predictiveStart() {
        backAnimView = null;
        backAnimKind = 0;
        if (findBar != null && findBar.isOpen()) {
            backAnimKind = 1;
            backAnimView = findBar;
        } else if (drawerOpen) {
            backAnimKind = 2;
            backAnimView = drawer;
        } else if (terminal != null && terminal.isOpen()) {
            backAnimKind = 3;
            backAnimView = terminal;
        } else if (runPanel != null && runPanel.isOpen()) {
            backAnimKind = 4;
            backAnimView = runPanel;
        }
        if (backAnimView != null) backAnimView.animate().cancel();
        backAnimActive = backAnimView != null;
    }

    private void predictiveProgress(float progress) {
        if (!backAnimActive || backAnimView == null) return;
        float p = Math.max(0f, Math.min(1f, progress));
        if (backAnimKind == 2) {
            int w = drawer.getWidth();
            if (w <= 0) w = (int) d(228);
            drawer.setTranslationX(-w * p);
            drawerScrim.setAlpha(1f - p);
        } else {
            int h = backAnimView.getHeight();
            if (h <= 0) h = (int) d(160);
            backAnimView.setTranslationY(h * p);
            backAnimView.setAlpha(1f - p);
        }
    }

    private void predictiveCancel() {
        if (!backAnimActive || backAnimView == null) {
            backAnimActive = false;
            return;
        }
        if (backAnimKind == 2) {
            drawer.animate().translationX(0f).setDuration(140).start();
            drawerScrim.animate().alpha(1f).setDuration(140).start();
        } else {
            backAnimView.animate().translationY(0f).alpha(1f).setDuration(140).start();
        }
        backAnimActive = false;
    }

    private void predictiveInvoke() {
        int kind = backAnimKind;
        View v = backAnimView;
        boolean active = backAnimActive;
        backAnimActive = false;
        backAnimView = null;
        backAnimKind = 0;
        if (!active) {
            handleBack();
            return;
        }
        handleBack();
        if (kind == 2) {
            // 抽屉自己会滑出，等动画结束再复位，避免闪一下
            drawer.postDelayed(() -> {
                drawer.setTranslationX(0f);
                drawerScrim.setAlpha(1f);
            }, 220);
        } else if (v != null) {
            v.setTranslationY(0f);
            v.setAlpha(1f);
        }
    }

    /** 返回优先级：查找栏 → 抽屉 → 终端 → 运行/解释器 → 补全 → 退出确认。 */
    private void handleBack() {
        if (paneLayout != null && paneLayout.isSwapMode()) {
            paneLayout.setSwapMode(false);
            return;
        }
        if (panePick) {
            panePick = false;
            pendingReplaceTab = -1;
            if (paneLayout != null) paneLayout.setPickMode(false);
            return;
        }
        if (findBar != null && findBar.isOpen()) {
            findBar.close();
            return;
        }
        if (drawerOpen) {
            closeDrawer();
            return;
        }
        if (terminal != null && terminal.isOpen()) {
            terminal.close();
            if (editor != null) editor.requestFocus();
            return;
        }
        if (runPanel != null && runPanel.isOpen()) {
            runPanel.close();
            if (editor != null) editor.requestFocus();
            return;
        }
        if (editor != null && editor.completionVisible()) {
            editor.hideCompletion();
            return;
        }
        if (anyPaneDirty()) {
            new AlertDialog.Builder(this)
                    .setTitle(Lang.s("有未保存的修改"))
                    .setMessage(Lang.s("是否保存后再退出？"))
                    .setPositiveButton(Lang.s("保存"), (d, w) -> {
                        saveAllDirty();
                        if (focusedPane != null && focusedPane.view.isDirty()
                                && currentUri == null) {
                            saveAs();
                        } else {
                            finish();
                        }
                    })
                    .setNegativeButton(Lang.s("不保存"), (d, w) -> finish())
                    .setNeutralButton(Lang.s("取消"), null)
                    .show();
            return;
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onDestroy() {
        BackCompat.unregister(this, backToken);
        backToken = null;
        super.onDestroy();
    }
}
