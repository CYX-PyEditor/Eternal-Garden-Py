package com.yhhy.pyeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * 多编辑区容器（5.4.0）。
 *
 * <p>布局：1 个全屏；2 个左右；3 个左侧主区 + 右侧上下两格；4 个 2x2。
 * 分割线可以拖：把某个区挤到阈值以内松手，会回调 {@link Callback#onSqueeze(View)} 销毁它；
 * 长按任意分割线进入「换位模式」，把一个区拖到另一个区上松手即交换位置。
 * 另有「待替换模式」：所有区微亮，点哪个就把文件替换到哪个区。
 */
class PaneLayout extends ViewGroup {

    interface Callback {
        /** 分割线拖动松手时，这个区已经被挤到阈值以内，应当销毁。 */
        void onSqueeze(View paneView);

        /** 交换两个区的显示位置（View 实例原样换位）。 */
        void onSwap(View a, View b);

        /** 待替换模式：用户点了某个区。 */
        void onPick(View paneView);

        /** 进入 / 退出换位模式（用于收键盘、提示）。 */
        void onSwapModeChanged(boolean on);
    }

    private final ArrayList<View> panes = new ArrayList<>();
    private Callback cb;

    private final int gap;
    private final int minKeep;
    private final int squeezeAt;
    private final int slop;

    private final Paint bgPaint = new Paint();
    private final Paint dividerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tintPaint = new Paint();
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strongPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float splitX = 0.5f;
    private float splitY = 0.5f;

    private final Rect[] rects = new Rect[]{new Rect(), new Rect(), new Rect(), new Rect()};
    private int computedW, computedH;

    private int dragDivider;          // 0=none 1=竖 2=横
    private float downX, downY;
    private float startSplitX, startSplitY;
    private boolean longPressDone;
    private boolean dividerMoved;
    private View squeezeView;
    private boolean swapMode;
    private boolean pickMode;
    private View swapSel, swapHover;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable longPressRun = () -> {
        if (dragDivider == 0) return;
        longPressDone = true;
        dragDivider = 0;
        squeezeView = null;
        setSwapMode(true);
    };

    PaneLayout(Context c) {
        super(c);
        gap = dp(8);
        minKeep = dp(40);
        squeezeAt = dp(40);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        dividerPaint.setColor(0xFF3A3F4B);
        dividerPaint.setStrokeWidth(dp(2));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(2));
        strongPaint.setStyle(Paint.Style.STROKE);
        strongPaint.setStrokeWidth(dp(3));
        setWillNotDraw(false);
        setClipChildren(true);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    void setColors(int bg, int divider, int accent, int warn) {
        bgPaint.setColor(bg);
        dividerPaint.setColor(divider);
        borderPaint.setColor(accent);
        strongPaint.setColor(accent);
        tintPaint.setColor(accent);
        setBackgroundColor(bg);
    }

    void setCallback(Callback c) {
        cb = c;
    }

    void setPanes(List<View> views) {
        for (int i = getChildCount() - 1; i >= 0; i--) {
            View ch = getChildAt(i);
            boolean keep = false;
            for (View v : views) {
                if (v == ch) {
                    keep = true;
                    break;
                }
            }
            if (!keep) removeView(ch);
        }
        boolean countChanged = panes.size() != views.size();
        panes.clear();
        panes.addAll(views);
        if (countChanged) {
            splitX = 0.5f;
            splitY = 0.5f;
            squeezeView = null;
            swapSel = null;
            swapHover = null;
        }
        for (View v : views) {
            if (v.getParent() != this) addView(v);
        }
        requestLayout();
        invalidate();
    }

    List<View> panes() {
        return panes;
    }

    boolean isSwapMode() {
        return swapMode;
    }

    boolean isPickMode() {
        return pickMode;
    }

    void setSwapMode(boolean on) {
        if (swapMode == on) return;
        swapMode = on;
        swapSel = null;
        swapHover = null;
        dragDivider = 0;
        squeezeView = null;
        handler.removeCallbacks(longPressRun);
        if (on) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            if (cb != null) cb.onSwapModeChanged(true);
        } else {
            if (cb != null) cb.onSwapModeChanged(false);
        }
        invalidate();
    }

    void setPickMode(boolean on) {
        if (pickMode == on) return;
        pickMode = on;
        if (on) setSwapMode(false);
        invalidate();
    }

    // ------------------------------------------------------------ 布局
    /** 竖屏（高大于宽）时把布局转成上下式。 */
    private boolean portrait() {
        return getHeight() > getWidth();
    }

    private boolean hasDividerX() {
        int n = panes.size();
        if (n >= 4) return true;
        if (portrait()) return n == 3;   // 竖屏 3 格：下面一行左右分
        return n >= 2;                    // 横屏 2 格起：左右分
    }

    private boolean hasDividerY() {
        int n = panes.size();
        if (n >= 4) return true;
        if (portrait()) return n >= 2;   // 竖屏 2 格起：上下分
        return n == 3;                    // 横屏 3 格：右侧上下分
    }

    private void computeRects() {
        computeRects(getWidth(), getHeight());
    }

    private void computeRects(int w, int h) {
        int n = panes.size();
        if (n <= 0) return;
        int l = getPaddingLeft(), t = getPaddingTop();
        int r = w - getPaddingRight(), b = h - getPaddingBottom();
        int cw = Math.max(0, r - l), ch = Math.max(0, b - t);
        boolean p = h > w;
        if (n == 1) {
            rects[0].set(l, t, r, b);
        } else if (n == 2) {
            if (p) {
                int th = Math.round((ch - gap) * splitY);
                rects[0].set(l, t, r, t + th);
                rects[1].set(l, t + th + gap, r, b);
            } else {
                int lw = Math.round((cw - gap) * splitX);
                rects[0].set(l, t, l + lw, b);
                rects[1].set(l + lw + gap, t, r, b);
            }
        } else if (n == 3) {
            if (p) {
                int th = Math.round((ch - gap) * splitY);
                int bw = Math.round((cw - gap) * splitX);
                rects[0].set(l, t, r, t + th);
                rects[1].set(l, t + th + gap, l + bw, b);
                rects[2].set(l + bw + gap, t + th + gap, r, b);
            } else {
                int lw = Math.round((cw - gap) * splitX);
                int rh = Math.round((ch - gap) * splitY);
                rects[0].set(l, t, l + lw, b);
                rects[1].set(l + lw + gap, t, r, t + rh);
                rects[2].set(l + lw + gap, t + rh + gap, r, b);
            }
        } else {
            int lw = Math.round((cw - gap) * splitX);
            int th = Math.round((ch - gap) * splitY);
            rects[0].set(l, t, l + lw, t + th);
            rects[1].set(l + lw + gap, t, r, t + th);
            rects[2].set(l, t + th + gap, l + lw, b);
            rects[3].set(l + lw + gap, t + th + gap, r, b);
        }
        computedW = w;
        computedH = h;
    }

    private Rect dividerRectX() {
        if (!hasDividerX()) return null;
        int l = getPaddingLeft(), t = getPaddingTop();
        int cw = Math.max(0, getWidth() - getPaddingLeft() - getPaddingRight());
        int ch = Math.max(0, getHeight() - getPaddingTop() - getPaddingBottom());
        int x = l + Math.round((cw - gap) * splitX);
        if (portrait() && panes.size() == 3) {
            int th = Math.round((ch - gap) * splitY);
            return new Rect(x, t + th + gap, x + gap, getHeight() - getPaddingBottom());
        }
        return new Rect(x, t, x + gap, getHeight() - getPaddingBottom());
    }

    private Rect dividerRectY() {
        if (!hasDividerY()) return null;
        int l = getPaddingLeft(), t = getPaddingTop();
        int cw = Math.max(0, getWidth() - getPaddingLeft() - getPaddingRight());
        int ch = Math.max(0, getHeight() - getPaddingTop() - getPaddingBottom());
        int y = t + Math.round((ch - gap) * splitY);
        if (!portrait() && panes.size() == 3) {
            int lw = Math.round((cw - gap) * splitX);
            return new Rect(l + lw + gap, y, getWidth() - getPaddingRight(), y + gap);
        }
        return new Rect(l, y, getWidth() - getPaddingRight(), y + gap);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int h = MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(w, h);
        computeRects(w, h);
        int n = Math.min(panes.size(), rects.length);
        for (int i = 0; i < n; i++) {
            View v = panes.get(i);
            Rect r = rects[i];
            v.measure(MeasureSpec.makeMeasureSpec(Math.max(1, r.width()), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1, r.height()), MeasureSpec.EXACTLY));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        computeRects();
        int n = Math.min(panes.size(), rects.length);
        for (int i = 0; i < n; i++) {
            Rect rc = rects[i];
            panes.get(i).layout(rc.left, rc.top, rc.right, rc.bottom);
        }
    }

    // ------------------------------------------------------------ 绘制
    @Override
    protected void dispatchDraw(Canvas c) {
        if (getWidth() != computedW || getHeight() != computedH) computeRects();
        c.drawRect(0, 0, getWidth(), getHeight(), bgPaint);
        super.dispatchDraw(c);
        Rect dx = dividerRectX();
        if (dx != null) c.drawRect(dx.left + gap / 2f - dp(1), dx.top, dx.left + gap / 2f + dp(1),
                dx.bottom, dividerPaint);
        Rect dy = dividerRectY();
        if (dy != null) c.drawRect(dy.left, dy.top + gap / 2f - dp(1), dy.right,
                dy.top + gap / 2f + dp(1), dividerPaint);
        int n = Math.min(panes.size(), rects.length);
        if (pickMode) {
            tintPaint.setAlpha(38);
            for (int i = 0; i < n; i++) {
                c.drawRect(rects[i], tintPaint);
                c.drawRect(rects[i], borderPaint);
            }
        }
        if (squeezeView != null) {
            for (int i = 0; i < n; i++) {
                if (panes.get(i) != squeezeView) continue;
                tintPaint.setAlpha(70);
                c.drawRect(rects[i], tintPaint);
                strongPaint.setColor(0xFFFF6B6B);
                c.drawRect(rects[i], strongPaint);
                strongPaint.setColor(0xFFFF6B6B);
            }
        }
        if (swapMode) {
            for (int i = 0; i < n; i++) {
                View v = panes.get(i);
                if (v == swapSel) {
                    tintPaint.setAlpha(45);
                    c.drawRect(rects[i], tintPaint);
                    c.drawRect(rects[i], strongPaint);
                } else if (v == swapHover) {
                    tintPaint.setAlpha(28);
                    c.drawRect(rects[i], tintPaint);
                    c.drawRect(rects[i], borderPaint);
                }
            }
        }
    }

    // ------------------------------------------------------------ 触摸
    private View paneAt(float x, float y) {
        computeRects();
        int n = Math.min(panes.size(), rects.length);
        for (int i = 0; i < n; i++) {
            if (rects[i].contains((int) x, (int) y)) return panes.get(i);
        }
        return null;
    }

    private boolean onDivider(float x, float y) {
        Rect dx = dividerRectX();
        if (dx != null && x >= dx.left - dp(10) && x <= dx.right + dp(10)
                && y >= dx.top && y <= dx.bottom) return true;
        Rect dy = dividerRectY();
        return dy != null && y >= dy.top - dp(10) && y <= dy.bottom + dp(10)
                && x >= dy.left && x <= dy.right;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (pickMode || swapMode) return true;
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            return onDivider(e.getX(), e.getY());
        }
        return dragDivider != 0;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        float x = e.getX(), y = e.getY();
        if (pickMode) {
            if (action == MotionEvent.ACTION_UP) {
                View p = paneAt(x, y);
                if (p != null && cb != null) cb.onPick(p);
            }
            return true;
        }
        if (swapMode) {
            if (action == MotionEvent.ACTION_DOWN) {
                View p = paneAt(x, y);
                if (p == null) return true;
                downX = x;
                downY = y;
                if (swapSel == null) {
                    swapSel = p;
                } else if (swapSel == p) {
                    swapSel = null;
                } else {
                    swap(swapSel, p);
                }
                swapHover = p;
                invalidate();
                return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                View p = paneAt(x, y);
                if (p != swapHover) {
                    swapHover = p;
                    invalidate();
                }
                return true;
            }
            if (action == MotionEvent.ACTION_UP) {
                if (swapSel != null && swapHover != null && swapHover != swapSel) {
                    swap(swapSel, swapHover);
                } else if (swapSel != null && swapHover == swapSel
                        && Math.abs(x - downX) < slop && Math.abs(y - downY) < slop) {
                    // 单击选中，等下一次点另一个区
                }
                swapHover = null;
                invalidate();
                return true;
            }
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                if (!onDivider(x, y)) return false;
                downX = x;
                downY = y;
                startSplitX = splitX;
                startSplitY = splitY;
                longPressDone = false;
                dividerMoved = false;
                dragDivider = dividerHit(x, y);
                squeezeView = null;
                handler.removeCallbacks(longPressRun);
                handler.postDelayed(longPressRun, 380);
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (dragDivider == 0) return true;
                float dx = x - downX, dy = y - downY;
                if (!longPressDone && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                    handler.removeCallbacks(longPressRun);
                    dividerMoved = true;
                    if (dragDivider == 1) dragVertical(x);
                    else dragHorizontal(y);
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                handler.removeCallbacks(longPressRun);
                if (dragDivider != 0 && !longPressDone && dividerMoved) {
                    if (dragDivider == 1) dragVertical(x);
                    else dragHorizontal(y);
                }
                dragDivider = 0;
                if (squeezeView != null) {
                    View dead = squeezeView;
                    squeezeView = null;
                    if (cb != null) cb.onSqueeze(dead);
                }
                invalidate();
                return true;
            }
        }
        return true;
    }

    private int dividerHit(float x, float y) {
        Rect dx = dividerRectX();
        if (dx != null && x >= dx.left - dp(10) && x <= dx.right + dp(10)
                && y >= dx.top && y <= dx.bottom) return 1;
        Rect dy = dividerRectY();
        if (dy != null && y >= dy.top - dp(10) && y <= dy.bottom + dp(10)
                && x >= dy.left && x <= dy.right) return 2;
        return 0;
    }

    private void dragVertical(float x) {
        int l = getPaddingLeft();
        int cw = Math.max(1, getWidth() - getPaddingLeft() - getPaddingRight());
        float avail = Math.max(1, cw - gap);
        float f = (x - l) / avail;
        float hard = (float) dp(12) / avail;
        splitX = Math.max(hard, Math.min(1 - hard, f));
        if (panes.size() >= 2) {
            float thr = Math.max(squeezeAt, avail * 0.10f);
            float leftW = splitX * avail;
            float rightW = (1 - splitX) * avail;
            int li = 0, ri = 1;
            if (portrait() && panes.size() == 3) {
                li = 1;
                ri = 2;
            }
            if (leftW < thr) squeezeView = panes.get(li);
            else if (rightW < thr) squeezeView = panes.get(ri);
            else squeezeView = null;
        }
        requestLayout();
        invalidate();
    }

    private void dragHorizontal(float y) {
        int t = getPaddingTop();
        int ch = Math.max(1, getHeight() - getPaddingTop() - getPaddingBottom());
        float avail = Math.max(1, ch - gap);
        float f = (y - t) / avail;
        float hard = (float) dp(12) / avail;
        splitY = Math.max(hard, Math.min(1 - hard, f));
        if (panes.size() >= 2) {
            float thr = Math.max(squeezeAt, avail * 0.10f);
            float topH = splitY * avail;
            float botH = (1 - splitY) * avail;
            int ti = 0, bi = 1;
            if (!portrait() && panes.size() == 3) {
                ti = 1;
                bi = 2;
            } else if (panes.size() == 4) {
                ti = 0;
                bi = 2;
            }
            if (topH < thr) squeezeView = panes.get(ti);
            else if (botH < thr) squeezeView = panes.get(bi);
            else squeezeView = null;
        }
        requestLayout();
        invalidate();
    }

    private void swap(View a, View b) {
        if (a == null || b == null || a == b) return;
        int ia = panes.indexOf(a), ib = panes.indexOf(b);
        if (ia < 0 || ib < 0) return;
        panes.set(ia, b);
        panes.set(ib, a);
        swapSel = null;
        swapHover = null;
        setSwapMode(false);
        if (cb != null) cb.onSwap(a, b);
        requestLayout();
        invalidate();
    }
}
