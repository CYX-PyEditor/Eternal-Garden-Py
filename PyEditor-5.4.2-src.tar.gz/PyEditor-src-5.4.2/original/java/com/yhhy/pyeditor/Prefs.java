package com.yhhy.pyeditor;

import android.content.Context;
import android.content.SharedPreferences;

/** 非外观类设置：语法检查、自动保存、终端默认目录。 */
public final class Prefs {

    private static final String NAME = "pyedit";

    private Prefs() {
    }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static boolean syntaxCheck(Context c) {
        return p(c).getBoolean("syntax_check", true);
    }

    public static void setSyntaxCheck(Context c, boolean v) {
        p(c).edit().putBoolean("syntax_check", v).apply();
    }

    public static boolean autoSave(Context c) {
        return p(c).getBoolean("autosave", true);
    }

    public static void setAutoSave(Context c, boolean v) {
        p(c).edit().putBoolean("autosave", v).apply();
    }

    /** 用户自带的 C 编译器目录（可为空）。 */
    public static String ccDir(Context c) {
        return p(c).getString("cc_dir", "");
    }

    public static void setCcDir(Context c, String v) {
        p(c).edit().putString("cc_dir", v == null ? "" : v).apply();
    }

    public static int completeMax(Context c) {
        return Math.max(1, Math.min(20, p(c).getInt("complete_max", 5)));
    }

    public static void setCompleteMax(Context c, int v) {
        p(c).edit().putInt("complete_max", Math.max(1, Math.min(20, v))).apply();
    }

    /** 多编辑区开关（5.4.0）。 */
    public static boolean multiPane(Context c) {
        return p(c).getBoolean("multi_pane", false);
    }

    public static void setMultiPane(Context c, boolean v) {
        p(c).edit().putBoolean("multi_pane", v).apply();
    }

    public static String termDir(Context c) {
        return p(c).getString("term_dir", "");
    }

    public static void setTermDir(Context c, String v) {
        p(c).edit().putString("term_dir", v == null ? "" : v.trim()).apply();
    }
}
