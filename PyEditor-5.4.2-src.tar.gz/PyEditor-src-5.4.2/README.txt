YHHYPy 5.4.2 源码备份（2026-10-28，versionCode 71）
original/ 原始 Java + native + res + manifest + build.sh + tools + test + 文档
minified/ Java 压缩版（删注释/缩进/空行，单行），已 javac 验证；native 原样
不含 assets/libs/lib/build/dist/keystore。
重建：./build.sh（clang-19、SDK 35、JDK 17；aapt2 经 qemu 运行，带 --auto-add-overlay）
单测：javac -d /tmp/t java/com/yhhy/pyeditor/FoldScan.java \
        java/com/yhhy/pyeditor/SymbolStats.java test/ScanTest.java
      java -cp /tmp/t com.yhhy.pyeditor.ScanTest
界面文案：python3 tools/wrap_lang.py；python3 tools/gen_lang.py
5.4.2 改动：新增 Immersive.java（横屏隐藏状态栏 + 刘海安全区）；MainActivity /
SettingsActivity 在 onCreate 与 onConfigurationChanged 里应用
